using System;
using System.Collections;
using System.Data;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{
    public class Contacts
    {
        private string _Stfips = "49";
        private string _UIAccount;
        private string _Year;
        private string _Quarter;
        private string _ContactName;
        private string _OwnerContactTelephone;
        private string _OwnerOfficerSSN;
        private string _ContactTitle = " ";

        public string Stfips
        {
            get
            {
                return _Stfips;
            }
        }

        public string UIAccount
        {
            get
            {
                return _UIAccount.PadLeft(10, '0');
            }
            set
            {
                _UIAccount = value;
            }
        }

        public string Year
        {
            get
            {
                return _Year.Substring(0, 4);
            }
            set
            {
                _Year = value;
            }
        }

        public string Quarter
        {
            get
            {
                return _Quarter.Substring(4, 1);
            }
            set
            {
                _Quarter = value;
            }
        }

        public string ContactName
        {
            get
            {
                return _ContactName.PadRight(35, ' ');
            }
            set
            {
                if (value.Length > 35)
                    value = value.Substring(0, 35);
                _ContactName = value;
            }
        }

        public string OwnerContactTelephone
        {
            get
            {
                return _OwnerContactTelephone.PadRight(10, ' ');
            }
            set
            {
                _OwnerContactTelephone = value;
            }
        }

        public string OwnerOfficerSSN
        {
            get
            {
                return _OwnerOfficerSSN.PadRight(9, ' ');
            }
            set
            {
                if (value.Length != 9)
                    _OwnerOfficerSSN = " ";
                else
                    _OwnerOfficerSSN = value;
            }
        }

        public string ContactTitle
        {
            get
            {
                return _ContactTitle.PadRight(30, ' ');
            }
        }

    public static ArrayList GetContactRecordData(string Username, string Pwd, string Source, string TaxYear)
    {
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList ContactsCollection = new ArrayList();
        Contacts ContactData;

        string QueryString = String.Format("SELECT ev.Emprid, sv.YrQtr,OwnerNames.NAME,OwnerNames.TIN,TxPhone.phoneoremail" +
                                           " FROM CATS_OWNER.EMPLOYER ev" +
                                           " join CATS_OWNER.Qtr_Summary sv on sv.EMPRID = ev.EMPRID" +
                                           " left outer join CATS_OWNER.NAMES OwnerNames on OwnerNames.NAMES_ID = (Select Max(Names_ID) NAMES_ID from CATS_OWNER.NAMES Where EMPRID = ev.Emprid and NAME_TYPE_CD = 'OWN' and STATUS_CD = 'A')" +
                                           " left outer join CATS_OWNER.NAMES TxNames on TxNames.NAMES_ID = (Select Max(Names_ID) NAMES_ID from CATS_OWNER.NAMES Where EMPRID = ev.Emprid and Contact_Type_cd = 'TX' and STATUS_CD = 'A')" +
                                           " left outer join CATS_OWNER.PHONE TxPhone on TxPhone.phone_ID = (Select Max(Phone_ID) from CATS_OWNER.Phone where NAMES_ID = TxNames.NAMES_ID and Phone_Type = 'VOICE' and Status_CD in('A', 'P'))" +
                                           " WHERE sv.YrQtr = '{0}'", TaxYear);
        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {
            while (OracleDR.Read())
            {
              ContactData = new Contacts();
              ContactData.UIAccount = OracleDR[0] == System.DBNull.Value ? string.Empty : OracleDR.GetString(0);
              ContactData.Year = OracleDR[1] == System.DBNull.Value ? string.Empty : OracleDR.GetString(1);
              ContactData.Quarter = OracleDR[1] == System.DBNull.Value ? string.Empty : OracleDR.GetString(1);
              ContactData.ContactName = OracleDR[2] == System.DBNull.Value ? string.Empty : OracleDR.GetString(2);
              ContactData.OwnerOfficerSSN = OracleDR[3] == System.DBNull.Value ? string.Empty : OracleDR.GetString(3);
              ContactData.OwnerContactTelephone = OracleDR[4] == System.DBNull.Value ? string.Empty : OracleDR.GetString(4);
              if (ContactData.OwnerContactTelephone.Length > 10)
                ContactData.OwnerContactTelephone = ContactData.OwnerContactTelephone.Substring(0, 10);
              ContactsCollection.Add(ContactData);
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
        }
        return ContactsCollection;
      }
    }
  }    
}
