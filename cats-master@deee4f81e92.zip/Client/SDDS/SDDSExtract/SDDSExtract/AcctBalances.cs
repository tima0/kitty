using System;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Data;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{
  public class AcctBalances
  {
    private string _Stfips = "49";
    private string _UIaccount;
    private string _Year;
    private string _Periodtype = "01";
    private string _Period = "00";
    private string _AccountBalance = "0000000000.00";
    private string _ExperienceRating;
    private string _BenefitRatio;


    public string Stfips
    {
      get
      {
        return _Stfips.PadRight(2, ' ');
      }
    }

    public string UIaccount
    {
      get
      {
        return _UIaccount.PadLeft(10, '0');
      }
      set
      {
        _UIaccount = value;
      }
    }

    public string Year
    {
      get
      {
        return _Year.Substring(0, 4);
      }
      set
      {
        _Year = value;
      }
    }

    public string Periodtype
    {
      get
      {
        return _Periodtype.PadLeft(2, '0');
      }
      set
      {
        _Periodtype = value;
      }
    }

    public string Period
    {
      get
      {
        return _Period;
      }
      set
      {
        _Period = value;
      }
    }

    public string AccountBalance
    {
      get
      {
        return _AccountBalance.PadLeft(13, '0');
      }
      set
      {
        _AccountBalance = value;
      }
    }

    public string ExperienceRating
    {
      get
      {
        return _ExperienceRating.PadLeft(7, '0');
      }
      set
      {
        if (value == string.Empty)
          _ExperienceRating = "000.000";
        else if (value.Length < 5)
          _ExperienceRating = "00" + value + "0";
        else
          _ExperienceRating = System.Convert.ToDouble(value).ToString();
      }
    }

    public string BenefitRatio
    {
      get
      {
        return _BenefitRatio.PadLeft(5, '0');
      }
      set
      {
        _BenefitRatio = value;
      }
    }

    public static ArrayList GetAcctRecordData(string Username, string Pwd, string Source, string TaxYear)
    {
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList AcctCollection = new ArrayList();
        AcctBalances AcctBalances;

        string QueryString = String.Format("SELECT Emprid, YRQtr, " +
                                           "Rate FROM CATS_OWNER.Qtr_Summary " +
                                           "WHERE YRQtr = '{0}'", TaxYear);

        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {
            while (OracleDR.Read())
            {
              AcctBalances = new AcctBalances();
              AcctBalances.UIaccount = OracleDR[0] == System.DBNull.Value ? String.Empty : OracleDR.GetString(0);
              AcctBalances.Year = OracleDR[1] == System.DBNull.Value ? String.Empty : OracleDR.GetString(1);
              AcctBalances.ExperienceRating = OracleDR[2] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(2).ToString();
              AcctCollection.Add(AcctBalances);
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
        }
        return AcctCollection;
      }
    }
  }
}
