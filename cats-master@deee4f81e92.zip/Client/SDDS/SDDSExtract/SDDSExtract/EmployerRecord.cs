using System;
using System.Collections;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{

  public class EmployerRecord
  {
    private string _Stfips = "49";
    private string _UIAccount;
    private string _EIN;
    private string _Year;
    private string _Quarter;
    private string _Name1;
    private string _Name2;
    private string _UIAddress1;
    private string _UIAddress2;
    private string _UICity;
    private string _UIState;
    private string _UIZip5;
    private string _UIZip4;
    private string _PhysicalAddress1;
    private string _PhysicalAddress2;
    private string _PhysicalCity;
    private string _PhysicalState;
    private string _PhysicalZip5;
    private string _PhysicalZip4;
    private string _Telephone;
    private string _Ownership;
    private string _SICcode;
    private string _NAICScode;

    public string Stfips
    {
      get
      {
        return _Stfips;
      }
    }

    public string UIAccount
    {
      get
      {
        return _UIAccount.PadLeft(10, '0');
      }
      set
      {
        _UIAccount = value;
      }
    }

    public string EIN
    {
      get
      {
        return _EIN.PadLeft(9, '0');
      }
      set
      {
        _EIN = value.Trim();
      }
    }

    public string Year
    {
      get
      {
        return _Year.Substring(0, 4);
      }
      set
      {
        _Year = value;
      }
    }

    public string Quarter
    {
      get
      {
        return _Quarter.Substring(4, 1);
      }
      set
      {
        _Quarter = value;
      }
    }

    public string Name1
    {
      get
      {
        return _Name1.PadRight(35, ' ');
      }
      set
      {
        if (value.Length > 35)
          value = value.Substring(0, 35);
        _Name1 = value;
      }
    }

    public string Name2
    {
      get
      {
        return _Name2.PadRight(35, ' ');
      }
      set
      {
        if (value.Length > 35)
          value = value.Substring(0, 35);
        _Name2 = value;
      }
    }

    public string UIAddress1
    {
      get
      {
        return _UIAddress1.PadRight(35, ' ');
      }
      set
      {
        if (value.Length > 35)
          value = value.Substring(0, 35);
        _UIAddress1 = value;
      }
    }

    public string UIAddress2
    {
      get
      {
        return _UIAddress2.PadRight(35, ' ');
      }
      set
      {
        if (value.Length > 35)
          value = value.Substring(0, 35);
        _UIAddress2 = value;
      }
    }

    public string UICity
    {
      get
      {
        return _UICity.PadRight(30, ' ');
      }
      set
      {
        _UICity = value;
      }
    }

    public string UIState
    {
      get
      {
        return _UIState.PadRight(2, ' ');
      }
      set
      {
        if (value.Length != 0)
          _UIState = GetStateFips(value);
        else
          _UIState = string.Empty;
      }
    }

    public string UIZip5
    {
      get
      {
        return _UIZip5.PadRight(5, '0');
      }
      set
      {
        if (value.Length > 5)
          value = value.Substring(0, 5);
        _UIZip5 = value;
      }
    }

    public string UIZip4
    {
      get
      {
        return _UIZip4.PadRight(4, '0');
      }
      set
      {
        if (value.Length == 9)
          value = value.Substring(4, 4);
        else
          value = string.Empty;
        _UIZip4 = value;
      }
    }

    public string PhysicalAddress1
    {
      get
      {
        return _PhysicalAddress1.PadRight(35, ' ');
      }
      set
      {
        if (value.Length > 35)
          value = value.Substring(0, 35);
        _PhysicalAddress1 = value;
      }
    }

    public string PhysicalAddress2
    {
      get
      {
        return _PhysicalAddress2.PadRight(35, ' ');
      }
      set
      {
        if (value.Length > 35)
          value = value.Substring(0, 35);
        _PhysicalAddress2 = value;
      }
    }

    public string PhysicalCity
    {
      get
      {
        return _PhysicalCity.PadRight(30, ' ');
      }
      set
      {
        _PhysicalCity = value;
      }
    }

    public string PhysicalState
    {
      get
      {
        return _PhysicalState.PadRight(2, ' ');
      }
      set
      {
        if (value.Length > 0)
          _PhysicalState = GetStateFips(value);
        else
          _PhysicalState = string.Empty;
      }
    }

    public string PhysicalZip5
    {
      get
      {
        return _PhysicalZip5.PadRight(5, ' ');
      }
      set
      {
        if (value.Length > 5)
          value = value.Substring(0, 5);
        _PhysicalZip5 = value;
      }
    }

    public string PhysicalZip4
    {
      get
      {
        return _PhysicalZip4.PadRight(4, ' ');
      }
      set
      {
        if (value.Length == 9)
          value = value.Substring(4, 4);
        else
          value = string.Empty;
        _PhysicalZip4 = value;
      }
    }

    public string Telephone
    {
      get
      {
        return _Telephone.PadRight(10, ' ');
      }
      set
      {
        _Telephone = value;
      }
    }

    public string Ownership
    {
      get
      {
        return _Ownership.PadRight(2, ' ');
      }
      set
      {
        _Ownership = value;
      }
    }

    public string SICcode
    {
      get
      {
        return _SICcode.PadRight(4, ' ');
      }
      set
      {
        _SICcode = value;
      }
    }

    public string NAICScode
    {
      get
      {
        return _NAICScode.PadRight(6, ' ');
      }
      set
      {
        _NAICScode = value;
      }
    }

    public static ArrayList GetEmprRecordData(string Username, string Pwd, string Source, string TaxYear)
    {
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList EmprCollection = new ArrayList();
        EmployerRecord EmployerRec;

        string QueryString = String.Format("SELECT ev.Emprid, ev.Federal_id, sv.YrQtr, ev.Ownership_Cd, ev.SIC, ev.NAICS, OwnerNames.NAME Name1, DBANames.NAME Name2, TaxAddress.ADDRESS1 TaxAddress1," +
                                           " TaxAddress.ADDRESS2 TaxAddress2, TaxAddress.city TaxCity, TaxAddress.STATE TaxState, TaxAddress.ZIP TaxZip," +
                                           " WorkAddress.ADDRESS1 WorkAddress1, WorkAddress.ADDRESS2 WorkAddress2, WorkAddress.City WorkCity, WorkAddress.State WorkState, WorkAddress.Zip WorkZip, OwnerPhone.PhoneOrEmail" +
                                           " FROM CATS_OWNER.EMPLOYER ev" +
                                           " join CATS_OWNER.QTR_SUMMARY sv on sv.EMPRID = ev.EMPRID" +
                                           " left outer join CATS_OWNER.NAMES OwnerNames on OwnerNames.NAMES_ID = (Select Max(Names_ID) NAMES_ID from CATS_OWNER.NAMES Where EMPRID = ev.Emprid and NAME_TYPE_CD = 'OWN' and STATUS_CD = 'A')" +
                                           " left outer join CATS_OWNER.NAMES DBANames on DBANames.NAMES_ID = (Select Max(Names_ID) NAMES_ID from CATS_OWNER.NAMES Where EMPRID = ev.Emprid and NAME_TYPE_CD = 'DBA' and STATUS_CD = 'A')" +
                                           " left outer join CATS_OWNER.ADDRESS TaxAddress on TaxAddress.ADDRESS_ID = (Select Max(ADDRESS_ID) from CATS_OWNER.ADDRESS Where EMPRID = ev.Emprid and Contact_Type_cd = 'TX' and STATUS_CD = 'P')" +
                                           " left outer join CATS_OWNER.ADDRESS WorkAddress on WorkAddress.ADDRESS_ID = (Select Max(ADDRESS_ID) from CATS_OWNER.ADDRESS Where EMPRID = ev.Emprid and Contact_Type_cd = 'WS' and STATUS_CD = 'P')" +
                                           " left outer join CATS_OWNER.PHONE OwnerPhone on OwnerPhone.phone_ID = (Select Max(Phone_ID) from CATS_OWNER.Phone where NAMES_ID = OwnerNames.NAMES_ID and Status_CD in('A', 'P')) " +
                                           " WHERE sv.YrQtr = '{0}'", TaxYear);
        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {
            while (OracleDR.Read())
            {
              EmployerRec = new EmployerRecord();
              EmployerRec.UIAccount = OracleDR[0] == System.DBNull.Value ? string.Empty : OracleDR.GetString(0);
              EmployerRec.EIN = OracleDR[1] == System.DBNull.Value ? string.Empty : OracleDR.GetString(1);
              EmployerRec.Year = OracleDR[2] == System.DBNull.Value ? string.Empty : OracleDR.GetString(2);
              EmployerRec.Quarter = OracleDR[2] == System.DBNull.Value ? string.Empty : OracleDR.GetString(2);
              EmployerRec.Ownership = OracleDR[3] == System.DBNull.Value ? string.Empty : OracleDR.GetString(3);
              EmployerRec.SICcode = OracleDR[4] == System.DBNull.Value ? string.Empty : OracleDR.GetString(4);
              EmployerRec.NAICScode = OracleDR[5] == System.DBNull.Value ? string.Empty : OracleDR.GetString(5);
              EmployerRec.Name1 = OracleDR[6] == System.DBNull.Value ? string.Empty : OracleDR.GetString(6);
              EmployerRec.Name2 = OracleDR[7] == System.DBNull.Value ? string.Empty : OracleDR.GetString(7);
              EmployerRec.UIAddress1 = OracleDR[8] == System.DBNull.Value ? string.Empty : OracleDR.GetString(8);
              EmployerRec.UIAddress2 = OracleDR[9] == System.DBNull.Value ? string.Empty : OracleDR.GetString(9);
              EmployerRec.UICity = OracleDR[10] == System.DBNull.Value ? string.Empty : OracleDR.GetString(10);
              EmployerRec.UIState = OracleDR[11] == System.DBNull.Value ? string.Empty : OracleDR.GetString(11);
              EmployerRec.UIZip4 = OracleDR[12] == System.DBNull.Value ? string.Empty : OracleDR.GetString(12);
              EmployerRec.UIZip5 = OracleDR[12] == System.DBNull.Value ? string.Empty : OracleDR.GetString(12);
              EmployerRec.PhysicalAddress1 = OracleDR[13] == System.DBNull.Value ? string.Empty : OracleDR.GetString(13);
              EmployerRec.PhysicalAddress2 = OracleDR[14] == System.DBNull.Value ? string.Empty : OracleDR.GetString(14);
              EmployerRec.PhysicalCity = OracleDR[15] == System.DBNull.Value ? string.Empty : OracleDR.GetString(15);
              EmployerRec.PhysicalState = OracleDR[16] == System.DBNull.Value ? string.Empty : OracleDR.GetString(16);
              EmployerRec.PhysicalZip4 = OracleDR[17] == System.DBNull.Value ? string.Empty : OracleDR.GetString(17);
              EmployerRec.PhysicalZip5 = OracleDR[17] == System.DBNull.Value ? string.Empty : OracleDR.GetString(17);
              EmployerRec.Telephone = OracleDR[18] == System.DBNull.Value ? string.Empty : OracleDR.GetString(18);
              EmprCollection.Add(EmployerRec);
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
        }
        return EmprCollection;
      }
    }

    private string GetStateFips(string ST)
    {
      switch (ST)
      {
        case "AL":
          {
            return "01";
          }

        case "AK":
          {
            return "02";
          }

        case "AZ":
          {
            return "04";
          }

        case "AR":
          {
            return "05";
          }

        case "CA":
          {
            return "06";
          }

        case "CO":
          {
            return "08";
          }

        case "CT":
          {
            return "09";
          }

        case "DE":
          {
            return "10";
          }

        case "DC":
          {
            return "11";
          }

        case "FL":
          {
            return "12";
          }

        case "GA":
          {
            return "13";
          }

        case "HI":
          {
            return "15";
          }

        case "ID":
          {
            return "16";
          }

        case "IL":
          {
            return "17";
          }

        case "IN":
          {
            return "18";
          }

        case "IA":
          {
            return "19";
          }

        case "KS":
          {
            return "20";
          }

        case "KY":
          {
            return "21";
          }

        case "LA":
          {
            return "22";
          }

        case "ME":
          {
            return "23";
          }

        case "MD":
          {
            return "24";
          }

        case "MA":
          {
            return "25";
          }

        case "MI":
          {
            return "26";
          }

        case "MN":
          {
            return "27";
          }

        case "MS":
          {
            return "28";
          }

        case "MO":
          {
            return "29";
          }

        case "MT":
          {
            return "30";
          }

        case "NE":
          {
            return "31";
          }

        case "NV":
          {
            return "32";
          }

        case "NH":
          {
            return "33";
          }

        case "NJ":
          {
            return "34";
          }

        case "NM":
          {
            return "35";
          }

        case "NY":
          {
            return "36";
          }

        case "NC":
          {
            return "37";
          }

        case "ND":
          {
            return "38";
          }

        case "OH":
          {
            return "39";
          }

        case "OK":
          {
            return "40";
          }

        case "OR":
          {
            return "41";
          }

        case "PA":
          {
            return "42";
          }

        case "PR":
          {
            return "72";
          }

        case "RI":
          {
            return "44";
          }

        case "SC":
          {
            return "45";
          }

        case "SD":
          {
            return "46";
          }

        case "TN":
          {
            return "47";
          }

        case "TX":
          {
            return "48";
          }

        case "UT":
          {
            return "49";
          }

        case "VT":
          {
            return "50";
          }

        case "VA":
          {
            return "51";
          }

        case "VI":
          {
            return "78";
          }

        case "WA":
          {
            return "53";
          }

        case "WV":
          {
            return "54";
          }

        case "WI":
          {
            return "55";
          }

        case "WY":
          {
            return "56";
          }

        default:
          {
            return " ";
          }
      }
    }

    
    

    



  }
}
