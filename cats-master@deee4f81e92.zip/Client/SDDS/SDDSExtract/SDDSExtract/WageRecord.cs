using System;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Data;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{
  public class WageRecord
  {
    private string _SSN;
    private string _Namefirst;
    private string _Namemiddle;
    private string _Namelast;
    private string _State = "49";
    private string _UIAccount;
    private string _Seinunit;
    private string _EIN;
    private string _Year;
    private string _Quarter;
    private string _Wage;

    private string StripNulls(string StringCheck)
    {
      if (StringCheck == "")
        return string.Empty;
      else
        return StringCheck.ToString();
    }

    public string SSN
    {
      get
      {
        return _SSN.PadRight(9, ' ');
      }
      set
      {
        _SSN = value;
      }
    }

    public string Namefirst
    {
      get
      {
        return _Namefirst.PadRight(15, ' ');
      }
      set
      {
        _Namefirst = value;
      }
    }

    public string Namemiddle
    {
      get
      {
        return _Namemiddle.PadRight(1, ' ');
      }
      set
      {
        _Namemiddle = value;
      }
    }

    public string Namelast
    {
      get
      {
        return _Namelast.PadRight(20, ' ');
      }
      set
      {
        if (value.Length > 20)
          value = value.Substring(0, 20);
        _Namelast = value;
      }
    }

    public string State
    {
      get
      {
        return _State;
      }
    }

    public string UIAccount
    {
      get
      {
        return _UIAccount.PadLeft(10, '0');
      }
      set
      {
        _UIAccount = value;
      }
    }

    public string Seinunit
    {
      get
      {
        return _Seinunit.PadLeft(5, '0');
      }
      set
      {
        _Seinunit = value;
      }
    }

    public string EIN
    {
      get
      {
        return _EIN.PadLeft(9, '0');
      }
      set
      {
        _EIN = value;
      }
    }

    public string Year
    {
      get
      {
        return _Year.Substring(0, 4);
      }
      set
      {
        _Year = value;
      }
    }

    public string Quarter
    {
      get
      {
        return _Quarter.Substring(4, 1);
      }
      set
      {
        _Quarter = value;
      }
    }

    public string Wage
    {
      get
      {
        return _Wage.PadLeft(10, '0');
      }
      set
      {
        _Wage = value;
      }
    }

    public static ArrayList GetWageRecordData(string Username, string Pwd, string Source, string TaxYear)
    {
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList WageCollection = new ArrayList();
        WageRecord WageRecord;

        string QueryString = String.Format(String.Format("SELECT wv.SSN, wv.FirstName, wv.MiddleInitial, wv.LastName, wv.EMPRID, ev.ES_Worksite_num, ev.Federal_ID, wv.YRQTR, wv.WAGES"
                                                + " FROM CATS_OWNER.WAGE_DATA wv, CATS_OWNER.EMPLOYER ev"
                                                + " WHERE wv.YRQTR = '{0}'"
                                                + " And wv.SSN Is Not Null"
                                                + " And wv.SSN <> ' '"
                                                + " And wv.EMPRID = ev.EMPRID", TaxYear));

        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {            
            while (OracleDR.Read())
            {
              WageRecord = new WageRecord();
              WageRecord.SSN = OracleDR[0] == System.DBNull.Value ? String.Empty: OracleDR.GetString(0);
              WageRecord.Namefirst = OracleDR[1] == System.DBNull.Value ? String.Empty : OracleDR.GetString(1);
              WageRecord.Namemiddle = OracleDR[2] == System.DBNull.Value ? String.Empty : OracleDR.GetString(2);
              WageRecord.Namelast = OracleDR[3] == System.DBNull.Value ? String.Empty : OracleDR.GetString(3);
              WageRecord.UIAccount = OracleDR[4] == System.DBNull.Value ? String.Empty : OracleDR.GetString(4);
              WageRecord.Seinunit = OracleDR[5] == System.DBNull.Value ? String.Empty : OracleDR.GetString(5);
              WageRecord.EIN = OracleDR[6] == System.DBNull.Value ? String.Empty : OracleDR.GetString(6);
              WageRecord.Year = OracleDR[7] == System.DBNull.Value ? String.Empty : OracleDR.GetString(7);
              WageRecord.Quarter = OracleDR[8] == System.DBNull.Value ? String.Empty : OracleDR.GetString(7);
              WageRecord.Wage = OracleDR[8] == System.DBNull.Value ? String.Empty : OracleDR.GetInt64(8).ToString();
              WageCollection.Add(WageRecord);
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
          return WageCollection;
        }
      }
    }
  }  
}
