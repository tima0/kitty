using System;
using System.Collections;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{
  public class Demographics
  {
    private string _DataSourceType = "UI ";
    private string _DataSource = "UUU";
    private string _DataSourceDate;
    private string _StatusFlag = "C";
    private string _SourceStfips = "49";
    private string _Year;
    private static string _Quarter;
    private string _SSN;
    private string _AlternateID;
    private string _FullName;
    private string _LastName;
    private string _FirstName;
    private string _MiddleName = " ";
    private string _Title = " ";
    private string _Suffix = " ";
    private string _Gender;
    private string _Race;
    private string _Ethnicity;
    private string _DOB;
    private string _Citizen;
    private string _Address1;
    private string _Address2;
    private string _Address3 = " ";
    private string _City;
    private string _State;
    private string _Zip5;
    private string _Zip4;
    private string _Stfips;

    public string DataSourceType
    {
      get
      {
        return _DataSourceType.PadRight(3, ' ');
      }
      set
      {
        _DataSourceType = value;
      }
    }

    public string DataSource
    {
      get
      {
        return _DataSource;
      }
      set
      {
        _DataSource = value;
      }
    }
        
      public string DataSourceDate
    {
      get
      {
        return _DataSourceDate.PadRight(10, ' ');
      }
      set
      {
        if (value != string.Empty)
          _DataSourceDate = System.Convert.ToDateTime(value).Month.ToString().PadLeft(2, '0') + "/" + System.Convert.ToDateTime(value).Day.ToString().PadLeft(2, '0') + "/" + System.Convert.ToDateTime(value).Year.ToString().PadLeft(4, '0');
        else
          _DataSourceDate = string.Empty;
      }
    }
  

    public string StatusFlag
    {
      get
      {
        return _StatusFlag;
      }
      set
      {
        _StatusFlag = value;
      }
    }

    public string SourceStfips
    {
      get
      {
        return _SourceStfips.PadRight(2, ' ');
      }
      set
      {
        _SourceStfips = value;
      }
    }

    public string Year
    {
      get
      {
        return _Year.PadLeft(4, '0');
      }
      set
      {
        _Year = System.Convert.ToDateTime(value).Year.ToString();
      }
    }

    public string Quarter
    {
      get
      {
        return _Quarter.PadRight(1, '0');
      }
      set
      {
        _Quarter = QuarterDateUtils.GetQuarter(System.Convert.ToDateTime(value).Month.ToString());
      }
    }

    public string SSN
    {
      get
      {
        return _SSN.PadRight(9, ' ');
      }
      set
      {
        _SSN = value;
      }
    }

    public string AlternateID
    {
      get
      {
        if (_AlternateID.Length < 10)
          return _AlternateID.Trim().PadRight(10, ' ');
        else
          return _AlternateID.Substring(0, 10).Trim().PadRight(10, ' ');
      }
      set
      {
        _AlternateID = value;
      }
    }

    public string FullName
    {
      get
      {        
        return _FullName.Trim().PadRight(110, ' ');
      }
      set
      {
        _FullName = value;
      }
    }

    public string LastName
    {
      get
      {
        return _LastName.PadRight(30, ' ');
      }
      set
      {
        _LastName = value;
      }
    }

    public string FirstName
    {
      get
      {
        return _FirstName.PadRight(30, ' ');
      }
      set
      {
        _FirstName = value;
      }
    }

    public string MiddleName
    {
      get
      {
        return _MiddleName.PadRight(30, ' ');
      }
      set
      {
        _MiddleName = value;
      }
    }

    public string Title
    {
      get
      {
        return _Title.PadRight(4, ' ');
      }
      set
      {
        _Title = value;
      }
    }

    public string Suffix
    {
      get
      {
        return _Suffix.PadRight(4, ' ');
      }
      set
      {
        _Suffix = value;
      }
    }

    public string Gender
    {
      get
      {
        return _Gender;
      }
      set
      {
        if (value == " " | value == "-")
          _Gender = "U";
        else
          _Gender = value;
      }
    }

    public string Race
    {
      get
      {
        return _Race;
      }
      set
      {
        if (value == "W")
          _Race = "1";
        else if (value == "B")
          _Race = "2";
        else if (value == "A")
          _Race = "3";
        else if (value == "N")
          _Race = "4";
        else if (value == "P")
          _Race = "5";
        else if (value == "M")
          _Race = "6";
        else
          _Race = "9";
      }
    }

    public string Ethnicity
    {
      get
      {
        return _Ethnicity;
      }
      set
      {
        if (value == "N" | value == "-")
          _Ethnicity = "0";
        else if (value == "H")
          _Ethnicity = "1";
        else
          _Ethnicity = "9";
      }
    }

    public string DOB
    {
      get
      {
        return _DOB.PadLeft(10, ' ');
      }
      set
      {
        if (value != string.Empty)
          _DOB = System.Convert.ToDateTime(value).Month.ToString().PadLeft(2, '0') + "/" + System.Convert.ToDateTime(value).Day.ToString().PadLeft(2, '0') + "/" +
            System.Convert.ToDateTime(value).Year.ToString().PadLeft(4, '0');
      }
    }
    

    public string Citizen
    {
      get
      {
        return _Citizen;
      }
      set
      {
        if (value == "Y")
          _Citizen = "C";
        else if (value == "N")
          _Citizen = "N";
        else
          _Citizen = "U";
      }
    }

    public string Address1
    {
      get
      {
        return _Address1.Trim().PadRight(35, ' ');
      }
      set
      {
        _Address1 = value;
      }
    }

    public string Address2
    {
      get
      {
        return _Address2.Trim().PadRight(35, ' ');
      }
      set
      {
        _Address2 = value;
      }
    }

    public string Address3
    {
      get
      {
        return _Address3.Trim().PadRight(35, ' ');
      }
      set
      {
        _Address3 = value;
      }
    }

    public string City
    {
      get
      {
        return _City.Trim().PadRight(30, ' ');
      }
      set
      {
        _City = value;
      }
    }

    public string State
    {
      get
      {
        return _State;
      }
      set
      {
        if (value == " ")
          _State = "UU";
        else
          _State = value;
      }
    }

    public string Zip5
    {
      get
      {
        return _Zip5.PadLeft(5, '0');
      }
      set
      {
        if (value.Length > 5)
          value = value.Substring(0, 5);
        _Zip5 = value;
      }
    }

    public string Zip4
    {
      get
      {
        return _Zip4.PadLeft(4, '0');
      }
      set
      {
        if (value.Length == 9)
          value = value.Substring(4, 4);
        else
          value = string.Empty;
        _Zip4 = value;
      }
    }

    public string Stfips
    {
      get
      {
        return _Stfips;
      }
      set
      {
        if (value.Length == 0)
          _Stfips = "99";
        else
          _Stfips = value;
      }
    }

    public static ArrayList  GetDemoRecordData(string Username, string Pwd, string Source, string iTaxYear)
    {
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList DemoCollection = new ArrayList();
        Demographics DemoRec;

        int TaxYear = Int16.Parse(iTaxYear.Substring(0, 4));
        int Quarter = Int16.Parse(iTaxYear.Substring(4,1));

        DateRange quarterDates = QuarterDateUtils.GetQuarterDates(Quarter, TaxYear);
        string QueryString = String.Format("SELECT UC.cli_id , UC.audit_create_dt, SC.state_fips_cd, UC.audit_modify_dt," +
                                           " ssn, drivers_licence_nbr, first_name , middle_name, last_name, gender_cd, ethnic_cd  , birth_dt," +
                                           " citizen_flag, addr1, addr2, city, state," +
                                           " zip, (SELECT COUNT(distinct race_cd) AS race_count FROM uworks_owner.uw_client_race WHERE cli_id = UC.cli_id) as RaceCount, UR.RACE_CD" +
                                           " FROM uworks_owner.uw_clients UC" +
                                           " Join uworks_owner.uw_client_address CA on CA.CADR_ID = UC.CLI_ID"+
                                           " Join cubs_owner.state_codes SC on SC.STATE_CD = CA.STATE" +
                                           " left outer join uworks_owner.uw_client_race UR on UR.CR_ID = (Select Max(CR_ID) from uworks_owner.uw_client_race WHERE cli_id = UC.cli_id)" +
                                           " WHERE UC.audit_modify_dt BETWEEN to_date('{0}', 'YYYY/MM/DD HH24:MI:SS') AND to_date('{1}', 'YYYY/MM/DD HH24:MI:SS') AND NVL(ssn,' ') <> ' '",
                                             quarterDates.BeginDate.ToString("yyyy/MM/dd HH:mm:ss"), quarterDates.EndDate.ToString("yyyy/MM/dd HH:mm:ss"));
        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {
            while (OracleDR.Read())
            {
              DemoRec = new Demographics();              
              DateTime AudCreateDate = OracleDR[1] == System.DBNull.Value ? DateTime.MinValue : OracleDR.GetDateTime(1);
              DemoRec.Stfips = OracleDR[2] == System.DBNull.Value ? string.Empty : OracleDR.GetString(2);
              DateTime AudModDate = OracleDR[3] == System.DBNull.Value ? DateTime.MinValue : OracleDR.GetDateTime(3);
              DemoRec.StatusFlag = CalcStatusFlag(AudCreateDate, AudModDate, TaxYear.ToString(),Quarter.ToString());
              DemoRec.DataSourceDate = AudCreateDate == DateTime.MinValue ? string.Empty : AudCreateDate.ToString();
              DemoRec.Year = AudModDate == DateTime.MinValue ? string.Empty : AudModDate.ToString();
              DemoRec.Quarter = AudModDate == DateTime.MinValue ? string.Empty : AudModDate.ToString();
              DemoRec.SSN = OracleDR[4] == System.DBNull.Value ? string.Empty : OracleDR.GetString(4);
              DemoRec.AlternateID = OracleDR[5] == System.DBNull.Value ? string.Empty : OracleDR.GetString(5);
              DemoRec.FirstName = OracleDR[6] == System.DBNull.Value ? string.Empty : OracleDR.GetString(6);
              DemoRec.MiddleName = OracleDR[7] == System.DBNull.Value ? string.Empty : OracleDR.GetString(7);
              DemoRec.LastName = OracleDR[8] == System.DBNull.Value ? string.Empty : OracleDR.GetString(8);
              DemoRec.FullName = DemoRec.FirstName.Trim() +' '+ DemoRec.MiddleName.Trim() +' '+ DemoRec.LastName.Trim();
              DemoRec.Gender = OracleDR[9] == System.DBNull.Value ? "U" : OracleDR.GetString(9);

              if (OracleDR.GetInt16(18) <= 0)
              { DemoRec.Race = "U"; }
              else
                if (OracleDR.GetInt16(18) == 1)
              { DemoRec.Race = OracleDR.GetString(19); }
              else
              { DemoRec.Race = "M"; }

              DemoRec.Ethnicity = OracleDR[10] == System.DBNull.Value ? "U" : OracleDR.GetString(10);

              DemoRec.DOB = OracleDR[11] == System.DBNull.Value ? string.Empty : OracleDR.GetDateTime(11).ToString();
              DemoRec.Citizen = OracleDR[12] == System.DBNull.Value ? string.Empty : OracleDR.GetString(12);
              DemoRec.Address1 = OracleDR[13] == System.DBNull.Value ? string.Empty : OracleDR.GetString(13);
              DemoRec.Address2 = OracleDR[14] == System.DBNull.Value ? string.Empty : OracleDR.GetString(14);
              DemoRec.City = OracleDR[15] == System.DBNull.Value ? string.Empty : OracleDR.GetString(15);
              DemoRec.State = OracleDR[16] == System.DBNull.Value ? string.Empty : OracleDR.GetString(16);
              DemoRec.Zip5 = OracleDR[17] == System.DBNull.Value ? string.Empty : OracleDR.GetString(17);
              DemoRec.Zip4 = OracleDR[17] == System.DBNull.Value ? string.Empty : OracleDR.GetString(17);
              

              DemoCollection.Add(DemoRec);
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
        }
        return DemoCollection;
      }
    }    

    private static string CalcStatusFlag(DateTime dtCreateDate, DateTime dtModifyDate, string strCurYear, string strCurQtr)
    {
      string strCreateYear;
      string strCreateQtr;
      string strRetVal;

      if ((dtCreateDate == DateTime.MinValue) || (dtModifyDate == DateTime.MinValue))
        strRetVal = "U";
      else
      {
        strCreateYear = System.Convert.ToDateTime(dtCreateDate).Year.ToString();
        strCreateQtr = QuarterDateUtils.GetQuarter(System.Convert.ToDateTime(dtCreateDate).Month.ToString());

        if (dtCreateDate != dtModifyDate)
          strRetVal = "C";
        else if (strCreateYear == strCurYear & strCreateQtr == strCurQtr)
          strRetVal = "N";
        else
          strRetVal = "U";
      }

      return strRetVal;
    }    
  }  
}

