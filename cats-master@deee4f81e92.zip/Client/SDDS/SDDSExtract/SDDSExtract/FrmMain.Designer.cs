﻿namespace SDDSExtract
{
  partial class fMain
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.BtnSetSavePath = new System.Windows.Forms.Button();
            this.TxtBoxPath = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.btnWage = new System.Windows.Forms.Button();
            this.BtnAccountBal = new System.Windows.Forms.Button();
            this.btnTaxQtr = new System.Windows.Forms.Button();
            this.btnBenefitCharges = new System.Windows.Forms.Button();
            this.btnEmployerRec = new System.Windows.Forms.Button();
            this.btnDemographics = new System.Windows.Forms.Button();
            this.btnPred_Succ = new System.Windows.Forms.Button();
            this.btnContacts = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.spinTaxTear = new System.Windows.Forms.NumericUpDown();
            this.SpinQuarter = new System.Windows.Forms.NumericUpDown();
            this.comboSource = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.setUsernamePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setUsernamePasswordToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.lblPasswordSetWarning = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.spinTaxTear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpinQuarter)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnSetSavePath
            // 
            this.BtnSetSavePath.Location = new System.Drawing.Point(12, 37);
            this.BtnSetSavePath.Name = "BtnSetSavePath";
            this.BtnSetSavePath.Size = new System.Drawing.Size(16, 23);
            this.BtnSetSavePath.TabIndex = 0;
            this.BtnSetSavePath.Text = ">";
            this.BtnSetSavePath.UseVisualStyleBackColor = true;
            // 
            // TxtBoxPath
            // 
            this.TxtBoxPath.Location = new System.Drawing.Point(34, 40);
            this.TxtBoxPath.Name = "TxtBoxPath";
            this.TxtBoxPath.Size = new System.Drawing.Size(116, 20);
            this.TxtBoxPath.TabIndex = 1;
            this.TxtBoxPath.Text = "C:\\Users\\dbush\\Suta";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(34, 24);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(57, 13);
            this.Label1.TabIndex = 30;
            this.Label1.Text = "Save Path";
            // 
            // btnWage
            // 
            this.btnWage.Location = new System.Drawing.Point(34, 106);
            this.btnWage.Name = "btnWage";
            this.btnWage.Size = new System.Drawing.Size(104, 24);
            this.btnWage.TabIndex = 5;
            this.btnWage.Text = "Wage Record";
            this.btnWage.Click += new System.EventHandler(this.btnWage_Click);
            // 
            // BtnAccountBal
            // 
            this.BtnAccountBal.Location = new System.Drawing.Point(144, 106);
            this.BtnAccountBal.Name = "BtnAccountBal";
            this.BtnAccountBal.Size = new System.Drawing.Size(104, 24);
            this.BtnAccountBal.TabIndex = 15;
            this.BtnAccountBal.Text = "Account Balance";
            this.BtnAccountBal.Click += new System.EventHandler(this.BtnAccountBal_Click);
            // 
            // btnTaxQtr
            // 
            this.btnTaxQtr.Location = new System.Drawing.Point(34, 136);
            this.btnTaxQtr.Name = "btnTaxQtr";
            this.btnTaxQtr.Size = new System.Drawing.Size(104, 24);
            this.btnTaxQtr.TabIndex = 16;
            this.btnTaxQtr.Text = "Tax Quarter";
            this.btnTaxQtr.Click += new System.EventHandler(this.btnTaxQtr_Click);
            // 
            // btnBenefitCharges
            // 
            this.btnBenefitCharges.Location = new System.Drawing.Point(144, 136);
            this.btnBenefitCharges.Name = "btnBenefitCharges";
            this.btnBenefitCharges.Size = new System.Drawing.Size(104, 24);
            this.btnBenefitCharges.TabIndex = 17;
            this.btnBenefitCharges.Text = "Benefit Charges";
            this.btnBenefitCharges.Click += new System.EventHandler(this.btnBenefitCharges_Click);
            // 
            // btnEmployerRec
            // 
            this.btnEmployerRec.Location = new System.Drawing.Point(34, 166);
            this.btnEmployerRec.Name = "btnEmployerRec";
            this.btnEmployerRec.Size = new System.Drawing.Size(104, 24);
            this.btnEmployerRec.TabIndex = 18;
            this.btnEmployerRec.Text = "Employer Record";
            this.btnEmployerRec.Click += new System.EventHandler(this.btnEmployerRec_Click);
            // 
            // btnDemographics
            // 
            this.btnDemographics.Location = new System.Drawing.Point(144, 166);
            this.btnDemographics.Name = "btnDemographics";
            this.btnDemographics.Size = new System.Drawing.Size(104, 24);
            this.btnDemographics.TabIndex = 19;
            this.btnDemographics.Text = "Demographics";
            this.btnDemographics.Click += new System.EventHandler(this.btnDemographics_Click);
            // 
            // btnPred_Succ
            // 
            this.btnPred_Succ.Location = new System.Drawing.Point(34, 196);
            this.btnPred_Succ.Name = "btnPred_Succ";
            this.btnPred_Succ.Size = new System.Drawing.Size(104, 24);
            this.btnPred_Succ.TabIndex = 20;
            this.btnPred_Succ.Text = "Pred / Succ";
            this.btnPred_Succ.Click += new System.EventHandler(this.btnPred_Succ_Click);
            // 
            // btnContacts
            // 
            this.btnContacts.Location = new System.Drawing.Point(144, 196);
            this.btnContacts.Name = "btnContacts";
            this.btnContacts.Size = new System.Drawing.Size(104, 24);
            this.btnContacts.TabIndex = 21;
            this.btnContacts.Text = "Contacts";
            this.btnContacts.Click += new System.EventHandler(this.btnContacts_Click);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(41, 64);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(50, 13);
            this.Label2.TabIndex = 24;
            this.Label2.Text = "Tax Year";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(152, 64);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(42, 13);
            this.Label3.TabIndex = 25;
            this.Label3.Text = "Quarter";
            // 
            // spinTaxTear
            // 
            this.spinTaxTear.Location = new System.Drawing.Point(44, 80);
            this.spinTaxTear.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.spinTaxTear.Minimum = new decimal(new int[] {
            1999,
            0,
            0,
            0});
            this.spinTaxTear.Name = "spinTaxTear";
            this.spinTaxTear.Size = new System.Drawing.Size(61, 20);
            this.spinTaxTear.TabIndex = 3;
            this.spinTaxTear.Value = new decimal(new int[] {
            2018,
            0,
            0,
            0});
            // 
            // SpinQuarter
            // 
            this.SpinQuarter.Location = new System.Drawing.Point(155, 80);
            this.SpinQuarter.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.SpinQuarter.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SpinQuarter.Name = "SpinQuarter";
            this.SpinQuarter.Size = new System.Drawing.Size(61, 20);
            this.SpinQuarter.TabIndex = 4;
            this.SpinQuarter.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // comboSource
            // 
            this.comboSource.FormattingEnabled = true;
            this.comboSource.Items.AddRange(new object[] {
            "CATS_DEV",
            "CATS_TEST",
            "CATS_QA",
            "CATS_PROD"});
            this.comboSource.Location = new System.Drawing.Point(159, 40);
            this.comboSource.Name = "comboSource";
            this.comboSource.Size = new System.Drawing.Size(121, 21);
            this.comboSource.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(159, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 31;
            this.label4.Text = "Database";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setUsernamePasswordToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(292, 24);
            this.menuStrip1.TabIndex = 32;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // setUsernamePasswordToolStripMenuItem
            // 
            this.setUsernamePasswordToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setUsernamePasswordToolStripMenuItem1});
            this.setUsernamePasswordToolStripMenuItem.Name = "setUsernamePasswordToolStripMenuItem";
            this.setUsernamePasswordToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.setUsernamePasswordToolStripMenuItem.Text = "Setup";
            // 
            // setUsernamePasswordToolStripMenuItem1
            // 
            this.setUsernamePasswordToolStripMenuItem1.Name = "setUsernamePasswordToolStripMenuItem1";
            this.setUsernamePasswordToolStripMenuItem1.Size = new System.Drawing.Size(199, 22);
            this.setUsernamePasswordToolStripMenuItem1.Text = "Set Username Password";
            this.setUsernamePasswordToolStripMenuItem1.Click += new System.EventHandler(this.setUsernamePasswordToolStripMenuItem1_Click);
            // 
            // lblPasswordSetWarning
            // 
            this.lblPasswordSetWarning.AutoSize = true;
            this.lblPasswordSetWarning.ForeColor = System.Drawing.Color.Red;
            this.lblPasswordSetWarning.Location = new System.Drawing.Point(78, 234);
            this.lblPasswordSetWarning.Name = "lblPasswordSetWarning";
            this.lblPasswordSetWarning.Size = new System.Drawing.Size(116, 13);
            this.lblPasswordSetWarning.TabIndex = 33;
            this.lblPasswordSetWarning.Text = "Username/Pwd not set";
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.lblPasswordSetWarning);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboSource);
            this.Controls.Add(this.SpinQuarter);
            this.Controls.Add(this.spinTaxTear);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.btnContacts);
            this.Controls.Add(this.btnPred_Succ);
            this.Controls.Add(this.btnDemographics);
            this.Controls.Add(this.btnEmployerRec);
            this.Controls.Add(this.btnBenefitCharges);
            this.Controls.Add(this.btnTaxQtr);
            this.Controls.Add(this.BtnAccountBal);
            this.Controls.Add(this.btnWage);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.TxtBoxPath);
            this.Controls.Add(this.BtnSetSavePath);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "fMain";
            this.Load += new System.EventHandler(this.fMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spinTaxTear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpinQuarter)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    #endregion

    internal System.Windows.Forms.Button BtnSetSavePath;
    internal System.Windows.Forms.TextBox TxtBoxPath;
    internal System.Windows.Forms.Label Label1;
    internal System.Windows.Forms.Button btnWage;
    internal System.Windows.Forms.Button BtnAccountBal;
    internal System.Windows.Forms.Button btnTaxQtr;
    internal System.Windows.Forms.Button btnBenefitCharges;
    internal System.Windows.Forms.Button btnEmployerRec;
    internal System.Windows.Forms.Button btnDemographics;
    internal System.Windows.Forms.Button btnPred_Succ;
    internal System.Windows.Forms.Button btnContacts;
    internal System.Windows.Forms.Label Label2;
    internal System.Windows.Forms.Label Label3;
    private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    private System.Windows.Forms.NumericUpDown spinTaxTear;
    private System.Windows.Forms.NumericUpDown SpinQuarter;
    private System.Windows.Forms.ComboBox comboSource;
    internal System.Windows.Forms.Label label4;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem setUsernamePasswordToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem setUsernamePasswordToolStripMenuItem1;
    private System.Windows.Forms.Label lblPasswordSetWarning;
  }
}

