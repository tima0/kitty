using System;
using System.Collections;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{

  public class PredSucc
  {
    private string _Stfips = "49";
    private string _PredAcct;
    private string _SuccAcct;
    private string _ToEmprid;
    private string _FromEmprid;

    public string Stfips
    {
      get
      {
        return _Stfips;
      }
      set
      {
        _Stfips = value;
      }
    }

    public string PredAcct
    {
      get
      {
        return _PredAcct.PadLeft(10, '0');
      }
      set
      {
        if (value == "0")
          value = "";
        _PredAcct = value;
      }
    }

    public string SuccAcct
    {
      get
      {
        return _SuccAcct.PadLeft(10, '0');
      }
      set
      {
        _SuccAcct = value;
      }
    }
    public string ToEmprid
    {
      get
      {
        return _ToEmprid.PadLeft(10, '0');
      }
      set
      {
        _ToEmprid = value;
      }
    }
    public string FromEmprid
    {
      get
      {
        return _FromEmprid.PadLeft(10, '0');
      }
      set
      {
        if (value == "0")
          value = "";
        _FromEmprid = value;
      }
    }

    public static ArrayList GetPSData(string Username, string Pwd, string Source, string iTaxYear)
    {      
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList PredSuccCollection = new ArrayList();
        PredSucc PredSucc;

        int endTaxYear = Int16.Parse(iTaxYear.Substring(0, 4));
        int endQuarter = Int16.Parse(iTaxYear.Substring(4, 1));
        DateRange endQuarterDates = QuarterDateUtils.GetQuarterDates(endQuarter, endTaxYear);
        DateRange beginQuarterDates = QuarterDateUtils.GetQuarterDates(1, endTaxYear-2);
        string beginTaxYear = (endTaxYear - 2).ToString() + "1";



        string QueryString = String.Format("SELECT DISTINCT Previous_ID, EmprID" +
                                           " FROM CATS_OWNER.Employer" +
                                           " WHERE Previous_ID IS NOT NULL" +
                                           " UNION" +
                                           " SELECT DISTINCT tt.FromEmprID AS PrevID, tt.ToEmprID AS EmprID" +
                                           " FROM CATS_OWNER.Tax_Trans_Qtr_History tt, CATS_OWNER.Employer ev" +
                                           " WHERE tt.Qtr BETWEEN '{0}' AND '{1}'" +
                                           " AND tt.ToEmprID IS NOT NULL" +
                                           " AND tt.FromEmprID <> ev.Previous_ID" +
                                           " AND ev.Previous_ID IS NOT NULL" +
                                           " AND ev.Previous_ID_Dt BETWEEN to_date('{2}', 'YYYY/MM/DD HH24:MI:SS') AND to_date('{3}', 'YYYY/MM/DD HH24:MI:SS') ",
                                           beginTaxYear, iTaxYear, beginQuarterDates.BeginDate.ToString("yyyy/MM/dd HH:mm:ss"), endQuarterDates.EndDate.ToString("yyyy/MM/dd HH:mm:ss")
                                           );

        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {
            while (OracleDR.Read())
            {
              PredSucc = new PredSucc();
              PredSucc.PredAcct = OracleDR[0] == System.DBNull.Value ? string.Empty : OracleDR.GetString(0);
              PredSucc.SuccAcct = OracleDR[1] == System.DBNull.Value ? string.Empty : OracleDR.GetString(1);
              if (Int64.TryParse(PredSucc.PredAcct, out long tempVal))
                if (Int64.TryParse(PredSucc.SuccAcct, out long tempVal1))
                {
                  PredSucc.PredAcct = PredSucc.PredAcct.PadLeft(10, '0');
                  PredSucc.SuccAcct = PredSucc.SuccAcct.PadLeft(10, '0');
                  PredSuccCollection.Add(PredSucc);
                }
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
        }
        return PredSuccCollection;
      }
    }    
  }
}

