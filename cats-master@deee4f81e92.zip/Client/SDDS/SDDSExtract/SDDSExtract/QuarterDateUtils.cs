using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDDSExtract
{
  public class QuarterDateUtils
  {
    public static DateRange GetQuarterDates(int iQuarter, int iQuarterYear)
    {
      DateTime beginDate, endDate;

      switch (iQuarter)
      {
        case 1:
          {
            beginDate = new DateTime(iQuarterYear, 1, 1);
            endDate = new DateTime(iQuarterYear, 3, 31, 23, 59, 59);
            break;
          }

        case 2:
          {
            beginDate = new DateTime(iQuarterYear, 4, 1);
            endDate = new DateTime(iQuarterYear, 6, 30, 23, 59, 59);
            break;
          }

        case 3:
          {
            beginDate = new DateTime(iQuarterYear, 7, 1);
            endDate = new DateTime(iQuarterYear, 9, 30, 23, 59, 59);
            break;
          }

        default:
          {
            beginDate = new DateTime(iQuarterYear, 10, 1);
            endDate = new DateTime(iQuarterYear, 12, 31, 23, 59, 59);
            break;
          }

      }
      return new DateRange(beginDate, endDate);
    }

    public static string GetQuarter(string Month)
    {
      switch (Month)
      {
        case "1":
        case "2":
        case "3":
          {
            return "1";
          }

        case "4":
        case "5":
        case "6":
          {
            return "2";
          }

        case "7":
        case "8":
        case "9":
          {
            return "3";
          }

        default:
          {
            return "4";
          }
      }
    }
  }

  public class DateRange
  {
    public DateTime BeginDate { get; private set; }
    public DateTime EndDate { get; private set; }

    public DateRange(DateTime beginDate, DateTime endDate)
    {
      BeginDate = beginDate;
      EndDate = endDate;
    }
  }
}
