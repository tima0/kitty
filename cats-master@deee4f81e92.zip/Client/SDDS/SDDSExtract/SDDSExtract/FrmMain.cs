using System;
using System.IO;
using System.Collections;
using System.Windows.Forms;


 
namespace SDDSExtract
{
  public partial class fMain : Form
  {
    private string _Username = string.Empty;
    private string _Password = string.Empty;
    private bool UsernameSet = false;
    private bool PasswordSet = false;

    private string Username
    {
      get { return _Username; }
      set
      {
        this._Username = value;
        this.UsernameSet = (this._Username != string.Empty);
      }
    }

    private string Password
    {
      get { return _Password; }
      set
      {
        this._Password = value;
        this.PasswordSet = (this._Password != string.Empty);
      }
    }

    public fMain()
    {
      InitializeComponent();
    }

    private void fMain_Load(object sender, EventArgs e)
    {
      string defaultPath = System.IO.Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile, Environment.SpecialFolderOption.None),
        "Suta");
      TxtBoxPath.Text = defaultPath;
      int CurrentYear = DateTime.Now.Year;
      spinTaxTear.Maximum = CurrentYear + 5;
      spinTaxTear.Minimum = CurrentYear - 5;
      DateTime ThreeMonthsAgo = DateTime.Now.AddMonths(-3);
      spinTaxTear.Value = ThreeMonthsAgo.Year;
      switch (ThreeMonthsAgo.Month)
      {
        case 1:
        case 2:
        case 3:
          SpinQuarter.Value = 1;
          break;
        case 4:
        case 5:
        case 6:
          SpinQuarter.Value = 2;
          break;
        case 7:
        case 8:
        case 9:
          SpinQuarter.Value = 3;
          break;
        default:
          SpinQuarter.Value = 4;
          break;
      }
      comboSource.SelectedIndex = 0;
    }

    private void setUsernamePasswordToolStripMenuItem1_Click(object sender, EventArgs e)
    {
      using (FrmUserNamePwd fm = new FrmUserNamePwd())
      {
        if (fm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
          this.Username = fm.Username;
          this.Password = fm.Password;
        }
      }
      lblPasswordSetWarning.Visible = !(this.UsernameSet && this.PasswordSet);
    }

    private void btnWage_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {
        string FileName = TxtBoxPath.Text + @"\Wage" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {
          ArrayList NewDataCollection = WageRecord.GetWageRecordData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (WageRecord NewWageData in NewDataCollection)
          {
            sw.WriteLine(NewWageData.SSN +
                         NewWageData.Namefirst +
                         NewWageData.Namemiddle +
                         NewWageData.Namelast +
                         NewWageData.State +
                         NewWageData.UIAccount +
                         NewWageData.Seinunit +
                         NewWageData.EIN +
                         NewWageData.Year +
                         NewWageData.Quarter +
                         NewWageData.Wage);
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
      }
      else
      {
        MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
      }      
    }

    private void BtnAccountBal_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {
        string FileName = TxtBoxPath.Text + @"\AccountBal" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {

          ArrayList NewDataCollection = AcctBalances.GetAcctRecordData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (AcctBalances NewAcctData in NewDataCollection)
          {
            sw.WriteLine(NewAcctData.Stfips +
                         NewAcctData.UIaccount +
                         NewAcctData.Year +
                         NewAcctData.Periodtype +
                         NewAcctData.Period +
                         NewAcctData.AccountBalance +
                         NewAcctData.ExperienceRating);
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
      }
      else
      {
        MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
      }      
    }

    private void btnTaxQtr_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {
        string FileName = TxtBoxPath.Text + @"\TaxQrt" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {

          ArrayList NewDataCollection = TaxQtrData.GetTxQtrData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (TaxQtrData NewTaxData in NewDataCollection)
          {
            sw.WriteLine(NewTaxData.StateFIPS +
                         NewTaxData.UIAccount +
                         NewTaxData.Year +
                         NewTaxData.Quarter +
                         NewTaxData.TaxesPaid +
                         NewTaxData.TotalWages +
                         NewTaxData.TaxableWages +
                         NewTaxData.TaxRate +
                         NewTaxData.MonthEmp1 +
                         NewTaxData.MonthEmp2 +
                         NewTaxData.MonthEmp3);
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
      }
      else
      {
        MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
      }      
    }

    private void btnBenefitCharges_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {
        string FileName = TxtBoxPath.Text + @"\BenCharges" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {

          ArrayList NewDataCollection = BenefitCharges.GetBenRecordData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (BenefitCharges NewBenData in NewDataCollection)
          {
            sw.WriteLine(NewBenData.Stfips +
                         NewBenData.UIaccount +
                         NewBenData.Year +
                         NewBenData.Periodtype +
                         NewBenData.Period +
                         NewBenData.ChargeAmount +
                         NewBenData.ChargeDate);
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
      }
      else
      {
        MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
      }      
    }

    private void btnEmployerRec_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {

        string FileName = TxtBoxPath.Text + @"\EmployerRec" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {

          ArrayList NewDataCollection = EmployerRecord.GetEmprRecordData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (EmployerRecord NewEmpData in NewDataCollection)
          {
            sw.WriteLine(NewEmpData.Stfips +
                         NewEmpData.UIAccount +
                         NewEmpData.EIN +
                         NewEmpData.Year +
                         NewEmpData.Quarter +
                         NewEmpData.Name1 +
                         NewEmpData.Name2 +
                         NewEmpData.UIAddress1 +
                         NewEmpData.UIAddress2 +
                         NewEmpData.UICity +
                         NewEmpData.UIState +
                         NewEmpData.UIZip5 +
                         NewEmpData.UIZip4 +
                         NewEmpData.PhysicalAddress1 +
                         NewEmpData.PhysicalAddress2 +
                         NewEmpData.PhysicalCity +
                         NewEmpData.PhysicalState +
                         NewEmpData.PhysicalZip5 +
                         NewEmpData.PhysicalZip4 +
                         NewEmpData.Telephone +
                         NewEmpData.Ownership +
                         NewEmpData.SICcode +
                         NewEmpData.NAICScode);
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
      }
      else
      {
        MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
      }      
    }

    private void btnDemographics_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {
        string FileName = TxtBoxPath.Text + @"\Demographic" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {

          ArrayList NewDataCollection = Demographics.GetDemoRecordData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (Demographics NewDemoData in NewDataCollection)
          {
            sw.WriteLine(NewDemoData.DataSourceType +
                         NewDemoData.DataSource +
                         NewDemoData.DataSourceDate +
                         NewDemoData.StatusFlag +
                         NewDemoData.SourceStfips +
                         NewDemoData.Year +
                         NewDemoData.Quarter +
                         NewDemoData.SSN +
                         NewDemoData.AlternateID +
                         NewDemoData.FullName +
                         NewDemoData.LastName +
                         NewDemoData.FirstName +
                         NewDemoData.MiddleName +
                         NewDemoData.Title +
                         NewDemoData.Suffix +
                         NewDemoData.Gender +
                         NewDemoData.Race +
                         NewDemoData.Ethnicity +
                         NewDemoData.DOB +
                         NewDemoData.Citizen +
                         NewDemoData.Address1 +
                         NewDemoData.Address2 +
                         NewDemoData.Address3 +
                         NewDemoData.City +
                         NewDemoData.State +
                         NewDemoData.Zip5 +
                         NewDemoData.Zip4 +
                         NewDemoData.Stfips
                         );
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
        else
        {
          MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
        }
      }
    }

    private void btnPred_Succ_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {

        string FileName = TxtBoxPath.Text + @"\PredSucc" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {

          ArrayList NewDataCollection = PredSucc.GetPSData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (PredSucc NewPredData in NewDataCollection)
          {
            sw.WriteLine(NewPredData.Stfips +
                         NewPredData.PredAcct +
                         NewPredData.SuccAcct
                         );
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
        else
        {
          MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
        }
      }
    }

    private void btnContacts_Click(object sender, EventArgs e)
    {
      if (_Username != string.Empty && _Password != string.Empty)
      {
        string FileName = TxtBoxPath.Text + @"\Contacts" + spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString() + ".txt";
        bool OverwriteFile = false;
        bool FileExists = File.Exists(FileName);

        if (FileExists)
        {
          DialogResult dr = MessageBox.Show(String.Format("File {0} already exists and will be overwritten", FileName), "original file will be lost", MessageBoxButtons.OKCancel);
          if (dr == DialogResult.OK)
          {
            OverwriteFile = true;
          }
          else
          {
            OverwriteFile = false;
            MessageBox.Show("canceled", "canceled", MessageBoxButtons.OK);
          }
        }

        if ((FileExists && OverwriteFile) || (!FileExists))
        {

          ArrayList NewDataCollection = Contacts.GetContactRecordData(Username + "[cats_read]", Password, comboSource.Text, spinTaxTear.Value.ToString() + SpinQuarter.Value.ToString());
          StreamWriter sw = new StreamWriter(FileName);
          foreach (Contacts NewContactData in NewDataCollection)
          {
            sw.WriteLine(NewContactData.Stfips +
                         NewContactData.UIAccount +
                         NewContactData.Year +
                         NewContactData.Quarter +
                         NewContactData.ContactName +
                         NewContactData.OwnerContactTelephone +
                         NewContactData.OwnerOfficerSSN +
                         NewContactData.ContactTitle
                         );
          }
          sw.Close();
          MessageBox.Show("Done", "Done", MessageBoxButtons.OK);
        }
        else
        {
          MessageBox.Show("User Name and Password must be setup See Setup menu item", "User Name Password not setup", MessageBoxButtons.OK);
        }
      }
    }
  } 
}
