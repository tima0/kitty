using System;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{
  public class TaxQtrData
  {
    private string _StFIPS = "49";
    private string _UIAccount;
    private string _Year;
    private string _Quarter;
    private string _TaxesPaid;
    private string _TotalWages;
    private string _TaxableWages;
    private string _TaxRate;
    private string _MonthEmployment1;
    private string _MonthEmployment2;
    private string _MonthEmployment3;

    public string StateFIPS
    {
      get
      {
        return _StFIPS;
      }
    }

    public string UIAccount
    {
      get
      {
        return _UIAccount.PadLeft(10, '0');
      }
      set
      {
        _UIAccount = value;
      }
    }
    public string Year
    {
      get
      {
        return _Year.Substring(0, 4);
      }
      set
      {
        _Year = value;
      }
    }
    public string Quarter
    {
      get
      {
        return _Quarter.Substring(4, 1);
      }
      set
      {
        _Quarter = value;
      }
    }
    public string TaxesPaid
    {
      get
      {
        return _TaxesPaid.PadLeft(9, '0');
      }
      set
      {
        if (value.Length != 0)
          _TaxesPaid = String.Format(value, "###0.00").ToString();
        else
          _TaxesPaid = "0.00";
      }
    }
    public string TotalWages
    {
      get
      {
        return _TotalWages.PadLeft(11, '0');
      }
      set
      {
        _TotalWages = value.Trim() + ".00";
      }
    }
    public string TaxableWages
    {
      get
      {
        return _TaxableWages.PadLeft(11, '0');
      }
      set
      {
        _TaxableWages = value.Trim() + ".00";
      }
    }
    public string TaxRate
    {
      get
      {
        return _TaxRate.PadLeft(6, '0');
      }
      set
      {
        if (value.Length != 0)
          _TaxRate = String.Format(value, "###0.000").ToString();
        else
          _TaxRate = "0.000";
      }
    }
    public string MonthEmp1
    {
      get
      {
        return _MonthEmployment1.PadLeft(6, '0');
      }
      set
      {
        _MonthEmployment1 = value.Trim();
      }
    }
    public string MonthEmp2
    {
      get
      {
        return _MonthEmployment2.PadLeft(6, '0');
      }
      set
      {
        _MonthEmployment2 = value.Trim();
      }
    }
    public string MonthEmp3
    {
      get
      {
        return _MonthEmployment3.PadLeft(6, '0');
      }
      set
      {
        _MonthEmployment3 = value.Trim();
      }
    }

    public static ArrayList GetTxQtrData(string Username, string Pwd, string Source, string TaxYear)
    {
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList DataCollection = new ArrayList();
        TaxQtrData TaxQtrData;

        string QueryString = String.Format("SELECT Emprid, YrQtr, ContrPd, TotWag, SubjWag, Rate, Empl1, Empl2, Empl3" + " FROM CATS_OWNER.QTR_SUMMARY" + " WHERE YrQtr = '{0}'", TaxYear);

        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {
            while (OracleDR.Read())
            {
              TaxQtrData = new TaxQtrData();
              TaxQtrData.UIAccount = OracleDR[0] == System.DBNull.Value ? String.Empty : OracleDR.GetString(0);
              TaxQtrData.Year = OracleDR[1] == System.DBNull.Value ? String.Empty : OracleDR.GetString(1);
              TaxQtrData.Quarter = OracleDR[1] == System.DBNull.Value ? String.Empty : OracleDR.GetString(1);
              TaxQtrData.TaxesPaid = OracleDR[2] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(2).ToString();
              TaxQtrData.TotalWages = OracleDR[3] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(3).ToString();
              TaxQtrData.TaxableWages = OracleDR[4] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(4).ToString();
              TaxQtrData.TaxRate = OracleDR[5] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(5).ToString();
              TaxQtrData.MonthEmp1 = OracleDR[6] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(6).ToString();
              TaxQtrData.MonthEmp2 = OracleDR[7] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(7).ToString();
              TaxQtrData.MonthEmp3 = OracleDR[8] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(8).ToString();
              DataCollection.Add(TaxQtrData);
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
        }
        return DataCollection;
      }
    }
  }
}

