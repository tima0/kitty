using System;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Oracle.DataAccess.Client;

namespace SDDSExtract
{
  public class BenefitCharges
  {
    private string _Stfips = "49";
    private string _UIaccount;
    private string _Year;
    private string _Periodtype = "02";
    private string _Period;
    private string _ChargeAmount;
    private string _ChargeDate;

    public string Stfips
    {
      get
      {
        return _Stfips;
      }
    }

    public string UIaccount
    {
      get
      {
        return _UIaccount.PadLeft(10, '0');
      }
      set
      {
        _UIaccount = value;
      }
    }

    public string Year
    {
      get
      {
        return _Year.Substring(0, 4);
      }
      set
      {
        _Year = value;
      }
    }

    public string Periodtype
    {
      get
      {
        return _Periodtype.PadLeft(2, ' ');
      }
      set
      {
        _Periodtype = value;
      }
    }

    public string Period
    {
      get
      {
        return _Period.PadLeft(2, '0');
      }
      set
      {
        _Period = value.Substring(4, 1);
      }
    }

    public string ChargeAmount
    {
      get
      {
        string NegAmtChk;
        if (_ChargeAmount.IndexOf("-") != -1)
        {
          NegAmtChk = _ChargeAmount.Replace("-", "");
          _ChargeAmount = NegAmtChk;
          return "-" + _ChargeAmount.PadLeft(11, '0');
        }
        else
          return _ChargeAmount.PadLeft(12, '0');
      }
      set
      {
        if (value.IndexOf(".") != -1)
          _ChargeAmount = value;
        else
          _ChargeAmount = value + ".00";
      }
    }

    public string ChargeDate
    {
      get
      {
        return _ChargeDate.PadLeft(10, ' ');
      }
      set
      {
        if (value.Length > 0)
        {
          if (value.Substring(4, 1) == "4")
            _ChargeDate = GetChargeDate(value.Substring(4, 1)) + (System.Convert.ToDouble(value.Substring(0, 4)) + 1.ToString());
          else
            _ChargeDate = GetChargeDate(value.Substring(4, 1)) + value.Substring(0, 4);
        }
        else
          _ChargeDate = string.Empty;
      }
    }

    public static ArrayList GetBenRecordData(string Username, string Pwd, string Source, string TaxYear)
    {
      using (OracleConnection OracleConn = new OracleConnection(String.Format("Data Source={0};User ID={1};Password={2}", Source, Username, Pwd)))
      {
        ArrayList DataCollection = new ArrayList();
        BenefitCharges BenefitCharges;

        string QueryString = String.Format("SELECT EMPRID, YRQTR, BENCOST" + " FROM CATS_OWNER.Qtr_Summary" + " WHERE YRQTR ='{0}'", TaxYear);

        OracleCommand OracleCommnd = new OracleCommand(QueryString, OracleConn);
        OracleConn.Open();
        using (OracleDataReader OracleDR = OracleCommnd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
        {
          try
          {
            while (OracleDR.Read())
            {
              BenefitCharges = new BenefitCharges();
              BenefitCharges.UIaccount = OracleDR[0] == System.DBNull.Value ? String.Empty : OracleDR.GetString(0);
              BenefitCharges.Year = OracleDR[1] == System.DBNull.Value ? String.Empty : OracleDR.GetString(1);
              BenefitCharges.Period = OracleDR[1] == System.DBNull.Value ? String.Empty : OracleDR.GetString(1);
              BenefitCharges.ChargeAmount = OracleDR[2] == System.DBNull.Value ? String.Empty : OracleDR.GetDouble(2).ToString();
              BenefitCharges.ChargeDate = OracleDR[1] == System.DBNull.Value ? String.Empty : OracleDR.GetString(1);
              DataCollection.Add(BenefitCharges);
            }
          }
          finally
          {
            OracleDR.Close();
            OracleCommnd.Connection.Close();
            OracleCommnd.Dispose();
          }
        }
        return DataCollection;
      }
    }


    private string GetChargeDate(string Qtr)
    {
      switch (Qtr)
      {
        case "1":
          {
            return "04/10/";
          }

        case "2":
          {
            return "07/10/";
          }

        case "3":
          {
            return "10/10/";
          }

        case "4":
          {
            return "01/10/";
          }

        default:
          {
            return "";
          }
      }
    }
  }
}

  
