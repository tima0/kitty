/* tslint:disable */

export interface SessionIdentifier {
  SessionId: string;
}
