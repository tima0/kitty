/* tslint:disable */

export interface OrderListItem {
  Ascending: boolean;
  FieldName: string;
}
