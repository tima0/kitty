/* tslint:disable */

export enum SessionsFilter {
  0 = 0,
  1 = 1,
}
