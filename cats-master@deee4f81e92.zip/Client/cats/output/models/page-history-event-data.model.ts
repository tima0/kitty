/* tslint:disable */

export interface PageHistoryEventData {
  Page: string;
  ReferringPage: string;
  SessionId: string;
}
