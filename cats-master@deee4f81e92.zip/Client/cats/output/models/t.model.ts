/* tslint:disable */

export interface T {
}
