/* tslint:disable */

export enum SessionTerminationMethod {
  Abandoned = "Abandoned",
  LoggedOff = "LoggedOff",
  Timeout = "Timeout",
  Killed = "Killed",
}
