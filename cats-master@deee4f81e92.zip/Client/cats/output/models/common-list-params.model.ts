/* tslint:disable */
import {
  OrderListItem,
  PageListParam,
} from '.';

export interface CommonListParams {
  Order: OrderListItem[];
  Paging: PageListParam;
}
