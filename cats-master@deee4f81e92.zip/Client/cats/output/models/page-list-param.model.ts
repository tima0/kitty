/* tslint:disable */

export interface PageListParam {
  Offset: number;
  PageSize: number;
}
