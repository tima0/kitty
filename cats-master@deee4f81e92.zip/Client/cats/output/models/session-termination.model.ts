/* tslint:disable */
import {
  SessionTerminationMethod,
} from '.';

export interface SessionTermination {
  TerminationMethod: SessionTerminationMethod;
}
