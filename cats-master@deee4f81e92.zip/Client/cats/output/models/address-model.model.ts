/* tslint:disable */

export interface AddressModel {
  Address1: string;
  Address2: string;
  AddressCleansedCd: string;
  AddressId: number;
  BadAddressFlag: string;
  City: string;
  PartyId: number;
  State: string;
  Zip: string;
}
