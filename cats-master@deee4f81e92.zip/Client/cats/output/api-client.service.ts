/* tslint:disable */

import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, Injectable, InjectionToken, Optional } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { DefaultHttpOptions, HttpOptions, APIClientInterface } from './';

import * as models from './models';

export const USE_DOMAIN = new InjectionToken<string>('APIClient_USE_DOMAIN');
export const USE_HTTP_OPTIONS = new InjectionToken<HttpOptions>('APIClient_USE_HTTP_OPTIONS');

type APIHttpOptions = HttpOptions & {
  headers: HttpHeaders;
  params: HttpParams;
};

/**
 * Created with https://github.com/flowup/api-client-generator
 */
@Injectable()
export class APIClient implements APIClientInterface {

  readonly options: APIHttpOptions;

  readonly domain: string = `http://localhost:50682/v1`;

  constructor(private readonly http: HttpClient,
              @Optional() @Inject(USE_DOMAIN) domain?: string,
              @Optional() @Inject(USE_HTTP_OPTIONS) options?: DefaultHttpOptions) {

    if (domain != null) {
      this.domain = domain;
    }

    this.options = {
      headers: new HttpHeaders(options && options.headers ? options.headers : {}),
      params: new HttpParams(options && options.params ? options.params : {}),
      ...(options && options.reportProgress ? { reportProgress: options.reportProgress } : {}),
      ...(options && options.withCredentials ? { withCredentials: options.withCredentials } : {})
    };
  }

  notesGetNote(
    args: {
      partyId: number,
      id: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}/notes/${args.id}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  notesGetNotes(
    args: {
      partyId: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}/notes`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options, JSON.stringify(args.listParams));
  }

  addressGetAddress(
    args: {
      partyId: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}/address`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  addressPut(
    args: {
      value: models.AddressModel,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/claimant/address`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('PUT', path, options, JSON.stringify(args.value));
  }

  phoneGetPhone(
    args: {
      partyId: number,
      phonetype: string,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}/phones/${args.phonetype}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  phoneGetPhones(
    args: {
      partyId: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}/phones`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options, JSON.stringify(args.listParams));
  }

  claimantGetClaimants(
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  claimantGetClaimantByPartyId(
    args: {
      partyId: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  claimantOkOrNotFound(
    args: {
      data: models.T,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/Claimant`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('POST', path, options, JSON.stringify(args.data));
  }

  claimantSearchGetAll(
    requestHttpOptions?: HttpOptions
  ): Observable<string[]> {
    const path = `/api/ClaimantSearch`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<string[]>('GET', path, options);
  }

  claimantSearchPost(
    args: {
      value: any,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/ClaimantSearch`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('POST', path, options, JSON.stringify(args.value));
  }

  claimantSearchSearchClaimant(
    args: {
      search: string,
      commonListParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/claimantsearch`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    if ('search' in args) {
      options.params = options.params.set('search', String(args.search));
    }
    return this.sendRequest<any>('GET', path, options, JSON.stringify(args.commonListParams));
  }

  claimantSearchGet(
    args: {
      id: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/ClaimantSearch/${args.id}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  claimantSearchPut(
    args: {
      id: number,
      value: any,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/ClaimantSearch/${args.id}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('PUT', path, options, JSON.stringify(args.value));
  }

  claimantSearchDelete(
    args: {
      id: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/ClaimantSearch/${args.id}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('DELETE', path, options);
  }

  pageVisitRecordPageVist(
    args: {
      pageVisit: models.PageHistoryEventData,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/pagevisits`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('POST', path, options, JSON.stringify(args.pageVisit));
  }

  sessionGetSessions(
    args: {
      filter: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessions`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    if ('filter' in args) {
      options.params = options.params.set('Filter', String(args.filter));
    }
    return this.sendRequest<any>('GET', path, options, JSON.stringify(args.listParams));
  }

  sessionCreateSession(
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessions`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('POST', path, options);
  }

  sessionExtendCurrentSession(
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessions`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('PUT', path, options);
  }

  sessionKillSession(
    args: {
      sessionIdentifiers: any,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessions`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('DELETE', path, options, JSON.stringify(args.sessionIdentifiers));
  }

  sessionGetCurrentSession(
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessions/current`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  sessionEndCurrentSession(
    args: {
      sessionTermination: models.SessionTermination,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessions/current`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('DELETE', path, options, JSON.stringify(args.sessionTermination));
  }

  sessionGetSession(
    args: {
      jti: string,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessions/${args.jti}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  sessionGetActiveUserHistory(
    args: {
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessionhistories/current`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options, JSON.stringify(args.listParams));
  }

  sessionGetUserHistory(
    args: {
      employeeid: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/security/sessionhistories/${args.employeeid}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options, JSON.stringify(args.listParams));
  }

  holdGetStateOfAllHoldTypesForPartyId(
    args: {
      partyId: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}/holds`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options, JSON.stringify(args.listParams));
  }

  holdGetHold(
    args: {
      partyId: number,
      holdType: string,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/v1.0/bop/claimants/${args.partyId}/holds/${args.holdType}`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('GET', path, options);
  }

  holdOkOrNotFound(
    args: {
      data: models.T,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any> {
    const path = `/api/Hold`;
    const options: APIHttpOptions = {...this.options, ...requestHttpOptions};

    return this.sendRequest<any>('POST', path, options, JSON.stringify(args.data));
  }

  private sendRequest<T>(method: string, path: string, options: HttpOptions, body?: any): Observable<T> {
    switch (method) {
      case 'DELETE':
        return this.http.delete<T>(`${this.domain}${path}`, options);
      case 'GET':
        return this.http.get<T>(`${this.domain}${path}`, options);
      case 'HEAD':
        return this.http.head<T>(`${this.domain}${path}`, options);
      case 'OPTIONS':
        return this.http.options<T>(`${this.domain}${path}`, options);
      case 'PATCH':
        return this.http.patch<T>(`${this.domain}${path}`, body, options);
      case 'POST':
        return this.http.post<T>(`${this.domain}${path}`, body, options);
      case 'PUT':
        return this.http.put<T>(`${this.domain}${path}`, body, options);
      default:
        console.error(`Unsupported request: ${method}`);
        return throwError(`Unsupported request: ${method}`);
    }
  }
}
