/* tslint:disable */

import { Observable } from 'rxjs';
import { HttpOptions } from './';
import * as models from './models';

export interface APIClientInterface {

  notesGetNote(
    args: {
      partyId: number,
      id: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  notesGetNotes(
    args: {
      partyId: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  addressGetAddress(
    args: {
      partyId: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  addressPut(
    args: {
      value: models.AddressModel,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  phoneGetPhone(
    args: {
      partyId: number,
      phonetype: string,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  phoneGetPhones(
    args: {
      partyId: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantGetClaimants(
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantGetClaimantByPartyId(
    args: {
      partyId: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantOkOrNotFound(
    args: {
      data: models.T,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantSearchGetAll(
    requestHttpOptions?: HttpOptions
  ): Observable<string[]>;

  claimantSearchPost(
    args: {
      value: any,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantSearchSearchClaimant(
    args: {
      search: string,
      commonListParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantSearchGet(
    args: {
      id: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantSearchPut(
    args: {
      id: number,
      value: any,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  claimantSearchDelete(
    args: {
      id: number,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  pageVisitRecordPageVist(
    args: {
      pageVisit: models.PageHistoryEventData,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionGetSessions(
    args: {
      filter: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionCreateSession(
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionExtendCurrentSession(
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionKillSession(
    args: {
      sessionIdentifiers: any,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionGetCurrentSession(
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionEndCurrentSession(
    args: {
      sessionTermination: models.SessionTermination,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionGetSession(
    args: {
      jti: string,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionGetActiveUserHistory(
    args: {
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  sessionGetUserHistory(
    args: {
      employeeid: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  holdGetStateOfAllHoldTypesForPartyId(
    args: {
      partyId: number,
      listParams: models.CommonListParams,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  holdGetHold(
    args: {
      partyId: number,
      holdType: string,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

  holdOkOrNotFound(
    args: {
      data: models.T,
    },
    requestHttpOptions?: HttpOptions
  ): Observable<any>;

}
