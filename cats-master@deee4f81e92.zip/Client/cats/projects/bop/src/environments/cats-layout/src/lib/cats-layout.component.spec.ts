import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CatsLayoutComponent } from './cats-layout.component';

describe('CatsLayoutComponent', () => {
  let component: CatsLayoutComponent;
  let fixture: ComponentFixture<CatsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CatsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CatsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
