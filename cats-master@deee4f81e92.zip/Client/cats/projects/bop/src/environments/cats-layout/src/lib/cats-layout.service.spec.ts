import { TestBed, inject } from '@angular/core/testing';

import { CatsLayoutService } from './cats-layout.service';

describe('CatsLayoutService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CatsLayoutService]
    });
  });

  it('should be created', inject([CatsLayoutService], (service: CatsLayoutService) => {
    expect(service).toBeTruthy();
  }));
});
