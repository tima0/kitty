import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cats-cats-layout',
  template: `
    <p>
      cats-layout works!
    </p>
  `,
  styles: []
})
export class CatsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
