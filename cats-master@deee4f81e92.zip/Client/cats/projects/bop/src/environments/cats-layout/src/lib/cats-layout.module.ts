import { NgModule } from '@angular/core';
import { CatsLayoutComponent } from './cats-layout.component';

@NgModule({
  imports: [
  ],
  declarations: [CatsLayoutComponent],
  exports: [CatsLayoutComponent]
})
export class CatsLayoutModule { }
