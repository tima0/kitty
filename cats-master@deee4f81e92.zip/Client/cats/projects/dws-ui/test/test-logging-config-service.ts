import { Injectable } from '@angular/core';
import { LogPublisher } from 'projects/dws-ui/logging/src/publisher/log-publisher';
import { HttpClient } from 'selenium-webdriver/http';

@Injectable({
  providedIn: 'root'
})
//export class TestLoggingService implements LoggingService {
export class TestLoggingConfigService {
  publishers: LogPublisher[] = [];

  constructor(private http: HttpClient) {}
}
