import { Injectable } from '@angular/core';
import { LogLevel, LoggingService } from 'projects/dws-ui/public_api';
import { LoggingConfigService } from 'projects/dws-ui/logging/src/logging-config.service';
import { LoggingServiceInterface } from '../logging/src/logging-service-interface';
import { LogPublisher } from '../logging/src/publisher/log-publisher';

@Injectable({
  providedIn: 'root'
})
export class TestLoggingService implements LoggingServiceInterface {
  publishers: LogPublisher[] = [];

  constructor(private loggingConfig: LoggingConfigService) {}

  log(logLevel: LogLevel, msg: any, ...params: any[]) {}

  debug(msg: string, ...params: any[]) {}

  info(msg: string, ...params: any[]) {}

  warning(msg: string, ...params: any[]) {}

  trace(msg: string, ...params: any[]) {}

  critical(msg: string, ...params: any[]) {}
}
