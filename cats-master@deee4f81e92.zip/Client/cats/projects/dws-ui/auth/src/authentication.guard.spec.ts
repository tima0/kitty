import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthenticationGuard } from './authentication.guard';
import { SecurityTokenService } from './security-token.service';


describe('AuthenticationGuard', () => {
  let isAuthenticatedState = false;
  const token = { isAuthenticated: () => isAuthenticatedState };
  const document = { href: '' };
  beforeEach(() => {
    document.href = '';
  });

  it('Authenticated - href does not change', () => {
    const guard = new AuthenticationGuard(<SecurityTokenService>token, document);
    isAuthenticatedState = true;
    expect(guard.canActivate(<ActivatedRouteSnapshot>{}, <RouterStateSnapshot>{})).toBeTruthy();
    expect(document.href).toEqual('');
  });

  it('Not Authenticated - href does change', () => {
    const guard = new AuthenticationGuard(<SecurityTokenService>token, document);
    isAuthenticatedState = false;
    expect(guard.canActivate(<ActivatedRouteSnapshot>{}, <RouterStateSnapshot>{})).toBeFalsy();
    expect(document.href.length).toBeGreaterThan(1);
  });
});
