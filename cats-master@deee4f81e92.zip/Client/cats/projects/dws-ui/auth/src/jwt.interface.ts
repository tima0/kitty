export interface JWT {
  exp: number;
}
