import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed, inject } from '@angular/core/testing';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { SecurityTokenService } from './security-token.service';

describe('SecurityTokenService', () => {
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [SecurityTokenService]
    });
    httpClient = TestBed.get(HttpClient);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  it('should be created', inject([SecurityTokenService, HttpClientTestingModule], (service: SecurityTokenService) => {
    expect(service).toBeTruthy();
  }));

  it('Expire Date Match', inject([SecurityTokenService, HttpClientTestingModule], (service: SecurityTokenService) => {
    //secret key used: "asdf"
    const jwtToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MTYyMzAwMDB9.sCr8I8Ym6jUplFe0x9QEVacPL2IPg0yL4BcRis2HNqM';
    service.encodedAuthToken = jwtToken;
    expect(service.getExpirationDateTime()).toEqual(new Date(1516230000));
  }));

  it('IsAuthenticated = false with no Token', inject([SecurityTokenService, HttpClientTestingModule], (service: SecurityTokenService) => {
    service.encodedAuthToken = '';
    expect(service.isAuthenticated()).toEqual(false);
  }));

  it('IsAuthenticated = false, when expired', inject([SecurityTokenService, HttpClientTestingModule], (service: SecurityTokenService) => {
    //secret key used: "asdf"  (Exp Date is in 1970 so it's expired)
    const jwtToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MTYyMzAwMDB9.sCr8I8Ym6jUplFe0x9QEVacPL2IPg0yL4BcRis2HNqM';
    service.encodedAuthToken = jwtToken;
    expect(service.isAuthenticated()).toEqual(false);
  }));

  it('IsAuthenticated = true, when not expired', inject([SecurityTokenService, HttpClientTestingModule],
    (service: SecurityTokenService) => {
    //secret key used: "asdf"  (Exp Date is in 2198 so it's hopefully not expired)
    const jwtToken = 'eyJhbGciOiJIUzI1 cNiIsInR5cCI6IkpXVCJ9.eyJleHAiOjcyMTQ1MTYyMzAwMDB9.5kM0Wa8T7cZpiLtMQELqJZbci2mfiYWg6MPL0p8JuDM';
    service.encodedAuthToken = jwtToken;
    expect(service.isAuthenticated()).toEqual(true);
  }));

  it('should refresh a token', inject([SecurityTokenService, HttpClientTestingModule], (service: SecurityTokenService) => {
    //secret key used: "asdf"  (Exp Date is in 1970 so it's expired)
    const jwtToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MTYyMzAwMDB9.sCr8I8Ym6jUplFe0x9QEVacPL2IPg0yL4BcRis2HNqM';
    service.encodedAuthToken = jwtToken;
    service.refreshToken();
    //this should return true when we have an actual token service working.
    expect(service.isAuthenticated()).toEqual(false);
  }));
});
