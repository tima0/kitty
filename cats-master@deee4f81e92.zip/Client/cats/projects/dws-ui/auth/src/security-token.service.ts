import { Injectable } from '@angular/core';
import { JWT } from './jwt.interface';
import {Observable, throwError} from 'rxjs';
import { HttpClient } from '@angular/common/http';

const AUTH_KEY = 'sts-authkey';
const PAYLOAD_LOCATION = 1;

@Injectable({
  providedIn: 'root'
})
export class SecurityTokenService {
  constructor(private http: HttpClient) { }

  get encodedAuthToken(): string | null {
    return localStorage.getItem(AUTH_KEY);
  }
  set encodedAuthToken(value: string | null) {
    if (value) {
      localStorage.setItem(AUTH_KEY, value);
    } else {
      localStorage.removeItem(AUTH_KEY);
    }
  }

  getJWTPayload(encodedAuthToken: string): object {
    const splitToken = encodedAuthToken.split('.');
    if (splitToken.length !== 3) {
      throw Error('Unexpected token value');
    }
    return JSON.parse(atob(splitToken[PAYLOAD_LOCATION]));
  }
  getExpirationDateTime(): Date {
    const validToken = this.encodedAuthToken;
    if (validToken) {
      const payload = this.getJWTPayload(validToken);
      const jwt = <JWT>(payload);
      return new Date(jwt.exp);
    } else {
      return new Date(Date.now());
    }
  }
  isAuthenticated(): boolean {
    return ((this.encodedAuthToken !== null) && (this.getExpirationDateTime().valueOf() >  Date.now().valueOf()));
  }
  isStale(): boolean {
    const MS_PER_MINUTE = 60000;
    const fiveMinutes = (MS_PER_MINUTE * 5);
    return   ((this.encodedAuthToken !== null) && (this.getExpirationDateTime().valueOf() > ( Date.now().valueOf() + fiveMinutes)));
  }
  refreshToken(): boolean {
    if (this.isStale) {
      //todo:   this will probably need a new name fro the get() funtion
      this.getJWTText();
    }
    return true;
  }
  private handleErrors(error: any): Observable<any> {
    const errors: string[] = [];
    let msg = '';

    msg = 'Status: ' + error.status;
    msg += ' - Status text: ' + error.statusText;
    if (error.json()) {
      msg += ' - Exception message: ' + error.json().exceptionMessage;
    }

    error.push(error);
    console.error('An error ocurred', errors);
    return throwError(errors);
  }

  hasAuthorizationClaim(claim: string): boolean {
    return true; //TODO: Implement when we know where are stored in the JWT
  }


  //todo:  this almost certainly goes somewhere else.
  getJWTText(): void {
    const jwtUrl = 'https://alpha.dws.utah.gov/sso/api/jwt';
    this.http.post(jwtUrl, {ttl: 15}).subscribe(
      response => {this.encodedAuthToken = response.toString(); },
      err => {this.encodedAuthToken = err.toString(); }
    );
  }
}

