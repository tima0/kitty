import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

import { SecurityTokenService } from './security-token.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationGuard implements CanActivate {
  constructor(private token: SecurityTokenService,
    @Inject(DOCUMENT) private document: any) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
     // todo:  this causes an error, I don't know why
     //this.token.refreshToken();
      if (!this.token.isAuthenticated()) {
        const returnUrl = ''; // next.url[0].path;
        this.document.href = `/sso/home/tokenlogin?Reason=LoginType&ReturnUrl=$(returnUrl)`;
        return false;
      }
      return true;
  }
}
