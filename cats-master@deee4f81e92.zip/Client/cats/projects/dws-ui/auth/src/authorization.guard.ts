import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

import { SecurityTokenService } from './security-token.service';

@Injectable({
   providedIn: 'root'
 })
export class AuthorizationGuard implements CanActivate {
  constructor(private token: SecurityTokenService,
    @Inject(DOCUMENT) private document: any
  ) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      const role = next.data['role'] as string;
      if (!this.token.hasAuthorizationClaim(role)) {
        this.document.href = 'todo: dashboard not authorized route  URL';
        return false;
      }
      return true;
  }
}
