import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthorizationGuard } from './authorization.guard';
import { SecurityTokenService } from './security-token.service';


describe('AuthorizationGuard', () => {
  const token = { hasAuthorizationClaim: (claim: string) => claim === 'letmein' };
  const document = { href: '' };
  const routeSnapshot = new ActivatedRouteSnapshot();
  beforeEach(() => {
    document.href = '';
  });

  it('Is Authorized - href does not change', () => {
    const guard = new AuthorizationGuard(<SecurityTokenService>token, document);
    routeSnapshot.data = { role: 'letmein' };
    expect(guard.canActivate(routeSnapshot, <RouterStateSnapshot>{})).toBeTruthy();
    expect(document.href).toEqual('');
  });

  it('Is Not Authorized - href does change', () => {
    const guard = new AuthorizationGuard(<SecurityTokenService>token, document);
    routeSnapshot.data = { role: 'dontletmein'};
    expect(guard.canActivate(routeSnapshot, <RouterStateSnapshot>{})).toBeFalsy();
    expect(document.href.length).toBeGreaterThan(1);
  });
});
