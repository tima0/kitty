import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { TestBed, inject } from '@angular/core/testing';

import { LoggingService } from './logging.service';
import { LoggingConfigService } from './logging-config.service';

describe('LoggingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [LoggingConfigService]
    });
  });

  it('should be created', inject(
    [HttpClientTestingModule, LoggingService],
    (httpMock: HttpClientTestingModule, service: LoggingService) => {
      expect(service).toBeTruthy();
    }
  ));
});
