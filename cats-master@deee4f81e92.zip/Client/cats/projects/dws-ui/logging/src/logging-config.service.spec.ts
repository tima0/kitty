import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

import { TestBed, inject } from '@angular/core/testing';

import { LoggingConfigService } from './logging-config.service';

describe('LoggingConfigService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: []
    });
  });

  it('should be created', inject(
    [LoggingConfigService],
    (service: LoggingConfigService) => {
      expect(service).toBeTruthy();
    }
  ));

  it('should return log publisher config', inject(
    [HttpTestingController, LoggingConfigService],
    (httpMock: HttpTestingController, service: LoggingConfigService) => {
      // backend.connections.subscribe((connection: MockConnection) => {
      //   const json = `[{"logLevel":1,"loggerName":"console","location":"","isActive":true},
      //                {"logLevel":3,"loggerName":"web","location":"http://localhost:52381/api/log","isActive":false}]`;
      //   const options = new ResponseOptions({ body: json });
      //   connection.mockRespond(new Response(options));
      // });

      service.getLoggers().subscribe(response => {
        expect(response.length).toEqual(2);
        expect(response[0].isActive).toEqual(true);
        expect(response[1].isActive).toEqual(false);
      });
    }
  ));
});
