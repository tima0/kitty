import { Observable, of as observableOf } from 'rxjs';

import { LogEntry } from '../log-entry';
import { LogPublisher } from './log-publisher';

export class LogConsole extends LogPublisher {
  log(logEntry: LogEntry): Observable<boolean> {
    console.log(logEntry.buildLogText());
    return observableOf(true);
  }

  clear(): Observable<boolean> {
    console.clear();
    return observableOf(true);
  }
}
