import { Observable, of as observableOf, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { LogEntry } from '../log-entry';
import { LogPublisher } from './log-publisher';

export class LogWebapi extends LogPublisher {
  constructor(private http: HttpClient) {
    super();
  }

  log(logEntry: LogEntry): Observable<boolean> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    this.http
      .post(this.location, logEntry, { headers })
      .pipe(catchError(this.handleErrors));
    return observableOf(true);
  }

  clear(): Observable<boolean> {
    return observableOf(true);
  }

  private handleErrors(error: any): Observable<any> {
    const errors: string[] = [];
    let msg = '';

    msg = 'Status: ' + error.status;
    msg += ' - Status text: ' + error.statusText;
    if (error.json()) {
      msg += ' - Exception message: ' + error.json().exceptionMessage;
    }

    error.push(error);
    console.error('An error ocurred', errors);
    return throwError(errors);
  }
}
