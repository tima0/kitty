import { LogConsole } from './log-console';

describe('LogConsole', () => {
  let logger: LogConsole;

  beforeEach(() => {
    logger = new LogConsole();
  });

  it('should create an instance', () => {
    expect(logger).toBeTruthy();
  });
});
