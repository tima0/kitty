import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
//import { HttpClient, HttpHeaders, HttpResponse, HttpClientModule } from '@angular/common/http';
import { TestBed, inject } from '@angular/core/testing';
import { LogWebapi } from './log-webapi';
import { LogEntry } from '../log-entry';

describe('LogWebapi', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpClientTestingModule, HttpTestingController]
    });
  });

  it("should call endpoint and return it's result", inject(
    [HttpTestingController],
    (httpMock: HttpTestingController) => {
      const logEntry = new LogEntry();
      logEntry.message = 'test error';
      logEntry.extraInfo = [1];
      logEntry.logTime = new Date();

      // const logger = new LogWebapi(httpMock);
      // logger.log(logEntry).subscribe(response => {
      //   expect(response).toEqual(true);
      // });
    }
  ));
});
