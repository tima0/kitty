import { LogLevel } from '../log-level.enum';
import { Observable } from 'rxjs';
import { LogEntry } from '../log-entry';

export abstract class LogPublisher {
  location = '';
  logLevel: LogLevel = LogLevel.trace;
  abstract log(logEntry: LogEntry): Observable<boolean>;
  abstract clear(): Observable<boolean>;
}
