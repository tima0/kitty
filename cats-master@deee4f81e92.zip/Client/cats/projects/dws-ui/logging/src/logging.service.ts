import { LoggingConfigService } from './logging-config.service';
import { LogEntry } from './log-entry';
import { LogLevel } from './log-level.enum';
import { Injectable } from '@angular/core';
import { LogPublisher } from './publisher/log-publisher';
import { LoggingServiceInterface } from './logging-service-interface';

@Injectable({
  providedIn: 'root'
})
export class LoggingService implements LoggingServiceInterface {
  publishers: LogPublisher[] = [];

  constructor(private loggingConfig: LoggingConfigService) {
    this.publishers = this.loggingConfig.publishers;
  }

  log(logLevel: LogLevel, msg: any, ...params: any[]) {
    this.writeToLog(logLevel, msg, params);
  }

  private writeToLog(logLevel: LogLevel, msg: any, ...params: any[]) {
    const logEntry = new LogEntry();
    logEntry.message = msg;
    logEntry.logTime = new Date();
    logEntry.logLevel = logLevel;
    logEntry.extraInfo = params;

    for (const logger of this.publishers) {
      if (logEntry.logLevel <= logger.logLevel) {
        logger.log(logEntry).subscribe(response => {
          if (!response) {
            console.log('Oops! something went wrong with the logger.');
          }
        });
      }
    }
  }

  debug(msg: string, ...params: any[]) {
    this.writeToLog(LogLevel.debug, msg, params);
  }

  info(msg: string, ...params: any[]) {
    this.writeToLog(LogLevel.information, msg, params);
  }

  warning(msg: string, ...params: any[]) {
    this.writeToLog(LogLevel.warning, msg, params);
  }

  trace(msg: string, ...params: any[]) {
    this.writeToLog(LogLevel.trace, msg, params);
  }

  critical(msg: string, ...params: any[]) {
    this.writeToLog(LogLevel.critical, msg, params);
  }
}
