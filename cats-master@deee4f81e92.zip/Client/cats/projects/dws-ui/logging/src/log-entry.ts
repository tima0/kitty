import { LogLevel } from './log-level.enum';

export class LogEntry {
  message = '';
  logTime: Date = new Date();
  logLevel: LogLevel = LogLevel.trace;
  extraInfo: any[] = [];

  public buildLogText(): string {
    let result = `${this.logTime} - ${LogLevel[this.logLevel]}: ${this.message}`;
    if (this.extraInfo.length) {
      result += ' Extra info: ' + this.extraInfo;
    }
    return result;
  }
}
