import { LogLevel } from './log-level.enum';

export interface LogPublisherConfig {
  logLevel: LogLevel;
  loggerName: string;
  location: string;
  isActive: boolean;
}

