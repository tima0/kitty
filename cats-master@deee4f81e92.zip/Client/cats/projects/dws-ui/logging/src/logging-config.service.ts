import { LogPublisherConfig } from './log-publisher-config';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LogConsole } from './publisher/log-console';
import { Injectable } from '@angular/core';

import { LogWebapi } from './publisher/log-webapi';
import { LogPublisher } from './publisher/log-publisher';

@Injectable({
  providedIn: 'root'
})
export class LoggingConfigService {
  publishers: LogPublisher[] = [];

  constructor(private http: HttpClient) {
    this.buildPublishers();
  }

  getLoggers(): Observable<LogPublisherConfig[]> {
    const logConfigUrl = 'http://localhost:52381/api/logconfig';
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    return this.http
      .get(logConfigUrl, { headers })
      .pipe(catchError(this.handleErrors));
  }

  private buildPublishers(): void {
    let logger: LogPublisher;
    this.getLoggers().subscribe(response => {
      for (const pub of response.filter(p => p.isActive)) {
        switch (pub.loggerName.toLocaleLowerCase()) {
          case 'web':
            logger = new LogWebapi(this.http);
            break;
          case 'console':
            logger = new LogConsole();
            break;
        }
        logger.location = pub.location;
        logger.logLevel = pub.logLevel;
        this.publishers.push(logger);
      }
    });
  }

  private handleErrors(error: any): Observable<any> {
    const errors: string[] = [];
    let msg = '';

    msg = 'Status: ' + error.status;
    msg += ' - Status text: ' + error.statusText;
    if (error.json()) {
      msg += ' - Exception message: ' + error.json().exceptionMessage;
    }

    errors.push(error);
    console.error('An error ocurred', errors);
    return throwError(errors);
  }
}
