export enum LogLevel {
  trace,
  debug,
  information,
  warning,
  error,
  critical
}
