import { LogLevel } from './log-level.enum';
import { LogPublisher } from './publisher/log-publisher';

export class LoggingServiceInterface {
  publishers: LogPublisher[] = [];

  log(logLevel: LogLevel, msg: any, ...params: any[]) {}

  debug(msg: string, ...params: any[]) {}

  info(msg: string, ...params: any[]) {}

  warning(msg: string, ...params: any[]) {}

  trace(msg: string, ...params: any[]) {}

  critical(msg: string, ...params: any[]) {}
}
