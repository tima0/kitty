import { Injectable } from '@angular/core';
import {
  CanDeactivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { Observable } from 'rxjs';

import { BopSearchComponent } from './bop-search/bop-search.component';

@Injectable({
  providedIn: 'root'
})
export class BopSearchDeactivateGuard
  implements CanDeactivate<BopSearchComponent> {
  canDeactivate(
    component: BopSearchComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    component.clearSearchText();
    return true;
  }
}
