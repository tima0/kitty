import { Component, OnInit } from '@angular/core';
import { TitleService } from '../../core/title.service';

// Move this type to it's own file when not a mock up and actually implementing.
class History {
  pid = '';
  name = '';
  lastAccessed = ''; // most likely should be a date here
}

@Component({
  selector: 'cats-bop-search-history',
  templateUrl: './bop-search-history.component.html',
  styles: []
})
export class BopSearchHistoryComponent implements OnInit {
  filterDate: Date = new Date();
  history: History[] = [
    {
      pid: '060113109',
      name: 'Tom Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '041201621',
      name: 'John Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '080275907',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '080380231',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '080002462',
      name: 'Tom Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '080240431',
      name: 'John Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '42232325',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '42232325',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '987654321',
      name: 'Tom Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '23332321',
      name: 'John Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '42232325',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '42232325',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '987654321',
      name: 'Tom Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '23332321',
      name: 'John Clancy',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '42232325',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    },
    {
      pid: '42232325',
      name: 'John Doe',
      lastAccessed: '23 Aug 2015'
    }
  ];

  constructor(private titleService: TitleService) {}

  ngOnInit() {
    this.titleService.setTitle('Bop Home Page', 'Bop - Home Page');
  }
}
