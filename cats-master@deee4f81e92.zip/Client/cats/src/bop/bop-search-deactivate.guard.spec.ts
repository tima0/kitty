import { TestBed, async, inject } from '@angular/core/testing';

import { BopSearchDeactivateGuard } from './bop-search-deactivate.guard';

describe('BopSearchDeactivateGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BopSearchDeactivateGuard]
    });
  });

  it('should ...', inject([BopSearchDeactivateGuard], (guard: BopSearchDeactivateGuard) => {
    expect(guard).toBeTruthy();
  }));
});
