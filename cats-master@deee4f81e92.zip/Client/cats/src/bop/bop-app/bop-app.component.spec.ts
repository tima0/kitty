import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopAppComponent } from './bop-app.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('BopAppComponent', () => {
  let component: BopAppComponent;
  let fixture: ComponentFixture<BopAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BopAppComponent],
      imports: [RouterTestingModule],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
