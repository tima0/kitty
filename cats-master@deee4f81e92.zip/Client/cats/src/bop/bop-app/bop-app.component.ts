import { Component, OnInit } from '@angular/core';
import { SideMenuService } from '../../core/side-menu.service';
import { SearchBoxService } from '../../core/search-box.service';
import { RouterLink, Router } from '@angular/router';
import { TopMenuService } from '../../core/top-menu.service';
import { MenuItem } from 'primeng/api';
import { BopMenuItems } from '../../core/common-menu.const';

//  Temp for Mock ups, don't keep this class here
class QueueList {
  name = '';
}

@Component({
  selector: 'cats-bop-app',
  templateUrl: './bop-app.component.html',
  styles: []
})
export class BopAppComponent implements OnInit {
  showQueueSelection = true;
  workMenuItems: MenuItem[] = BopMenuItems;
  queueSelectionOptions: QueueList[] = [
    { name: 'Current Work' },
    { name: 'Garnishment' },
    { name: 'Assigned Account List' }
  ];
  queueSelection: QueueList = new QueueList();

  constructor(
    private menuService: SideMenuService,
    private topMenuService: TopMenuService,
    private search: SearchBoxService,
    private router: Router
  ) {}

  ngOnInit() {
    // this.menuService.changeMenu([
    //   { label: 'Load Account 123', routerLink: 'bop/123' }
    // ]);
    this.menuService.changeToDefault();
    this.topMenuService.changeToDefault();
    this.search.clearSearchText();
    this.search.setupSearch({
      visible: true,
      minChar: 3,
      performSearch: (searchText: string) => {
        this.router.navigate(['/bop/search/'], {
          queryParams: { query: searchText }
        });
      }
    });
  }

  flipShowQueueSelection() {
    this.showQueueSelection = !this.showQueueSelection;
  }
}
