import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BopAppComponent } from './bop-app/bop-app.component';
import { BopSearchHistoryComponent } from './bop-search-history/bop-search-history.component';
import { ClaimantComponent } from './claimant/claimant.component';
import { BopCurrentWorkComponent } from './bop-current-work/bop-current-work.component';
import { BopGarnQueueComponent } from './bop-garn-queue/bop-garn-queue.component';
import { BopAssignedAccountListComponent } from './bop-assigned-account-list/bop-assigned-account-list.component';
import { BopBankruptcyComponent } from './bop-bankruptcy/bop-bankruptcy.component';
import { BopProsecutionComponent } from './bop-prosecution/bop-prosecution.component';
import { BopSearchComponent } from './bop-search/bop-search.component';
import { BopSearchDeactivateGuard } from './bop-search-deactivate.guard';
import { ClaimantResolver } from './claimant/claimant.resolver';

const routes: Routes = [
  {
    path: '',
    component: BopAppComponent,
    children: [
      { path: '', component: BopSearchHistoryComponent },
      {
        path: 'claimant/:id',
        component: ClaimantComponent,
        resolve: { claimant: ClaimantResolver }
      },
      { path: 'current', component: BopCurrentWorkComponent },
      { path: 'garn', component: BopGarnQueueComponent },
      { path: 'assigned-account', component: BopAssignedAccountListComponent },
      { path: 'bankruptcy', component: BopBankruptcyComponent },
      { path: 'prosecution', component: BopProsecutionComponent },
      {
        path: 'search',
        component: BopSearchComponent,
        canDeactivate: [BopSearchDeactivateGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [BopSearchDeactivateGuard]
})
export class BopRoutingModule {}
