import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopGarnQueueComponent } from './bop-garn-queue.component';

describe('BopGarnQueueComponent', () => {
  let component: BopGarnQueueComponent;
  let fixture: ComponentFixture<BopGarnQueueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopGarnQueueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopGarnQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
