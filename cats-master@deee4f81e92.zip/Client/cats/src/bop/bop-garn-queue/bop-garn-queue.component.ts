import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cats-bop-garn-queue',
  templateUrl: './bop-garn-queue.component.html',
  styles: []
})
export class BopGarnQueueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
