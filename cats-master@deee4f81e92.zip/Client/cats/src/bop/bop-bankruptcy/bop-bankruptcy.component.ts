import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cats-bop-bankruptcy',
  templateUrl: './bop-bankruptcy.component.html',
  styles: []
})
export class BopBankruptcyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
