import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopBankruptcyComponent } from './bop-bankruptcy.component';

describe('BopBankruptcyComponent', () => {
  let component: BopBankruptcyComponent;
  let fixture: ComponentFixture<BopBankruptcyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopBankruptcyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopBankruptcyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
