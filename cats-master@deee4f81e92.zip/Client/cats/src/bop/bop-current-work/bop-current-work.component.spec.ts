import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopCurrentWorkComponent } from './bop-current-work.component';

describe('BopCurrentWorkComponent', () => {
  let component: BopCurrentWorkComponent;
  let fixture: ComponentFixture<BopCurrentWorkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BopCurrentWorkComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopCurrentWorkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
