import { Component, OnInit } from '@angular/core';
import { TitleService } from '../../core/title.service';

// Move this type to it's own file when not a mock up and actually implementing.
class CurrentWork {
  pid = '';
  name = '';
  acctBalance = '';
  lastPmtDate = '';
  lastPmtType = '';
  followupDate = '';
}

@Component({
  selector: 'cats-bop-current-work',
  templateUrl: './bop-current-work.component.html',
  styles: []
})
export class BopCurrentWorkComponent implements OnInit {
  followupDate: Date = new Date();
  currentWork: CurrentWork[] = [];
  constructor(private titleService: TitleService) {}

  ngOnInit() {
    this.titleService.setTitle('Current Work', 'Bop - Current Work');
    // Mock Data
    this.currentWork = [
      {
        pid: '12325455',
        name: 'John Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'FTI',
        followupDate: ''
      },
      {
        pid: '3235265',
        name: 'Jane Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Garnishment',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '12325455',
        name: 'John Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'FTI',
        followupDate: ''
      },
      {
        pid: '3235265',
        name: 'Jane Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Garnishment',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '12325455',
        name: 'John Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'FTI',
        followupDate: ''
      },
      {
        pid: '3235265',
        name: 'Jane Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Garnishment',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '12325455',
        name: 'John Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'FTI',
        followupDate: '12 Dec 2013'
      },
      {
        pid: '3235265',
        name: 'Jane Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Garnishment',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      },
      {
        pid: '723235455',
        name: 'Misty Doe',
        acctBalance: '$24,444.00',
        lastPmtDate: '12 Dec 2017',
        lastPmtType: 'Credit Card',
        followupDate: ''
      }
    ];
  }
}
