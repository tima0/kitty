import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BopRoutingModule } from './bop-routing.module';
import { ClaimantComponent } from './claimant/claimant.component';
import { BopSearchHistoryComponent } from './bop-search-history/bop-search-history.component';
import { BopAppComponent } from './bop-app/bop-app.component';
import { SharedModule } from '../shared/shared.module';
import { BopCurrentWorkComponent } from './bop-current-work/bop-current-work.component';
import { BopGarnQueueComponent } from './bop-garn-queue/bop-garn-queue.component';
import { BopAssignedAccountListComponent } from './bop-assigned-account-list/bop-assigned-account-list.component';
import { BopBankruptcyComponent } from './bop-bankruptcy/bop-bankruptcy.component';
import { BopProsecutionComponent } from './bop-prosecution/bop-prosecution.component';
import { BopSearchComponent } from './bop-search/bop-search.component';

@NgModule({
  imports: [CommonModule, SharedModule, BopRoutingModule],
  declarations: [
    ClaimantComponent,
    BopSearchHistoryComponent,
    BopAppComponent,
    BopCurrentWorkComponent,
    BopGarnQueueComponent,
    BopAssignedAccountListComponent,
    BopBankruptcyComponent,
    BopProsecutionComponent,
    BopSearchComponent
  ]
})
export class BopModule {}
