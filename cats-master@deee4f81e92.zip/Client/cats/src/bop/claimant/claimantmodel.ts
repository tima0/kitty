export class ClaimantModel {
  PartyID: number;
  PID: string;
  CliId?: number;
  LastName?: string;
  FirstName?: string;
  MiddleName?: string;
  Email?: string;
  BadEmailFlag?: boolean;
  BirthDate?: Date;
  DriversLicenseNumber?: string;
  MothersMaidenName?: string;
  WriteoffIndicator?: boolean;

  constructor() {
    this.PartyID = 0;
    this.PID = '';
  }
}
