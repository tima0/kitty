import { TestBed, inject } from '@angular/core/testing';
import { ClaimantService } from './claimant.service';
import {
  HttpTestingController,
  HttpClientTestingModule
} from '@angular/common/http/testing';

describe('ClaimantService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ClaimantService]
    });
  });

  it('should be created', inject(
    [HttpTestingController, ClaimantService],
    (service: ClaimantService) => {
      expect(service).toBeTruthy();
    }
  ));
});
