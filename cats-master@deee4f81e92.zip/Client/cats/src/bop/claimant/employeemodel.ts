export class EmployeeModel {
  FIRSTNAME = '';
  JOB = '';
  LASTNAME = '';

  constructor() {}
}
