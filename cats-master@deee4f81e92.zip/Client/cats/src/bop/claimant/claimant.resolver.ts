import {
  Resolve,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { ClaimantModel } from './claimantmodel';
import { Injectable } from '@angular/core';
import { ClaimantService } from './claimant.service';

@Injectable({
  providedIn: 'root'
})
export class ClaimantResolver implements Resolve<ClaimantModel> {
  constructor(private claimantservice: ClaimantService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const id = route.paramMap.get('id');
    const pid: string = id === null ? '0' : id;
    return this.claimantservice.GetClaimant(pid);
  }
}
