import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimantComponent } from './claimant.component';
import { TitleService } from '../../core/title.service';
import { TestLoggingService } from 'projects/dws-ui/test/test-logging-service';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ClaimantComponent', () => {
  let component: ClaimantComponent;
  let fixture: ComponentFixture<ClaimantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClaimantComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ id: '123' })
          }
        },
        TitleService,
        TestLoggingService
      ],
      imports: [HttpClientTestingModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
