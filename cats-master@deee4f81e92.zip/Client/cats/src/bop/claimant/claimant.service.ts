import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ClaimantModel } from './claimantmodel';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ClaimantService {
  claimantApiUrl = '';

  constructor(private httpClient: HttpClient) {}

  GetClaimant(pid: string): Observable<ClaimantModel> {
    console.log('Running ClaimantService.GetClaimaint().');
    // I don't like that the URL root is literal here.  If route path rewrites change, this is a sparse side-effect.
    this.claimantApiUrl = `app/api/v1.0/bop/claimants/${pid}`;
    return this.httpClient.get<ClaimantModel>(this.claimantApiUrl);
  }
}
