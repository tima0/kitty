import { Component, OnInit } from '@angular/core';
import { TitleService } from '../../core/title.service';
import { ActivatedRoute } from '@angular/router';
import { LoggingService } from 'projects/dws-ui/public_api';
import { ClaimantModel } from './claimantmodel';
//import { ClaimantService } from './claimant.service';

@Component({
  selector: 'cats-claimant',
  templateUrl: './claimant.component.html',
  styles: []
})
export class ClaimantComponent implements OnInit {
  public id = '';
  public name = 'My Name is Inigo Montoya';
  public claimant: ClaimantModel = new ClaimantModel();

  //claimantApiUrl = `app/api/claimant/${this.id}`;
  claimantApiUrl = '';

  constructor(
    private route: ActivatedRoute,
    private titleService: TitleService,
    private logger: LoggingService
  ) {
    // Logger not working yet.  The publishers object is undefined.
    //this.logger.critical('ClaimantComponent .ctor Test');
    this.logger.info('ClaimantComponent .ctor Test');
    // console.log('ClaimantComponent .ctor Test');
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params['id'];
      this.claimant = this.route.snapshot.data['claimant'];
      this.titleService.setTitle(
        this.name + ' - ' + this.id,
        'Bop - ' + this.name
      );
    });
  }
}
