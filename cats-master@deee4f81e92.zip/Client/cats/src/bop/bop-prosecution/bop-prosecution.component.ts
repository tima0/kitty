import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cats-bop-prosecution',
  templateUrl: './bop-prosecution.component.html',
  styles: []
})
export class BopProsecutionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
