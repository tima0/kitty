import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopProsecutionComponent } from './bop-prosecution.component';

describe('BopProsecutionComponent', () => {
  let component: BopProsecutionComponent;
  let fixture: ComponentFixture<BopProsecutionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopProsecutionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopProsecutionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
