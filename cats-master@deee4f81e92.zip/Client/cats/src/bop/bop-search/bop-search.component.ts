import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { SearchBoxService } from '../../core/search-box.service';
import { GridColumn } from '../../shared/grid/grid-column';

@Component({
  selector: 'cats-bop-search',
  templateUrl: './bop-search.component.html',
  styles: []
})
export class BopSearchComponent implements OnInit {
  public queryString = '';
  public gridColumns: GridColumn[] = [
    { field: 'prtyId', header: 'Party ID' },
    { field: 'firstName', header: 'First Name' },
    { field: 'lastName', header: 'Last Name' },
    { field: 'ssn', header: 'SSN' }
  ];
  constructor(
    private searchBox: SearchBoxService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.queryString = params['query'];
      console.log(this.queryString);
      this.searchBox.setSearchText(this.queryString);
    });
  }

  // Called by deactive Guard
  clearSearchText() {
    this.searchBox.clearSearchText();
  }
}
