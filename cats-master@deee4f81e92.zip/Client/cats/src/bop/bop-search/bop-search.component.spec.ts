import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';

import { Observable } from 'rxjs';
import { of } from 'rxjs';

import { BopSearchComponent } from './bop-search.component';
import { SearchBoxService } from '../../core/search-box.service';

describe('BopSearchComponent', () => {
  let component: BopSearchComponent;
  let fixture: ComponentFixture<BopSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      declarations: [BopSearchComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: of({ query: 123 })
          }
        },
        {
          provide: SearchBoxService,
          useValue: {
            setSearchText: (search: string) => {},
            clearSearchText: () => {}
          }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
