import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopAssignedAccountListComponent } from './bop-assigned-account-list.component';

describe('BopAssignedAccountListComponent', () => {
  let component: BopAssignedAccountListComponent;
  let fixture: ComponentFixture<BopAssignedAccountListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopAssignedAccountListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopAssignedAccountListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
