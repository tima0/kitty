import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cats-bop-assigned-account-list',
  templateUrl: './bop-assigned-account-list.component.html',
  styles: []
})
export class BopAssignedAccountListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
