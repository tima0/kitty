import { BopModule } from './bop.module';

describe('BopModule', () => {
  let bopModule: BopModule;

  beforeEach(() => {
    bopModule = new BopModule();
  });

  it('should create an instance', () => {
    expect(bopModule).toBeTruthy();
  });
});
