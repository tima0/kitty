import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { CardModule } from 'primeng/card';
import { DropdownModule } from 'primeng/dropdown';
import { MenuModule } from 'primeng/menu';
import { PaginatorModule } from 'primeng/paginator';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ToolbarModule } from 'primeng/toolbar';

import { BootstrapRulerComponent } from './bootstrap-ruler/bootstrap-ruler.component';
import { GridComponent } from './grid/grid.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ButtonModule,
    CalendarModule,
    CardModule,
    DropdownModule,
    MenuModule,
    PaginatorModule,
    ScrollPanelModule,
    TableModule,
    TabViewModule,
    ToolbarModule
  ],
  declarations: [BootstrapRulerComponent, GridComponent],
  exports: [
    CommonModule,
    FormsModule,
    GridComponent,
    BootstrapRulerComponent,
    ButtonModule,
    CalendarModule,
    CardModule,
    DropdownModule,
    MenuModule,
    PaginatorModule,
    ScrollPanelModule,
    TableModule,
    TabViewModule,
    ToolbarModule
  ]
})
export class SharedModule {}
