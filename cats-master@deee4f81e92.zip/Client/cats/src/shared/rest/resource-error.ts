export class ResourceError {
  userErrorMessage = '';
  techErrorMessage = '';
}
