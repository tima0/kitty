// import { Injectable } from '@angular/core';
// import { HttpClient, HttpParams } from '@angular/common/http';
// import { Observable } from 'rxjs';

// import { GetResourceService } from './get-resource.service';
// import { ResourceError } from './resource-error';
// import { CollectionEnvelope } from './collection-envelope';
// import { FieldOrder } from './field-order';
// import { CollectionParamsService } from './collection-params.service';
// import { CollectionPage } from './collection-page';

// @Injectable({
//   providedIn: 'root'
// })
// export class GetResourceCollectionService<T> extends GetResourceService<
//   CollectionEnvelope<T>
// > {
//   constructor(
//     http: HttpClient,
//     url: string,
//     private paramService: CollectionParamsService
//   ) {
//     super(http, url);
//   }
//   public get(
//     params?: HttpParams,
//     sort?: FieldOrder[],
//     paging?: CollectionPage
//   ): Observable<CollectionEnvelope<T> | ResourceError> {
//     const fullParams = this.paramService.getQueryParams({
//       order: sort,
//       paging: paging,
//       filter: params
//     });
//     return super.get(fullParams);
//   }
// }
