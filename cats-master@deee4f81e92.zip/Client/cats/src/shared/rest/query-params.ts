import { HttpParams } from '@angular/common/http';

export type ParamValue = string | number | boolean | Date;

export interface QueryParamCodec {
  encodeValue(value: ParamValue): string;
}

export class QueryParamEncoding implements QueryParamCodec {
  encodeValue(value: ParamValue): string {
    if (typeof value === 'string') {
      return value;
    } else if (typeof value === 'number') {
      return value.toString();
    } else if (typeof value === 'boolean') {
      return value ? '1' : '0';
    }
    if (typeof value === 'object') {
      if (value instanceof Date) {
        return value.toJSON();
      }
    }
    throw new Error('Unhandled ParamValue type in QueryParamEncoding');
  }
}

export class QueryParam {
  constructor(
    public readonly paramName: string,
    public readonly paramValue: ParamValue
  ) {}
}

export class QueryParams {
  readonly params: QueryParam[];
  readonly encoding: QueryParamCodec;

  constructor(options?: {
    readonly params?: QueryParam[];
    readonly encoding?: QueryParamCodec;
  }) {
    this.encoding =
      options && options.encoding ? options.encoding : new QueryParamEncoding();
    this.params = options && options.params ? options.params.slice(0) : [];
  }

  public append(name: string, value: ParamValue): QueryParams {
    let newParams: QueryParam[];
    newParams = this.params.slice(0);
    newParams.push(new QueryParam(name, value));
    return new QueryParams({ params: newParams, encoding: this.encoding });
  }
  public toHttpParams(): HttpParams {
    const objParams: { [param: string]: string | string[] } = {};
    this.params.forEach(val => {
      objParams[val.paramName] = this.encoding.encodeValue(val.paramValue);
    });
    return new HttpParams({ fromObject: objParams });
  }
}
