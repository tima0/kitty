import {
  QueryParam,
  QueryParams,
  QueryParamEncoding,
  ParamValue
} from './query-params';
import { Query } from '@angular/core';

describe('QueryParams', () => {
  it('construction - no params', () => {
    const queryParams = new QueryParams();
    expect(queryParams).toBeTruthy();
    expect(queryParams.toHttpParams().keys.length).toBe(0);
  });

  it('construction - default param', () => {
    const queryParams = new QueryParams({
      params: [new QueryParam('name1', 'value1')]
    });
    expect(queryParams).toBeTruthy();
    expect(queryParams.toHttpParams().keys().length).toBe(1);
    expect(queryParams.toHttpParams().get('name1')).toBe('value1');
  });

  it('ability to append params w/ immutability', () => {
    const queryParams = new QueryParams().append('name1', 'value1');
    const queryParams2 = queryParams.append('name2', 'value2');
    expect(queryParams.toHttpParams().keys().length).toBe(1);
    expect(queryParams2.toHttpParams().keys().length).toBe(2);
  });
});

describe('QueryParamEncoding', () => {
  let encoder: QueryParamEncoding;
  beforeEach(() => {
    encoder = new QueryParamEncoding();
  });

  it('string type', () => {
    const value: ParamValue = 'stringvalue';
    const encodedValue = encoder.encodeValue(value);
    expect(encodedValue).toBe(value);
  });

  it('number type', () => {
    const value: ParamValue = 1;
    const encodedValue = encoder.encodeValue(value);
    expect(encodedValue).toBe(value.toString());
  });

  it('boolean type: true', () => {
    const value: ParamValue = true;
    const encodedValue = encoder.encodeValue(value);
    expect(encodedValue).toBe('1');
  });

  it('boolean type: false', () => {
    const value: ParamValue = false;
    const encodedValue = encoder.encodeValue(value);
    expect(encodedValue).toBe('0');
  });

  it('boolean type: 10', () => {
    const value: ParamValue = Boolean(10);
    const encodedValue = encoder.encodeValue(value);
    expect(encodedValue).toBe('1');
  });

  it('boolean type: 0', () => {
    const value: ParamValue = Boolean(0);
    const encodedValue = encoder.encodeValue(value);
    expect(encodedValue).toBe('0');
  });

  it('Date type', () => {
    const value: ParamValue = new Date();
    const encodedValue = encoder.encodeValue(value);
    expect(encodedValue).toBe(value.toJSON());
  });
});
