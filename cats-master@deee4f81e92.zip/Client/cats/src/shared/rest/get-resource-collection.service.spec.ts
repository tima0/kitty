// import { TestBed, inject } from '@angular/core/testing';

// // import { GetResourceCollectionService } from './get-resource-collection.service';

// describe('GetResourceCollectionService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [GetResourceCollectionService]
//     });
//   });

//   // it('should be created', inject([GetResourceCollectionService], (service: GetResourceCollectionService<MockType>) => {
//   //   expect(service).toBeTruthy();
//   // }));
// });
