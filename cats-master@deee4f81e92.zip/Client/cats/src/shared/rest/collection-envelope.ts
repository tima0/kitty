export class CollectionEnvelopePaging {
  constructor(public rowOffset: number, public pageNum: number) {}
}

export class CollectionEnvelope<T> {
  constructor(
    public count: number,
    public data: T[],
    public paging?: CollectionEnvelopePaging
  ) {}
}
