// import { TestBed, inject, getTestBed } from '@angular/core/testing';
// import { HttpClientModule, HttpClient } from '@angular/common/http';
// import {
//   HttpClientTestingModule,
//   HttpTestingController
// } from '@angular/common/http/testing';

// import { GetResourceService } from './get-resource.service';

// class MockType {
//   field1 = '';
//   field2 = 1;
//   field3 = false;
//   field4 = new Date();
// }

// describe('GetResourceService', () => {
//   let injector: TestBed;
//   let httpMock: HttpTestingController;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientModule, HttpClientTestingModule],
//       providers: [GetResourceService]
//     });
//     injector = getTestBed();
//     httpMock = injector.get(HttpTestingController);
//   });

//   it('should be created', inject(
//     [GetResourceService],
//     (service: GetResourceService<MockType>) => {
//       expect(service).toBeTruthy();
//     }
//   ));
// });
