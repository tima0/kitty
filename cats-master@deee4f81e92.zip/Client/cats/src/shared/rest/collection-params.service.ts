import { Injectable, Type } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Params } from '@angular/router';
import { FieldOrder } from './field-order';
import { CollectionPage } from './collection-page';

export const orderQueryKey = '_order';
export const rowOffsetQueryKey = '_rowoffset';
export const pageSizeQueryKey = '_pagesize';

@Injectable({
  providedIn: 'root'
})
export class CollectionParamsService {
  constructor() {}

  public getQueryParams(options: {
    order?: FieldOrder[];
    paging?: CollectionPage;
    filter?: HttpParams;
  }): HttpParams {
    let params = options.filter ? options.filter : new HttpParams();
    params = options.order ? this.addOrder(options.order, params) : params;
    params = options.paging ? this.addPaging(options.paging, params) : params;
    return params;
  }

  private addOrder(order: FieldOrder[], params: HttpParams): HttpParams {
    let fields = '';
    if (order.length > 0) {
      order.forEach((val, idx, arr) => {
        if (!val.asc) {
          fields += '-';
        }

        fields += val.fieldName;
        if (!(idx === arr.length - 1)) {
          fields += ',';
        }
      });
    }
    return fields.length > 0 ? params.append(orderQueryKey, fields) : params;
  }

  private addPaging(paging: CollectionPage, params: HttpParams): HttpParams {
    return params
      .append(rowOffsetQueryKey, paging.pageSize.toString())
      .append(pageSizeQueryKey, paging.pageSize.toString());
  }
}
