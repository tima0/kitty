export class FieldOrder {
  constructor(public fieldName: string, public asc: boolean) {}
}
