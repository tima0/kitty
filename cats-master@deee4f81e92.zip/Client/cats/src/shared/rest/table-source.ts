// import { Table } from 'primeng/table';
// import { HttpParams } from '@angular/common/http';
// import { LazyLoadEvent } from 'primeng/components/common/api';
// import { CollectionEnvelope } from './collection-envelope';
// import { GetResourceCollectionService } from './get-resource-collection.service';
// import { FieldOrder } from './field-order';
// import { CollectionPage } from './collection-page';

// export class TableSource<T> {
//   private _dataEnvelope: CollectionEnvelope<T> = { count: 0, data: [] };

//   public get dataEnvelope(): CollectionEnvelope<T> {
//     return this.dataEnvelope;
//   }

//   constructor(
//     private baseParams: HttpParams,
//     private dataService: GetResourceCollectionService<T>,
//     private table: Table
//   ) {
//     table.onLazyLoad.subscribe((event: LazyLoadEvent) => {
//       this.loadDataEvent(event);
//     });
//   }

//   public bind(
//     baseParams: HttpParams,
//     dataService: GetResourceCollectionService<T>,
//     table: Table
//   ) {
//     table.loading = true;
//   }

//   public loadDataEvent(event: LazyLoadEvent) {
//     let sortOrder: FieldOrder[] | undefined;
//     // A Single Sort is Selected.
//     if (event.sortField && event.sortOrder) {
//       sortOrder = [];
//       // Sort order as number, 1 for asc and -1 for dec in single sort mode
//       sortOrder.push({
//         fieldName: event.sortField,
//         asc: event.sortOrder === 1
//       });
//     }
//     // A Multi Sort is Selected
//     if (event.multiSortMeta) {
//       sortOrder = [];
//       for (const so of event.multiSortMeta) {
//         sortOrder.push({ fieldName: so.field, asc: so.order === 1 });
//       }
//     }

//     let paging: CollectionPage | undefined;
//     if (this.table.paginator === true && event.rows) {
//       paging = new CollectionPage(event.first ? event.first : 0, event.rows);
//     }
//     this.dataService.get(this.baseParams, sortOrder, paging);
//   }
//   public updateParams(baseParams: HttpParams) {}
// }
