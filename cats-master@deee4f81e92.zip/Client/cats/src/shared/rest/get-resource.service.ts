// import { Injectable } from '@angular/core';
// import {
//   HttpClient,
//   HttpErrorResponse,
//   HttpParams
// } from '@angular/common/http';

// import { Observable, of } from 'rxjs';
// import { catchError } from 'rxjs/operators';
// import { ResourceError } from './resource-error';

// @Injectable({
//   providedIn: 'root'
// })
// export class GetResourceService<T> {
//   constructor(private http: HttpClient, private url: string) {}

//   private handleError(httpError: HttpErrorResponse): Observable<ResourceError> {
//     const resourceError = new ResourceError();
//     if (httpError.error instanceof Error) {
//       // A client-side or network error occurred. Handle it accordingly.
//       resourceError.techErrorMessage = httpError.error.message;
//     } else {
//       // The backend returned an unsuccessful response code.
//       // The response body may contain clues as to what went wrong,
//       console.error(
//         `Backend returned code ${httpError.status}, body was: ${
//           httpError.error
//         }`
//       );
//       resourceError.techErrorMessage = httpError.error.body;
//     }

//     return of(resourceError);
//   }

//   public get(params?: HttpParams): Observable<T | ResourceError> {
//     return this.http
//       .get<T | ResourceError>(this.url, {
//         params: params,
//         responseType: 'json'
//       })
//       .pipe(catchError(this.handleError));
//   }
// }
