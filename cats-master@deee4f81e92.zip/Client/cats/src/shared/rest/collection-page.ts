export class CollectionPage {
  constructor(public rowOffset: number, public pageSize: number) {}
}
