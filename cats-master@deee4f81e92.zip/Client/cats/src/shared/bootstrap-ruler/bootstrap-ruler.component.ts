import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cats-bootstrap-ruler',
  templateUrl: './bootstrap-ruler.component.html',
  styles: []
})
export class BootstrapRulerComponent implements OnInit {
// This component is to help layout areas of code and should typically not be left in code when
// working with the layout.

  constructor() { }

  ngOnInit() {
  }

}
