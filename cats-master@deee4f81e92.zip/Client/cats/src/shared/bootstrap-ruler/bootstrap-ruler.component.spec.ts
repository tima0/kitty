import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BootstrapRulerComponent } from './bootstrap-ruler.component';

describe('BootstrapRulerComponent', () => {
  let component: BootstrapRulerComponent;
  let fixture: ComponentFixture<BootstrapRulerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BootstrapRulerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BootstrapRulerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
