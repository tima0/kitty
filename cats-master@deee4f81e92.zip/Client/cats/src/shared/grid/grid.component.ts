import { Component, OnInit, Input } from '@angular/core';
import { GridColumn } from './grid-column';

@Component({
  selector: 'cats-grid',
  templateUrl: './grid.component.html',
  styles: []
})
export class GridComponent implements OnInit {
  @Input()
  gridColumns: GridColumn[] = [];
  @Input()
  caption?: string;
  rows: any[] = [];
  constructor() {}

  ngOnInit() {}
}
