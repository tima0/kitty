export interface GridColumn {
  field: string;
  // orderFields?: string;
  header: string;
}
