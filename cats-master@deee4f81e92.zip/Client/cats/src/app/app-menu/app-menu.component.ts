import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  EventEmitter,
  ViewChild
} from '@angular/core';
import {
  trigger,
  state,
  style,
  transition,
  animate
} from '@angular/animations';
import { MenuItem } from 'primeng/primeng';

import { SideMenuService } from '../../core/side-menu.service';
import { AppComponent } from '../app/app.component';
import { AppSubMenuComponent } from '../app-submenu/app-submenu.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'cats-menu',
  templateUrl: './app-menu.component.html'
})
export class AppMenuComponent implements OnInit, OnDestroy {
  @Input() reset: boolean;

  model: any[];

  theme = 'blue';

  layout = 'blue';

  version = 'v3';

  private dashboardMenu: MenuItem = {
    label: 'Dashboard',
    icon: 'fa fa-fw fa-home',
    routerLink: ['/']
  };

  private menuSubscription?: Subscription;
  constructor(public app: AppComponent, private menuService: SideMenuService) {
    this.reset = false;
    this.model = [];
  }

  ngOnDestroy() {
    if (this.menuSubscription) {
      this.menuSubscription.unsubscribe();
    }
  }

  ngOnInit() {
    this.menuSubscription = this.menuService.currentMenu$.subscribe(m => {
      this.model = [this.dashboardMenu].concat(m);
    });
    // this.model = [
    //   { label: 'Dashboard', icon: 'fa fa-fw fa-home', routerLink: ['/'] },
    //   {
    //     label: 'Menu Hierarchy',
    //     icon: 'fa fa-fw fa-gg',
    //     items: [
    //       {
    //         label: 'Submenu 1',
    //         icon: 'fa fa-fw fa-sign-in',
    //         items: [
    //           {
    //             label: 'Submenu 1.1',
    //             icon: 'fa fa-fw fa-sign-in',
    //             items: [
    //               { label: 'Submenu 1.1.1', icon: 'fa fa-fw fa-sign-in' },
    //               { label: 'Submenu 1.1.2', icon: 'fa fa-fw fa-sign-in' },
    //               { label: 'Submenu 1.1.3', icon: 'fa fa-fw fa-sign-in' }
    //             ]
    //           },
    //           {
    //             label: 'Submenu 1.2',
    //             icon: 'fa fa-fw fa-sign-in',
    //             items: [
    //               { label: 'Submenu 1.2.1', icon: 'fa fa-fw fa-sign-in' },
    //               { label: 'Submenu 1.2.2', icon: 'fa fa-fw fa-sign-in' }
    //             ]
    //           }
    //         ]
    //       },
    //       {
    //         label: 'Submenu 2',
    //         icon: 'fa fa-fw fa-sign-in',
    //         items: [
    //           {
    //             label: 'Submenu 2.1',
    //             icon: 'fa fa-fw fa-sign-in',
    //             items: [
    //               { label: 'Submenu 2.1.1', icon: 'fa fa-fw fa-sign-in' },
    //               { label: 'Submenu 2.1.2', icon: 'fa fa-fw fa-sign-in' },
    //               { label: 'Submenu 2.1.3', icon: 'fa fa-fw fa-sign-in' }
    //             ]
    //           },
    //           {
    //             label: 'Submenu 2.2',
    //             icon: 'fa fa-fw fa-sign-in',
    //             items: [
    //               { label: 'Submenu 2.2.1', icon: 'fa fa-fw fa-sign-in' },
    //               { label: 'Submenu 2.2.2', icon: 'fa fa-fw fa-sign-in' }
    //             ]
    //           }
    //         ]
    //       }
    //     ]
    //   }
    // ];
  }
}
