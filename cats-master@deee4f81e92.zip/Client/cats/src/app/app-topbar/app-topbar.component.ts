import { Component, OnInit, OnDestroy } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Subscription } from 'rxjs';

import { MenuItem } from 'primeng/primeng';

import { AppComponent } from '../app/app.component';
import { SearchBoxService } from '../../core/search-box.service';
import {
  PerformSearchFunction,
  SearchBoxConfig
} from '../../core/search-box-config';
import { ProfileInfoService } from '../../core/profile-info.service';
import { ProfileInfo } from '../../core/profile-info';
import { TopMenuService } from '../../core/top-menu.service';
import { TitleService } from '../../core/title.service';

@Component({
  selector: 'cats-topbar',
  templateUrl: './app-topbar.component.html'
})
export class AppTopBarComponent implements OnInit, OnDestroy {
  public profileInfo: ProfileInfo = ProfileInfo.defaultEmptyProfile();
  public searchText = '';
  public searchConfig: SearchBoxConfig = {
    visible: false,
    minChar: 0,
    performSearch: (searchtext: string) => {}
  };
  public topMenu: MenuItem[] = [];
  public appTitle = '';
  private searchSubscription?: Subscription;
  private searchTextSubscription?: Subscription;
  private profileSubscription?: Subscription;
  private topMenuSubscription?: Subscription;
  private appTitleSubscription?: Subscription;
  private browserTitleSubscription?: Subscription;

  constructor(
    public app: AppComponent,
    private search: SearchBoxService,
    private profileService: ProfileInfoService,
    private topMenuService: TopMenuService,
    private titleService: TitleService,
    private browserTitleService: Title
  ) {}

  ngOnInit() {
    this.searchSubscription = this.search.currentSearchConfig$.subscribe(
      config => {
        this.searchConfig = config;
      }
    );
    this.searchTextSubscription = this.search.searchTextSource$.subscribe(
      searchText => {
        this.searchText = searchText;
      }
    );
    this.profileSubscription = this.profileService.profileInfoConfig$.subscribe(
      p => {
        this.profileInfo = p;
      }
    );
    this.topMenuSubscription = this.topMenuService.currentMenu$.subscribe(m => {
      this.topMenu = m;
      console.log(this.topMenu);
    });
    this.appTitleSubscription = this.titleService.currentAppTitle$.subscribe(
      t => {
        this.appTitle = t;
      }
    );
    this.browserTitleSubscription = this.titleService.currentBrowserTitle$.subscribe(
      t => {
        this.browserTitleService.setTitle(t);
      }
    );
  }

  ngOnDestroy() {
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
    if (this.searchTextSubscription) {
      this.searchTextSubscription.unsubscribe();
    }
    if (this.profileSubscription) {
      this.profileSubscription.unsubscribe();
    }
    if (this.topMenuSubscription) {
      this.topMenuSubscription.unsubscribe();
    }
    if (this.appTitleSubscription) {
      this.appTitleSubscription.unsubscribe();
    }
    if (this.browserTitleSubscription) {
      this.browserTitleSubscription.unsubscribe();
    }
  }

  performSearch() {
    this.searchConfig.performSearch(this.searchText);
  }
}
