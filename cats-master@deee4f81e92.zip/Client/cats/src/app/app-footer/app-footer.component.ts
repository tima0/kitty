import { Component } from '@angular/core';

@Component({
  selector: 'cats-footer',
  templateUrl: './app-footer.component.html'
})
export class AppFooterComponent {}
