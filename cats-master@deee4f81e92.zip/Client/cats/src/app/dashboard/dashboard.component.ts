import { Component, OnInit } from '@angular/core';
import { SideMenuService } from '../../core/side-menu.service';
import { SearchBoxService } from '../../core/search-box.service';
import { TopMenuService } from '../../core/top-menu.service';

// This is for demo/mock up purposes, needs to be moved to it's own file long term.
export class PendingQueues {
  name = '';
  count = 0;
}
@Component({
  selector: 'cats-dashboard',
  templateUrl: './dashboard.component.html',
  styles: []
})
export class DashboardComponent implements OnInit {
  pendingQueues: PendingQueues[] = [
    { name: 'Current Work', count: 3 },
    { name: 'Garnishment: Verfication Not Started', count: 4 },
    { name: 'Garnishment: Missed Payment', count: 5 }
  ];
  constructor(
    private menuService: SideMenuService,
    private search: SearchBoxService,
    private topMenuService: TopMenuService
  ) {}

  ngOnInit() {
    this.menuService.changeToDefault();
    this.search.hideSearch();
    this.topMenuService.changeToDefault();
  }
}
