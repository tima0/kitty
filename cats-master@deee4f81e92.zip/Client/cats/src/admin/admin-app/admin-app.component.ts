import { Component, OnInit } from '@angular/core';
import { SideMenuService } from '../../core/side-menu.service';
import { SearchBoxService } from '../../core/search-box.service';
import { TopMenuService } from '../../core/top-menu.service';

@Component({
  selector: 'cats-admin-app',
  templateUrl: './admin-app.component.html',
  styles: []
})
export class AdminAppComponent implements OnInit {
  constructor(
    private menuService: SideMenuService,
    private search: SearchBoxService,
    private topMenuService: TopMenuService
  ) {}

  ngOnInit() {
    this.menuService.changeMenu([]);
    this.search.hideSearch();
    this.topMenuService.changeToDefault();
  }
}
