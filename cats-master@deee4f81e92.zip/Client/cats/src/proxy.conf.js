const PROXY_CONFIG = {
  '/app': {
    target: 'http://localhost/divisions/ui/cats/app',
    secure: false,
    changeOrigin: true,
    pathRewrite: {
      '^/app': ''
    }
  },
  '/dwsui': {
    target: 'http://localhost/divisions/ui/cats/dwsui',
    secure: false,
    changeOrigin: true,
    pathRewrite: {
      '^/dws': ''
    },
    logLevel: 'debug'
  }
};

module.exports = PROXY_CONFIG;
