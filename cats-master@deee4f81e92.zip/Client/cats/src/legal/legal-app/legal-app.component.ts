import { Component, OnInit } from '@angular/core';
import { SideMenuService } from '../../core/side-menu.service';
import { SearchBoxService } from '../../core/search-box.service';
import { TopMenuService } from '../../core/top-menu.service';

@Component({
  selector: 'cats-legal-app',
  templateUrl: './legal-app.component.html',
  styles: []
})
export class LegalAppComponent implements OnInit {
  constructor(
    private menuService: SideMenuService,
    private search: SearchBoxService,
    private topMenuService: TopMenuService
  ) {}

  ngOnInit() {
    this.menuService.changeMenu([]);
    this.search.setupSearch({
      visible: true,
      minChar: 3,
      performSearch: (searchText: string) => {}
    });
    this.topMenuService.changeToDefault();
  }
}
