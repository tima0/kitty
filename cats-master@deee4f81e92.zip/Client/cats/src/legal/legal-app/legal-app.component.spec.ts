import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalAppComponent } from './legal-app.component';

describe('LegalAppComponent', () => {
  let component: LegalAppComponent;
  let fixture: ComponentFixture<LegalAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LegalAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LegalAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
