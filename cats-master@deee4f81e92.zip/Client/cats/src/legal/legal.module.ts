import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LegalRoutingModule } from './legal-routing.module';
import { LegalAppComponent } from './legal-app/legal-app.component';

@NgModule({
  imports: [
    CommonModule,
    LegalRoutingModule
  ],
  declarations: [LegalAppComponent]
})
export class LegalModule { }
