import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LegalAppComponent } from './legal-app/legal-app.component';

const routes: Routes = [
  {
    path: '',
    component: LegalAppComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LegalRoutingModule {}
