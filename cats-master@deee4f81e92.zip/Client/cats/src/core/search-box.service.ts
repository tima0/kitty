import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import { SearchBoxConfig } from './search-box-config';

@Injectable({
  providedIn: 'root'
})
export class SearchBoxService {
  private readonly noSearchConfig: SearchBoxConfig = {
    visible: false,
    minChar: 0,
    performSearch: (searchText: string) => {}
  };
  private searchConfigSource = new BehaviorSubject(this.noSearchConfig);
  currentSearchConfig$ = this.searchConfigSource.asObservable();

  private searchTextSource = new BehaviorSubject<string>('');
  searchTextSource$ = this.searchTextSource.asObservable();

  constructor() {}

  hideSearch() {
    this.setupSearch(this.noSearchConfig);
  }

  setupSearch(searchConfig: SearchBoxConfig) {
    this.searchConfigSource.next(searchConfig);
  }

  clearSearchText() {
    this.setSearchText('');
  }
  setSearchText(searchText: string) {
    this.searchTextSource.next(searchText);
  }
}
