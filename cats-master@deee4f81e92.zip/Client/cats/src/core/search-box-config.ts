export type PerformSearchFunction = (searchText: string) => any;
export interface SearchBoxConfig {
  visible: boolean;
  minChar: number;
  performSearch: PerformSearchFunction;
}
