import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TitleService {
  private readonly DefaultAppTitle: string = '';
  private readonly DefaultBrowserTitle: string = 'Cats';
  private appTitleSource = new BehaviorSubject(this.DefaultAppTitle);
  private browserTitleSource = new BehaviorSubject(this.DefaultBrowserTitle);
  currentBrowserTitle$ = this.browserTitleSource.asObservable();
  currentAppTitle$ = this.appTitleSource.asObservable();

  constructor() {}
  setTitle(appTitle: string, browserTitle: string) {
    this.appTitleSource.next(appTitle);
    this.browserTitleSource.next(browserTitle);
  }
  setDefaultTitle() {
    this.appTitleSource.next(this.DefaultAppTitle);
    this.browserTitleSource.next(this.DefaultBrowserTitle);
  }
}
