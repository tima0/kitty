import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import { DashboardMenuItems } from './common-menu.const';

import { MenuItem } from 'primeng/primeng';
@Injectable({
  providedIn: 'root'
})
export class SideMenuService {
  private readonly DefaultMenu: MenuItem[] = DashboardMenuItems;
  private menuSource = new BehaviorSubject(this.DefaultMenu);
  currentMenu$ = this.menuSource.asObservable();

  constructor() {}

  changeMenu(newMenu: MenuItem[]) {
    this.menuSource.next(newMenu);
  }
  changeToDefault() {
    this.menuSource.next(this.DefaultMenu);
  }
}
