import { Injectable } from '@angular/core';
import { ProfileInfo } from './profile-info';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileInfoService {
  private readonly noUser: ProfileInfo = {
    profileName: '',
    position: '',
    imageUrl: ''
  };
  private profileInfoSource = new BehaviorSubject(this.noUser);
  profileInfoConfig$ = this.profileInfoSource.asObservable();
  constructor() {
    // Temporary until we get Security implemented.
    this.profileInfoSource.next({
      profileName: 'Jack Ryan',
      position: '',
      imageUrl: 'assets/temp/jack-ryan.jpg'
    });
  }
}
