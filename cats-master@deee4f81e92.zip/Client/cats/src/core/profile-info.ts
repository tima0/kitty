export class ProfileInfo {
  profileName = '';
  position = '';
  imageUrl = '';

  static defaultEmptyProfile(): ProfileInfo {
    const profile = new ProfileInfo();
    return profile;
  }
}
