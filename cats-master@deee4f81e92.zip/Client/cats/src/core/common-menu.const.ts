import { MenuItem } from 'primeng/primeng';
// Icons are Fontawesome 4.7
// https://fontawesome.com/v4.7.0/cheatsheet/

export const BopMenuItems: MenuItem[] = [
  { label: 'BOP Home', icon: 'fa fa-fw  fa-home', routerLink: ['/bop'] },
  {
    label: 'Current Work Queue',
    icon: 'fa fa-fw  fa-clock-o',
    routerLink: ['/bop/current']
  },
  {
    label: 'Garnishment Queues',
    icon: 'fa fa-fw  fa-dollar',
    routerLink: ['/bop/garn']
  },
  {
    label: 'Assigned Accounts',
    icon: 'fa fa-fw  fa-list-alt',
    routerLink: ['/bop/assigned-account']
  },
  {
    label: 'Bankruptcy',
    icon: 'fa fa-fw  fa-university',
    routerLink: ['/bop/bankruptcy']
  },
  {
    label: 'Prosecution',
    icon: 'fa fa-fw  fa-gavel',
    routerLink: ['/bop/prosecution']
  }
];

export const DashboardMenuItems: MenuItem[] = [
  {
    label: 'Bop',
    icon: 'fa fa-fw  fa-address-book-o',
    items: BopMenuItems
  },
  { label: 'Legal', icon: 'fa fa-fw fa-balance-scale', routerLink: ['legal'] },
  { label: 'Admin', icon: 'fa fa-fw fa-group', routerLink: ['admin'] }
];
