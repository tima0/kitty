import { Injectable } from '@angular/core';
import { MenuItem } from 'primeng/primeng';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TopMenuService {
  private readonly DefaultMenu: MenuItem[] = [];
  private menuSource = new BehaviorSubject(this.DefaultMenu);
  currentMenu$ = this.menuSource.asObservable();

  constructor() {}

  changeMenu(newMenu: MenuItem[]) {
    this.menuSource.next(newMenu);
  }
  changeToDefault() {
    this.menuSource.next(this.DefaultMenu);
  }
}
