using System;
using System.Linq;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Shouldly;

namespace Cats.Core.Tests.Liens
{
	public class LienStateEngineBaseTest
    {		
		protected void PerformFlowRuleFactoryTest(ActionCode actionCode, StateCode sourceState,
			StateCode destinationState, Type expectedType)
		{
			// test the 
			var flowRuleFactory = new FlowRuleFactory(DateTime.Now);
			var expectedFlowRule = flowRuleFactory.Get(actionCode, sourceState, destinationState);
			expectedFlowRule.GetType().ShouldBe(expectedType);
		}

		protected LienData CreateLienData(DateTime establishedDate, decimal arBalance, StateCode currentState)
		{
			var lienData = new LienData
			{
				ArEstablishedDate = establishedDate,
				ArBalance = arBalance,
				LastLienAction = currentState,
				LastLienActionDate = DateTime.Now,
				PreviousStateCode = currentState
			};
			return lienData;
		}

		protected LienStateEngineBase CreateStateEngine(StateCode initialState)
		{
			var stateFlowHistory = new StateFlowHistory<ActionCode, StateCode, LienData>();
			var _stateEngine = new LienStateEngineBase(initialState, stateFlowHistory, DateTime.Now);			
			return _stateEngine;

		}

		protected void PerformTests(LienData lienData, ActionCode sourceAction, StateCode expectedState)
		{
			var _stateEngine = CreateStateEngine(lienData.PreviousStateCode);

			_stateEngine.ExecuteFlow(lienData);
			_stateEngine.State.ShouldBe(expectedState);

			lienData.LastLienAction.ShouldBe(expectedState);
			lienData.LastLienActionDate.Value.Date.ShouldBe(_stateEngine.ProcessingDate.Date);

			_stateEngine.StateFlowHistory.FlowHistory.Count.ShouldBeGreaterThan(0);
			if (_stateEngine.StateFlowHistory.FlowHistory.Count > 0)
			{
				var lastFlow = _stateEngine.StateFlowHistory.FlowHistory.Last();
				StateFlowHistoryItem<ActionCode, StateCode, LienData> historyItem = lastFlow.Value;

				historyItem.TransititionInfo.DestinationState.ShouldBe(expectedState);				
			}
		}

		
    }
}
