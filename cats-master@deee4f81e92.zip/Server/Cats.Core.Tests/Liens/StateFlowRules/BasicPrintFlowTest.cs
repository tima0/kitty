using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using Xunit;
using Shouldly;


namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class BasicPrintFlowTest : StateFlowRuleTests
    {
        [Fact]
		public void CanGetFlowTest()
		{
			var lien = new LienData();
			var flowRule = new BasicPrintFlow(DateTime.Now);
			var transitionInfo = CreateFlowTransitionInfo(lien);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
			result = flowRule.AllowCascadeEntry(transitionInfo);
			result.ShouldBe(false);
		}
    }
}
