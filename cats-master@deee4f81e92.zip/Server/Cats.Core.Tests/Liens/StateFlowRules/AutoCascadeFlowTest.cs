using System;
using Xunit;
using Shouldly;
using Moq;
using Cats.Core.Liens.StateFlowRules;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class AutoCascadeFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest() 
		{
			var lien = new Mock<LienData>().Object;
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new AutoCascadeFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}
    }
}
