using System;
using Xunit;
using Moq;
using Shouldly;
using Cats.Core.Liens.StateFlowRules;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class CanceledDebtFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest_ReturnTrue()
		{
			var lien = new Mock<LienData>().Object;
			lien.CanceledDebt = true;
			
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.SentToFile, StateCode.BOPCanceled, ActionCode.BOPCanceled, lien);
			var flowRule = new CanceledDebtFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			var lien = new Mock<LienData>().Object;
			lien.CanceledDebt = false;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.SentToFile, StateCode.BOPCanceled, ActionCode.BOPCanceled, lien);
			var flowRule = new CanceledDebtFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);
		}
    }
}
