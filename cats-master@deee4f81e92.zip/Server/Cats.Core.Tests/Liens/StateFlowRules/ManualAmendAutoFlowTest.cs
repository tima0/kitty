using System;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class ManualAmendAutoFlowTest : StateFlowRuleTests
	{
		[Fact]
		public void ManualAmendAutoFlowTest_FlowTrue()

		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.ManualAmend);
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.WaitToFile, StateCode.ManualAmend, ActionCode.ManualAmend, lienData);
			var flow = new ManualAmendAutoFlow(this.MockLienStateEngine().Object.ProcessingDate);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(true);

			

		}
	}
}
