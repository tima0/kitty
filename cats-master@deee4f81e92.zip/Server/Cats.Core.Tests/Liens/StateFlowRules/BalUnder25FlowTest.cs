using System;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class BalUnder25FlowTest: StateFlowRuleTests
	{

		[Fact]
		public void BalUnder25FlowTest_checkBal()

		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lienData.ArBalance = 24;
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.WaitToFile, StateCode.WaitToFile, ActionCode.WaitToFile, lienData);
			var flow = new BalUnder25Flow(this.MockLienStateEngine().Object.ProcessingDate);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(true);

			lienData.ArBalance = 26;

			flow = new BalUnder25Flow(this.MockLienStateEngine().Object.ProcessingDate);
			result = flow.CanFlow(transitionInfo);

			result.ShouldBe(false);


		}

	}
}
