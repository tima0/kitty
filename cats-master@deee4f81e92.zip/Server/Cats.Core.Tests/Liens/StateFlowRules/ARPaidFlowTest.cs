using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class ARPaidFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CascadeFlowTest()
		{
			var lienData = this.CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR);
			var arPaidFlow = new ARPaidFlow(DateTime.Now);
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lienData);
			var result = arPaidFlow.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}
    }
}
