using System;
using Xunit;
using Moq;
using Shouldly;
using Cats.Core.Liens.StateFlowRules;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class SetConPenFlowTest : StateFlowRuleTests
    {
		[Fact]
		public void CanFlowTest()
		{
			var lien = new Mock<LienData>().Object;
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new SetConPenFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void BeforeFlowEventTest()
		{
			var lien = new Mock<LienData>().Object;
			lien.ConPenDueAmount = 0;
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new SetConPenFlow(DateTime.Now);

			// throws an exception when ConPenDueAmount = 0
			Should.Throw<FlowRuleException>(() =>
			{				
				flowRule.BeforeFlowEvent(transitionInfo);
			});

			lien.ConPenDueAmount = 100.5m;
			flowRule.BeforeFlowEvent(transitionInfo);
			lien.ConPenDueForcedAmt.ShouldBe(100.5m);

		}
    }
}
