using System;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class WaitToFileFlowTest : StateFlowRuleTests
	{

		[Fact]
		public void WaitToFileFlowTest_CheckWaitDate()

		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lienData.FirstWaitToFileDate = DateTime.Now.AddDays(-16);
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.WaitToFile, StateCode.WaitToFile, ActionCode.WaitToFile, lienData);
			var flow = new WaitToFileFlow(this.MockLienStateEngine().Object.ProcessingDate);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(true);

			lienData.FirstWaitToFileDate = DateTime.Now.AddDays(-14);

			flow = new WaitToFileFlow(this.MockLienStateEngine().Object.ProcessingDate);
			result = flow.CanFlow(transitionInfo);

			result.ShouldBe(false);


		}

	}
}
