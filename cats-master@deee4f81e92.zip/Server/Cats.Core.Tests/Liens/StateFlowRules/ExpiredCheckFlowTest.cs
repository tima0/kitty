using System;
using Xunit;
using Moq;
using Shouldly;
using Cats.Core.Liens.StateFlowRules;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class ExpiredCheckFlowTest : StateFlowRuleTests
	{
		[Fact]
		public void CanFlowTest_ReturnTrue()
		{
			// FiledDate > 8 years ago
			var lien = new Mock<LienData>().Object;
			lien.FiledDate = DateTime.Now.AddYears(-9);
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.ManualRestart, StateCode.LienRestartProcess, ActionCode.LienRestartProcess, lien);
			var flowRule = new ExpiredCheckFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CascadeFlowTest_ReturnFalse()
		{
			// // FiledDate <= 8 years ago
			var lien = new Mock<LienData>().Object;
			lien.FiledDate = DateTime.Now.AddYears(-7);

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new ExpiredCheckFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);
		}
	}
}
