using System;
using Xunit;
using Moq;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using Shouldly;
using DwsUI.Core.Collections;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class NoFlagStopFlowtest : StateFlowRuleTests
	{
		[Fact]
		public void CanFlowTest_ReturnTrue()
		{
			// not (HasAdminHold || HasAppealHold || HasBankruptcy)
			var lien = new Mock<LienData>().Object;
			lien.HasAdminHold = false;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = false;
			lien.HasInstallmentAgreement = false;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new NoFlagStopFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			var lien = new Mock<LienData>().Object;
			lien.HasAdminHold = false;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = false;
			lien.HasInstallmentAgreement = true;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new NoFlagStopFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);
		}
	}
}
