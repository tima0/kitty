using System;
using Xunit;
using Shouldly;
using Cats.Core.Liens;
using DwsUI.Core;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class LienDataTest
    {
		[Fact]
        public void GetPayoffTypeTest_NonCertFunds()
		{
			var lien = new LienData
			{
				LastNonCertPmtDate = null,
				LastCertPmtDate = null
			};
			lien.GetPayoffType().ShouldBe(LienPayoffType.NonCertFunds);

			lien.LastNonCertPmtDate = DateTime.Now;
			lien.GetPayoffType().ShouldBe(LienPayoffType.NonCertFunds);

			// certified later
			// LastCertPmtDate + DelayCertFundDays >= LastNonCertPmtDate + DelayNonCertFundDays
			// DelayCertFundDays = 3 days
			// DelayNonCertFundDays = 21 days
			lien.LastCertPmtDate = DateTime.Now;
			lien.GetPayoffType().ShouldBe(LienPayoffType.NonCertFunds);
		}

		[Fact]
		public void GetPayoffTypeTest_CertFunds()
		{
			var lien = new LienData
			{
				LastNonCertPmtDate = null,
				LastCertPmtDate = DateTime.Now
			};
			lien.GetPayoffType().ShouldBe(LienPayoffType.CertFunds);

			// certified later
			// LastCertPmtDate + DelayCertFundDays >= LastNonCertPmtDate + DelayNonCertFundDays
			// DelayCertFundDays = 3 days
			// DelayNonCertFundDays = 21 days
			lien.LastCertPmtDate = new DateTime(2018, 10, 26);
			lien.LastNonCertPmtDate = new DateTime(2018, 9, 1);
			
			lien.GetPayoffType().ShouldBe(LienPayoffType.CertFunds);

		}

		[Fact]
		public void GetWillFlowDateTest()
		{
			// cert funds
			// when LastCertPmtDate not null
			// expect result LastCertPmtDate + LienData.DelayCertFundDays
			var lien = new LienData
			{
				LastNonCertPmtDate = null,
				LastCertPmtDate = new DateTime(2018, 10, 26)
			};
			var expected = new DateTime(2018, 10, 31);
			lien.GetWillFlowDate().ShouldBe(expected);

			// non cert funds
			lien.LastCertPmtDate = null;
			lien.LastNonCertPmtDate = null;
			lien.LastLienActionDate = DateTime.Now.Date;
			expected = lien.LastLienActionDate.Value
				.AddDays(LienData.DelayNonCertFundDays)
				.Date;
			lien.GetWillFlowDate().ShouldBe(expected);

			lien.LastNonCertPmtDate = DateTime.Now.Date;
			lien.LastCertPmtDate = null;
			expected = lien.LastNonCertPmtDate.Value
				.AddDays(LienData.DelayNonCertFundDays)
				.Date;
			lien.GetWillFlowDate().ShouldBe(expected);

		}
    }
}
