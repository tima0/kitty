using System;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Shouldly;
using Xunit;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class BasicFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest()
		{
			var basicFlow = new BasicFlow(DateTime.Now);
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.AR, StateCode.AR, ActionCode.AR28Hold, null);			
			var result = basicFlow.CanFlow(transitionInfo);
			result.ShouldBe(true);
			result = basicFlow.AllowCascadeEntry(transitionInfo);
			result.ShouldBe(false);
		}
    }
}
