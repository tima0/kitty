using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class WDNonCertPaidFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest_NonCertFunds()
		{
			// ChargeOffAmt == 0 &&
			// ArBalance == 0 &&
			// GetPayoffType() == LienPayoffType.NonCertFunds;
			// LastNonCertPmtDate = null
			// LastCertPmtDate = null
			var lienData = this.CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR);
			lienData.ChargeOffAmt = 0;
			lienData.ArBalance = 0;
			lienData.LastNonCertPmtDate = null;
			lienData.LastCertPmtDate = null;
			var transitionInfo = this.CreateFlowTransitionInfo(lienData);
			var flowRule = new WDNonCertPaidFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);

			result.ShouldBe(true);

			// LastCertPmtDate = null
			// LastNonCertPmtDate is NOT SET
			lienData.LastCertPmtDate = null;
			lienData.LastNonCertPmtDate = DateTime.Now;
			result = flowRule.CanFlow(transitionInfo);

			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_CertFunds()
		{
			// ChargeOffAmt == 0 &&
			// ArBalance == 0 &&
			// LastNonCertPmtDate = null
			// LastCertPmtDate is set
			var lienData = this.CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lienData.ChargeOffAmt = 0;
			lienData.ArBalance = 0;
			lienData.LastNonCertPmtDate = null;
			lienData.LastCertPmtDate = DateTime.Now;
			var transitionInfo = this.CreateFlowTransitionInfo(lienData);
			var flowRule = new WDNonCertPaidFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);

			result.ShouldBe(false);
		}

		// TODO: DateTime extensions are broken
		[Fact]
		public void CanFlowTest_CertifiedLater()
		{

		}
	}
}
