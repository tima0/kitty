using System;
using Xunit;
using Moq;
using Shouldly;
using Cats.Core.Liens.StateFlowRules;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class OlderThan3YearFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest_ReturnTrue()
		{
			// AR established date is older than 3 years
			var lien = new Mock<LienData>().Object;
			lien.ArEstablishedDate = new DateTime(2015, 1, 1);

			var processingDate = new DateTime(2018, 1, 2);
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new OlderThan3YearFlow(processingDate);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			// AR established date is not older than 3 years
			// AR date is null
			var lien = new Mock<LienData>().Object;
			
			var processingDate = new DateTime(2018, 1, 2);
			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new OlderThan3YearFlow(processingDate);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);

			lien.ArEstablishedDate = new DateTime(2015, 1, 1);
			result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}
    }
}
