using System;
using Xunit;
using Moq;
using Shouldly;
using Cats.Core.Liens.StateFlowRules;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class DaysWaitFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest_ReturnTrue()
		{
			// LastLienActionDate + 1 day < ProcessingDate
			var lien = new Mock<LienData>().Object;
			lien.LastLienActionDate = DateTime.Now.AddDays(-2);

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new DaysWaitFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			// LastLienActionDate >= ProcessingDate
			var lien = new Mock<LienData>().Object;
			lien.LastLienActionDate = DateTime.Now;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new DaysWaitFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);			
		}
	}
}
