using System;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class Wait10DayFlowTest : StateFlowRuleTests
	{
		[Fact]
		public void Wait10DayFlowTest_15Day()
		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			 lienData.FirstWait10DayDate = DateTime.Now.AddDays(-16);
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.Wait10day, StateCode.Need10day, ActionCode.Need10day, lienData);
			var flow = new Wait10DayFlow(this.MockLienStateEngine().Object.ProcessingDate);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(true);

			lienData.FirstWait10DayDate = DateTime.Now.AddDays(-14);

			flow = new Wait10DayFlow(this.MockLienStateEngine().Object.ProcessingDate);
			result = flow.CanFlow(transitionInfo);

			result.ShouldBe(false);
		}
	}
}
