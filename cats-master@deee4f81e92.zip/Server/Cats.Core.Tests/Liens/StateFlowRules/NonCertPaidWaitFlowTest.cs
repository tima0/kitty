using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using Cats.Core.Liens.StateFlowRules;
using Moq;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class NonCertPaidWaitFlowTest : StateFlowRuleTests
    {
		[Fact]
		public void CanFlowTest_ReturnTrue()
		{
			// lien.WillFlowDate < ProcessingDate
			var moqData = new Mock<LienData>();

			moqData.Setup(m => m.GetWillFlowDate())
				.Returns(DateTime.Now.AddDays(-1));

			var transitionInfo = this.CreateFlowTransitionInfo(moqData.Object);
			var flowRule = new NonCertPaidWaitFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);

			result.ShouldBe(true);

			// WillFlowDate = ProcessingDate
			moqData.Setup(m => m.GetWillFlowDate())
				.Returns(DateTime.Now);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			// lien.WillFlowDate > ProcessingDate			
			var moqData = new Mock<LienData>();
			moqData.Setup(m => m.GetWillFlowDate())
				.Returns(DateTime.Now.AddDays(1));

			var transitionInfo = this.CreateFlowTransitionInfo(moqData.Object);
			var flowRule = new NonCertPaidWaitFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);

			result.ShouldBe(false);
		}
	}
}
