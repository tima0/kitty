using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class SatisfyNonCertPaidFlowTest : StateFlowRuleTests
	{
		[Fact]
		public void SatisfyNonCertPaidFlowTest_true()
		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.SatNonCertPaid);
			lienData.CanceledDebt = false;
			lienData.ChargeOffAmt = 0;
			lienData.ArBalance = 0;

			//a non-certified date, and no certified date, makes this a non-certified payoff.  
			lienData.LastNonCertPmtDate = DateTime.Now.AddDays(-5);
			lienData.LastCertPmtDate = null;


			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(
					StateCode.SatNonCertPaid, StateCode.SatNonCertPaid, ActionCode.SatNonCertPaid, lienData);
			var flow = new SatisfyNonCertPaidFlow(this.MockLienStateEngine().Object.ProcessingDate);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(true);

		}
	}
}
