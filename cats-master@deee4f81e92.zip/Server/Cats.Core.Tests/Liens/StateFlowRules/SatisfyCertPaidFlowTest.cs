using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class SatisfyCertPaidFlowTest : StateFlowRuleTests
	{
		[Fact]
		public void SatisfyCertPaidFlowTest_true()
		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			lienData.CanceledDebt = false;
			lienData.ChargeOffAmt = 0;
			lienData.ArBalance = 0;

			//a certified date, and no non-certified date, makes this a certified payoff.  
			lienData.LastCertPmtDate = DateTime.Now.AddDays(-100);
			lienData.LastNonCertPmtDate = null;


			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.SatCertPaid, StateCode.SatCertPaid, ActionCode.SatCertPaid, lienData);
			var flow = new SatisfyCertPaidFlow(this.MockLienStateEngine().Object.ProcessingDate);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(true);

		}
	}
}

