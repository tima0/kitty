using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class WDCertPaidFlowTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest_CertFunds()
		{
			// ChargeOffAmt == 0 && ArBalance == 0 && GetPayoffType() == LienPayoffType.CertFunds
			// LastNonCertPmtDate is set
			// LastNonCertPmtDate is null
			var lienData = this.CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR);
			lienData.ChargeOffAmt = 0;
			lienData.LastNonCertPmtDate = null;
			lienData.LastCertPmtDate = DateTime.Now;			

			var flowRule = new WDCertPaidFlow(DateTime.Now);
			var flowTransition = this.CreateFlowTransitionInfo(StateCode.AR28Hold, StateCode.ARIncrease, ActionCode.ARIncrease, lienData);
			var result = flowRule.CanFlow(flowTransition);
			result.ShouldBe(true);
		
			// either LastNonCertPmtDate or LastCertPmtDate dates are SET
			// LastNonCertPmtDate is null
			lienData.LastNonCertPmtDate = null;
			lienData.LastCertPmtDate = null;			
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_NonCertFunds()
		{
			// ChargeOffAmt == 0 && ArBalance == 0 && GetPayoffType() == LienPayoffType.CertFunds
			// LastNonCertPmtDate && LastCertPmtDate dates are NOT SET
			// LastNonCertPmtDate is null
			var lienData = this.CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR);
			lienData.ChargeOffAmt = 0;
			lienData.LastNonCertPmtDate = null;
			lienData.LastCertPmtDate = null;			

			var flowRule = new WDCertPaidFlow(DateTime.Now);
			var flowTransition = this.CreateFlowTransitionInfo(StateCode.AR28Hold, StateCode.ARIncrease, ActionCode.ARIncrease, lienData);
			var result = flowRule.CanFlow(flowTransition);
			result.ShouldBe(false);

			// either LastNonCertPmtDate && LastCertPmtDate dates are SET
			// LastNonCertPmtDate is set
			// LastCertPmtDate is NOT SET
			lienData.LastNonCertPmtDate = DateTime.Now;
			lienData.LastCertPmtDate = null;
			lienData.LastNonCertPmtDate = DateTime.Now;
			result.ShouldBe(false);
		}

		[Fact]
		public void CanFlowTest_CertifiedLater()
		{
			// ChargeOffAmt == 0 && ArBalance == 0 && GetPayoffType() == LienPayoffType.CertFunds
			// LastNonCertPmtDate is null			
			// LastCertPmtDate is null
			var lienData = this.CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR);
			lienData.ChargeOffAmt = 0;

			// Delay Cert fund = 3 days
			// Delay non cert fund = 21 days
			lienData.LastCertPmtDate = DateTime.Now.AddDays(21 + 3);
			lienData.LastNonCertPmtDate = DateTime.Now.AddDays(21);

			var flowRule = new WDCertPaidFlow(DateTime.Now);
			var flowTransition = this.CreateFlowTransitionInfo(StateCode.AR28Hold, StateCode.ARIncrease, ActionCode.ARIncrease, lienData);

			// TODO: DateTime extensions are broken
			// LastCertPmtDate >= LastNonCertPmtDate
			lienData.LastCertPmtDate = DateTime.Now.AddDays(21 + 4);
			lienData.LastNonCertPmtDate = DateTime.Now.Date;
			var result = flowRule.CanFlow(flowTransition);
			result.ShouldBe(true);
		}
    }
}
