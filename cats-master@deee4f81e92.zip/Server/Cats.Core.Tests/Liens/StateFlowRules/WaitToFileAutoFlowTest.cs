using System;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class WaitToFileAutoFlowTest : StateFlowRuleTests
	{

		[Fact]
		public void WaitToFileAutoFlowTest_CheckWaitDate()
		
		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.WaitToFile, StateCode.WaitToFile, ActionCode.WaitToFile, lienData);
			var flow = new WaitToFileAutoFlow(this.MockLienStateEngine().Object.ProcessingDate);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(true);

			//did we set the datetime to today?  ignore anything smaller than 24 hours
			//result = (lienData.FirstWaitToFileDate.Value.Date == this.MockLienStateEngine().Object.ProcessingDate);
			//result.ShouldBe(true);

		}

	}
}
