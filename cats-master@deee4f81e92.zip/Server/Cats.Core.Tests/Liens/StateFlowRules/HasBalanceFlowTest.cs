using System;
using Xunit;
using Moq;
using Shouldly;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
	public class HasBalanceFlowTest : StateFlowRuleTests
	{
		[Fact]
		public void CanFlowTest_ReturnTrue()
		{
			// ArBalance > 0
			// SourceState = DestinationState
			var lienData = new Mock<LienData>();
			lienData.Object.ArBalance = 123.50m;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.Need28, StateCode.Need28, ActionCode.Need28, lienData.Object);
			var flowRule = new HasBalanceFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			// ArBalance > 0
			// SourceState != DestinationState
			var lienData = new Mock<LienData>();
			lienData.Object.ArBalance = 0;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.Need28, StateCode._28Printed, ActionCode.Need28, lienData.Object);
			var flowRule = new HasBalanceFlow(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);

			lienData.Object.ArBalance = 0;
			result.ShouldBe(false);
		}
	}
}
