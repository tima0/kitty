using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Xunit;
using Shouldly;

namespace Cats.Core.Tests.Liens.StateFlowRules
{
    public class AmendQueueFlowTest : StateFlowRuleTests
	{
        [Fact]
		public void AmendQueueFlowTest_ZeroConPenDueForcedAmt()
		{
			// arrange
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lienData.ConPenDueForcedAmt = 0;
			lienData.ConPenDueFiledAmt = 1;
			lienData.ConPenDueAmount = 2;
			
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lienData);			
			var flow = new AmendQueueFlow(DateTime.Now);
			var result = flow.CanFlow(transitionInfo);
			
			result.ShouldBe(true);

			lienData.ConPenDueFiledAmt = 1;
			lienData.ConPenDueAmount = 1;

			flow = new AmendQueueFlow(DateTime.Now);
			result = flow.CanFlow(transitionInfo);

			result.ShouldBe(false);
		}

		[Fact]
		public void AmendQueueFlowTest_NonZeroConPenDueForcedAmt()
		{			
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lienData.ConPenDueForcedAmt = 1;
			lienData.ConPenDueAmount = 2;
			
			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lienData);
			var flow = new AmendQueueFlow(DateTime.Now);
			var result = flow.CanFlow(transitionInfo);
			
			result.ShouldBe(true);

			lienData.ConPenDueForcedAmt = 1;
			lienData.ConPenDueAmount = 1;
			flow = new AmendQueueFlow(DateTime.Now);
			result = flow.CanFlow(transitionInfo);

			result.ShouldBe(false);
		}

		[Fact]
		public void AmendQueueFlowTest_ConPenDueAmountIsZero()
		{
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lienData.ConPenDueForcedAmt = 0;
			lienData.ConPenDueAmount = 0;

			var transitionInfo = new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lienData);
			var flow = new AmendQueueFlow(DateTime.Now);
			var result = flow.CanFlow(transitionInfo);

			result.ShouldBe(false);

		}
	}
}
