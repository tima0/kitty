using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens
{
    public class Need10DayFlowTest : LienStateEngineBaseTest
    {
        [Fact]
		public void Need10DaytoARPAIDTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Need10day);
			lien.HasAdminHold = true;
			PerformTests(lien, ActionCode.Need10day, StateCode.ARPaid);
		}

		[Fact]
		public void Need10Dayto10DayHold_AppealTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need10day);
			lien.HasAppealHold = true;
			PerformTests(lien, ActionCode.Need10day, StateCode._10DayHold);
		}

		[Fact]
		public void Need10Dayto10DayHold_AdminTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need10day);
			lien.HasAdminHold = true;
			PerformTests(lien, ActionCode.Need10day, StateCode._10DayHold);
		}

		[Fact]
		public void Need10Dayto10DayHold_BankruptcyTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need10day);
			lien.HasBankruptcy = true;
			PerformTests(lien, ActionCode.Need10day, StateCode._10DayHold);
		}

		[Fact]
		public void TestNeed10Dayto10DayHold_IA()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need10day);
			lien.HasInstallmentAgreement = true;
			PerformTests(lien, ActionCode.Need10day, StateCode._10DayHold);
		}
	}
}
