using System;
using Xunit;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;

namespace Cats.Core.Tests.Liens
{
	public class ARLienFlowTest : LienStateEngineBaseTest
    {
		[Fact]
		public void ArToArPaidTest()
		{
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR);
			PerformFlowRuleFactoryTest(ActionCode.ARPaid, StateCode.AR, StateCode.ARPaid, typeof(ARPaidFlow));
			PerformTests(lienData, ActionCode.AR, StateCode.ARPaid);
		}

		[Fact]
		public void ArToNeed28Test()
		{
			var lienData = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);

			// actual state flow test
			PerformTests(lienData, ActionCode.AR, StateCode.Need28);
		}

		[Fact]
		public void ARtoAR28HOLD_AppealTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lien.HasAppealHold = true;
			PerformTests(lien, ActionCode.AR, StateCode.AR28Hold);
		}

		[Fact]
		public void ARtoAR28HOLD_AdminTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lien.HasAdminHold = true;
			PerformTests(lien, ActionCode.AR, StateCode.AR28Hold);
		}

		[Fact]
		public void ARtoAR28HOLD_BankruptcyTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lien.HasBankruptcy = true;
			PerformTests(lien, ActionCode.AR, StateCode.AR28Hold);
		}

		[Fact]
		public void ARtoAR28HOLD_IATest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			lien.HasInstallmentAgreement = true;
			PerformTests(lien, ActionCode.AR, StateCode.AR28Hold);
		}

		[Fact]
		public void ARtoNEED28_NoHoldsTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR);
			PerformTests(lien, ActionCode.AR, StateCode.Need28);
		}

		[Fact]
		public void AR28HOLDtoARPaidTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR28Hold);
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move to ARPaid
			PerformTests(lien, ActionCode.AR28Hold, StateCode.ARPaid);
		}

		[Fact]
		public void AR28HOLDtoNeed28Test()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.AR28Hold);
			PerformTests(lien, ActionCode.AR28Hold, StateCode.Need28);
		}
	}
}
