using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;
using Shouldly;

namespace Cats.Core.Tests.Liens
{
    public class AmendQueueFlowTest : LienStateEngineBaseTest
    {
        [Fact]
		public void AmendQueueTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 200, StateCode.Filed);
			lien.FiledDate = DateTime.Now.AddDays(-50);
			lien.FiledLienAmount = 200;
			lien.ConPenBalAmount = 220;
			LienStateEngineBase engine = CreateStateEngine(StateCode.Filed);
			engine.State.ShouldBe(StateCode.Filed); // no state change expected
		}

	}
}
