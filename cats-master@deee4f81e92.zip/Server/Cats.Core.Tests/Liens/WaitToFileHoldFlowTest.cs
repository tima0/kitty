using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens
{
    public class WaitToFileHoldFlowTest : LienStateEngineBaseTest
    {
		[Fact]
        public void WaitToFileHoldToDueProcessRestartTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFileHold);
			lien.LastCorrespondenceDate = DateTime.Now.AddDays(-91);
			lien.FirstWait10DayDate = DateTime.Now;
			PerformTests(lien, ActionCode.WaitToFileHold, StateCode.Need28);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFileHold);
			lien.HasAdminHold = true;
			lien.LastCorrespondenceDate = DateTime.Now.AddDays(-91);
			lien.FirstWait10DayDate = DateTime.Now;
			PerformTests(lien, ActionCode.WaitToFileHold, StateCode.AR28Hold);
		}

		[Fact]
		public void WaitToFileHoldtoARPAIDTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.WaitToFileHold);
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move to ARPaid
			PerformTests(lien, ActionCode.WaitToFileHold, StateCode.ARPaid);
		}

		[Fact]
		public void WaitToFileHoldtoWaitToFileTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFileHold);
			lien.FirstWaitToFileDate = DateTime.Now;
			PerformTests(lien, ActionCode.WaitToFileHold, StateCode.WaitToFile);
		}
	}
}
