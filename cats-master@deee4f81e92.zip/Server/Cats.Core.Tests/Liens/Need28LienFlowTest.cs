using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens
{
    public class Need28LienFlowTest : LienStateEngineBaseTest
    {
		[Fact]
        public void TestNeed28toARPAID()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Need28);
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move to ARPaid
			PerformTests(lien, ActionCode.Need28, StateCode.ARPaid);
		}

		[Fact]
		public void Need28to28PrintHold_AppealTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need28);
			lien.HasAppealHold = true;
			PerformTests(lien, ActionCode.Need28, StateCode._28PrintHold);
		}

		[Fact]
		public void Need28to28PrintHold_AdminTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need28);
			lien.HasAppealHold = true;
			PerformTests(lien, ActionCode.Need28, StateCode._28PrintHold);
		}

		[Fact]
		public void Need28to28PrintHold_BankruptcyTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need28);
			lien.HasBankruptcy = true;
			PerformTests(lien, ActionCode.Need28, StateCode._28PrintHold);
		}

		[Fact]
		public void Need28to28PrintHold_IATest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Need28);
			lien.HasInstallmentAgreement = true;
			PerformTests(lien, ActionCode.Need28, StateCode._28PrintHold);
		}
	}
}
