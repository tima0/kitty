using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens
{
    public class ExpiredFlowTest : LienStateEngineBaseTest
    {
        [Fact]
		public void ExpiredTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-3000), 4000, StateCode.Filed);
			lien.FiledDate = DateTime.Now.AddYears(-8).AddDays(-1);
			PerformTests(lien, ActionCode.Filed, StateCode.Expired);
		}

	}
}
