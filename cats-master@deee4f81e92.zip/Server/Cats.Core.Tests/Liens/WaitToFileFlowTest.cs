using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;
using Shouldly;

namespace Cats.Core.Tests.Liens
{
    public class WaitToFileFlowTest : LienStateEngineBaseTest
    {
        [Fact]
		public void WaitToFiletoARPAIDTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.WaitToFile);
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move to ARPaid
			PerformTests(lien, ActionCode.WaitToFile, StateCode.ARPaid);
		}

		[Fact]
		public void WaitToFiletoSentToFileTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lien.FirstWaitToFileDate = DateTime.Now.AddDays(-16);
			lien.LastLienActionDate = DateTime.Now.AddDays(-16);
			PerformTests(lien, ActionCode.WaitToFile, StateCode.SentToFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lien.FirstWaitToFileDate = DateTime.Now.AddDays(-14);
			lien.LastLienActionDate = DateTime.Now.AddDays(-14);

			LienStateEngineBase engine = CreateStateEngine(lien.PreviousStateCode);
			engine.ExecuteFlow(lien);
			engine.State.ShouldBe(StateCode.WaitToFile); // no state change expected
		}

		[Fact]
		public void WaitToFiletoWaitToFileHold_AppealTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lien.HasAppealHold = true;
			PerformTests(lien, ActionCode.WaitToFile, StateCode.WaitToFileHold);
		}

		[Fact]
		public void WaitToFiletoWaitToFIleHold_AdminTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lien.HasAdminHold = true;
			PerformTests(lien, ActionCode.WaitToFile, StateCode.WaitToFileHold);
		}

		[Fact]
		public void WaitToFiletoWaitToFileHold_BankruptcyTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lien.HasBankruptcy = true;
			PerformTests(lien, ActionCode.WaitToFile, StateCode.WaitToFileHold);
		}


		[Fact]
		public void WaitToFiletoWaitToFileHold_IATest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.WaitToFile);
			lien.HasInstallmentAgreement = true;
			PerformTests(lien, ActionCode.WaitToFile, StateCode.WaitToFileHold);
		}
	}
}
