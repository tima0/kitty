using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens
{
    public class _28PrintHoldFlowTest : LienStateEngineBaseTest
    {
		[Fact]
        public void T28PrintHoldtoNeed28Test()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode._28PrintHold);
			PerformTests(lien, ActionCode._28PrintHold, StateCode.Need28);
		}

		[Fact]
		public void T28PrintHoldtoARPAIDTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode._28PrintHold);
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move to ARPaid
			PerformTests(lien, ActionCode._28PrintHold, StateCode.ARPaid);
		}

		[Fact]
		public void T28PrintedtoWait10DayTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode._28Printed);
			PerformTests(lien, ActionCode._28Printed, StateCode.Wait10day);
		}

	}
}
