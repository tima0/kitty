using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;
using Shouldly;

namespace Cats.Core.Tests.Liens
{
    public class Wait10DayFlowTest : LienStateEngineBaseTest
    {
        [Fact]
		public void Wait10DaytoARPAIDTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Wait10day);
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move to ARPaid
			PerformTests(lien, ActionCode.Wait10day, StateCode.ARPaid);
		}

		[Fact]
		public void Wait10DaytoNeed10DayTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			lien.FirstWait10DayDate = DateTime.Now.AddDays(-15);
			lien.LastLienActionDate = DateTime.Now.AddDays(-15);
			PerformTests(lien, ActionCode.Wait10day, StateCode.Need10day);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			lien.FirstWait10DayDate = DateTime.Now.AddDays(-14);
			lien.LastLienActionDate = DateTime.Now.AddDays(-14);

			var stateEngine = CreateStateEngine(lien.PreviousStateCode);
			stateEngine.ExecuteFlow(lien);

			// no state change expected
			lien.LastLienAction.ShouldBe(StateCode.Wait10day);
			stateEngine.State.ShouldBe(StateCode.Wait10day);
		}

		[Fact]
		public void Wait10Dayto10DayHold_AppealTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			lien.HasAppealHold = true;
			PerformTests(lien, ActionCode.Wait10day, StateCode._10DayHold);
		}

		[Fact]
		public void Wait10Dayto10DayHold_AdminTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			lien.HasAdminHold = true;
			PerformTests(lien, ActionCode.Wait10day, StateCode._10DayHold);
		}

		[Fact]
		public void Wait10Dayto10DayHold_BankruptcyTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			lien.HasBankruptcy = true;
			PerformTests(lien, ActionCode.Wait10day, StateCode._10DayHold);
		}

		[Fact]
		public void Wait10Dayto10DayHold_IATest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode.Wait10day);
			lien.HasInstallmentAgreement = true;
			PerformTests(lien, ActionCode.Wait10day, StateCode._10DayHold);
		}
	}
}
