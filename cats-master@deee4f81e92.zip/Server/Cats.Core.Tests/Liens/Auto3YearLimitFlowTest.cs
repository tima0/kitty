using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;

namespace Cats.Core.Tests.Liens
{
    public class Auto3YearLimitFlowTest : LienStateEngineBaseTest
    {
        [Fact]
		public void Auto3YearLimitTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-366 * 3), 4000, StateCode.AR);
			PerformTests(lien, ActionCode.AR, StateCode.DoNotFile);
		}

	}
}
