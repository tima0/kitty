using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using Xunit;

namespace Cats.Core.Tests.Liens
{
    public class _10DayHoldFlowTest : LienStateEngineBaseTest
    {
        [Fact]
		public void _10DayHoldToDueProcessRestartTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode._10DayHold);
			lien.LastCorrespondenceDate = DateTime.Now.AddDays(-90);
			lien.FirstWait10DayDate = DateTime.Now;
			PerformTests(lien, ActionCode._10DayHold, StateCode.Need28);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode._10DayHold);
			lien.HasAdminHold = true;
			lien.LastCorrespondenceDate = DateTime.Now.AddDays(-91);
			lien.FirstWait10DayDate = DateTime.Now;
			PerformTests(lien, ActionCode._10DayHold, StateCode.AR28Hold);
		}

		[Fact]
		public void _10DayHoldtoARPAIDTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode._10DayHold);
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move to ARPaid
			PerformTests(lien, ActionCode._10DayHold, StateCode.ARPaid);
		}

		[Fact]
		public void _10DayHoldtoWait10DayTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode._10DayHold);
			lien.FirstWait10DayDate = DateTime.Now;
			PerformTests(lien, ActionCode._10DayHold, StateCode.Wait10day);
		}

		[Fact]
		public void _10DayPrintedtoWaitToFileTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 4000, StateCode._10DayPrinted);
			PerformTests(lien, ActionCode._10DayPrinted, StateCode.WaitToFile);
		}
	}
}
