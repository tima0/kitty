using Cats.Core;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Internals
{
	public class GenericRepository<T> : IGenericRepository<T> where T: class
	{
		///<summary>Contains the Entity Framework database context.</summary>
		private DbContext _context { get; }
		///<summary>Contains the DbSet for the type T inside the database context.</summary>
		private System.Data.Entity.DbSet<T> _dbSet { get; }
		private string _keyPropertyName { get; set; }

		///<summary>The constructor for a generic repository.</summary>
		public GenericRepository(DbContext context) : this(context, null)
		{
		}
		public GenericRepository(DbContext context, string keyPropertyName)
		{
			_context = context;
			_dbSet = context.Set<T>();
			DetermineKeyPropertyName(keyPropertyName);
		}

		public void SaveChanges()
		{
			_context.SaveChanges();
		}

		public async void SaveChangesAsync()
		{
			await _context.SaveChangesAsync();
		}

		private void DetermineKeyPropertyName(string keyPropertyName)
		{
			if (!string.IsNullOrEmpty(keyPropertyName))
				// The key field name has been specified.
				this._keyPropertyName = keyPropertyName;
			else
			{
				// Return the first property with a PrimaryKeyAttribute on it.
				System.Reflection.PropertyInfo prop1 = typeof(T)
								.GetProperties()
								.FirstOrDefault(p => p.GetCustomAttributes(false)
									.Cast<Attribute>()
									.Any(a => a.GetType().Name.Equals("PrimaryKeyAttribute")));
				if (prop1 != null)
					this._keyPropertyName = prop1.Name;
				else
				{
					// Determine if there is a property with name {TableName}_ID.
					string tableName = typeof(T).GetType().Name;
					string expectedKeyName = string.Concat(tableName, "_ID");
					System.Reflection.PropertyInfo prop2 = typeof(T).GetProperty(expectedKeyName);
					if (prop2 != null)
						this._keyPropertyName = expectedKeyName;
					else
						throw new Exception($"Unable to determine key field name for entity ({typeof(T).FullName}).  "
							+ "Consider using the constructor overload which allows you to specify the primary key field name.");
				}
			}
		}

		/// <summary>
		/// Returns all records in the DbSet.  
		/// </summary>
		/// <remarks>WARNING!  This method probably returns all rows in a table.  This should be used careful on DbSets with a limited set of rows, such as code tables.</remarks>
		/// <returns>All records in the DbSet.</returns>
		public IEnumerable<T> All()
		{
			return _dbSet.AsNoTracking().ToList();
		}

		/// <summary>
		/// Returns all records in the DbSet with any specified related records included in the object graph as well.  
		/// </summary>
		/// <remarks>WARNING!  This method probably returns all rows in a table.  This should be used careful on DbSets with a limited set of rows, such as code tables.</remarks>
		/// <param name="includeProperties">Any includes you want to have included in the results (a "select" without projection).</param>
		/// <returns>All records in the DbSet and their related includes as specified.</returns>
		public IEnumerable<T> AllIncluding(params Expression<Func<T, object>>[] includeProperties)
		{
			return GetAllIncluding(includeProperties).ToList();
		}

		/// <summary>
		/// Returns a filtered set of records in the DbSet with any specified related records included in the object graph as well.
		/// </summary>
		/// <param name="predicate">The "where" clause as a lambda expression.</param>
		/// <param name="includeProperties">Any includes you want to have included in the results (a "select" without projection)./</param>
		/// <returns></returns>
		public IEnumerable<T> FindByIncluding (Expression<Func<T, bool>> predicate,
			params Expression<Func<T, object>>[] includeProperties)
		{
			var query = GetAllIncluding(includeProperties);
			IEnumerable<T> results = query.Where(predicate).ToList();
			return results;
		}

		private IQueryable<T> GetAllIncluding(params Expression<Func<T, object>>[] includeProperties)
		{
			IQueryable<T> queryable = _dbSet.AsNoTracking();
			return includeProperties.Aggregate(
				queryable,
				(current, includeProperty) => current.Include(includeProperty));
		}

		/// <summary>
		/// Searches a DbSet or table for records matching the specified filter.
		/// </summary>
		/// <param name="predicate">A "where" clause for filtering records in the DbSet.</param>
		/// <returns>A collection of records from the DbSet.</returns>
		public IEnumerable<T> FindBy(Expression<Func<T, bool>> predicate)
		{
			return _dbSet.AsNoTracking()
				.Where(predicate)
				.ToList();
		}

		/// <summary>
		///	Returns the record with the specified primary key.
		/// </summary>
		/// <param name="id">The primary key to find.</param>
		/// <returns>The record with the specified Id if found, null otherwise.</returns>
		public T FindByKey<TKEY>(TKEY id) 
		{
			//Predicate<T> filter =
			// This probably works with our generated entities, but not outside of a bounded context.
			//entity => (decimal)entity.GetType().GetProperty(entity.PrimaryKeyFieldname()).GetValue(entity) == id;
			// Do not use reflection here!  It will possibly cause a table scan or worse.
			//entity => (decimal)entity.GetType().GetProperty(this._keyPropertyName).GetValue(entity) == id;
			// Instead, we have the key field value which was determined in the ctor.  Create an expression for it.

			var item = Expression.Parameter(typeof(T), "entity");
			var prop = Expression.Property(item, _keyPropertyName);
			var value = Expression.Constant(id);
			var equal = Expression.Equal(prop, value);
			var filter = Expression.Lambda<Func<T, bool>>(equal, item);

			var result = _dbSet.AsNoTracking().SingleOrDefault(filter);
			return result;
		}

		/// <summary>
		/// Inserts a record into the DbSet.
		/// </summary>
		/// <param name="entity">The entity to be inserted in the DbSet.</param>
		public void Insert(T entity)
		{
			_dbSet.Add(entity);
		}

		/// <summary>
		/// Updates a record in the DbSet.
		/// </summary>
		/// <param name="entity">The entity to be updated in the DbSet.</param>
		public void Update(T entity)
		{
			_dbSet.Attach(entity);
			_context.Entry(entity).State = EntityState.Modified;
		}

		/// <summary>
		/// Deletes a record in the DbSet.
		/// </summary>
		/// <param name="id">The entity to be deleted from the DbSet.</param>
		public void Delete<TKEY>(TKEY id)
		{
			var entity = FindByKey(id);
			_dbSet.Remove(entity);
		}

		public Expression<Func<T, bool>> BuildLambdaForFindByKey(decimal id)
		{
			var item = Expression.Parameter(typeof(T), "entity");
			var prop = Expression.Property(item, typeof(T).Name + "_ID");
			var value = Expression.Constant(id);
			var equal = Expression.Equal(prop, value);
			var lambda = Expression.Lambda<Func<T, bool>>(equal, item);
			return lambda;
		}
	}
}
