using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace Cats.UnityConfig.Shared

{
	public class SharedContainerRegistry
	{
		private readonly IUnityContainer _unityContainer;
		public SharedContainerRegistry(IUnityContainer unityContainer)
		{
			_unityContainer = unityContainer;
		}

		public void Register()
		{
			//Great Note from documentation: Bear in mind, that if your registrations
			// start to become too complicated or fragile, you are probably doing it wrong.

			//Add _unityContainer.RegisterType() class as needed.

			// Logger registrations
			//_unityContainer.RegisterType<Cats.Logging.ILogger, Cats.Logging.VisualStudioLogger>();	// This works.
			_unityContainer.RegisterType<DwsUI.Core.Logging.ILogger, DwsUI.Core.Logging.Log4NetLogger>();

			// AppService registrations
			_unityContainer.RegisterType<Cats.Bop.Claimant.Data.Interfaces.IClaimantRepository, Cats.Bop.Claimant.Data.Internals.ClaimantRepository>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.Data.Interfaces.IPhoneRepository, Cats.Bop.Claimant.Data.Internals.PhoneRepository>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.Data.Interfaces.IAddressRepository, Cats.Bop.Claimant.Data.Internals.AddressRepository>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.Data.Interfaces.INotesRepository, Cats.Bop.Claimant.Data.Internals.NotesRepository>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.Data.Interfaces.IBopLienRepository, Cats.Bop.Claimant.Data.Internals.BopLienRepository>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.INotesAppService, Cats.Bop.Claimant.Internals.NotesAppService>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.IClaimantSearchService, Cats.Bop.Claimant.Internals.ClaimantSearchService>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.IEmployeeAppService, Cats.Bop.Claimant.Internals.EmployeeAppService>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.IClaimantAppService, Cats.Bop.Claimant.Internals.ClaimantAppService>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.IPhoneAppService, Cats.Bop.Claimant.Internals.PhoneAppService>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.IAddressAppService, Cats.Bop.Claimant.Internals.AddressAppService>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.IBopLienAppService, Cats.Bop.Claimant.Internals.BopLienAppService>();

			// Automapper registrations
			_unityContainer.RegisterType<Cats.Bop.Claimant.Internals.IClaimantAppMappers, Cats.Bop.Claimant.Internals.ClaimantAppMappers>();
			_unityContainer.RegisterType<Cats.Bop.Claimant.Internals.IPhoneAppMappers, Cats.Bop.Claimant.Internals.PhoneAppMappers>();
			//_unityContainer.RegisterType<Cats.Bop.Claimant.Internals.i>

			// Business registrations
			_unityContainer.RegisterType<Cats.Bop.Claimant.Business.Liens.IBopLienStateEngineServiceInterface, Cats.Bop.Claimant.Business.Internals.Liens.BopLienStateEngineService>();
			_unityContainer.RegisterType<DwsUI.Core.Collections.IStateFlowHistory<Cats.Core.Liens.ActionCode, Cats.Core.Liens.StateCode, Cats.Core.Liens.LienData>, DwsUI.Core.Collections.StateFlowHistory<Cats.Core.Liens.ActionCode, Cats.Core.Liens.StateCode, Cats.Core.Liens.LienData>>();

			// Libraries
			_unityContainer.RegisterType<Cats.Core.ILetterRequest, Cats.Core.LetterRequest>();

				// Registery various Bounded Context needs
			new CatsSecurityRegistry(_unityContainer).Register();
		}
	}
}
