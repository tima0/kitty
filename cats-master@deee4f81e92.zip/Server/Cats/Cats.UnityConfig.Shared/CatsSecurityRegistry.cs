using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace Cats.UnityConfig.Shared
{
	public class CatsSecurityRegistry
	{

		private readonly IUnityContainer _unityContainer;
		public CatsSecurityRegistry(IUnityContainer unityContainer)
		{
			_unityContainer = unityContainer;
		}

		public void Register()
		{
			//Application 
			//Note: Configuration File Registration is in Web.config and hence in the Cats.Unity.Config.Web  (Don't place it here)
			_unityContainer.RegisterType<DwsUI.Core.Security.IPrincipalValidation, Cats.Security.Internals.Services.PrincipalValidation>();
			_unityContainer.RegisterType<DwsUI.Core.Security.ISystemAvailable, Cats.Security.Internals.Services.SystemAvailable>();
			_unityContainer.RegisterType<Cats.Security.Services.IPageViewService, Cats.Security.Internals.Services.PageViewService>();
			_unityContainer.RegisterType<Cats.Security.Services.ISessionService, Cats.Security.Internals.Services.SessionService>();
			_unityContainer.RegisterType<Cats.Security.Models.ISessionTimeoutSettings, Cats.Security.Internals.Services.FifteenMinuteSessionTimeoutSettings>();

			//Business
			_unityContainer.RegisterType<Cats.Security.Business.ISessionRules, Cats.Security.Business.Internal.SessionRules>();

			//Data
			_unityContainer.RegisterType<Cats.Security.Data.Repositories.ISecurityParametersRepository, Cats.Security.Data.Internals.Repositories.SecurityParametersRepository>();
			_unityContainer.RegisterType<Cats.Security.Data.Repositories.ISecurityValidationRepository, Cats.Security.Data.Internals.Repositories.SecurityValidationRepository>();
			_unityContainer.RegisterType<Cats.Security.Data.Repositories.IPageVisitRepository, Cats.Security.Data.Internals.Repositories.PageVisitRepository>();
			_unityContainer.RegisterType<Cats.Security.Data.Repositories.ISessionRepository, Cats.Security.Data.Internals.Repositories.SessionRepository>();
			_unityContainer.RegisterType<Cats.Security.Data.Repositories.IEmployeeRepository, Cats.Security.Data.Internals.Repositories.EmployeeRepository>();
		}
	}
}
