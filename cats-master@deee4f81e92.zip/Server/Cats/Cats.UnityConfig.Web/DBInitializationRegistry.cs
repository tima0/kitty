using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.UnityConfig.Web
{
	public class DBInitializationRegistry
	{
		public static void Initialize()
		{
			// All DBContexts must have their DBInitializers set to null to avoid code-first migrations.
			// Register yours by calling it here.
			Cats.Bop.Claimant.Data.Internals.ContextDBInitializer.DisableCodeFirstMigrations();
			Cats.Security.Data.Internals.ContextDBInitializer.DisableCodeFirstMigrations();
		}
	}
}
