using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens
{
	#region public enum StateCode
	public enum StateCode
	{
		_10DayHold,
		_10DayPrinted,
		_28Printed,
		_28PrintHold,
		AR,
		AR28Hold,
		ARIncrease,
		ARPaid,
		Auto3YRLimit,
		BOPCanceled,
		Converted,
		DoNotFile,
		DueProcessRestart,
		Expired,
		Expiring,
		FileAccept,
		Filed,
		FileReject,
		LienRestartProcess,
		ManualAmend,
		ManualFiling,
		ManualNotFiled,
		ManualRestart,
		ManualSatisfy,
		ManualWithdraw,
		Need10day,
		Need28,
		RefileQueue,
		RejectResubmit,
		ReqToSatisfy,
		ReqWithdraw,
		SatCertPaid,
		Satisfied,
		SatisfyAccept,
		SatisfyReject,
		SatNonCertPaid,
		SentToCourt,
		SentToFile,
		SentToSatisfy,
		Wait10day,
		WaitToFile,
		WaitToFileHold,
		WdCertPaid,
		WdNonCertPaid,
		WdrawAccept,
		WdrawIfPaid,
		WdrawReject,
		Withdrawn,
		WithdrawSent
	}
	#endregion


	#region public enum ActionCode
	public enum ActionCode
	{
		_10DayHold,
		_10DayPrinted,
		_28Printed,
		_28PrintHold,
		AR,
		AR28Hold,
		ARIncrease,
		ARPaid,
		Auto3YRLimit,
		BOPCanceled,
		Converted,
		DoNotFile,
		DueProcessRestart,
		Expired,
		Expiring,
		FileAccept,
		Filed,
		FileReject,
		LienRestartProcess,
		ManualAmend,
		ManualFiling,
		ManualNotFiled,
		ManualRestart,
		ManualSatisfy,
		ManualWithdraw,
		Need10day,
		Need28,
		RefileQueue,
		RejectResubmit,
		ReqToSatisfy,
		ReqWithdraw,
		SatCertPaid,
		Satisfied,
		SatisfyAccept,
		SatisfyReject,
		SatNonCertPaid,
		SentToCourt,
		SentToFile,
		SentToSatisfy,
		Wait10day,
		WaitToFile,
		WaitToFileHold,
		WdCertPaid,
		WdNonCertPaid,
		WdrawAccept,
		WdrawIfPaid,
		WdrawReject,
		Withdrawn,
		WithdrawSent
	}
	#endregion

	public enum LienPayoffType { CertFunds, NonCertFunds }

	public static class ConvertStringToEnum
	{
		public static StateCode ToStateCode(this string stateCode)
		{
			var result = stateCode;
			switch (stateCode)
			{
				case "10DAYHOLD":
				case "10DAYPRINTED":
				case "28PRINTED":
				case "28PRINTHOLD":
					result = "_" + stateCode;
					break;
			}
			return (StateCode)Enum.Parse(typeof(StateCode), result, true);
		}

		public static string ToStateCodeString(this StateCode stateCode)
		{
			var result = stateCode.ToString();
			switch(stateCode)
			{
				case StateCode._10DayHold:
				case StateCode._10DayPrinted:
				case StateCode._28Printed:
				case StateCode._28PrintHold:
					result = result.Trim(new char[] { '_' });
					break;
			}
			return result.ToUpper();
		}

		public static ActionCode ToActionCode(this string actionCode)
		{
			var result = actionCode;
			switch (actionCode)
			{
				case "10DAYHOLD":
				case "10DAYPRINTED":
				case "28PRINTED":
				case "28PRINTHOLD":
					result = "_" + actionCode;
					break;
			}
			return (ActionCode)Enum.Parse(typeof(ActionCode), result, true);
		}

		public static string ToActionCodeString(this ActionCode actionCode)
		{
			var result = actionCode.ToString();
			switch (actionCode)
			{
				case ActionCode._10DayHold:
				case ActionCode._10DayPrinted:
				case ActionCode._28Printed:
				case ActionCode._28PrintHold:
					result = result.Trim(new char[] { '_' });
					break;
			}
			return result.ToUpper();
		}
	}


}
