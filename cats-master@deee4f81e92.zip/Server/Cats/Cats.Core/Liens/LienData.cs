using System;
using DwsUI.Core;

namespace Cats.Core.Liens
{
	public partial class LienData
	{
		public long LienID { get; set; }
		public decimal? RestartBalanceWhen28Sent { get; set; }
		public decimal? ArBalance { get; set; }
		public decimal? FiledLienAmount { get; set; }
		public decimal? ConPenBalAmount { get; set; }
		public decimal? ConPenDueAmount { get; set; }
		//public decimal? DebtChargedOff { get; set; }
		public DateTime? ArEstablishedDate { get; set; }
		//public DateTime? ARPayoffDate { get; set; }
		public DateTime? FiledDate { get; set; }

		public DateTime? LastCertPmtDate { get; set; }
		public DateTime? LastNonCertPmtDate { get; set; }

		public decimal? BalanceChangedNeedToRestart { get; set; }

		public bool HasAdminHold { get; set; }
		public bool HasAppealHold { get; set; }
		public bool HasBankruptcy { get; set; }
		public bool HasInstallmentAgreement { get; set; }
		public StateCode LastLienAction { get; set; }
		public DateTime? LastLienActionDate { get; set; }
		public string LastActionReason { get; set; }
		public DateTime? FirstWait10DayDate { get; set; }
		public DateTime? FirstWaitToFileDate { get; set; }
		public DateTime? LastCorrespondenceDate { get; set; }
		public StateCode PreviousStateCode { get; set; }
		public decimal? ConPenDueFiledAmt { get; set; }
		public decimal? ConPenDueForcedAmt { get; set; }
		public decimal? ChargeOffAmt { get; set; }
		public bool CanceledDebt { get; set; }
		public decimal? CurrentRestartBal { get; set; }

		public static int DelayCertFundDays => 3;
		public static int DelayNonCertFundDays => 21;

		public virtual LienPayoffType GetPayoffType()
		{
			// Default to Non Cert Funds
			if (this.LastNonCertPmtDate == null && this.LastCertPmtDate == null)
			{
				return LienPayoffType.NonCertFunds;
			}

			// If No "NON" Certifed funds payments have come in then it has to be Certfied.
			if (this.LastNonCertPmtDate == null)
			{
				return LienPayoffType.CertFunds;
			}

			// If No Certifed funds payments have come in then it has to be "NON" Certfied.
			if (this.LastCertPmtDate == null)
			{
				return LienPayoffType.NonCertFunds;
			}

			// If Certified later than or equal to Non Certified then its certifed
			DateTime lastCertPmtDelayDate = this.LastCertPmtDate.Value.AddWorkDays(LienData.DelayCertFundDays).Date;
			DateTime lastNonCertPmtDelayDate = this.LastNonCertPmtDate.Value.AddDays(LienData.DelayNonCertFundDays).Date;
			if (lastCertPmtDelayDate >= lastNonCertPmtDelayDate)
			{
				return LienPayoffType.CertFunds;
			}
			else
			{
				return LienPayoffType.NonCertFunds;
			}

		}

		public virtual DateTime GetWillFlowDate()
		{
			var payOffType = this.GetPayoffType();

			if (payOffType == LienPayoffType.CertFunds)
			{
				if (this.LastCertPmtDate == null)
				{
					return this.LastLienActionDate.Value
						.AddWorkDays(LienData.DelayCertFundDays)
						.Date;
				}
				else
				{
					return this.LastCertPmtDate.Value
						.AddWorkDays(LienData.DelayCertFundDays)
						.Date;
				}
			}
			else
			{
				if (this.LastNonCertPmtDate == null)
				{
					return this.LastLienActionDate.Value
						.AddDays(LienData.DelayNonCertFundDays)
						.Date;
				}
				else
				{
					return this.LastNonCertPmtDate.Value
						.AddDays(LienData.DelayNonCertFundDays)
						.Date;
				}
			}
		}
	}
}
