using System;
using System.Linq;
using System.Collections.Generic;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public class FlowRuleFactory : IFlowRuleFactory<ActionCode, StateCode, LienData>
    {
		public DateTime ProcessingDate
		{
			get => _processingDate;
			set => _processingDate = value;
		}

		private DateTime _processingDate;		

		public FlowRuleFactory(DateTime processingDate)
		{
			_processingDate = processingDate;
		}

		protected virtual IFlowRule<ActionCode, StateCode, LienData> CreateFlowRuleObject(Type flowRuleClass)
		{
			var result = flowRuleClass.GetConstructor(new Type[] { typeof(DateTime) }).Invoke( new object[] { _processingDate } );
			return result as IFlowRule<ActionCode, StateCode, LienData>;
		}

		public IFlowRule<ActionCode, StateCode, LienData> Get(ActionCode actionCode, StateCode sourceState, StateCode destinationState)
		{
			switch (actionCode)
			{
				case ActionCode._28PrintHold:
				case ActionCode.AR28Hold:
				case ActionCode._10DayHold:
				case ActionCode.WaitToFileHold:
					return CreateFlowRuleObject(typeof(FlagStopFlow));

				case ActionCode._28Printed:
					return CreateFlowRuleObject(typeof(_28PrintedFlow));

				case ActionCode._10DayPrinted:
					return CreateFlowRuleObject(typeof(BasicPrintFlow));					

				case ActionCode.ManualRestart:
				case ActionCode.SentToCourt:
				case ActionCode.FileAccept:
				case ActionCode.FileReject:
				case ActionCode.ManualNotFiled:
				case ActionCode.RejectResubmit:
				case ActionCode.ManualFiling:
				case ActionCode.WdrawIfPaid:
				case ActionCode.ManualWithdraw:
				case ActionCode.ManualSatisfy:
				case ActionCode.WithdrawSent:
				case ActionCode.WdrawAccept:					
				case ActionCode.WdrawReject:
				case ActionCode.SentToSatisfy:
				case ActionCode.SatisfyAccept:
				case ActionCode.SatisfyReject:
					return new BasicFlow(_processingDate);

				case ActionCode.AR:
					switch(sourceState)
					{
						case StateCode.LienRestartProcess:
							return new AutoCascadeFlow(_processingDate);
						default:
							return new BasicFlow(_processingDate);
					}

				case ActionCode.DoNotFile:
					switch(sourceState)
					{
						case StateCode.Auto3YRLimit:
						case StateCode.ManualNotFiled:
						case StateCode.BOPCanceled:
							return new AutoCascadeFlow(_processingDate);
						default:
							return new BasicFlow(_processingDate);
					}

				case ActionCode.Expiring:
					switch(sourceState)
					{
						case StateCode.SatNonCertPaid:
						case StateCode.SatCertPaid:
							return new HasBalanceAndPrevStateMatchFlow(_processingDate);
						default:
							return new BasicFlow(_processingDate);
					}

				case ActionCode.ReqWithdraw:
					switch(sourceState)
					{
						case StateCode.WdNonCertPaid:
							return new CertPaidWaitFlow(_processingDate);
						case StateCode.ReqToSatisfy:
							return new CanceledDebtFlow(_processingDate);
						default:
							return new BasicFlow(_processingDate);
					}

				case ActionCode.ManualAmend:
					switch(sourceState)
					{
						case StateCode.ARIncrease:
							return new SetConPenFlow(_processingDate);
						default:
							return new BasicFlow(_processingDate);
					}
				case ActionCode.ARPaid:
					switch(sourceState)
					{
						case StateCode.SentToCourt:
							return new BasicFlow(_processingDate);
						default:
							return new ARPaidFlow(_processingDate);
					}
										
				case ActionCode.BOPCanceled:
					return new CanceledDebtFlow(_processingDate);
					
				case ActionCode.LienRestartProcess:
					switch(sourceState)
					{
						case StateCode.DoNotFile:
							return new BasicFlow(_processingDate);
						default:
							return new AutoCascadeFlow(_processingDate);
					}
									
				case ActionCode.DueProcessRestart:
					switch(sourceState)
					{
						case StateCode.DueProcessRestart:
							return new AutoCascadeFlow(_processingDate);
						default:
							return new DueProcessRestart(_processingDate);
					}


				case ActionCode.Need28:
					switch(sourceState)
					{
						case StateCode._28PrintHold:
						case StateCode.AR28Hold:
							return new NoFlagStopFlow(_processingDate);
						default:
							return new AutoCascadeFlow(_processingDate);
					}					

				case ActionCode.Wait10day:
					switch(sourceState)
					{
						case StateCode._10DayHold:
							return new NoFlagStopFlow(_processingDate);
						default:
							return new Wait10DayAutoFlow(_processingDate);
					}
					
				case ActionCode.Need10day:
					return new Wait10DayFlow(_processingDate);					

				case ActionCode.WaitToFile:
					switch(sourceState)
					{
						case StateCode.WaitToFileHold:
							return new NoFlagStopFlow(_processingDate);							
						case StateCode.SentToFile:
							return new FlagStopFlow(_processingDate);
						default:
							return new WaitToFileAutoFlow(_processingDate);
					}

				case ActionCode.SentToFile:
					switch(sourceState)
					{
						case StateCode.SentToCourt:
							return new BasicFlow(_processingDate);
						default:
							return new WaitToFileFlow(_processingDate);
					}					

				case ActionCode.Filed:
					switch(sourceState)
					{
						case StateCode.ManualFiling:
						case StateCode.ManualAmend:
							return new ManualAmendAutoFlow(_processingDate);
						case StateCode.ARIncrease:
							return new SetConPenFlow(_processingDate);
						case StateCode.SatNonCertPaid:
						case StateCode.SatCertPaid:
							return new HasBalanceAndPrevStateMatchFlow(_processingDate);
						case StateCode.ReqToSatisfy:
							return new HasBalanceFlow(_processingDate);
						default:
							return new BasicFlow(_processingDate);
					}
										
				case ActionCode.Auto3YRLimit:
					return new OlderThan3YearFlow(_processingDate);
					

				case ActionCode.ARIncrease:
					break;
				
				case ActionCode.Expired:
					switch(sourceState)
					{
						case StateCode.WdrawIfPaid:
						case StateCode.WdNonCertPaid:
							return new BasicFlow(_processingDate);
						case StateCode.SatNonCertPaid:
						case StateCode.SatCertPaid:
							return new HasBalanceAndPrevStateMatchFlow(_processingDate);
						default:
							return new ExpiredCheckFlow(_processingDate);
					}

				case ActionCode.WdNonCertPaid:
					switch(sourceState)
					{
						case StateCode.SatNonCertPaid:
							return new BasicFlow(_processingDate);
						default:
							return new WDNonCertPaidFlow(_processingDate);
					}					
					
				case ActionCode.WdCertPaid:
					switch(sourceState)
					{
						case StateCode.SatCertPaid:
							return new BasicFlow(_processingDate);
						default:
							return new WDCertPaidFlow(_processingDate);
					}
					
				case ActionCode.Withdrawn:
					switch(sourceState)
					{
						case StateCode.Satisfied:
						case StateCode.ManualWithdraw:
							return new BasicFlow(_processingDate);
						default:
							return new AutoCascadeFlow(_processingDate);
					}
					

				case ActionCode.ReqToSatisfy:
					switch(sourceState)
					{
						case StateCode.SatNonCertPaid:
							return new NonCertPaidWaitFlow(_processingDate);
						case StateCode.SatCertPaid:
							return new CertPaidWaitFlow(_processingDate);
						case StateCode.SentToSatisfy:
							return new BasicFlow(_processingDate);
						default:
							return new NonCertPaidWaitFlow(_processingDate);
					}
					
				case ActionCode.SatNonCertPaid:
					return new SatisfyNonCertPaidFlow(_processingDate);
					
				case ActionCode.SatCertPaid:
					return new SatisfyCertPaidFlow(_processingDate);
					
				case ActionCode.Satisfied:
					return new AutoCascadeFlow(_processingDate);
					
				case ActionCode.RefileQueue:
					break;
				default:
					return new BasicFlow(_processingDate);
			}
			return new BasicFlow(_processingDate);
		}
	}
}
