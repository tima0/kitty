using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class ARPaidFlow : FlowRuleBase
	{
		public ARPaidFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			// will move to the target state if $0
			return transitionInfo.Data.ArBalance == 0;
		}
	}
}
