using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class BasicFlow : FlowRuleBase
	{
		public BasicFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanCascadeFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}

		protected override bool GetAllowCascadeEntry(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			// Non-cascadeable. One shot flow.
			return false;
		}
	}
}
