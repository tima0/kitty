using DwsUI.Core.Collections;
using System;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class HasBalanceFlow : FlowRuleBase
	{
		public HasBalanceFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return transitionInfo.Data.ArBalance > 0;
		}
	}
}
