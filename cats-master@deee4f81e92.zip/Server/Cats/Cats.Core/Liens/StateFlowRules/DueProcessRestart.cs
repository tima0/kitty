using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class DueProcessRestart : FlowRuleBase
	{
		public DueProcessRestart(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var result = false;
			var data = transitionInfo.Data;

			if (data.LastCorrespondenceDate.HasValue)
			{
				result = data.LastCorrespondenceDate.Value.AddDays(90).Date < this.ProcessingDate;
			}
			else
			{
				result = data.LastLienActionDate.Value.AddDays(90).Date < this.ProcessingDate;
			}

			if (!result)
			{
				result = data.RestartBalanceWhen28Sent < data.CurrentRestartBal;
			}

			return result;
		}

		protected override bool GetCanCascadeFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}


	}
}
