using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class _28PrintedFlow: FlowRuleBase
	{
		public _28PrintedFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}

		protected override bool GetAllowCascadeEntry(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return false;
		}

		protected override void GetAfterFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			transitionInfo.Data.LastCorrespondenceDate = ProcessingDate;
			transitionInfo.Data.RestartBalanceWhen28Sent = transitionInfo.Data.CurrentRestartBal;

			base.GetAfterFlowEvent(transitionInfo);

		}
	}
}
