using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	// TODO: Move this to employer (Need10Day rule)
	public sealed class BalUnder25Flow : FlowRuleBase
	{
		public BalUnder25Flow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return transitionInfo.Data.ArBalance < 25;
		}

		protected override string GetFlowReason(LienData data)
		{
			return "Balance is under $25.00 moving back to wait";
		}
		protected override void GetAfterFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			base.GetAfterFlowEvent(transitionInfo);

			transitionInfo.Data.FirstWait10DayDate = ProcessingDate;
		}
	}
}
