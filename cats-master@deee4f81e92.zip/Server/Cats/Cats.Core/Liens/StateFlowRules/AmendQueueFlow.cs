using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class AmendQueueFlow : FlowRuleBase
	{
		public AmendQueueFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var result = false;
			if (transitionInfo.Data.ConPenDueForcedAmt == 0)
			{
				result = transitionInfo.Data.ConPenDueFiledAmt != transitionInfo.Data.ConPenDueAmount;
			}
			else
			{
				result = transitionInfo.Data.ConPenDueForcedAmt != transitionInfo.Data.ConPenDueAmount;
			}

			if (transitionInfo.Data.ConPenDueAmount == 0)
			{
				result = false;
			}

			return result;
		}
	}
}
