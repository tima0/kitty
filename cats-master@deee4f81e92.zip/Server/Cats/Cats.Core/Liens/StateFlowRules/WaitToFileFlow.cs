using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class WaitToFileFlow : FlowRuleBase
	{
		public WaitToFileFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			//wait 15 days
			return(transitionInfo.Data.FirstWaitToFileDate.Value.AddDays(15).Date < ProcessingDate.Date);
		}	

		protected override void GetAfterFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			transitionInfo.Data.FirstWaitToFileDate = ProcessingDate.Date;
			base.GetAfterFlowEvent(transitionInfo);
		}
	}
}

