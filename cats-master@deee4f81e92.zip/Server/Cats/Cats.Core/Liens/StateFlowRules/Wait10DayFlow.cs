using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class Wait10DayFlow : FlowRuleBase
	{

		public Wait10DayFlow(DateTime processingDate) : base(processingDate)
		{

		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var firstWait10DayDate = transitionInfo.Data.FirstWait10DayDate.Value.AddDays(15).Date;
			return (firstWait10DayDate < this.ProcessingDate);
		}

	}
}
