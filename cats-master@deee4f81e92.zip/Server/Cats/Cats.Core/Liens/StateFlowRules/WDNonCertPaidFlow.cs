using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class WDNonCertPaidFlow : FlowRuleBase
	{
		public WDNonCertPaidFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return transitionInfo.Data.ChargeOffAmt == 0 && transitionInfo.Data.ArBalance == 0 && transitionInfo.Data.GetPayoffType() == LienPayoffType.NonCertFunds;
		}
	}
}
