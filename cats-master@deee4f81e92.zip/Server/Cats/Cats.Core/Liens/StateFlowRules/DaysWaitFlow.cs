using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	// TODO: This code is not used in the Delphi lien source
	public sealed class DaysWaitFlow : FlowRuleBase
	{
		public DaysWaitFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var daysWait = 1;
			var lastLienActionDate = transitionInfo.Data.LastLienActionDate.Value;
			return lastLienActionDate.AddDays(daysWait).Date < this.ProcessingDate.Date;
		}
	}
}
