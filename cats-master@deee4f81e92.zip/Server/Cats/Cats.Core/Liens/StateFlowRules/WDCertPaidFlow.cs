using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class WDCertPaidFlow : FlowRuleBase
	{
		public WDCertPaidFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var data = transitionInfo.Data;
			return data.ChargeOffAmt == 0 && data.ArBalance == 0 && data.GetPayoffType().Equals(LienPayoffType.CertFunds);
		}
	}
}
