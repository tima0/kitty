using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class WaitToFileAutoFlow : FlowRuleBase
	{
		public WaitToFileAutoFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanCascadeFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return false;
		}
			

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}

		protected override void GetAfterFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			//just the standard stuff. 
			transitionInfo.Data.FirstWaitToFileDate = ProcessingDate.Date;
			base.GetAfterFlowEvent(transitionInfo);
		}
	}
}
