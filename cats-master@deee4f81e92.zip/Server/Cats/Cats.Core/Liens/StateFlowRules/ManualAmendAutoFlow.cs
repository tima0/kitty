using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public class ManualAmendAutoFlow : FlowRuleBase
	{
		public ManualAmendAutoFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanCascadeFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo) => true;

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo) => true;

		protected override string GetFlowReason(LienData data)
		{
			return ("Amending Lien");
		}
	}
}
