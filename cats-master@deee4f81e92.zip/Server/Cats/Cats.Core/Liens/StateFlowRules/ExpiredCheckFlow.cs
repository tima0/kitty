using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class ExpiredCheckFlow : FlowRuleBase
	{
		public ExpiredCheckFlow(DateTime processingDate) : base(processingDate)
		{

		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var result = false;
			var data = transitionInfo.Data;

			if (data.FiledDate == null)
			{
				result = false;
			}
			else
			{
				var expireDate = data.FiledDate.Value.AddYears(8);
				result = expireDate <= ProcessingDate; ;
			}

			return result;

		}
	}
}
