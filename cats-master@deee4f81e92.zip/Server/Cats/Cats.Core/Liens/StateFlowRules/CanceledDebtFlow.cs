using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class CanceledDebtFlow : FlowRuleBase
	{
		public CanceledDebtFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return transitionInfo.Data.CanceledDebt;
		}
		protected override string GetFlowReason(LienData data)
		{
			return "Canceled Debt Detected";
		}
	}
}
