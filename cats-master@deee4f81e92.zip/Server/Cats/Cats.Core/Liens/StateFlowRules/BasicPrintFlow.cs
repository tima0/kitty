using System;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public class BasicPrintFlow : FlowRuleBase
	{
		public BasicPrintFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanCascadeFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}

		protected override bool GetAllowCascadeEntry(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return false;
		}

		protected override void GetAfterFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			transitionInfo.Data.LastCorrespondenceDate = ProcessingDate;
			base.GetAfterFlowEvent(transitionInfo);
		}
	}
}
