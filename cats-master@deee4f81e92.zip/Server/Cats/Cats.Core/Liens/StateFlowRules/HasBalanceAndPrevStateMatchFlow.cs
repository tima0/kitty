using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class HasBalanceAndPrevStateMatchFlow : FlowRuleBase
	{
		public HasBalanceAndPrevStateMatchFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var result = transitionInfo.Data.ArBalance > 0 && (transitionInfo.SourceState == transitionInfo.DestinationState);
			return result;
		}
	}
}
