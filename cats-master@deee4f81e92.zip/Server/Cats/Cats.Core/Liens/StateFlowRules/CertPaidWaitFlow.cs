using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class CertPaidWaitFlow : FlowRuleBase
	{
		public CertPaidWaitFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return transitionInfo.Data.GetWillFlowDate().Date <= this.ProcessingDate.Date;
		}
	}
}
