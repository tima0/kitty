using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class SetConPenFlow : FlowRuleBase
	{
		public SetConPenFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return true;
		}

		protected override bool GetCanCascadeFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return false;
		}

		protected override void GetBeforeFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			if (transitionInfo.Data.ConPenDueAmount == 0)
			{
				throw new FlowRuleException("Con/Pen Due is Zero, should not be amending it should be going down satisfication. Contact Programmer to fix data.");
			}
			transitionInfo.Data.ConPenDueForcedAmt = transitionInfo.Data.ConPenDueAmount;

			base.GetBeforeFlowEvent(transitionInfo);
		}
	}
}
