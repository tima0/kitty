using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public sealed class OlderThan3YearFlow : FlowRuleBase
	{
		public OlderThan3YearFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var result = false;
			if (transitionInfo.Data.ArEstablishedDate.HasValue)
			{
				result = transitionInfo.Data.ArEstablishedDate.Value.AddYears(3).Date < this.ProcessingDate.Date;
			}

			return result;
		}

		protected override string GetFlowReason(LienData data)
		{			
			return "Established Date is over 3 years old.";
		}
	}
}
