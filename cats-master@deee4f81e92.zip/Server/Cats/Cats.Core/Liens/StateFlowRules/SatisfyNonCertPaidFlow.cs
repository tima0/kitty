using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens.StateFlowRules
{
	public class SatisfyNonCertPaidFlow : FlowRuleBase
	{
		public SatisfyNonCertPaidFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var data = transitionInfo.Data;
			var chargedOffAmount = data.ChargeOffAmt ?? 0;
			var result = (!data.CanceledDebt)
					&& (chargedOffAmount == 0)
					&& (data.ArBalance == 0)
					&& (data.GetPayoffType() == LienPayoffType.NonCertFunds);

			return (result);
		}

	}
}
