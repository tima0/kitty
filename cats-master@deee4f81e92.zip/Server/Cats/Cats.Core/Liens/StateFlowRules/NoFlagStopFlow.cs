using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;
using Cats.Core.Liens;

namespace Cats.Core.Liens.StateFlowRules
{
	public class NoFlagStopFlow : FlowRuleBase
	{
		public NoFlagStopFlow(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return !(transitionInfo.Data.HasAdminHold
				|| transitionInfo.Data.HasAppealHold
				|| transitionInfo.Data.HasBankruptcy
				|| transitionInfo.Data.HasInstallmentAgreement);
		}

		protected override void GetAfterFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			base.GetAfterFlowEvent(transitionInfo);
			if ((transitionInfo.SourceState == StateCode._10DayHold)
				&& (transitionInfo.Data.FirstWait10DayDate == null))
			{
				transitionInfo.Data.FirstWait10DayDate = ProcessingDate;
			}
			else if ((transitionInfo.SourceState == StateCode.WaitToFileHold) && (transitionInfo.Data.FirstWaitToFileDate == null))
			{
				transitionInfo.Data.FirstWaitToFileDate = ProcessingDate;
			};
		}
	}
}
