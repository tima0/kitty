using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core.Liens
{
    public class FlowRuleException : Exception
	{

		protected FlowRuleException() : base()
		{

		}

		public FlowRuleException(string message) : base(message)
		{

		}

	}
}
