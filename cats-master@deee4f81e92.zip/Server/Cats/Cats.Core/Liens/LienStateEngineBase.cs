using System;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens
{
	public class LienStateEngineBase : StateFlowEngine<ActionCode, StateCode, LienData>
	{
		private DateTime _processingDate;

		protected FlowRuleFactory _flowRuleFactory;

		public LienStateEngineBase(StateCode initialState, IStateFlowHistory<ActionCode, StateCode, LienData> stateFlowHistory, DateTime processingDate)
			: base(initialState, stateFlowHistory)
		{
			_processingDate = processingDate;

			// default factory
			_flowRuleFactory = new FlowRuleFactory(processingDate);
			InitializeFlows(_flowRuleFactory); 			
		}

		public DateTime ProcessingDate 
		{
			get => _processingDate;			
		}

		protected virtual void InitializeFlows(FlowRuleFactory flowRuleFactory)
		{
			// read: When in StateCode.RefileQueue state
			//		What are the possible actions and its corresponding result state?
			//
			//		The 3rd .Flow() parameter defines the business rules on how it gets to the new state.
			//		A flow rule factory can also be passed into the Configure() method that will
			//		internally assign the appropriate Flow rule object.
			//
			//		If you pass in a FlowRule object into Flow(), that will take priority over the flow rule factory.
			//
			//		See Lien System flow chart for reference.

			Configure(StateCode.RefileQueue, flowRuleFactory)
				.Flow(ActionCode.AR, StateCode.AR)
				.Flow(ActionCode.DoNotFile, StateCode.DoNotFile);

			Configure(StateCode.AR, flowRuleFactory)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.AR28Hold, StateCode.AR28Hold)
				.Flow(ActionCode.Need28, StateCode.Need28)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit);
;				
			Configure(StateCode.LienRestartProcess, flowRuleFactory)
				.Flow(ActionCode.AR, StateCode.AR);

			Configure(StateCode.AR28Hold, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.Need28, StateCode.Need28); 

			Configure(StateCode.Need28, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode._28PrintHold, StateCode._28PrintHold)
				.Flow(ActionCode._28Printed, StateCode._28Printed)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit);

			Configure(StateCode._28PrintHold, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.Need28, StateCode.Need28)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit);

			Configure(StateCode._28Printed, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.Wait10day, StateCode.Wait10day);

			Configure(StateCode.Wait10day, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode._10DayHold, StateCode._10DayHold)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.Need10day, StateCode.Need10day)
				.Flow(ActionCode.ManualRestart, StateCode.ManualRestart)
				.Flow(ActionCode.DueProcessRestart, StateCode.DueProcessRestart);

			Configure(StateCode.Need10day, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode._10DayHold, StateCode._10DayHold)
				.Flow(ActionCode._10DayPrinted, StateCode._10DayPrinted)
				.Flow(ActionCode.ManualRestart, StateCode.ManualRestart)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.DueProcessRestart, StateCode.DueProcessRestart);

			Configure(StateCode._10DayHold, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.Wait10day, StateCode.Wait10day)
				.Flow(ActionCode.ManualRestart, StateCode.ManualRestart)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.DueProcessRestart, StateCode.DueProcessRestart);

			Configure(StateCode._10DayPrinted, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.WaitToFile, StateCode.WaitToFile)
				.Flow(ActionCode.ManualRestart, StateCode.ManualRestart)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit);

			Configure(StateCode.WaitToFile, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.WaitToFileHold, StateCode.WaitToFileHold)
				.Flow(ActionCode.SentToFile, StateCode.SentToFile)
				.Flow(ActionCode.ManualRestart, StateCode.ManualRestart)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.DueProcessRestart, StateCode.DueProcessRestart);

			Configure(StateCode.WaitToFileHold, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.WaitToFile, StateCode.WaitToFile)
				.Flow(ActionCode.ManualRestart, StateCode.ManualRestart)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.DueProcessRestart, StateCode.DueProcessRestart);

			Configure(StateCode.SentToFile, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.WaitToFileHold, StateCode.WaitToFileHold)
				.Flow(ActionCode.SentToCourt, StateCode.SentToCourt)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.DueProcessRestart, StateCode.DueProcessRestart);

			Configure(StateCode.SentToCourt, flowRuleFactory)
				.Flow(ActionCode.FileAccept, StateCode.FileAccept)
				.Flow(ActionCode.FileReject, StateCode.FileReject)
				.Flow(ActionCode.SentToFile, StateCode.SentToFile)
				.Flow(ActionCode.ManualRestart, StateCode.ManualRestart)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid);

			Configure(StateCode.FileReject, flowRuleFactory)
				.Flow(ActionCode.BOPCanceled, StateCode.BOPCanceled)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.Auto3YRLimit, StateCode.Auto3YRLimit)
				.Flow(ActionCode.ManualNotFiled, StateCode.ManualNotFiled)
				.Flow(ActionCode.FileAccept, StateCode.FileAccept)
				.Flow(ActionCode.RejectResubmit, StateCode.RejectResubmit)
				.Flow(ActionCode.ManualFiling, StateCode.ManualFiling);

			Configure(StateCode.RejectResubmit, flowRuleFactory)
				.Flow(ActionCode.ARPaid, StateCode.ARPaid)
				.Flow(ActionCode.SentToCourt, StateCode.SentToCourt);

			Configure(StateCode.FileAccept, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed);

			Configure(StateCode.ManualFiling, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed);

			Configure(StateCode.Filed, flowRuleFactory)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.Expired, StateCode.Expired)
				.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw)
				.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
				.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid)
				.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
				.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy);

			Configure(StateCode.ManualAmend, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed);

			Configure(StateCode.Expiring, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed)
				//.Flow(ActionCode.WillExpire, StateCode.WillExpire)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
				.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy)
				.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw)
				.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
				.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid)
				.Flow(ActionCode.Expired, StateCode.Expired);

			//Configure(StateCode.WillExpire, flowRuleFactory)
			//	.Flow(ActionCode.Expired, StateCode.Expired)
			//	.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
			//	.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
			//	.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy)
			//	.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)
			//	.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw)
			//	.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
			//	.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid);

			Configure(StateCode.Expired, flowRuleFactory)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
				.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy)
				.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
				.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw);

			Configure(StateCode.ARIncrease, flowRuleFactory)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.Filed, StateCode.Filed);

			Configure(StateCode.WdrawIfPaid, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.Expiring, StateCode.Expiring)
				//.Flow(ActionCode.WillExpire, StateCode.WillExpire)
				.Flow(ActionCode.Expired, StateCode.Expired)
				.Flow(ActionCode.WdCertPaid, StateCode.WdCertPaid)
				.Flow(ActionCode.WdNonCertPaid, StateCode.WdNonCertPaid);

			Configure(StateCode.WdNonCertPaid, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.Expiring, StateCode.Expiring)
				//.Flow(ActionCode.WillExpire, StateCode.WillExpire)
				.Flow(ActionCode.Expired, StateCode.Expired)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw);

			Configure(StateCode.WdCertPaid, flowRuleFactory)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw);

			Configure(StateCode.ManualWithdraw, flowRuleFactory)
				.Flow(ActionCode.Withdrawn, StateCode.Withdrawn);

			Configure(StateCode.ReqWithdraw, flowRuleFactory)
				.Flow(ActionCode.WithdrawSent, StateCode.WithdrawSent);

			Configure(StateCode.WithdrawSent, flowRuleFactory)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw)
				.Flow(ActionCode.WdrawAccept, StateCode.WdrawAccept)
				.Flow(ActionCode.WdrawReject, StateCode.WdrawReject);

			Configure(StateCode.WdrawAccept, flowRuleFactory)
				.Flow(ActionCode.Withdrawn, StateCode.Withdrawn);

			Configure(StateCode.WdrawReject, flowRuleFactory)
				.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw)
				.Flow(ActionCode.WdrawAccept, StateCode.WdrawAccept);

			Configure(StateCode.ManualSatisfy, flowRuleFactory)
				.Flow(ActionCode.Satisfied, StateCode.Satisfied);

			Configure(StateCode.ReqToSatisfy, flowRuleFactory)
				.Flow(ActionCode.SentToSatisfy, StateCode.SentToSatisfy)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw);

			Configure(StateCode.SatNonCertPaid, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.Expiring, StateCode.Expiring)
				//.Flow(ActionCode.WillExpire, StateCode.WillExpire)
				.Flow(ActionCode.Expired, StateCode.Expired)
				.Flow(ActionCode.WdNonCertPaid, StateCode.WdNonCertPaid)
				.Flow(ActionCode.ReqToSatisfy, StateCode.ReqToSatisfy);

			Configure(StateCode.SatCertPaid, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.Expiring, StateCode.Expiring)
				//.Flow(ActionCode.WillExpire, StateCode.WillExpire)
				.Flow(ActionCode.Expired, StateCode.Expired)
				.Flow(ActionCode.WdCertPaid, StateCode.WdCertPaid)
				.Flow(ActionCode.ReqToSatisfy, StateCode.ReqToSatisfy);

			Configure(StateCode.SentToSatisfy, flowRuleFactory)
				.Flow(ActionCode.SatisfyAccept, StateCode.SatisfyAccept)
				.Flow(ActionCode.SatisfyReject, StateCode.SatisfyReject)
				.Flow(ActionCode.ReqToSatisfy, StateCode.ReqToSatisfy);

			Configure(StateCode.SatisfyAccept, flowRuleFactory)
				.Flow(ActionCode.Satisfied, StateCode.Satisfied);

			Configure(StateCode.SatisfyReject, flowRuleFactory)
				.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy)
				.Flow(ActionCode.ReqToSatisfy, StateCode.ReqToSatisfy)
				.Flow(ActionCode.SatisfyAccept, StateCode.SatisfyAccept);

			Configure(StateCode.Satisfied, flowRuleFactory)
				.Flow(ActionCode.Withdrawn, StateCode.Withdrawn);

			Configure(StateCode.Auto3YRLimit, flowRuleFactory)
				.Flow(ActionCode.DoNotFile, StateCode.DoNotFile);

			Configure(StateCode.ManualNotFiled, flowRuleFactory)
				.Flow(ActionCode.DoNotFile, StateCode.DoNotFile);

			Configure(StateCode.BOPCanceled, flowRuleFactory)
				.Flow(ActionCode.DoNotFile, StateCode.DoNotFile);

			Configure(StateCode.DueProcessRestart, flowRuleFactory)
				.Flow(ActionCode.LienRestartProcess, StateCode.LienRestartProcess);

			Configure(StateCode.LienRestartProcess, flowRuleFactory)
				.Flow(ActionCode.AR, StateCode.AR);

			Configure(StateCode.ManualRestart, flowRuleFactory)
				.Flow(ActionCode.LienRestartProcess, StateCode.LienRestartProcess);

			Configure(StateCode.DoNotFile, flowRuleFactory)
				.Flow(ActionCode.LienRestartProcess, StateCode.LienRestartProcess);
		}

	}
}
