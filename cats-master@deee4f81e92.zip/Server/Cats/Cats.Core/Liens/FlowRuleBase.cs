using System;
using DwsUI.Core.Collections;

namespace Cats.Core.Liens
{
	public abstract class FlowRuleBase : IFlowRule<ActionCode, StateCode, LienData>
	{
		private readonly DateTime _processingDate;		

		public FlowRuleBase(DateTime processingDate)
		{
			_processingDate = processingDate;
		}

		protected DateTime ProcessingDate => _processingDate;

		public Func<FlowTransitionInfo<ActionCode, StateCode, LienData>, bool> CanFlow => GetCanFlow;

		public Func<FlowTransitionInfo<ActionCode, StateCode, LienData>, bool> CanCascadeFlow => GetCanCascadeFlow;

		public Func<FlowTransitionInfo<ActionCode, StateCode, LienData>, bool> CanChainFlow => GetCanChainFlow;

		public Action<FlowTransitionInfo<ActionCode, StateCode, LienData>> BeforeFlowEvent => GetBeforeFlowEvent;
	
		public Action<FlowTransitionInfo<ActionCode, StateCode, LienData>> AfterFlowEvent => GetAfterFlowEvent;

		public Func<LienData, string> FlowDescription => GetFlowReason;

		public Func<FlowTransitionInfo<ActionCode, StateCode, LienData>, bool> AllowCascadeEntry => GetAllowCascadeEntry;

		protected virtual bool GetAllowCascadeEntry(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			// default flow cascadeable
			return true;
		}
		
		protected virtual bool GetCanCascadeFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			// if it can't go to the next state
			// try the next flow config
			return CanFlow(transitionInfo) == false;
		}

		protected virtual bool GetCanChainFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			// if it can change state, it can chain states
			return CanFlow(transitionInfo);
		}

		protected abstract bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo);

		protected virtual string GetFlowReason(LienData data)
		{
			return string.Empty;
		}

		protected virtual void GetAfterFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			transitionInfo.Data.LastLienAction = transitionInfo.DestinationState;
			transitionInfo.Data.LastLienActionDate = _processingDate;
			transitionInfo.Data.LastActionReason = this.GetFlowReason(transitionInfo.Data);
		}

		protected virtual void GetBeforeFlowEvent(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{

		}
	}

}
