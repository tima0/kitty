using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core
{
	public struct LetterAddressBookmark
	{
		public string FullName;
		public string DbaName;
		public string Address1;
		public string Address2;
		public string City;
		public string State;
		public string Zip;
		public string Country;
		public int InternationalIndicator;
	}

    public interface ILetterRequest
    {
		long Print(string letterName, LetterAddressBookmark bookmark);
    }

	public class LetterRequest : ILetterRequest
	{
		public long Print(string letterName, LetterAddressBookmark bookmark)
		{
			return 0;
		}
	}
}
