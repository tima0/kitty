using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Core
{
	public interface IGenericRepository<T>
	{
		void SaveChanges();
		void SaveChangesAsync();
		IEnumerable<T> All();
		IEnumerable<T> AllIncluding(params Expression<Func<T, object>>[] includeProperties);
		IEnumerable<T> FindByIncluding(Expression<Func<T, bool>> predicate,
			params Expression<Func<T, object>>[] includeProperties);
		IEnumerable<T> FindBy(Expression<Func<T, bool>> predicate);
		T FindByKey<TKEY>(TKEY id);
		void Insert(T entity);
		void Update(T entity);
		void Delete<TKEY>(TKEY id);
		Expression<Func<T, bool>> BuildLambdaForFindByKey(decimal id);
	}
}
