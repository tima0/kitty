using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;
using Cats.UnityConfig.Shared;

namespace Cats.UnityConfig.Batch
{
    public class BatchContainerRegistry
    {
		private readonly IUnityContainer _unityContainer;
		public BatchContainerRegistry(IUnityContainer unityContainer)
		{
			_unityContainer = unityContainer;
		}

		public void Register()
		{
			new SharedContainerRegistry(_unityContainer).Register();

			//Great Note from documentation: Bear in mind, that if your registrations
			// start to become too complicated or fragile, you are probably doing it wrong.

			//Add _unityContainer.RegisterType() class as needed.
			_unityContainer.RegisterType<DwsUI.Core.Job.IJobRunner, DwsUI.Core.Job.JobRunner>();
			_unityContainer.RegisterInstance<DwsUI.Core.Job.IDateRun>(new DwsUI.Core.Job.DateRun());

			_unityContainer.RegisterType<DwsUI.Core.Job.IBaseJob, Cats.Bop.Claimant.Internals.Batch.Liens.LienBOPFault>("LienBopFault");
			_unityContainer.RegisterType<DwsUI.Core.Job.IBaseJob, Cats.Bop.Claimant.Internals.Batch.Liens.LienBopFraud>("LienBopFraud");
			_unityContainer.RegisterType<DwsUI.Core.Job.IBaseJob, Cats.Bop.Claimant.Internals.Batch.Liens.LienBOPFault10Print>("LienBOPFault10Print");
			_unityContainer.RegisterType<DwsUI.Core.Job.IBaseJob, Cats.Bop.Claimant.Internals.Batch.Liens.LienBOPFraud10Print>("LienBOPFraud10Print");
			_unityContainer.RegisterType<DwsUI.Core.Job.IBaseJob, Cats.Bop.Claimant.Internals.Batch.Liens.LienBOPFault28Print>("LienBOPFault28Print");
			_unityContainer.RegisterType<DwsUI.Core.Job.IBaseJob, Cats.Bop.Claimant.Internals.Batch.Liens.LienBOPFraud28Print>("LienBOPFraud28Print");
		}
	}
}
