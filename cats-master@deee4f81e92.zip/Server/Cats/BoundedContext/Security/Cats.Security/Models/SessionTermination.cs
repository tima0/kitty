using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Models
{
	public class SessionTermination
	{
		public SessionTerminationMethod TerminationMethod { get; set; }
	}
}
