using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Models
{
	public class NewTokenRequest
	{
		public string Email { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string UserName { get; set; }
		public DateTime ExpireDateTime { get; set; }
		public string UserAgent { get; set; }
		public string IpAddress { get; set; }
		public IEnumerable<string> SecurityRoles { get; set; }
	}
}
