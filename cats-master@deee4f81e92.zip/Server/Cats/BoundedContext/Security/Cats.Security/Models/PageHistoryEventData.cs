using System;

namespace Cats.Security.Models
{
	public class PageHistoryEventData
	{
		public string SessionId { get; set; }
		public string Page { get; set; }
		public string ReferringPage { get; set; }
	}
}
