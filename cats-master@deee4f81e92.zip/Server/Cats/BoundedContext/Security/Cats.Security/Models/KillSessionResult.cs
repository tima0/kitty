using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Cats.Security.Models
{
	[JsonConverter(typeof(StringEnumConverter))]
	enum KillSessionResultStatus { Success, Denied, NotFound }
	public class KillSessionResult
	{
		string SessionId { get; set; }
		KillSessionResultStatus ResultStatus { get; set; }
	}
}
