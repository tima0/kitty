using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Cats.Security.Models
{
	[JsonConverter(typeof(StringEnumConverter))]
	public enum SessionTerminationMethod
	{
		Abandoned,
		LoggedOff,
		Timeout,
		Killed
	}
}
