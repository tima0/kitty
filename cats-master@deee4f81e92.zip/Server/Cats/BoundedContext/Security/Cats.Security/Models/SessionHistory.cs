using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Models
{
	public class SessionHistory : Session
	{
		public DateTime SessionEnd { get; set; }
		public Nullable<SessionTerminationMethod> TerminationReason { get; set; }
	}
}
