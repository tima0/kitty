using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Models
{
	public class Session
    {
		public string SessionId { get; set; }
		public long EmployeeId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string IpAddress { get; set; }
		public string UserAgent { get; set; }
		public DateTime SessionStart { get; set; }
		public DateTime LastRenewal { get; set; }
	}   
}
