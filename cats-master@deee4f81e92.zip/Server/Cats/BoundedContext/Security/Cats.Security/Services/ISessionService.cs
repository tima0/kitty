using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Models;
using System.Security.Claims;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;
using System.Security.Principal;

namespace Cats.Security.Services
{
	public interface ISessionService
	{
		(SessionToken sessionToken, string jwtToken) CreateToken(NewTokenRequest tokenRequest);		
		Session GetSession(string sessionId);
		ListEnvelope<Session> GetAllActiveSessions(PageListParam page, OrderListParam order);
		ListEnvelope<Session> GetActiveSessions(string  jti, PageListParam page, OrderListParam order);
		ListEnvelope<SessionHistory> GetSessionHistory(int EmployeeID, PageListParam page, OrderListParam order);
		bool TryExtendSession(ClaimsPrincipal claimsPrincipal, out SessionToken sessionToken);
		void MarkExpiredSessionsAsAbandoned();
		ListEnvelope<KillSessionResult> KillSessions(IEnumerable<SessionIdentifier> SessionID);
		bool LogoffSession(ClaimsPrincipal claimsPrincipal);
		bool TimeoutSession(ClaimsPrincipal claimsPrincipal);
		DateTime SessionExpireDateTime();
		IEnumerable<string> ExtractSecurityRoles(GenericPrincipal principal);

	}
}
