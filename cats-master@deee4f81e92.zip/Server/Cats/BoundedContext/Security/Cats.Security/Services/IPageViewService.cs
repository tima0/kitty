using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Models;

namespace Cats.Security.Services
{
	public interface IPageViewService
	{
		void RecordPageHistory(PageHistoryEventData pageHistory);
	}
}
