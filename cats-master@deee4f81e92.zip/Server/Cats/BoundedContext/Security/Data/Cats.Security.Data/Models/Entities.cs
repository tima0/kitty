using System;
using System.Collections.Generic;
using System.Linq;

namespace Cats.Security.Data.Models
{
	public class CATS_SESSION : CATS_SESSIONGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(CATS_SESSION)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class EMPLOYEE : EMPLOYEEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(EMPLOYEE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class TERMINATION_REASON_CODE : TERMINATION_REASON_CODEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(TERMINATION_REASON_CODE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
}