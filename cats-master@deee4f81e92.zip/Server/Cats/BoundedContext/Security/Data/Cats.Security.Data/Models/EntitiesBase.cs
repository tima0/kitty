using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Data.Models
{
	public interface IEntityBase
	{
	}

	public interface ICloneableEntity
	{
		EntityBase Clone();
		EntityBase DeepClone();
	}


	public abstract partial class EntityBase : IEntityBase, ICloneableEntity
	{
		public abstract void SetDirtyFields(bool value);
		public abstract bool HasDirtyFields();
		public abstract string SchemaName();
		public abstract string TableName();
		public abstract string PrimaryKeyFieldname();
		public abstract bool HasPrimaryKey();
		public abstract bool HasForeignKeys();
		public abstract IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys();
		public abstract bool HasCompositePrimaryKey();
		public virtual EntityBase Clone() { return (EntityBase)this.MemberwiseClone(); }
		public abstract EntityBase DeepClone();

		public virtual List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(EntityBase)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			return myAttributes.ToList();
		}

		public virtual bool Validate(Action<string> errorHandler = null)
		{
			bool result = true;
			var validationAttributes = GetAllAttributes()
				.Where(x => x.Attr is CatsNetModelFieldValidationAttribute);

			result = result && validationAttributes
				.All(x => ((CatsNetModelFieldValidationAttribute)x.Attr)
					.Validate(x.Prop.Name, x.Prop.GetValue(this), err => errorHandler(err)));

			return result;
		}
	}

	public abstract class CATS_SESSIONBase : EntityBase, IEntityBase
	{
		public CATS_SESSIONBase() { }
	}
	public abstract class EMPLOYEEBase : EntityBase, IEntityBase
	{
		public EMPLOYEEBase() { }
	}
	public abstract class TERMINATION_REASON_CODEBase : EntityBase, IEntityBase
	{
		public TERMINATION_REASON_CODEBase() { }
	}
}


