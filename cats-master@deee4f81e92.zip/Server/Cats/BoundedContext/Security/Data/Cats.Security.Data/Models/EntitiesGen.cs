using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Data.Models
{

	//Reference to -> CATS_CORE_OWNER.CATS_SESSION.EMPLOYEE_ID->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_CORE_OWNER.CATS_SESSION.TERMINATION_REASON_CD->CATS_CORE_OWNER.TERMINATION_REASON_CODE.TERMINATION_REASON_CD
	[Cats.Security.Data.Models.DBSchema("CATS_CORE_OWNER")]
	[Cats.Security.Data.Models.DBTable("CATS_CORE_OWNER", "CATS_SESSION")]
	public partial class CATS_SESSIONGen : CATS_SESSIONBase
	{
		#region Property backing stores for table CATS_SESSION
		protected System.Int64 _CATS_SESSION_ID;
		protected virtual System.Int64 GetCATS_SESSION_ID() { return _CATS_SESSION_ID; }
		protected virtual void SetCATS_SESSION_ID(System.Int64 value) { _CATS_SESSION_ID = value; _CATS_SESSION_IDFieldIsDirty = true; }
		protected virtual bool _CATS_SESSION_IDFieldIsDirty { get; set; }

		protected System.String _JTI;
		protected virtual System.String GetJTI() { return _JTI; }
		protected virtual void SetJTI(System.String value) { _JTI = value; _JTIFieldIsDirty = true; }
		protected virtual bool _JTIFieldIsDirty { get; set; }

		protected System.Int64 _EMPLOYEE_ID;
		protected virtual System.Int64 GetEMPLOYEE_ID() { return _EMPLOYEE_ID; }
		protected virtual void SetEMPLOYEE_ID(System.Int64 value) { _EMPLOYEE_ID = value; _EMPLOYEE_IDFieldIsDirty = true; }
		protected virtual bool _EMPLOYEE_IDFieldIsDirty { get; set; }

		protected System.String _IP_ADDRESS;
		protected virtual System.String GetIP_ADDRESS() { return _IP_ADDRESS; }
		protected virtual void SetIP_ADDRESS(System.String value) { _IP_ADDRESS = value; _IP_ADDRESSFieldIsDirty = true; }
		protected virtual bool _IP_ADDRESSFieldIsDirty { get; set; }

		protected System.DateTime _LAST_ACTIVITY_TS;
		protected virtual System.DateTime GetLAST_ACTIVITY_TS() { return _LAST_ACTIVITY_TS; }
		protected virtual void SetLAST_ACTIVITY_TS(System.DateTime value) { _LAST_ACTIVITY_TS = value; _LAST_ACTIVITY_TSFieldIsDirty = true; }
		protected virtual bool _LAST_ACTIVITY_TSFieldIsDirty { get; set; }

		protected System.DateTime _EXPIRE_DT;
		protected virtual System.DateTime GetEXPIRE_DT() { return _EXPIRE_DT; }
		protected virtual void SetEXPIRE_DT(System.DateTime value) { _EXPIRE_DT = value; _EXPIRE_DTFieldIsDirty = true; }
		protected virtual bool _EXPIRE_DTFieldIsDirty { get; set; }

		protected System.String _USER_AGENT;
		protected virtual System.String GetUSER_AGENT() { return _USER_AGENT; }
		protected virtual void SetUSER_AGENT(System.String value) { _USER_AGENT = value; _USER_AGENTFieldIsDirty = true; }
		protected virtual bool _USER_AGENTFieldIsDirty { get; set; }

		protected System.DateTime _LOGIN_TS;
		protected virtual System.DateTime GetLOGIN_TS() { return _LOGIN_TS; }
		protected virtual void SetLOGIN_TS(System.DateTime value) { _LOGIN_TS = value; _LOGIN_TSFieldIsDirty = true; }
		protected virtual bool _LOGIN_TSFieldIsDirty { get; set; }

		protected System.DateTime? _LOGOUT_TS;
		protected virtual System.DateTime? GetLOGOUT_TS() { return _LOGOUT_TS; }
		protected virtual void SetLOGOUT_TS(System.DateTime? value) { _LOGOUT_TS = value; _LOGOUT_TSFieldIsDirty = true; }
		protected virtual bool _LOGOUT_TSFieldIsDirty { get; set; }

		protected System.String _TERMINATION_REASON_CD;
		protected virtual System.String GetTERMINATION_REASON_CD() { return _TERMINATION_REASON_CD; }
		protected virtual void SetTERMINATION_REASON_CD(System.String value) { _TERMINATION_REASON_CD = value; _TERMINATION_REASON_CDFieldIsDirty = true; }
		protected virtual bool _TERMINATION_REASON_CDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table CATS_SESSION

		[Cats.Security.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "CATS_SESSION_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CATS_SESSION_ID { get { return GetCATS_SESSION_ID(); } set { SetCATS_SESSION_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(200)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "JTI", "VARCHAR2", typeof(System.String))]
		public virtual System.String JTI { get { return GetJTI(); } set { SetJTI(value); } }

		[ReferenceTo("CATS_CORE_OWNER", "CATS_SESSION", "EMPLOYEE_ID", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "EMPLOYEE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 EMPLOYEE_ID { get { return GetEMPLOYEE_ID(); } set { SetEMPLOYEE_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(45)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "IP_ADDRESS", "VARCHAR2", typeof(System.String))]
		public virtual System.String IP_ADDRESS { get { return GetIP_ADDRESS(); } set { SetIP_ADDRESS(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "LAST_ACTIVITY_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime LAST_ACTIVITY_TS { get { return GetLAST_ACTIVITY_TS(); } set { SetLAST_ACTIVITY_TS(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "EXPIRE_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime EXPIRE_DT { get { return GetEXPIRE_DT(); } set { SetEXPIRE_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(512)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "USER_AGENT", "VARCHAR2", typeof(System.String))]
		public virtual System.String USER_AGENT { get { return GetUSER_AGENT(); } set { SetUSER_AGENT(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "LOGIN_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime LOGIN_TS { get { return GetLOGIN_TS(); } set { SetLOGIN_TS(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "LOGOUT_TS", "TIMESTAMP(6)", typeof(System.DateTime?))]
		public virtual System.DateTime? LOGOUT_TS { get { return GetLOGOUT_TS(); } set { SetLOGOUT_TS(value); } }

		[ReferenceTo("CATS_CORE_OWNER", "CATS_SESSION", "TERMINATION_REASON_CD", "CATS_CORE_OWNER", "TERMINATION_REASON_CODE", "TERMINATION_REASON_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "CATS_SESSION", "TERMINATION_REASON_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String TERMINATION_REASON_CD { get { return GetTERMINATION_REASON_CD(); } set { SetTERMINATION_REASON_CD(value); } }


		public virtual EMPLOYEE Ref_Employee { get; set; }
		public virtual TERMINATION_REASON_CODE Ref_TerminationReasonCode { get; set; }

		#endregion

		#region Constructors for table CATS_SESSIONGen
		public CATS_SESSIONGen()
		{
		}

		public CATS_SESSIONGen(System.Int64 CATS_SESSION_ID, System.String JTI, System.Int64 EMPLOYEE_ID, System.String IP_ADDRESS, System.DateTime LAST_ACTIVITY_TS, System.DateTime EXPIRE_DT, System.String USER_AGENT, System.DateTime LOGIN_TS, System.DateTime? LOGOUT_TS, System.String TERMINATION_REASON_CD) : this()
		{
			this._CATS_SESSION_ID = CATS_SESSION_ID;
			this._JTI = JTI;
			this._EMPLOYEE_ID = EMPLOYEE_ID;
			this._IP_ADDRESS = IP_ADDRESS;
			this._LAST_ACTIVITY_TS = LAST_ACTIVITY_TS;
			this._EXPIRE_DT = EXPIRE_DT;
			this._USER_AGENT = USER_AGENT;
			this._LOGIN_TS = LOGIN_TS;
			this._LOGOUT_TS = LOGOUT_TS;
			this._TERMINATION_REASON_CD = TERMINATION_REASON_CD;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(CATS_SESSIONGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_CATS_SESSION_IDFieldIsDirty = value;
			_JTIFieldIsDirty = value;
			_EMPLOYEE_IDFieldIsDirty = value;
			_IP_ADDRESSFieldIsDirty = value;
			_LAST_ACTIVITY_TSFieldIsDirty = value;
			_EXPIRE_DTFieldIsDirty = value;
			_USER_AGENTFieldIsDirty = value;
			_LOGIN_TSFieldIsDirty = value;
			_LOGOUT_TSFieldIsDirty = value;
			_TERMINATION_REASON_CDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _CATS_SESSION_IDFieldIsDirty
				|| _JTIFieldIsDirty
				|| _EMPLOYEE_IDFieldIsDirty
				|| _IP_ADDRESSFieldIsDirty
				|| _LAST_ACTIVITY_TSFieldIsDirty
				|| _EXPIRE_DTFieldIsDirty
				|| _USER_AGENTFieldIsDirty
				|| _LOGIN_TSFieldIsDirty
				|| _LOGOUT_TSFieldIsDirty
				|| _TERMINATION_REASON_CDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_CORE_OWNER";
		}

		public override string TableName()
		{
			return "CATS_SESSION";
		}

		public override string PrimaryKeyFieldname()
		{
			return "CATS_SESSION_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (CATS_SESSION)this.Clone();
			result.CATS_SESSION_ID = this.CATS_SESSION_ID;
			result.JTI = this.JTI;
			result.EMPLOYEE_ID = this.EMPLOYEE_ID;
			result.IP_ADDRESS = this.IP_ADDRESS;
			result.LAST_ACTIVITY_TS = this.LAST_ACTIVITY_TS;
			result.EXPIRE_DT = this.EXPIRE_DT;
			result.USER_AGENT = this.USER_AGENT;
			result.LOGIN_TS = this.LOGIN_TS;
			result.LOGOUT_TS = this.LOGOUT_TS;
			result.TERMINATION_REASON_CD = this.TERMINATION_REASON_CD;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_CORE_OWNER.CATS_SESSION")
				.Append(" { ")
				.Append("CATS_SESSION_ID")
				.Append(" = ")
				.Append(this.CATS_SESSION_ID.ToString())
				.Append("; ")
				.Append("JTI")
				.Append(" = ")
				.Append(this.JTI.ToString())
				.Append("; ")
				.Append("EMPLOYEE_ID")
				.Append(" = ")
				.Append(this.EMPLOYEE_ID.ToString())
				.Append("; ")
				.Append("IP_ADDRESS")
				.Append(" = ")
				.Append(this.IP_ADDRESS.ToString())
				.Append("; ")
				.Append("LAST_ACTIVITY_TS")
				.Append(" = ")
				.Append(this.LAST_ACTIVITY_TS.ToString())
				.Append("; ")
				.Append("EXPIRE_DT")
				.Append(" = ")
				.Append(this.EXPIRE_DT.ToString())
				.Append("; ")
				.Append("USER_AGENT")
				.Append(" = ")
				.Append(this.USER_AGENT.ToString())
				.Append("; ")
				.Append("LOGIN_TS")
				.Append(" = ")
				.Append(this.LOGIN_TS.ToString())
				.Append("; ")
				.Append("LOGOUT_TS")
				.Append(" = ")
				.Append(this.LOGOUT_TS.ToString())
				.Append("; ")
				.Append("TERMINATION_REASON_CD")
				.Append(" = ")
				.Append(this.TERMINATION_REASON_CD.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//ReferencedBy -> CATS_CORE_OWNER.CATS_SESSION.EMPLOYEE_ID->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	[Cats.Security.Data.Models.DBSchema("CATS_CORE_OWNER")]
	[Cats.Security.Data.Models.DBTable("CATS_CORE_OWNER", "EMPLOYEE")]
	public partial class EMPLOYEEGen : EMPLOYEEBase
	{
		#region Property backing stores for table EMPLOYEE
		protected System.Int64 _EMPLOYEE_ID;
		protected virtual System.Int64 GetEMPLOYEE_ID() { return _EMPLOYEE_ID; }
		protected virtual void SetEMPLOYEE_ID(System.Int64 value) { _EMPLOYEE_ID = value; _EMPLOYEE_IDFieldIsDirty = true; }
		protected virtual bool _EMPLOYEE_IDFieldIsDirty { get; set; }

		protected System.String _FIRSTNAME;
		protected virtual System.String GetFIRSTNAME() { return _FIRSTNAME; }
		protected virtual void SetFIRSTNAME(System.String value) { _FIRSTNAME = value; _FIRSTNAMEFieldIsDirty = true; }
		protected virtual bool _FIRSTNAMEFieldIsDirty { get; set; }

		protected System.String _LASTNAME;
		protected virtual System.String GetLASTNAME() { return _LASTNAME; }
		protected virtual void SetLASTNAME(System.String value) { _LASTNAME = value; _LASTNAMEFieldIsDirty = true; }
		protected virtual bool _LASTNAMEFieldIsDirty { get; set; }

		protected System.String _ADDRESS1;
		protected virtual System.String GetADDRESS1() { return _ADDRESS1; }
		protected virtual void SetADDRESS1(System.String value) { _ADDRESS1 = value; _ADDRESS1FieldIsDirty = true; }
		protected virtual bool _ADDRESS1FieldIsDirty { get; set; }

		protected System.String _ADDRESS2;
		protected virtual System.String GetADDRESS2() { return _ADDRESS2; }
		protected virtual void SetADDRESS2(System.String value) { _ADDRESS2 = value; _ADDRESS2FieldIsDirty = true; }
		protected virtual bool _ADDRESS2FieldIsDirty { get; set; }

		protected System.String _CITY;
		protected virtual System.String GetCITY() { return _CITY; }
		protected virtual void SetCITY(System.String value) { _CITY = value; _CITYFieldIsDirty = true; }
		protected virtual bool _CITYFieldIsDirty { get; set; }

		protected System.String _STATE;
		protected virtual System.String GetSTATE() { return _STATE; }
		protected virtual void SetSTATE(System.String value) { _STATE = value; _STATEFieldIsDirty = true; }
		protected virtual bool _STATEFieldIsDirty { get; set; }

		protected System.String _ZIP;
		protected virtual System.String GetZIP() { return _ZIP; }
		protected virtual void SetZIP(System.String value) { _ZIP = value; _ZIPFieldIsDirty = true; }
		protected virtual bool _ZIPFieldIsDirty { get; set; }

		protected System.String _DEPARTMENT;
		protected virtual System.String GetDEPARTMENT() { return _DEPARTMENT; }
		protected virtual void SetDEPARTMENT(System.String value) { _DEPARTMENT = value; _DEPARTMENTFieldIsDirty = true; }
		protected virtual bool _DEPARTMENTFieldIsDirty { get; set; }

		protected System.String _PHONE;
		protected virtual System.String GetPHONE() { return _PHONE; }
		protected virtual void SetPHONE(System.String value) { _PHONE = value; _PHONEFieldIsDirty = true; }
		protected virtual bool _PHONEFieldIsDirty { get; set; }

		protected System.String _FAX;
		protected virtual System.String GetFAX() { return _FAX; }
		protected virtual void SetFAX(System.String value) { _FAX = value; _FAXFieldIsDirty = true; }
		protected virtual bool _FAXFieldIsDirty { get; set; }

		protected System.String _EMAILADDR;
		protected virtual System.String GetEMAILADDR() { return _EMAILADDR; }
		protected virtual void SetEMAILADDR(System.String value) { _EMAILADDR = value; _EMAILADDRFieldIsDirty = true; }
		protected virtual bool _EMAILADDRFieldIsDirty { get; set; }

		protected System.String _USERID;
		protected virtual System.String GetUSERID() { return _USERID; }
		protected virtual void SetUSERID(System.String value) { _USERID = value; _USERIDFieldIsDirty = true; }
		protected virtual bool _USERIDFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_TS;
		protected virtual System.DateTime? GetMODIFIED_TS() { return _MODIFIED_TS; }
		protected virtual void SetMODIFIED_TS(System.DateTime? value) { _MODIFIED_TS = value; _MODIFIED_TSFieldIsDirty = true; }
		protected virtual bool _MODIFIED_TSFieldIsDirty { get; set; }

		protected System.String _PRONOUN;
		protected virtual System.String GetPRONOUN() { return _PRONOUN; }
		protected virtual void SetPRONOUN(System.String value) { _PRONOUN = value; _PRONOUNFieldIsDirty = true; }
		protected virtual bool _PRONOUNFieldIsDirty { get; set; }

		protected System.String _PRONOUN_POSS;
		protected virtual System.String GetPRONOUN_POSS() { return _PRONOUN_POSS; }
		protected virtual void SetPRONOUN_POSS(System.String value) { _PRONOUN_POSS = value; _PRONOUN_POSSFieldIsDirty = true; }
		protected virtual bool _PRONOUN_POSSFieldIsDirty { get; set; }

		#endregion

		#region Properties for table EMPLOYEE

		[Cats.Security.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_CORE_OWNER", "CATS_SESSION", "EMPLOYEE_ID", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 EMPLOYEE_ID { get { return GetEMPLOYEE_ID(); } set { SetEMPLOYEE_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "FIRSTNAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String FIRSTNAME { get { return GetFIRSTNAME(); } set { SetFIRSTNAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(25)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "LASTNAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String LASTNAME { get { return GetLASTNAME(); } set { SetLASTNAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(35)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "ADDRESS1", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDRESS1 { get { return GetADDRESS1(); } set { SetADDRESS1(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(35)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "ADDRESS2", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDRESS2 { get { return GetADDRESS2(); } set { SetADDRESS2(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(19)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "CITY", "VARCHAR2", typeof(System.String))]
		public virtual System.String CITY { get { return GetCITY(); } set { SetCITY(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "STATE", "VARCHAR2", typeof(System.String))]
		public virtual System.String STATE { get { return GetSTATE(); } set { SetSTATE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "ZIP", "VARCHAR2", typeof(System.String))]
		public virtual System.String ZIP { get { return GetZIP(); } set { SetZIP(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(25)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "DEPARTMENT", "VARCHAR2", typeof(System.String))]
		public virtual System.String DEPARTMENT { get { return GetDEPARTMENT(); } set { SetDEPARTMENT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "PHONE", "VARCHAR2", typeof(System.String))]
		public virtual System.String PHONE { get { return GetPHONE(); } set { SetPHONE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "FAX", "VARCHAR2", typeof(System.String))]
		public virtual System.String FAX { get { return GetFAX(); } set { SetFAX(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(40)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "EMAILADDR", "VARCHAR2", typeof(System.String))]
		public virtual System.String EMAILADDR { get { return GetEMAILADDR(); } set { SetEMAILADDR(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "USERID", "VARCHAR2", typeof(System.String))]
		public virtual System.String USERID { get { return GetUSERID(); } set { SetUSERID(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "MODIFIED_TS", "TIMESTAMP(6)", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_TS { get { return GetMODIFIED_TS(); } set { SetMODIFIED_TS(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "PRONOUN", "VARCHAR2", typeof(System.String))]
		public virtual System.String PRONOUN { get { return GetPRONOUN(); } set { SetPRONOUN(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "PRONOUN_POSS", "VARCHAR2", typeof(System.String))]
		public virtual System.String PRONOUN_POSS { get { return GetPRONOUN_POSS(); } set { SetPRONOUN_POSS(value); } }


		public virtual ICollection<CATS_SESSION> RefMany_CatsSession_EmployeeId { get; set; }

		#endregion

		#region Constructors for table EMPLOYEEGen
		public EMPLOYEEGen()
		{
		}

		public EMPLOYEEGen(System.Int64 EMPLOYEE_ID, System.String FIRSTNAME, System.String LASTNAME, System.String ADDRESS1, System.String ADDRESS2, System.String CITY, System.String STATE, System.String ZIP, System.String DEPARTMENT, System.String PHONE, System.String FAX, System.String EMAILADDR, System.String USERID, System.DateTime CREATED_TS, System.DateTime? MODIFIED_TS, System.String PRONOUN, System.String PRONOUN_POSS) : this()
		{
			this._EMPLOYEE_ID = EMPLOYEE_ID;
			this._FIRSTNAME = FIRSTNAME;
			this._LASTNAME = LASTNAME;
			this._ADDRESS1 = ADDRESS1;
			this._ADDRESS2 = ADDRESS2;
			this._CITY = CITY;
			this._STATE = STATE;
			this._ZIP = ZIP;
			this._DEPARTMENT = DEPARTMENT;
			this._PHONE = PHONE;
			this._FAX = FAX;
			this._EMAILADDR = EMAILADDR;
			this._USERID = USERID;
			this._CREATED_TS = CREATED_TS;
			this._MODIFIED_TS = MODIFIED_TS;
			this._PRONOUN = PRONOUN;
			this._PRONOUN_POSS = PRONOUN_POSS;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(EMPLOYEEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_EMPLOYEE_IDFieldIsDirty = value;
			_FIRSTNAMEFieldIsDirty = value;
			_LASTNAMEFieldIsDirty = value;
			_ADDRESS1FieldIsDirty = value;
			_ADDRESS2FieldIsDirty = value;
			_CITYFieldIsDirty = value;
			_STATEFieldIsDirty = value;
			_ZIPFieldIsDirty = value;
			_DEPARTMENTFieldIsDirty = value;
			_PHONEFieldIsDirty = value;
			_FAXFieldIsDirty = value;
			_EMAILADDRFieldIsDirty = value;
			_USERIDFieldIsDirty = value;
			_CREATED_TSFieldIsDirty = value;
			_MODIFIED_TSFieldIsDirty = value;
			_PRONOUNFieldIsDirty = value;
			_PRONOUN_POSSFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _EMPLOYEE_IDFieldIsDirty
				|| _FIRSTNAMEFieldIsDirty
				|| _LASTNAMEFieldIsDirty
				|| _ADDRESS1FieldIsDirty
				|| _ADDRESS2FieldIsDirty
				|| _CITYFieldIsDirty
				|| _STATEFieldIsDirty
				|| _ZIPFieldIsDirty
				|| _DEPARTMENTFieldIsDirty
				|| _PHONEFieldIsDirty
				|| _FAXFieldIsDirty
				|| _EMAILADDRFieldIsDirty
				|| _USERIDFieldIsDirty
				|| _CREATED_TSFieldIsDirty
				|| _MODIFIED_TSFieldIsDirty
				|| _PRONOUNFieldIsDirty
				|| _PRONOUN_POSSFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_CORE_OWNER";
		}

		public override string TableName()
		{
			return "EMPLOYEE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "EMPLOYEE_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_CORE_OWNER", "CATS_SESSION", "EMPLOYEE_ID", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (EMPLOYEE)this.Clone();
			result.EMPLOYEE_ID = this.EMPLOYEE_ID;
			result.FIRSTNAME = this.FIRSTNAME;
			result.LASTNAME = this.LASTNAME;
			result.ADDRESS1 = this.ADDRESS1;
			result.ADDRESS2 = this.ADDRESS2;
			result.CITY = this.CITY;
			result.STATE = this.STATE;
			result.ZIP = this.ZIP;
			result.DEPARTMENT = this.DEPARTMENT;
			result.PHONE = this.PHONE;
			result.FAX = this.FAX;
			result.EMAILADDR = this.EMAILADDR;
			result.USERID = this.USERID;
			result.CREATED_TS = this.CREATED_TS;
			result.MODIFIED_TS = this.MODIFIED_TS;
			result.PRONOUN = this.PRONOUN;
			result.PRONOUN_POSS = this.PRONOUN_POSS;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_CORE_OWNER.EMPLOYEE")
				.Append(" { ")
				.Append("EMPLOYEE_ID")
				.Append(" = ")
				.Append(this.EMPLOYEE_ID.ToString())
				.Append("; ")
				.Append("FIRSTNAME")
				.Append(" = ")
				.Append(this.FIRSTNAME.ToString())
				.Append("; ")
				.Append("LASTNAME")
				.Append(" = ")
				.Append(this.LASTNAME.ToString())
				.Append("; ")
				.Append("ADDRESS1")
				.Append(" = ")
				.Append(this.ADDRESS1.ToString())
				.Append("; ")
				.Append("ADDRESS2")
				.Append(" = ")
				.Append(this.ADDRESS2.ToString())
				.Append("; ")
				.Append("CITY")
				.Append(" = ")
				.Append(this.CITY.ToString())
				.Append("; ")
				.Append("STATE")
				.Append(" = ")
				.Append(this.STATE.ToString())
				.Append("; ")
				.Append("ZIP")
				.Append(" = ")
				.Append(this.ZIP.ToString())
				.Append("; ")
				.Append("DEPARTMENT")
				.Append(" = ")
				.Append(this.DEPARTMENT.ToString())
				.Append("; ")
				.Append("PHONE")
				.Append(" = ")
				.Append(this.PHONE.ToString())
				.Append("; ")
				.Append("FAX")
				.Append(" = ")
				.Append(this.FAX.ToString())
				.Append("; ")
				.Append("EMAILADDR")
				.Append(" = ")
				.Append(this.EMAILADDR.ToString())
				.Append("; ")
				.Append("USERID")
				.Append(" = ")
				.Append(this.USERID.ToString())
				.Append("; ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("MODIFIED_TS")
				.Append(" = ")
				.Append(this.MODIFIED_TS.ToString())
				.Append("; ")
				.Append("PRONOUN")
				.Append(" = ")
				.Append(this.PRONOUN.ToString())
				.Append("; ")
				.Append("PRONOUN_POSS")
				.Append(" = ")
				.Append(this.PRONOUN_POSS.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//ReferencedBy -> CATS_CORE_OWNER.CATS_SESSION.TERMINATION_REASON_CD->CATS_CORE_OWNER.TERMINATION_REASON_CODE.TERMINATION_REASON_CD
	[Cats.Security.Data.Models.DBSchema("CATS_CORE_OWNER")]
	[Cats.Security.Data.Models.DBTable("CATS_CORE_OWNER", "TERMINATION_REASON_CODE")]
	public partial class TERMINATION_REASON_CODEGen : TERMINATION_REASON_CODEBase
	{
		#region Property backing stores for table TERMINATION_REASON_CODE
		protected System.String _TERMINATION_REASON_CD;
		protected virtual System.String GetTERMINATION_REASON_CD() { return _TERMINATION_REASON_CD; }
		protected virtual void SetTERMINATION_REASON_CD(System.String value) { _TERMINATION_REASON_CD = value; _TERMINATION_REASON_CDFieldIsDirty = true; }
		protected virtual bool _TERMINATION_REASON_CDFieldIsDirty { get; set; }

		protected System.String _DESCRIPTION;
		protected virtual System.String GetDESCRIPTION() { return _DESCRIPTION; }
		protected virtual void SetDESCRIPTION(System.String value) { _DESCRIPTION = value; _DESCRIPTIONFieldIsDirty = true; }
		protected virtual bool _DESCRIPTIONFieldIsDirty { get; set; }

		#endregion

		#region Properties for table TERMINATION_REASON_CODE

		[Cats.Security.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_CORE_OWNER", "CATS_SESSION", "TERMINATION_REASON_CD", "CATS_CORE_OWNER", "TERMINATION_REASON_CODE", "TERMINATION_REASON_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "TERMINATION_REASON_CODE", "TERMINATION_REASON_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String TERMINATION_REASON_CD { get { return GetTERMINATION_REASON_CD(); } set { SetTERMINATION_REASON_CD(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Security.Data.Models.Column("CATS_CORE_OWNER", "TERMINATION_REASON_CODE", "DESCRIPTION", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCRIPTION { get { return GetDESCRIPTION(); } set { SetDESCRIPTION(value); } }


		public virtual ICollection<CATS_SESSION> RefMany_CatsSession_TerminationReasonCd { get; set; }

		#endregion

		#region Constructors for table TERMINATION_REASON_CODEGen
		public TERMINATION_REASON_CODEGen()
		{
		}

		public TERMINATION_REASON_CODEGen(System.String TERMINATION_REASON_CD, System.String DESCRIPTION) : this()
		{
			this._TERMINATION_REASON_CD = TERMINATION_REASON_CD;
			this._DESCRIPTION = DESCRIPTION;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(TERMINATION_REASON_CODEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_TERMINATION_REASON_CDFieldIsDirty = value;
			_DESCRIPTIONFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _TERMINATION_REASON_CDFieldIsDirty
				|| _DESCRIPTIONFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_CORE_OWNER";
		}

		public override string TableName()
		{
			return "TERMINATION_REASON_CODE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "TERMINATION_REASON_CD";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_CORE_OWNER", "CATS_SESSION", "TERMINATION_REASON_CD", "CATS_CORE_OWNER", "TERMINATION_REASON_CODE", "TERMINATION_REASON_CD");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (TERMINATION_REASON_CODE)this.Clone();
			result.TERMINATION_REASON_CD = this.TERMINATION_REASON_CD;
			result.DESCRIPTION = this.DESCRIPTION;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_CORE_OWNER.TERMINATION_REASON_CODE")
				.Append(" { ")
				.Append("TERMINATION_REASON_CD")
				.Append(" = ")
				.Append(this.TERMINATION_REASON_CD.ToString())
				.Append("; ")
				.Append("DESCRIPTION")
				.Append(" = ")
				.Append(this.DESCRIPTION.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}
}

