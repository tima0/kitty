using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Models;
using DwsUI.Core.Collections;
using DwsUI.Core.ListParams;

namespace Cats.Security.Data.Repositories
{
	public interface ISessionRepository
	{
		IPagedList<CATS_SESSION> GetAllSessions(PageListParam page, OrderListParam orderBy);

		IPagedList<CATS_SESSION> GetActiveSessions(long employeeId, OrderListParam orderBy = null);

		int GetActiveSessionCount(long employeeId);

		void CreateNewSession(CATS_SESSION session);

		void MarkExpiredSessionsAsAbandoned();
		
		CATS_SESSION GetSession(string jti);
	}
}
