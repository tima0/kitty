using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Models;

namespace Cats.Security.Data.Repositories
{
	public interface IPageVisitRepository
	{
		void RecordPageVisit(PageVisit pageVisit);
	}
}
