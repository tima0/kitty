using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Models;

namespace Cats.Security.Data.Internals
{
	public static class ContextDBInitializer
	{
		public static void DisableCodeFirstMigrations()
		{
			// Disable code-first migrations.  This should be called from the host project's startup code.
			// See this page:  https://www.dotnetexpertguide.com/2012/10/aspnet-preapplicationstartmethod-example.html
			Database.SetInitializer<Cats.Security.Data.Internals.DbContext>(null);
		}
	}

	public abstract partial class DbContextGen : System.Data.Entity.DbContext
	{
		public DbContextGen(string nameOrConnectionString) : base(nameOrConnectionString)
		{
			// Do not remove these lines!
			// These look like they do nothing, but it creates the only code reference to the Oracle assembly.
			// Without it, the dependency is deemed unnecessary by the linker and is not deployed to the web bin folder.
			var refFix1 = typeof(Oracle.ManagedDataAccess.Client.OracleConnection);
			System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(refFix1.AssemblyQualifiedName));
			var refFix2 = typeof(Oracle.ManagedDataAccess.EntityFramework.OracleConnectionFactory);
			System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(refFix2.AssemblyQualifiedName));
		}

		public virtual string GetDefaultSchemaName()
		{
			return "CATS_CORE_OWNER";
		}

		public DbSet<CATS_SESSION> CatsSession { get; set; }
		public DbSet<EMPLOYEE> Employee { get; set; }
		public DbSet<TERMINATION_REASON_CODE> TerminationReasonCode { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.HasDefaultSchema(GetDefaultSchemaName());

			modelBuilder.Configurations.Add(new DbSetConfig_CatsSession());
			modelBuilder.Configurations.Add(new DbSetConfig_Employee());
			modelBuilder.Configurations.Add(new DbSetConfig_TerminationReasonCode());
		}
	}

	public partial class DbSetConfigBase_CatsSession : EntityTypeConfiguration<CATS_SESSION>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.CATS_SESSION_ID);
			this.Property(p => p.CATS_SESSION_ID)
				.HasColumnName("CATS_SESSION_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.CATS_SESSION_ID).IsRequired();
			this.Property(p => p.JTI)
				.HasColumnName("JTI")
				.HasMaxLength(200)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.EMPLOYEE_ID)
				.HasColumnName("EMPLOYEE_ID")
				.IsRequired();
			this.Property(p => p.EMPLOYEE_ID).IsRequired();
			this.Property(p => p.IP_ADDRESS)
				.HasColumnName("IP_ADDRESS")
				.HasMaxLength(45)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.LAST_ACTIVITY_TS).IsRequired();
			this.Property(p => p.EXPIRE_DT).IsRequired();
			this.Property(p => p.USER_AGENT)
				.HasColumnName("USER_AGENT")
				.HasMaxLength(512)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.LOGIN_TS).IsRequired();
			this.Property(p => p.LOGOUT_TS).IsOptional();
			this.Property(p => p.TERMINATION_REASON_CD)
				.HasColumnName("TERMINATION_REASON_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.ToTable("CATS_SESSION", "CATS_CORE_OWNER");

			// Foreign key references.
			// CATS_CORE_OWNER.CATS_SESSION.EMPLOYEE_ID->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasRequired(r1 => r1.Ref_Employee)
				.WithMany(r2 => r2.RefMany_CatsSession_EmployeeId)
				.HasForeignKey(t => t.EMPLOYEE_ID);
			// CATS_CORE_OWNER.CATS_SESSION.TERMINATION_REASON_CD->CATS_CORE_OWNER.TERMINATION_REASON_CODE.TERMINATION_REASON_CD
			this.HasOptional(r1 => r1.Ref_TerminationReasonCode)
				.WithMany(r2 => r2.RefMany_CatsSession_TerminationReasonCd)
				.HasForeignKey(t => t.TERMINATION_REASON_CD);
		}

		public DbSetConfigBase_CatsSession()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_Employee : EntityTypeConfiguration<EMPLOYEE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.EMPLOYEE_ID);
			this.Property(p => p.EMPLOYEE_ID)
				.HasColumnName("EMPLOYEE_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.EMPLOYEE_ID).IsRequired();
			this.Property(p => p.FIRSTNAME)
				.HasColumnName("FIRSTNAME")
				.HasMaxLength(20)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.LASTNAME)
				.HasColumnName("LASTNAME")
				.HasMaxLength(25)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ADDRESS1)
				.HasColumnName("ADDRESS1")
				.HasMaxLength(35)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ADDRESS2)
				.HasColumnName("ADDRESS2")
				.HasMaxLength(35)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CITY)
				.HasColumnName("CITY")
				.HasMaxLength(19)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.STATE)
				.HasColumnName("STATE")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ZIP)
				.HasColumnName("ZIP")
				.HasMaxLength(9)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.DEPARTMENT)
				.HasColumnName("DEPARTMENT")
				.HasMaxLength(25)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PHONE)
				.HasColumnName("PHONE")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.FAX)
				.HasColumnName("FAX")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.EMAILADDR)
				.HasColumnName("EMAILADDR")
				.HasMaxLength(40)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.USERID)
				.HasColumnName("USERID")
				.HasMaxLength(20)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.MODIFIED_TS).IsOptional();
			this.Property(p => p.PRONOUN)
				.HasColumnName("PRONOUN")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PRONOUN_POSS)
				.HasColumnName("PRONOUN_POSS")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.ToTable("EMPLOYEE", "CATS_CORE_OWNER");
		}

		public DbSetConfigBase_Employee()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_TerminationReasonCode : EntityTypeConfiguration<TERMINATION_REASON_CODE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.TERMINATION_REASON_CD);
			this.Property(p => p.TERMINATION_REASON_CD)
				.HasColumnName("TERMINATION_REASON_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.DESCRIPTION)
				.HasColumnName("DESCRIPTION")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("TERMINATION_REASON_CODE", "CATS_CORE_OWNER");
		}

		public DbSetConfigBase_TerminationReasonCode()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
}

