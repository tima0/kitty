using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Data.Internals
{

	public partial class DbContext : DbContextGen
	{
		public DbContext() : base("defaultCatsConnection")
		{
		}

		//public DbSet<CATS_SESSION> CatsSession { get; set; }
		//public DbSet<EMPLOYEE> Employee { get; set; }
		//public DbSet<TERMINATION_REASON_CODE> TerminationReasonCode { get; set; }

	}

	public partial class DbSetConfig_CatsSession : DbSetConfigBase_CatsSession
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_CORE_OWNER.CATS_SESSION table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_CatsSession() : base() { }
	}
	public partial class DbSetConfig_Employee : DbSetConfigBase_Employee
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_CORE_OWNER.EMPLOYEE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_Employee() : base() { }
	}
	public partial class DbSetConfig_TerminationReasonCode : DbSetConfigBase_TerminationReasonCode
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_CORE_OWNER.TERMINATION_REASON_CODE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_TerminationReasonCode() : base() { }
	}
}

