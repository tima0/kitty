using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Repositories;

namespace Cats.Security.Data.Internals.Repositories
{
	public class SecurityValidationRepository : ISecurityValidationRepository
	{
		readonly DbContext _dbContext;
		public SecurityValidationRepository(DbContext dbContext)
		{
			_dbContext = dbContext;
		}
		public bool IsValidEmployeeId(int employeeId)
		{
			// TODO: Implement call to database
			// throw new NotImplementedException();
			return true;
		}

		public bool IsValidJti(string jti)
		{
			// TODO: Implement call to database
			//throw new NotImplementedException();
			return true;
		}
	}
}
