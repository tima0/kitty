using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Models;
using Cats.Security.Data.Repositories;

namespace Cats.Security.Data.Internals.Repositories
{
	public class PageVisitRepository : IPageVisitRepository
	{
		readonly DbContext _dbContext;
		public PageVisitRepository(DbContext dbContext)
		{
			_dbContext = dbContext;
		}
		public void RecordPageVisit(PageVisit pageVisit)
		{
			throw new NotImplementedException();
		}
	}
}
