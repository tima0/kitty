using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Models;
using Cats.Security.Data.Repositories;

namespace Cats.Security.Data.Internals.Repositories
{
	public class EmployeeRepository : IEmployeeRepository
	{
		private readonly DbContext _dbContext;
		public EmployeeRepository(DbContext dbContext)
		{
			_dbContext = dbContext;
		}
		public EMPLOYEE GetEmployeeByEmail(string email)
		{
			return _dbContext.Employee
				.AsNoTracking()
				.SingleOrDefault(e => e.EMAILADDR.ToLower() == email.ToLower());
		}
	}
}
