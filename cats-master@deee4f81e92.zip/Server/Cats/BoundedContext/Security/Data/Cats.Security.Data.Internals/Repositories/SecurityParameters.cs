using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Repositories;

namespace Cats.Security.Data.Internals.Repositories
{
	public class SecurityParametersRepository : ISecurityParametersRepository
	{
		readonly DbContext _dbContext;
		public SecurityParametersRepository(DbContext dbContext)
		{
			_dbContext = dbContext;
		}
		public bool IsSystemAvailable()
		{
			//TODO: Read from Database 
			return true;
		}
	}
}
