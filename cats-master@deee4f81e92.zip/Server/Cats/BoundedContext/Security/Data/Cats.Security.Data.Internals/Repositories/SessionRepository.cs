using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Repositories;
using Cats.Security.Data.Models;
using DwsUI.Core.Data.Collections;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;

namespace Cats.Security.Data.Internals.Repositories
{
	public class SessionRepository : ISessionRepository
	{
		private const string TermReasonAbandoned = "ABANDONED";

		readonly DbContext _dbContext;
		public SessionRepository(DbContext dbContext)
		{
			_dbContext = dbContext;
		}

		public IPagedList<CATS_SESSION> GetAllSessions(PageListParam page, OrderListParam orderBy)
		{
			var query = _dbContext.CatsSession
				.AsNoTracking()
				.Include(s => s.Ref_Employee)
				.Where(s => s.TERMINATION_REASON_CD != null)
				.OrderByParam(q => (q.OrderBy(s => s.CATS_SESSION_ID)), orderBy);
			return PagedList<CATS_SESSION>.Create(query, page);			
		}

		public IPagedList<CATS_SESSION> GetActiveSessions(long employeeId, OrderListParam orderBy = null)
		{
			IQueryable<CATS_SESSION> queryable = GetActiveSessionsForEmployee(employeeId);
			var query = queryable
				.OrderByParam(q => (q.OrderBy(s => s.CATS_SESSION_ID)), orderBy);
			return PagedList<CATS_SESSION>.Create(query);
		}

		private IQueryable<CATS_SESSION> GetActiveSessionsForEmployee(long employeeId)
		{
			return _dbContext.CatsSession
				.AsNoTracking()
				.Include(s => s.Ref_Employee)
				.Where(s => s.TERMINATION_REASON_CD == null
					&& s.EXPIRE_DT >= DateTime.Now
					&& s.EMPLOYEE_ID == employeeId);
		}

		public void CreateNewSession(CATS_SESSION session)
		{
			_dbContext.CatsSession.Add(session);
			_dbContext.SaveChanges();		 	
		}

		public CATS_SESSION GetSession(string jti)
		{
			return _dbContext.CatsSession
				.AsNoTracking()
				.SingleOrDefault(s => s.JTI == jti);
		}

		public void MarkExpiredSessionsAsAbandoned()
		{
			var abandonedSessions = _dbContext.CatsSession
				.Where(s => s.EXPIRE_DT < DateTime.Now && s.TERMINATION_REASON_CD == null)
				.ToList();

			abandonedSessions.ForEach(s =>
			{
				s.TERMINATION_REASON_CD = TermReasonAbandoned;
				s.LOGOUT_TS = s.EXPIRE_DT;
			});

			_dbContext.SaveChanges();
		}

		public int GetActiveSessionCount(long employeeId)
		{
			return GetActiveSessionsForEmployee(employeeId).Count();
		}
	}
}
