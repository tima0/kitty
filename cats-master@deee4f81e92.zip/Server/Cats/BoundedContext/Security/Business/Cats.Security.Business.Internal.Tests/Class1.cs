﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Business.Internal.Tests
{
    public class Class1
    {
    }
}
