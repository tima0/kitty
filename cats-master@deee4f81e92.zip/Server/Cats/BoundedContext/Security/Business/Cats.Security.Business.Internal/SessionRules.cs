using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Business;
using DwsUI.Core;

namespace Cats.Security.Business.Internal
{
	public class SessionRules : ISessionRules

	{
		public void ValidateSessionCount(int sessionCount)
		{
			if (sessionCount >= 2)
			{
				throw new ValidationException("Only two active sessions are allowed.");
			}
		}
	}
}
