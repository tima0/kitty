using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Business
{
    public interface ISessionRules
    {
		void ValidateSessionCount(int sessionCount);
    }
}
