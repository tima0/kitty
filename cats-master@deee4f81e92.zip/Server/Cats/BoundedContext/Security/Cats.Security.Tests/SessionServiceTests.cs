using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using Moq;
using DwsUI.Core.Security;
using Cats.Security;
using Cats.Security.Business;

namespace Cats.Security.Tests
{
    public class SessionServiceTests
    {
		[Fact]
		public void ReturnsProperObject()
		{
			// arrange
			string sessionId = "ct1";
			var mockRepo = new Mock<Data.Repositories.ISessionRepository>();
			var mockEmpRepo = new Mock<Data.Repositories.IEmployeeRepository>();
			var mockSessionRules = new Mock<ISessionRules>();
			var mockSessionTimeoutSettings = new Mock<Models.ISessionTimeoutSettings>();
			var mockTokenKeys = new Mock<ITokenKeys>();
			mockRepo.Setup(m => m.GetSession(sessionId))
				.Returns(new Data.Models.CATS_SESSION
				{
					JTI = "ct1"
				});
			var sessionService = new Internals.Services.SessionService(mockRepo.Object, mockEmpRepo.Object,
				mockSessionRules.Object, mockSessionTimeoutSettings.Object, mockTokenKeys.Object);

			// act
			Models.Session session  = sessionService.GetSession(sessionId);

			// assert
			session.SessionId.ShouldBe(sessionId);
		}

		[Fact]
		public void ReturnsNull()
		{
			// arrange, no need to setup method as it will return null by default
			var mockRepo = new Mock<Data.Repositories.ISessionRepository>();
			var mockEmpRepo = new Mock<Data.Repositories.IEmployeeRepository>();
			var mockSessionRules = new Mock<ISessionRules>();
			var mockSessionTimeoutSettings = new Mock<Models.ISessionTimeoutSettings>();
			var mockTokenKeys = new Mock<ITokenKeys>();

			var sessionService = new Internals.Services.SessionService(mockRepo.Object, mockEmpRepo.Object,
				mockSessionRules.Object, mockSessionTimeoutSettings.Object, mockTokenKeys.Object);

			// act
			Models.Session session = sessionService.GetSession("bogusId");

			// assert
			session.ShouldBeNull();
		}

	}
}
