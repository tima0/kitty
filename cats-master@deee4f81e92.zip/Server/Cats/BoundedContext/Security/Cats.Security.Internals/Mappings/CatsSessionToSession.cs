using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Models;
using Cats.Security.Data.Models;

namespace Cats.Security.Internals.Mappings
{
	public static class CatsSessionToSession
	{
		public static Session ToAppModel(this CATS_SESSION catsSession)
		{
			if (catsSession == null)
			{
				return null;
			}
			else
			{
				return new Session()
				{
					SessionId = catsSession.CATS_SESSION_ID.ToString(),
					EmployeeId = catsSession.EMPLOYEE_ID,
					FirstName = catsSession.Ref_Employee?.FIRSTNAME,
					LastName = catsSession.Ref_Employee?.LASTNAME,
					LastRenewal = catsSession.LAST_ACTIVITY_TS,
					SessionStart = catsSession.LOGIN_TS,					
					IpAddress = catsSession.IP_ADDRESS,
					UserAgent = catsSession.USER_AGENT
				};
			}
		}
	}
}
