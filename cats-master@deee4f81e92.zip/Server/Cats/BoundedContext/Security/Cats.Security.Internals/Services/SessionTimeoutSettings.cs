using Cats.Security.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Security.Internals.Services
{
	public class FifteenMinuteSessionTimeoutSettings : ISessionTimeoutSettings
	{
		public double NumberOfSecondsToAdd { get; }
		public FifteenMinuteSessionTimeoutSettings()
		{
			this.NumberOfSecondsToAdd = 15 * 60;
		}
	}
}
