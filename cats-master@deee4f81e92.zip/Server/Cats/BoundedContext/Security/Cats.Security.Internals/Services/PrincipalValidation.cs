using System.Security.Claims;
using DwsUI.Core.Security;
using Cats.Security.Data.Repositories;


namespace Cats.Security.Internals.Services
{
	public class PrincipalValidation : IPrincipalValidation
	{
		readonly ISecurityValidationRepository _securityValidationRepository;
		public PrincipalValidation(ISecurityValidationRepository repository)
		{
			_securityValidationRepository = repository;
		}
		public bool IsValid(ClaimsPrincipal claimsPrincipal)
		{
			return _securityValidationRepository.IsValidEmployeeId(claimsPrincipal.EmployeeId()) &&
				_securityValidationRepository.IsValidJti(claimsPrincipal.Jti());				
		}}
}
