using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Models;
using Cats.Security.Services;
using Cats.Security.Data.Repositories;

namespace Cats.Security.Internals.Services
{
	public class PageViewService : IPageViewService
	{
		readonly IPageVisitRepository _pageVisit;
		public PageViewService(IPageVisitRepository pageVisit)
		{
			_pageVisit = pageVisit;
		}

		public void RecordPageHistory(PageHistoryEventData pageHistory)
		{
			throw new NotImplementedException();
		}
	}
}
