using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Security;
using Cats.Security.Data.Repositories;

namespace Cats.Security.Internals.Services
{
	public class SystemAvailable : ISystemAvailable
	{
		readonly ISecurityParametersRepository _securityParameters;
		public SystemAvailable(ISecurityParametersRepository securityParameters)
		{
			_securityParameters = securityParameters;
		}
		public bool IsSystemAvailable => _securityParameters.IsSystemAvailable();
	}
}
