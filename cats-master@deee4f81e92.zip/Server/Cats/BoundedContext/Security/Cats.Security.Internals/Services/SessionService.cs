using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Cats.Security.Data.Models;
using Cats.Security.Data.Repositories;
using Cats.Security.Models;
using Cats.Security.Services;
using Cats.Security.Internals.Mappings;
using DwsUI.Core;
using DwsUI.Core.Collections;
using DwsUI.Core.ListParams;
using Cats.Security.Business;
using System.Security.Principal;
using DwsUI.Core.Security;

namespace Cats.Security.Internals.Services
{
	public class SessionService : ISessionService
	{
		private readonly ISessionRepository _sessionRepository;
		private readonly IEmployeeRepository _employeeRepository;
		private readonly ISessionRules _sessionRules;
		private readonly ISessionTimeoutSettings _sessionTimeoutSettings;
		private readonly ITokenKeys _tokenKeys;
		private const string ISSUER = "ct";

		public SessionService(ISessionRepository sessionRepository, IEmployeeRepository employeeRepository, ISessionRules sessionRules, ISessionTimeoutSettings sessionTimeoutSettings, ITokenKeys tokenKeys)
		{
			_sessionRepository = sessionRepository;
			_employeeRepository = employeeRepository;
			_sessionRules = sessionRules;
			_sessionTimeoutSettings = sessionTimeoutSettings;
			_tokenKeys = tokenKeys;
		}

		public (SessionToken sessionToken, string jwtToken) CreateToken(NewTokenRequest tokenRequest)
		{
			Session session = CreateSession(tokenRequest.Email, tokenRequest.ExpireDateTime, tokenRequest.UserAgent, tokenRequest.IpAddress);

			string issuerKey = ISSUER + "-priv";
			var secretKeyCertificateFilename = _tokenKeys.TokenKeys[issuerKey];

			JwtUserIdentity jwtUserIdentity = new JwtUserIdentity(session.EmployeeId, tokenRequest.UserName, tokenRequest.FirstName, tokenRequest.LastName, tokenRequest.Email);
			JwtTokenPayload jwtTokenPayload = new JwtTokenPayload(ISSUER, session.SessionId, jwtUserIdentity, tokenRequest.ExpireDateTime, tokenRequest.SecurityRoles);
			var credentials = JwtEncode.GetRSACredsFromFile(secretKeyCertificateFilename);
			JwtEncode jwtEncode = new JwtEncode(credentials);

			var jwtTokenParts = jwtEncode.CreateToken(jwtTokenPayload);

			SessionToken sessionToken = new SessionToken
			{
				JwtToken = jwtTokenParts.PayloadJSON
			};

			return (sessionToken, jwtTokenParts.Text);
		}

		private Session CreateSession(string emailAddress, DateTime expireDateTime,string userAgent, string ipAddress)
		{
			// Look up EmployeeId
			EMPLOYEE employee = _employeeRepository.GetEmployeeByEmail(emailAddress);
			if (employee == null)
			{
				throw new ValidationException("Employee is setup in SAMS but not in CATS");
			}
			// Lookup Existing Sessions for Empoyee
			IPagedList<CATS_SESSION> activeSessions = _sessionRepository.GetActiveSessions(employee.EMPLOYEE_ID,null);
			_sessionRules.ValidateSessionCount(activeSessions.TotalCount);
			CATS_SESSION session = new CATS_SESSION
			{
				EMPLOYEE_ID = employee.EMPLOYEE_ID,
				EXPIRE_DT = expireDateTime,
				IP_ADDRESS = ipAddress,
				LOGIN_TS = DateTime.Now,
				LAST_ACTIVITY_TS = DateTime.Now,
				USER_AGENT = userAgent
			};

			_sessionRepository.CreateNewSession(session);

			return session.ToAppModel();
		}

		public  IEnumerable<string> ExtractSecurityRoles(GenericPrincipal principal)
		{
			var rolesToExclude = new string[] { "authadmin", "Everyone" };
			var securityRoles = principal.Claims
				.Where(c => c.Issuer == ClaimTypes.Role && !rolesToExclude.Contains(c.Value))
				.Select(c => c.Value);
			return securityRoles;
		}

		public ListEnvelope<Session> GetActiveSessions(string jti, PageListParam page, OrderListParam order)
		{
			throw new NotImplementedException();
		}

		public ListEnvelope<Session> GetAllActiveSessions(PageListParam page, OrderListParam order)
		{
			return _sessionRepository
				.GetAllSessions(page, order)
				.ToEnvelope(s => s.ToAppModel());
		}


		public Session GetSession(string sessionId)
		{
			return _sessionRepository
				.GetSession(sessionId)
				.ToAppModel();
		}
		public void MarkExpiredSessionsAsAbandoned()
		{
			_sessionRepository.MarkExpiredSessionsAsAbandoned();
		}
		public ListEnvelope<SessionHistory> GetSessionHistory(int EmployeeID, PageListParam page, OrderListParam order)
		{
			throw new NotImplementedException();
		}

		public ListEnvelope<KillSessionResult> KillSessions(IEnumerable<SessionIdentifier> SessionID)
		{
			throw new NotImplementedException();
		}

		public bool LogoffSession(ClaimsPrincipal claimsPrincipal)
		{
			throw new NotImplementedException();
		}

		public bool TimeoutSession(ClaimsPrincipal claimsPrincipal)
		{
			throw new NotImplementedException();
		}

		public bool TryExtendSession(ClaimsPrincipal claimsPrincipal, out SessionToken sessionToken)
		{
			throw new NotImplementedException();
		}

		DateTime ISessionService.SessionExpireDateTime()
		{
			return DateTime.Now.AddSeconds(_sessionTimeoutSettings.NumberOfSecondsToAdd);
		}
	}
}
