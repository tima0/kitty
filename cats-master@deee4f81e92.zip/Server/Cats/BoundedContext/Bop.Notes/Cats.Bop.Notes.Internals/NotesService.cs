using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
//using Cats.Bop.Notes.Models;
using Cats.Bop.Notes.Data.Interfaces;


namespace Cats.Bop.Notes.Internals
{
	public interface IBopNoteMappers
	{
		IMapper NoteMapper { get; }
	}

	public abstract class MappersBase
	{
		public MappersBase()
		{
			CreateMappers();
		}

		protected abstract void CreateMappers();
	}

	public class NotesMappers : MappersBase, IBopNoteMappers
	{
		public IMapper NoteMapper { get; private set; }

		protected override void CreateMappers()
		{
			var claimantMapConfig = new MapperConfiguration(
					 c => c.CreateMap<Cats.Bop.Notes.Data.Models.NotesModel, Cats.Bop.Notes.Models.NotesModel>()
				);
			this.NoteMapper = claimantMapConfig.CreateMapper();
		}
	}

	public class NotesService
    {
    }
}
