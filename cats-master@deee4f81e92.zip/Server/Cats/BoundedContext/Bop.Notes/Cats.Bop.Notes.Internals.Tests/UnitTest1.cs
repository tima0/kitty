using System;

namespace Cats.Bop.Notes_Internals.Tests
{
	public class UnitTest1
	{
		public void TestMethod1()
		{
		}
	}
}
