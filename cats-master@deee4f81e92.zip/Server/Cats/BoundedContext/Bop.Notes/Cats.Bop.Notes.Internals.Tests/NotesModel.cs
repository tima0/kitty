using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Notes.Models
{
	public class NotesModel
	{
		public long BopNoteId { get; set; }
		public string BopNOteSourceCd { get; set; }
		public long BopProsecutionId { get; set; }
		public long BopGarnishmentId { get; set; }
		public long PrtyId { get; set; }
		public long Emplid { get; set; }
		public string ContactName { get; set; }
		public string ContactTitle { get; set; }
		public string ContactPhone { get; set; }
		public string ContactExt { get; set; }
		public string Descr { get; set; }
		public string Note { get; set; }
		public string MachineName { get; set; }
		public long CreatedBy { get; set; }
		public DateTime CreateTs { get; set; }
		public long ModifiedBy { get; set; }
		public DateTime ModifiedTs { get; set; }
		public string ImageId { get; set; }
		public long LettersLetterId { get; set; }
	}
}
