using System;

namespace Cats.Bop.Notes.Data.Models
{
	///<summary>Indicates a Cats-specific attribute.</summary>
	public class CatsNetModelAttributeAttribute : System.Attribute { }

	///<summary>Indicates a Cats-specific attribute on a field which can be validated.</summary>
	public abstract class CatsNetModelFieldValidationAttribute : CatsNetModelAttributeAttribute
	{
		public abstract bool Validate(object value);
	}

	public class DBFieldDataTypeAttribute : CatsNetModelAttributeAttribute
	{
		public string DBFieldDataType { get; }
		public DBFieldDataTypeAttribute(string dataType) { DBFieldDataType = dataType; }
	}

	///<summary>Add this to a class to specify the database schema of th table that it represents.</summary>
	[System.AttributeUsage(System.AttributeTargets.Class | System.AttributeTargets.Interface | System.AttributeTargets.Struct)]
	public class DBSchemaAttribute : CatsNetModelAttributeAttribute
	{
		public string SchemaName { get; }
		public DBSchemaAttribute(string schemaName)
		{
			SchemaName = schemaName;
		}
	}

	///<summary>Add this to a class to specify the database table that it represents.</summary>
	[System.AttributeUsage(System.AttributeTargets.Class | System.AttributeTargets.Interface | System.AttributeTargets.Struct)]
	public class DBTableAttribute : CatsNetModelAttributeAttribute
	{
		public string SchemaName { get; }
		public string TableName { get; }
		public DBTableAttribute(string schemaName, string tableName)
		{
			SchemaName = schemaName;
			TableName = tableName;
		}
	}

	///<summary>Add this to a class to specify the primary key column for that table.</summary>
	///<remarks>There can be more than one PrimaryKeyAttribute on the class if the table has a composite key.</remarks>
	[System.AttributeUsage(System.AttributeTargets.Class | System.AttributeTargets.Interface | System.AttributeTargets.Struct)]
	public class PrimaryKeyAttribute : CatsNetModelAttributeAttribute { }

	///<summary>Add this to a property to indicate that the column which it represents is part of the primary key.</summary>
	[System.AttributeUsage(System.AttributeTargets.Property | System.AttributeTargets.Field)]
	public class PrimaryKeyColumnAttribute : CatsNetModelFieldValidationAttribute
	{
		public override bool Validate(object value)
		{
			if (value == null)
				return false;
			else if (value is string)
				return !string.IsNullOrEmpty((string)value);
			else
			{
				try
				{
					decimal d = Convert.ToDecimal(value);
					return d != 0m;
				}
				catch
				{
					return false;
				}
			}
		}
	}

	///<summary>Add this to a property to indicate that it represents a column in the database.</summary>
	[System.AttributeUsage(System.AttributeTargets.Property | System.AttributeTargets.Field)]
	public class ColumnAttribute: CatsNetModelAttributeAttribute
	{
		public string SchemaName { get; }
		public string TableName { get; }
		public string ColumnName { get; }
		public string DBDataType { get; }
		public System.Type DotNetDataType { get; }
		public string FullName => $"{SchemaName}.{TableName}.{ColumnName}";

		public ColumnAttribute(string schemaName, string tableName, string columnName, string dbDataType, System.Type dotNetDataType)
		{
			SchemaName = schemaName;
			TableName = tableName;
			ColumnName = columnName;
			DBDataType = dbDataType;
			DotNetDataType = dotNetDataType;
		}
	}

	public class MaxLengthAttribute : CatsNetModelFieldValidationAttribute
	{
		public int MaxLength { get; }
		public MaxLengthAttribute(int maxLength)
		{
			this.MaxLength = maxLength;
		}
		public override bool Validate(object value)
		{
			if (value is string)
				return ((value != null) && (((string)value).Length <= this.MaxLength));
			else
				return false;
		}
	}

	public class IdentityReferenceAttribute : CatsNetModelAttributeAttribute
	{
		public string RefSchemaName { get; }
		public string RefTableName { get; }
		public string RefColumnName { get; }
		public string ForeignSchemaName { get; }
		public string ForeignTableName { get; }
		public string ForeignColumnName { get; }
		public IdentityReferenceAttribute(string refSchemaName, string refTableName, string refColumnName, string foreignSchemaName, string foreignTableName, string foreignColumnName)
		{
			this.RefSchemaName = refSchemaName;
			this.RefTableName = refTableName;
			this.RefColumnName = refColumnName;
			this.ForeignSchemaName = foreignSchemaName;
			this.ForeignTableName = foreignTableName;
			this.ForeignColumnName = foreignColumnName;
		}
	}

	public class ReferenceToAttribute : IdentityReferenceAttribute
	{
		public ReferenceToAttribute(string refSchemaName, string refTableName, string refColumnName, string foreignSchemaName, string foreignTableName, string foreignColumnName)
			: base(refSchemaName, refTableName, refColumnName, foreignSchemaName, foreignTableName, foreignColumnName)
		{ }
	}

	public class ReferenceFromAttribute : IdentityReferenceAttribute
	{
		public ReferenceFromAttribute(string refSchemaName, string refTableName, string refColumnName, string foreignSchemaName, string foreignTableName, string foreignColumnName)
			: base(refSchemaName, refTableName, refColumnName, foreignSchemaName, foreignTableName, foreignColumnName)
		{ }
	}
}
