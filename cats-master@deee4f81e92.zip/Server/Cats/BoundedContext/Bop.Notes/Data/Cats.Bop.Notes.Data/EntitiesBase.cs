using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Notes.Data.Models
{
	public interface IEntityBase
	{
	}

	public abstract partial class EntityBase: IEntityBase
	{
		public abstract void SetDirtyFields(bool value);
		public abstract bool HasDirtyFields();
		public abstract string SchemaName();
		public abstract string TableName();
		public abstract string PrimaryKeyFieldname();
		public abstract bool HasPrimaryKey();
		public abstract bool HasForeignKeys();
		//public abstract IEnumerable<string, string, string> ForeignKeys();
		public abstract bool HasCompositePrimaryKey();
	}

	public abstract class BOP_NOTEBase : EntityBase, IEntityBase
	{
		public BOP_NOTEBase() { }
	}
	public abstract class BOP_NOTE_SOURCE_CODEBase : EntityBase, IEntityBase
	{
		public BOP_NOTE_SOURCE_CODEBase() { }
	}
	public abstract class BOP_NOTE_TYPEBase : EntityBase, IEntityBase
	{
		public BOP_NOTE_TYPEBase() { }
	}
	public abstract class BOP_NOTE_TYPE_CODEBase : EntityBase, IEntityBase
	{
		public BOP_NOTE_TYPE_CODEBase() { }
	}
	public abstract class V_PARTIES2Base : EntityBase, IEntityBase
	{
		public V_PARTIES2Base() { }
	}
	public abstract class EMPLOYEEBase : EntityBase, IEntityBase
	{
		public EMPLOYEEBase() { }
	}
}


