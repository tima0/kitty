using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Notes.Data.Models
{


	//Reference to -> CATS_BOP_OWNER.BOP_NOTE.BOP_NOTE_SOURCE_CD->CATS_BOP_OWNER.BOP_NOTE_SOURCE_CODE.BOP_NOTE_SOURCE_CD
	//ReferencedBy -> CATS_BOP_OWNER.BOP_NOTE_TYPE.BOP_NOTE_ID->CATS_BOP_OWNER.BOP_NOTE.BOP_NOTE_ID
	[Cats.Bop.Notes.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Notes.Data.Models.DBTable("CATS_BOP_OWNER", "BOP_NOTE")]
	public partial class BOP_NOTEGen : BOP_NOTEBase
	{
		#region Property backing stores for table BOP_NOTE
		protected System.String _IMAGEID;
		protected virtual System.String GetIMAGEID() { return _IMAGEID; }
		protected virtual void SetIMAGEID(System.String value) { _IMAGEID = value; _IMAGEIDFieldIsDirty = true; }
		protected virtual bool _IMAGEIDFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.String _DESCR;
		protected virtual System.String GetDESCR() { return _DESCR; }
		protected virtual void SetDESCR(System.String value) { _DESCR = value; _DESCRFieldIsDirty = true; }
		protected virtual bool _DESCRFieldIsDirty { get; set; }

		protected System.String _CONTACT_EXT;
		protected virtual System.String GetCONTACT_EXT() { return _CONTACT_EXT; }
		protected virtual void SetCONTACT_EXT(System.String value) { _CONTACT_EXT = value; _CONTACT_EXTFieldIsDirty = true; }
		protected virtual bool _CONTACT_EXTFieldIsDirty { get; set; }

		protected System.String _CONTACT_TITLE;
		protected virtual System.String GetCONTACT_TITLE() { return _CONTACT_TITLE; }
		protected virtual void SetCONTACT_TITLE(System.String value) { _CONTACT_TITLE = value; _CONTACT_TITLEFieldIsDirty = true; }
		protected virtual bool _CONTACT_TITLEFieldIsDirty { get; set; }

		protected System.Int64 _EMPLID;
		protected virtual System.Int64 GetEMPLID() { return _EMPLID; }
		protected virtual void SetEMPLID(System.Int64 value) { _EMPLID = value; _EMPLIDFieldIsDirty = true; }
		protected virtual bool _EMPLIDFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.Int64? _BOP_PROSECUTION_ID;
		protected virtual System.Int64? GetBOP_PROSECUTION_ID() { return _BOP_PROSECUTION_ID; }
		protected virtual void SetBOP_PROSECUTION_ID(System.Int64? value) { _BOP_PROSECUTION_ID = value; _BOP_PROSECUTION_IDFieldIsDirty = true; }
		protected virtual bool _BOP_PROSECUTION_IDFieldIsDirty { get; set; }

		protected System.String _BOP_NOTE_SOURCE_CD;
		protected virtual System.String GetBOP_NOTE_SOURCE_CD() { return _BOP_NOTE_SOURCE_CD; }
		protected virtual void SetBOP_NOTE_SOURCE_CD(System.String value) { _BOP_NOTE_SOURCE_CD = value; _BOP_NOTE_SOURCE_CDFieldIsDirty = true; }
		protected virtual bool _BOP_NOTE_SOURCE_CDFieldIsDirty { get; set; }

		protected System.Int64 _BOP_NOTE_ID;
		protected virtual System.Int64 GetBOP_NOTE_ID() { return _BOP_NOTE_ID; }
		protected virtual void SetBOP_NOTE_ID(System.Int64 value) { _BOP_NOTE_ID = value; _BOP_NOTE_IDFieldIsDirty = true; }
		protected virtual bool _BOP_NOTE_IDFieldIsDirty { get; set; }

		protected System.Int64? _LETTERS_LETTER_ID;
		protected virtual System.Int64? GetLETTERS_LETTER_ID() { return _LETTERS_LETTER_ID; }
		protected virtual void SetLETTERS_LETTER_ID(System.Int64? value) { _LETTERS_LETTER_ID = value; _LETTERS_LETTER_IDFieldIsDirty = true; }
		protected virtual bool _LETTERS_LETTER_IDFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_TS;
		protected virtual System.DateTime? GetMODIFIED_TS() { return _MODIFIED_TS; }
		protected virtual void SetMODIFIED_TS(System.DateTime? value) { _MODIFIED_TS = value; _MODIFIED_TSFieldIsDirty = true; }
		protected virtual bool _MODIFIED_TSFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.String _MACHINE_NAME;
		protected virtual System.String GetMACHINE_NAME() { return _MACHINE_NAME; }
		protected virtual void SetMACHINE_NAME(System.String value) { _MACHINE_NAME = value; _MACHINE_NAMEFieldIsDirty = true; }
		protected virtual bool _MACHINE_NAMEFieldIsDirty { get; set; }

		protected System.String _NOTE;
		protected virtual System.String GetNOTE() { return _NOTE; }
		protected virtual void SetNOTE(System.String value) { _NOTE = value; _NOTEFieldIsDirty = true; }
		protected virtual bool _NOTEFieldIsDirty { get; set; }

		protected System.String _CONTACT_PHONE;
		protected virtual System.String GetCONTACT_PHONE() { return _CONTACT_PHONE; }
		protected virtual void SetCONTACT_PHONE(System.String value) { _CONTACT_PHONE = value; _CONTACT_PHONEFieldIsDirty = true; }
		protected virtual bool _CONTACT_PHONEFieldIsDirty { get; set; }

		protected System.String _CONTACT_NAME;
		protected virtual System.String GetCONTACT_NAME() { return _CONTACT_NAME; }
		protected virtual void SetCONTACT_NAME(System.String value) { _CONTACT_NAME = value; _CONTACT_NAMEFieldIsDirty = true; }
		protected virtual bool _CONTACT_NAMEFieldIsDirty { get; set; }

		protected System.Int64? _BOP_GARNISHMENT_ID;
		protected virtual System.Int64? GetBOP_GARNISHMENT_ID() { return _BOP_GARNISHMENT_ID; }
		protected virtual void SetBOP_GARNISHMENT_ID(System.Int64? value) { _BOP_GARNISHMENT_ID = value; _BOP_GARNISHMENT_IDFieldIsDirty = true; }
		protected virtual bool _BOP_GARNISHMENT_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table BOP_NOTE

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "IMAGEID", "VARCHAR2", typeof(System.String))]
		public virtual System.String IMAGEID { get { return GetIMAGEID(); } set { SetIMAGEID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "DESCR", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCR { get { return GetDESCR(); } set { SetDESCR(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(6)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "CONTACT_EXT", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_EXT { get { return GetCONTACT_EXT(); } set { SetCONTACT_EXT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "CONTACT_TITLE", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_TITLE { get { return GetCONTACT_TITLE(); } set { SetCONTACT_TITLE(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "EMPLID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 EMPLID { get { return GetEMPLID(); } set { SetEMPLID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "BOP_PROSECUTION_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? BOP_PROSECUTION_ID { get { return GetBOP_PROSECUTION_ID(); } set { SetBOP_PROSECUTION_ID(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "BOP_NOTE", "BOP_NOTE_SOURCE_CD", "CATS_BOP_OWNER", "BOP_NOTE_SOURCE_CODE", "BOP_NOTE_SOURCE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "BOP_NOTE_SOURCE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String BOP_NOTE_SOURCE_CD { get { return GetBOP_NOTE_SOURCE_CD(); } set { SetBOP_NOTE_SOURCE_CD(value); } }

		[Cats.Bop.Notes.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "BOP_NOTE_ID", "CATS_BOP_OWNER", "BOP_NOTE", "BOP_NOTE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "BOP_NOTE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 BOP_NOTE_ID { get { return GetBOP_NOTE_ID(); } set { SetBOP_NOTE_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "LETTERS_LETTER_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? LETTERS_LETTER_ID { get { return GetLETTERS_LETTER_ID(); } set { SetLETTERS_LETTER_ID(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "MODIFIED_TS", "TIMESTAMP(6)", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_TS { get { return GetMODIFIED_TS(); } set { SetMODIFIED_TS(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(256)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "MACHINE_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String MACHINE_NAME { get { return GetMACHINE_NAME(); } set { SetMACHINE_NAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(4000)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "NOTE", "VARCHAR2", typeof(System.String))]
		public virtual System.String NOTE { get { return GetNOTE(); } set { SetNOTE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(14)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "CONTACT_PHONE", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_PHONE { get { return GetCONTACT_PHONE(); } set { SetCONTACT_PHONE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "CONTACT_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_NAME { get { return GetCONTACT_NAME(); } set { SetCONTACT_NAME(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE", "BOP_GARNISHMENT_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? BOP_GARNISHMENT_ID { get { return GetBOP_GARNISHMENT_ID(); } set { SetBOP_GARNISHMENT_ID(value); } }


		public virtual BOP_NOTE_SOURCE_CODE RefToSingle_BopNoteSourceCode { get; set; }

		public virtual ICollection<BOP_NOTE_TYPE> RefFrom_BopNoteType_BopNoteId_To_BopNoteId { get; set; }

		#endregion

		#region Constructors for table BOP_NOTEGen
		public BOP_NOTEGen()
		{
		}

		public BOP_NOTEGen(System.String IMAGEID, System.Int64? MODIFIED_BY, System.Int64 CREATED_BY, System.String DESCR, System.String CONTACT_EXT, System.String CONTACT_TITLE, System.Int64 EMPLID, System.Int64 PRTY_ID, System.Int64? BOP_PROSECUTION_ID, System.String BOP_NOTE_SOURCE_CD, System.Int64 BOP_NOTE_ID, System.Int64? LETTERS_LETTER_ID, System.DateTime? MODIFIED_TS, System.DateTime CREATED_TS, System.String MACHINE_NAME, System.String NOTE, System.String CONTACT_PHONE, System.String CONTACT_NAME, System.Int64? BOP_GARNISHMENT_ID) : this()
		{
			this._IMAGEID = IMAGEID;
			this._MODIFIED_BY = MODIFIED_BY;
			this._CREATED_BY = CREATED_BY;
			this._DESCR = DESCR;
			this._CONTACT_EXT = CONTACT_EXT;
			this._CONTACT_TITLE = CONTACT_TITLE;
			this._EMPLID = EMPLID;
			this._PRTY_ID = PRTY_ID;
			this._BOP_PROSECUTION_ID = BOP_PROSECUTION_ID;
			this._BOP_NOTE_SOURCE_CD = BOP_NOTE_SOURCE_CD;
			this._BOP_NOTE_ID = BOP_NOTE_ID;
			this._LETTERS_LETTER_ID = LETTERS_LETTER_ID;
			this._MODIFIED_TS = MODIFIED_TS;
			this._CREATED_TS = CREATED_TS;
			this._MACHINE_NAME = MACHINE_NAME;
			this._NOTE = NOTE;
			this._CONTACT_PHONE = CONTACT_PHONE;
			this._CONTACT_NAME = CONTACT_NAME;
			this._BOP_GARNISHMENT_ID = BOP_GARNISHMENT_ID;
		}
		#endregion

		#region Overrides
		public override void SetDirtyFields(bool value)
		{
			_IMAGEIDFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_DESCRFieldIsDirty = value;
			_CONTACT_EXTFieldIsDirty = value;
			_CONTACT_TITLEFieldIsDirty = value;
			_EMPLIDFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_BOP_PROSECUTION_IDFieldIsDirty = value;
			_BOP_NOTE_SOURCE_CDFieldIsDirty = value;
			_BOP_NOTE_IDFieldIsDirty = value;
			_LETTERS_LETTER_IDFieldIsDirty = value;
			_MODIFIED_TSFieldIsDirty = value;
			_CREATED_TSFieldIsDirty = value;
			_MACHINE_NAMEFieldIsDirty = value;
			_NOTEFieldIsDirty = value;
			_CONTACT_PHONEFieldIsDirty = value;
			_CONTACT_NAMEFieldIsDirty = value;
			_BOP_GARNISHMENT_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _IMAGEIDFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _DESCRFieldIsDirty
				|| _CONTACT_EXTFieldIsDirty
				|| _CONTACT_TITLEFieldIsDirty
				|| _EMPLIDFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _BOP_PROSECUTION_IDFieldIsDirty
				|| _BOP_NOTE_SOURCE_CDFieldIsDirty
				|| _BOP_NOTE_IDFieldIsDirty
				|| _LETTERS_LETTER_IDFieldIsDirty
				|| _MODIFIED_TSFieldIsDirty
				|| _CREATED_TSFieldIsDirty
				|| _MACHINE_NAMEFieldIsDirty
				|| _NOTEFieldIsDirty
				|| _CONTACT_PHONEFieldIsDirty
				|| _CONTACT_NAMEFieldIsDirty
				|| _BOP_GARNISHMENT_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "BOP_NOTE";
	}

		public override string PrimaryKeyFieldname()
		{
			return "TODO:FinishThis";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		// TODO: I don't know how EF wants us to handle references yet.
		//public override IEnumerable<string, string, string> ForeignKeys()
		//{
		//	return null;
		//}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.BOP_NOTE")
				.Append(" { ")
				.Append("IMAGEID")
				.Append(" = ")
				.Append(this.IMAGEID.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("DESCR")
				.Append(" = ")
				.Append(this.DESCR.ToString())
				.Append("; ")
				.Append("CONTACT_EXT")
				.Append(" = ")
				.Append(this.CONTACT_EXT.ToString())
				.Append("; ")
				.Append("CONTACT_TITLE")
				.Append(" = ")
				.Append(this.CONTACT_TITLE.ToString())
				.Append("; ")
				.Append("EMPLID")
				.Append(" = ")
				.Append(this.EMPLID.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("BOP_PROSECUTION_ID")
				.Append(" = ")
				.Append(this.BOP_PROSECUTION_ID.ToString())
				.Append("; ")
				.Append("BOP_NOTE_SOURCE_CD")
				.Append(" = ")
				.Append(this.BOP_NOTE_SOURCE_CD.ToString())
				.Append("; ")
				.Append("BOP_NOTE_ID")
				.Append(" = ")
				.Append(this.BOP_NOTE_ID.ToString())
				.Append("; ")
				.Append("LETTERS_LETTER_ID")
				.Append(" = ")
				.Append(this.LETTERS_LETTER_ID.ToString())
				.Append("; ")
				.Append("MODIFIED_TS")
				.Append(" = ")
				.Append(this.MODIFIED_TS.ToString())
				.Append("; ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("MACHINE_NAME")
				.Append(" = ")
				.Append(this.MACHINE_NAME.ToString())
				.Append("; ")
				.Append("NOTE")
				.Append(" = ")
				.Append(this.NOTE.ToString())
				.Append("; ")
				.Append("CONTACT_PHONE")
				.Append(" = ")
				.Append(this.CONTACT_PHONE.ToString())
				.Append("; ")
				.Append("CONTACT_NAME")
				.Append(" = ")
				.Append(this.CONTACT_NAME.ToString())
				.Append("; ")
				.Append("BOP_GARNISHMENT_ID")
				.Append(" = ")
				.Append(this.BOP_GARNISHMENT_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}

		#endregion
	}

	//ReferencedBy -> CATS_BOP_OWNER.BOP_NOTE.BOP_NOTE_SOURCE_CD->CATS_BOP_OWNER.BOP_NOTE_SOURCE_CODE.BOP_NOTE_SOURCE_CD
	[Cats.Bop.Notes.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Notes.Data.Models.DBTable("CATS_BOP_OWNER", "BOP_NOTE_SOURCE_CODE")]
	public partial class BOP_NOTE_SOURCE_CODEGen : BOP_NOTE_SOURCE_CODEBase
	{
		#region Property backing stores for table BOP_NOTE_SOURCE_CODE
		protected System.Int64 _LOAD_ORDER;
		protected virtual System.Int64 GetLOAD_ORDER() { return _LOAD_ORDER; }
		protected virtual void SetLOAD_ORDER(System.Int64 value) { _LOAD_ORDER = value; _LOAD_ORDERFieldIsDirty = true; }
		protected virtual bool _LOAD_ORDERFieldIsDirty { get; set; }

		protected System.String _BOP_NOTE_SOURCE_CD;
		protected virtual System.String GetBOP_NOTE_SOURCE_CD() { return _BOP_NOTE_SOURCE_CD; }
		protected virtual void SetBOP_NOTE_SOURCE_CD(System.String value) { _BOP_NOTE_SOURCE_CD = value; _BOP_NOTE_SOURCE_CDFieldIsDirty = true; }
		protected virtual bool _BOP_NOTE_SOURCE_CDFieldIsDirty { get; set; }

		protected System.String _DESCRIPTION;
		protected virtual System.String GetDESCRIPTION() { return _DESCRIPTION; }
		protected virtual void SetDESCRIPTION(System.String value) { _DESCRIPTION = value; _DESCRIPTIONFieldIsDirty = true; }
		protected virtual bool _DESCRIPTIONFieldIsDirty { get; set; }

		#endregion

		#region Properties for table BOP_NOTE_SOURCE_CODE

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_SOURCE_CODE", "LOAD_ORDER", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LOAD_ORDER { get { return GetLOAD_ORDER(); } set { SetLOAD_ORDER(value); } }

		[Cats.Bop.Notes.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "BOP_NOTE", "BOP_NOTE_SOURCE_CD", "CATS_BOP_OWNER", "BOP_NOTE_SOURCE_CODE", "BOP_NOTE_SOURCE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_SOURCE_CODE", "BOP_NOTE_SOURCE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String BOP_NOTE_SOURCE_CD { get { return GetBOP_NOTE_SOURCE_CD(); } set { SetBOP_NOTE_SOURCE_CD(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_SOURCE_CODE", "DESCRIPTION", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCRIPTION { get { return GetDESCRIPTION(); } set { SetDESCRIPTION(value); } }



		public virtual ICollection<BOP_NOTE> RefFrom_BopNote_BopNoteSourceCd_To_BopNoteSourceCd { get; set; }

		#endregion

		#region Constructors for table BOP_NOTE_SOURCE_CODEGen
		public BOP_NOTE_SOURCE_CODEGen()
		{
		}

		public BOP_NOTE_SOURCE_CODEGen(System.Int64 LOAD_ORDER, System.String BOP_NOTE_SOURCE_CD, System.String DESCRIPTION) : this()
		{
			this._LOAD_ORDER = LOAD_ORDER;
			this._BOP_NOTE_SOURCE_CD = BOP_NOTE_SOURCE_CD;
			this._DESCRIPTION = DESCRIPTION;
		}
		#endregion

		#region Overrides
		public override void SetDirtyFields(bool value)
		{
			_LOAD_ORDERFieldIsDirty = value;
			_BOP_NOTE_SOURCE_CDFieldIsDirty = value;
			_DESCRIPTIONFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _LOAD_ORDERFieldIsDirty
				|| _BOP_NOTE_SOURCE_CDFieldIsDirty
				|| _DESCRIPTIONFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "BOP_NOTE_SOURCE_CODE";
	}

		public override string PrimaryKeyFieldname()
		{
			return "TODO:FinishThis";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		// TODO: I don't know how EF wants us to handle references yet.
		//public override IEnumerable<string, string, string> ForeignKeys()
		//{
		//	return null;
		//}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.BOP_NOTE_SOURCE_CODE")
				.Append(" { ")
				.Append("LOAD_ORDER")
				.Append(" = ")
				.Append(this.LOAD_ORDER.ToString())
				.Append("; ")
				.Append("BOP_NOTE_SOURCE_CD")
				.Append(" = ")
				.Append(this.BOP_NOTE_SOURCE_CD.ToString())
				.Append("; ")
				.Append("DESCRIPTION")
				.Append(" = ")
				.Append(this.DESCRIPTION.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}

		#endregion
	}

	//Reference to -> CATS_BOP_OWNER.BOP_NOTE_TYPE.BOP_NOTE_TYPE_CD->CATS_BOP_OWNER.BOP_NOTE_TYPE_CODE.BOP_NOTE_TYPE_CD
	//Reference to -> CATS_BOP_OWNER.BOP_NOTE_TYPE.BOP_NOTE_ID->CATS_BOP_OWNER.BOP_NOTE.BOP_NOTE_ID
	[Cats.Bop.Notes.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Notes.Data.Models.DBTable("CATS_BOP_OWNER", "BOP_NOTE_TYPE")]
	public partial class BOP_NOTE_TYPEGen : BOP_NOTE_TYPEBase
	{
		#region Property backing stores for table BOP_NOTE_TYPE
		protected System.Int64 _BOP_NOTE_TYPE_ID;
		protected virtual System.Int64 GetBOP_NOTE_TYPE_ID() { return _BOP_NOTE_TYPE_ID; }
		protected virtual void SetBOP_NOTE_TYPE_ID(System.Int64 value) { _BOP_NOTE_TYPE_ID = value; _BOP_NOTE_TYPE_IDFieldIsDirty = true; }
		protected virtual bool _BOP_NOTE_TYPE_IDFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.String _BOP_NOTE_TYPE_CD;
		protected virtual System.String GetBOP_NOTE_TYPE_CD() { return _BOP_NOTE_TYPE_CD; }
		protected virtual void SetBOP_NOTE_TYPE_CD(System.String value) { _BOP_NOTE_TYPE_CD = value; _BOP_NOTE_TYPE_CDFieldIsDirty = true; }
		protected virtual bool _BOP_NOTE_TYPE_CDFieldIsDirty { get; set; }

		protected System.Int64 _BOP_NOTE_ID;
		protected virtual System.Int64 GetBOP_NOTE_ID() { return _BOP_NOTE_ID; }
		protected virtual void SetBOP_NOTE_ID(System.Int64 value) { _BOP_NOTE_ID = value; _BOP_NOTE_IDFieldIsDirty = true; }
		protected virtual bool _BOP_NOTE_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table BOP_NOTE_TYPE

		[Cats.Bop.Notes.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "BOP_NOTE_TYPE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 BOP_NOTE_TYPE_ID { get { return GetBOP_NOTE_TYPE_ID(); } set { SetBOP_NOTE_TYPE_ID(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "BOP_NOTE_TYPE_CD", "CATS_BOP_OWNER", "BOP_NOTE_TYPE_CODE", "BOP_NOTE_TYPE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "BOP_NOTE_TYPE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String BOP_NOTE_TYPE_CD { get { return GetBOP_NOTE_TYPE_CD(); } set { SetBOP_NOTE_TYPE_CD(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "BOP_NOTE_ID", "CATS_BOP_OWNER", "BOP_NOTE", "BOP_NOTE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "BOP_NOTE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 BOP_NOTE_ID { get { return GetBOP_NOTE_ID(); } set { SetBOP_NOTE_ID(value); } }


		public virtual BOP_NOTE_TYPE_CODE RefToSingle_BopNoteTypeCode { get; set; }
		public virtual BOP_NOTE RefToSingle_BopNote { get; set; }


		#endregion

		#region Constructors for table BOP_NOTE_TYPEGen
		public BOP_NOTE_TYPEGen()
		{
		}

		public BOP_NOTE_TYPEGen(System.Int64 BOP_NOTE_TYPE_ID, System.DateTime CREATED_TS, System.Int64 CREATED_BY, System.String BOP_NOTE_TYPE_CD, System.Int64 BOP_NOTE_ID) : this()
		{
			this._BOP_NOTE_TYPE_ID = BOP_NOTE_TYPE_ID;
			this._CREATED_TS = CREATED_TS;
			this._CREATED_BY = CREATED_BY;
			this._BOP_NOTE_TYPE_CD = BOP_NOTE_TYPE_CD;
			this._BOP_NOTE_ID = BOP_NOTE_ID;
		}
		#endregion

		#region Overrides
		public override void SetDirtyFields(bool value)
		{
			_BOP_NOTE_TYPE_IDFieldIsDirty = value;
			_CREATED_TSFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_BOP_NOTE_TYPE_CDFieldIsDirty = value;
			_BOP_NOTE_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _BOP_NOTE_TYPE_IDFieldIsDirty
				|| _CREATED_TSFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _BOP_NOTE_TYPE_CDFieldIsDirty
				|| _BOP_NOTE_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "BOP_NOTE_TYPE";
	}

		public override string PrimaryKeyFieldname()
		{
			return "TODO:FinishThis";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		// TODO: I don't know how EF wants us to handle references yet.
		//public override IEnumerable<string, string, string> ForeignKeys()
		//{
		//	return null;
		//}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.BOP_NOTE_TYPE")
				.Append(" { ")
				.Append("BOP_NOTE_TYPE_ID")
				.Append(" = ")
				.Append(this.BOP_NOTE_TYPE_ID.ToString())
				.Append("; ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("BOP_NOTE_TYPE_CD")
				.Append(" = ")
				.Append(this.BOP_NOTE_TYPE_CD.ToString())
				.Append("; ")
				.Append("BOP_NOTE_ID")
				.Append(" = ")
				.Append(this.BOP_NOTE_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}

		#endregion
	}

	//ReferencedBy -> CATS_BOP_OWNER.BOP_NOTE_TYPE.BOP_NOTE_TYPE_CD->CATS_BOP_OWNER.BOP_NOTE_TYPE_CODE.BOP_NOTE_TYPE_CD
	[Cats.Bop.Notes.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Notes.Data.Models.DBTable("CATS_BOP_OWNER", "BOP_NOTE_TYPE_CODE")]
	public partial class BOP_NOTE_TYPE_CODEGen : BOP_NOTE_TYPE_CODEBase
	{
		#region Property backing stores for table BOP_NOTE_TYPE_CODE
		protected System.Int64 _LOAD_ORDER;
		protected virtual System.Int64 GetLOAD_ORDER() { return _LOAD_ORDER; }
		protected virtual void SetLOAD_ORDER(System.Int64 value) { _LOAD_ORDER = value; _LOAD_ORDERFieldIsDirty = true; }
		protected virtual bool _LOAD_ORDERFieldIsDirty { get; set; }

		protected System.String _DESCRIPTION;
		protected virtual System.String GetDESCRIPTION() { return _DESCRIPTION; }
		protected virtual void SetDESCRIPTION(System.String value) { _DESCRIPTION = value; _DESCRIPTIONFieldIsDirty = true; }
		protected virtual bool _DESCRIPTIONFieldIsDirty { get; set; }

		protected System.String _BOP_NOTE_TYPE_CD;
		protected virtual System.String GetBOP_NOTE_TYPE_CD() { return _BOP_NOTE_TYPE_CD; }
		protected virtual void SetBOP_NOTE_TYPE_CD(System.String value) { _BOP_NOTE_TYPE_CD = value; _BOP_NOTE_TYPE_CDFieldIsDirty = true; }
		protected virtual bool _BOP_NOTE_TYPE_CDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table BOP_NOTE_TYPE_CODE

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE_CODE", "LOAD_ORDER", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LOAD_ORDER { get { return GetLOAD_ORDER(); } set { SetLOAD_ORDER(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE_CODE", "DESCRIPTION", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCRIPTION { get { return GetDESCRIPTION(); } set { SetDESCRIPTION(value); } }

		[Cats.Bop.Notes.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "BOP_NOTE_TYPE", "BOP_NOTE_TYPE_CD", "CATS_BOP_OWNER", "BOP_NOTE_TYPE_CODE", "BOP_NOTE_TYPE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "BOP_NOTE_TYPE_CODE", "BOP_NOTE_TYPE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String BOP_NOTE_TYPE_CD { get { return GetBOP_NOTE_TYPE_CD(); } set { SetBOP_NOTE_TYPE_CD(value); } }



		public virtual ICollection<BOP_NOTE_TYPE> RefFrom_BopNoteType_BopNoteTypeCd_To_BopNoteTypeCd { get; set; }

		#endregion

		#region Constructors for table BOP_NOTE_TYPE_CODEGen
		public BOP_NOTE_TYPE_CODEGen()
		{
		}

		public BOP_NOTE_TYPE_CODEGen(System.Int64 LOAD_ORDER, System.String DESCRIPTION, System.String BOP_NOTE_TYPE_CD) : this()
		{
			this._LOAD_ORDER = LOAD_ORDER;
			this._DESCRIPTION = DESCRIPTION;
			this._BOP_NOTE_TYPE_CD = BOP_NOTE_TYPE_CD;
		}
		#endregion

		#region Overrides
		public override void SetDirtyFields(bool value)
		{
			_LOAD_ORDERFieldIsDirty = value;
			_DESCRIPTIONFieldIsDirty = value;
			_BOP_NOTE_TYPE_CDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _LOAD_ORDERFieldIsDirty
				|| _DESCRIPTIONFieldIsDirty
				|| _BOP_NOTE_TYPE_CDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "BOP_NOTE_TYPE_CODE";
	}

		public override string PrimaryKeyFieldname()
		{
			return "TODO:FinishThis";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		// TODO: I don't know how EF wants us to handle references yet.
		//public override IEnumerable<string, string, string> ForeignKeys()
		//{
		//	return null;
		//}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.BOP_NOTE_TYPE_CODE")
				.Append(" { ")
				.Append("LOAD_ORDER")
				.Append(" = ")
				.Append(this.LOAD_ORDER.ToString())
				.Append("; ")
				.Append("DESCRIPTION")
				.Append(" = ")
				.Append(this.DESCRIPTION.ToString())
				.Append("; ")
				.Append("BOP_NOTE_TYPE_CD")
				.Append(" = ")
				.Append(this.BOP_NOTE_TYPE_CD.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}

		#endregion
	}

	[Cats.Bop.Notes.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Notes.Data.Models.DBTable("CATS_BOP_OWNER", "V_PARTIES2")]
	public partial class V_PARTIES2Gen : V_PARTIES2Base
	{
		#region Property backing stores for table V_PARTIES2
		protected System.Int16 _WRITE_OFF_IND;
		protected virtual System.Int16 GetWRITE_OFF_IND() { return _WRITE_OFF_IND; }
		protected virtual void SetWRITE_OFF_IND(System.Int16 value) { _WRITE_OFF_IND = value; _WRITE_OFF_INDFieldIsDirty = true; }
		protected virtual bool _WRITE_OFF_INDFieldIsDirty { get; set; }

		protected System.String _FIRST_NAME;
		protected virtual System.String GetFIRST_NAME() { return _FIRST_NAME; }
		protected virtual void SetFIRST_NAME(System.String value) { _FIRST_NAME = value; _FIRST_NAMEFieldIsDirty = true; }
		protected virtual bool _FIRST_NAMEFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.DateTime _BIRTH_DT;
		protected virtual System.DateTime GetBIRTH_DT() { return _BIRTH_DT; }
		protected virtual void SetBIRTH_DT(System.DateTime value) { _BIRTH_DT = value; _BIRTH_DTFieldIsDirty = true; }
		protected virtual bool _BIRTH_DTFieldIsDirty { get; set; }

		protected System.String _PID;
		protected virtual System.String GetPID() { return _PID; }
		protected virtual void SetPID(System.String value) { _PID = value; _PIDFieldIsDirty = true; }
		protected virtual bool _PIDFieldIsDirty { get; set; }

		protected System.String _SSN;
		protected virtual System.String GetSSN() { return _SSN; }
		protected virtual void SetSSN(System.String value) { _SSN = value; _SSNFieldIsDirty = true; }
		protected virtual bool _SSNFieldIsDirty { get; set; }

		protected System.String _DRIVERS_LICENSE_NBR;
		protected virtual System.String GetDRIVERS_LICENSE_NBR() { return _DRIVERS_LICENSE_NBR; }
		protected virtual void SetDRIVERS_LICENSE_NBR(System.String value) { _DRIVERS_LICENSE_NBR = value; _DRIVERS_LICENSE_NBRFieldIsDirty = true; }
		protected virtual bool _DRIVERS_LICENSE_NBRFieldIsDirty { get; set; }

		protected System.Int64? _CLI_ID;
		protected virtual System.Int64? GetCLI_ID() { return _CLI_ID; }
		protected virtual void SetCLI_ID(System.Int64? value) { _CLI_ID = value; _CLI_IDFieldIsDirty = true; }
		protected virtual bool _CLI_IDFieldIsDirty { get; set; }

		protected System.String _MOTHERS_MAIDEN_NAME;
		protected virtual System.String GetMOTHERS_MAIDEN_NAME() { return _MOTHERS_MAIDEN_NAME; }
		protected virtual void SetMOTHERS_MAIDEN_NAME(System.String value) { _MOTHERS_MAIDEN_NAME = value; _MOTHERS_MAIDEN_NAMEFieldIsDirty = true; }
		protected virtual bool _MOTHERS_MAIDEN_NAMEFieldIsDirty { get; set; }

		protected System.String _EMAIL;
		protected virtual System.String GetEMAIL() { return _EMAIL; }
		protected virtual void SetEMAIL(System.String value) { _EMAIL = value; _EMAILFieldIsDirty = true; }
		protected virtual bool _EMAILFieldIsDirty { get; set; }

		protected System.String _MIDDLE_NAME;
		protected virtual System.String GetMIDDLE_NAME() { return _MIDDLE_NAME; }
		protected virtual void SetMIDDLE_NAME(System.String value) { _MIDDLE_NAME = value; _MIDDLE_NAMEFieldIsDirty = true; }
		protected virtual bool _MIDDLE_NAMEFieldIsDirty { get; set; }

		protected System.String _BAD_EMAIL_FLAG;
		protected virtual System.String GetBAD_EMAIL_FLAG() { return _BAD_EMAIL_FLAG; }
		protected virtual void SetBAD_EMAIL_FLAG(System.String value) { _BAD_EMAIL_FLAG = value; _BAD_EMAIL_FLAGFieldIsDirty = true; }
		protected virtual bool _BAD_EMAIL_FLAGFieldIsDirty { get; set; }

		protected System.String _LAST_NAME;
		protected virtual System.String GetLAST_NAME() { return _LAST_NAME; }
		protected virtual void SetLAST_NAME(System.String value) { _LAST_NAME = value; _LAST_NAMEFieldIsDirty = true; }
		protected virtual bool _LAST_NAMEFieldIsDirty { get; set; }

		#endregion

		#region Properties for table V_PARTIES2

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "WRITE_OFF_IND", "NUMBER", typeof(System.Int16))]
		public virtual System.Int16 WRITE_OFF_IND { get { return GetWRITE_OFF_IND(); } set { SetWRITE_OFF_IND(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(100)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "FIRST_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String FIRST_NAME { get { return GetFIRST_NAME(); } set { SetFIRST_NAME(value); } }

		[Cats.Bop.Notes.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "BIRTH_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime BIRTH_DT { get { return GetBIRTH_DT(); } set { SetBIRTH_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "PID", "VARCHAR2", typeof(System.String))]
		public virtual System.String PID { get { return GetPID(); } set { SetPID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "SSN", "VARCHAR2", typeof(System.String))]
		public virtual System.String SSN { get { return GetSSN(); } set { SetSSN(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "DRIVERS_LICENSE_NBR", "VARCHAR2", typeof(System.String))]
		public virtual System.String DRIVERS_LICENSE_NBR { get { return GetDRIVERS_LICENSE_NBR(); } set { SetDRIVERS_LICENSE_NBR(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "CLI_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? CLI_ID { get { return GetCLI_ID(); } set { SetCLI_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(80)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "MOTHERS_MAIDEN_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String MOTHERS_MAIDEN_NAME { get { return GetMOTHERS_MAIDEN_NAME(); } set { SetMOTHERS_MAIDEN_NAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(240)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "EMAIL", "VARCHAR2", typeof(System.String))]
		public virtual System.String EMAIL { get { return GetEMAIL(); } set { SetEMAIL(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "MIDDLE_NAME", "CHAR", typeof(System.String))]
		public virtual System.String MIDDLE_NAME { get { return GetMIDDLE_NAME(); } set { SetMIDDLE_NAME(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "BAD_EMAIL_FLAG", "CHAR", typeof(System.String))]
		public virtual System.String BAD_EMAIL_FLAG { get { return GetBAD_EMAIL_FLAG(); } set { SetBAD_EMAIL_FLAG(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(120)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_BOP_OWNER", "V_PARTIES2", "LAST_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String LAST_NAME { get { return GetLAST_NAME(); } set { SetLAST_NAME(value); } }




		#endregion

		#region Constructors for table V_PARTIES2Gen
		public V_PARTIES2Gen()
		{
		}

		public V_PARTIES2Gen(System.Int16 WRITE_OFF_IND, System.String FIRST_NAME, System.Int64 PRTY_ID, System.DateTime BIRTH_DT, System.String PID, System.String SSN, System.String DRIVERS_LICENSE_NBR, System.Int64? CLI_ID, System.String MOTHERS_MAIDEN_NAME, System.String EMAIL, System.String MIDDLE_NAME, System.String BAD_EMAIL_FLAG, System.String LAST_NAME) : this()
		{
			this._WRITE_OFF_IND = WRITE_OFF_IND;
			this._FIRST_NAME = FIRST_NAME;
			this._PRTY_ID = PRTY_ID;
			this._BIRTH_DT = BIRTH_DT;
			this._PID = PID;
			this._SSN = SSN;
			this._DRIVERS_LICENSE_NBR = DRIVERS_LICENSE_NBR;
			this._CLI_ID = CLI_ID;
			this._MOTHERS_MAIDEN_NAME = MOTHERS_MAIDEN_NAME;
			this._EMAIL = EMAIL;
			this._MIDDLE_NAME = MIDDLE_NAME;
			this._BAD_EMAIL_FLAG = BAD_EMAIL_FLAG;
			this._LAST_NAME = LAST_NAME;
		}
		#endregion

		#region Overrides
		public override void SetDirtyFields(bool value)
		{
			_WRITE_OFF_INDFieldIsDirty = value;
			_FIRST_NAMEFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_BIRTH_DTFieldIsDirty = value;
			_PIDFieldIsDirty = value;
			_SSNFieldIsDirty = value;
			_DRIVERS_LICENSE_NBRFieldIsDirty = value;
			_CLI_IDFieldIsDirty = value;
			_MOTHERS_MAIDEN_NAMEFieldIsDirty = value;
			_EMAILFieldIsDirty = value;
			_MIDDLE_NAMEFieldIsDirty = value;
			_BAD_EMAIL_FLAGFieldIsDirty = value;
			_LAST_NAMEFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _WRITE_OFF_INDFieldIsDirty
				|| _FIRST_NAMEFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _BIRTH_DTFieldIsDirty
				|| _PIDFieldIsDirty
				|| _SSNFieldIsDirty
				|| _DRIVERS_LICENSE_NBRFieldIsDirty
				|| _CLI_IDFieldIsDirty
				|| _MOTHERS_MAIDEN_NAMEFieldIsDirty
				|| _EMAILFieldIsDirty
				|| _MIDDLE_NAMEFieldIsDirty
				|| _BAD_EMAIL_FLAGFieldIsDirty
				|| _LAST_NAMEFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "V_PARTIES2";
	}

		public override string PrimaryKeyFieldname()
		{
			return "TODO:FinishThis";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		// TODO: I don't know how EF wants us to handle references yet.
		//public override IEnumerable<string, string, string> ForeignKeys()
		//{
		//	return null;
		//}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.V_PARTIES2")
				.Append(" { ")
				.Append("WRITE_OFF_IND")
				.Append(" = ")
				.Append(this.WRITE_OFF_IND.ToString())
				.Append("; ")
				.Append("FIRST_NAME")
				.Append(" = ")
				.Append(this.FIRST_NAME.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("BIRTH_DT")
				.Append(" = ")
				.Append(this.BIRTH_DT.ToString())
				.Append("; ")
				.Append("PID")
				.Append(" = ")
				.Append(this.PID.ToString())
				.Append("; ")
				.Append("SSN")
				.Append(" = ")
				.Append(this.SSN.ToString())
				.Append("; ")
				.Append("DRIVERS_LICENSE_NBR")
				.Append(" = ")
				.Append(this.DRIVERS_LICENSE_NBR.ToString())
				.Append("; ")
				.Append("CLI_ID")
				.Append(" = ")
				.Append(this.CLI_ID.ToString())
				.Append("; ")
				.Append("MOTHERS_MAIDEN_NAME")
				.Append(" = ")
				.Append(this.MOTHERS_MAIDEN_NAME.ToString())
				.Append("; ")
				.Append("EMAIL")
				.Append(" = ")
				.Append(this.EMAIL.ToString())
				.Append("; ")
				.Append("MIDDLE_NAME")
				.Append(" = ")
				.Append(this.MIDDLE_NAME.ToString())
				.Append("; ")
				.Append("BAD_EMAIL_FLAG")
				.Append(" = ")
				.Append(this.BAD_EMAIL_FLAG.ToString())
				.Append("; ")
				.Append("LAST_NAME")
				.Append(" = ")
				.Append(this.LAST_NAME.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}

		#endregion
	}

	[Cats.Bop.Notes.Data.Models.DBSchema("CATS_OWNER")]
	[Cats.Bop.Notes.Data.Models.DBTable("CATS_OWNER", "EMPLOYEE")]
	public partial class EMPLOYEEGen : EMPLOYEEBase
	{
		#region Property backing stores for table EMPLOYEE
		protected System.String _ADDR2;
		protected virtual System.String GetADDR2() { return _ADDR2; }
		protected virtual void SetADDR2(System.String value) { _ADDR2 = value; _ADDR2FieldIsDirty = true; }
		protected virtual bool _ADDR2FieldIsDirty { get; set; }

		protected System.String _LASTNAME;
		protected virtual System.String GetLASTNAME() { return _LASTNAME; }
		protected virtual void SetLASTNAME(System.String value) { _LASTNAME = value; _LASTNAMEFieldIsDirty = true; }
		protected virtual bool _LASTNAMEFieldIsDirty { get; set; }

		protected System.Int64 _EMPLID;
		protected virtual System.Int64 GetEMPLID() { return _EMPLID; }
		protected virtual void SetEMPLID(System.Int64 value) { _EMPLID = value; _EMPLIDFieldIsDirty = true; }
		protected virtual bool _EMPLIDFieldIsDirty { get; set; }

		protected System.String _PRONOUN;
		protected virtual System.String GetPRONOUN() { return _PRONOUN; }
		protected virtual void SetPRONOUN(System.String value) { _PRONOUN = value; _PRONOUNFieldIsDirty = true; }
		protected virtual bool _PRONOUNFieldIsDirty { get; set; }

		protected System.Int16? _LOCKED;
		protected virtual System.Int16? GetLOCKED() { return _LOCKED; }
		protected virtual void SetLOCKED(System.Int16? value) { _LOCKED = value; _LOCKEDFieldIsDirty = true; }
		protected virtual bool _LOCKEDFieldIsDirty { get; set; }

		protected System.Int16? _ATTEMPT_COUNT;
		protected virtual System.Int16? GetATTEMPT_COUNT() { return _ATTEMPT_COUNT; }
		protected virtual void SetATTEMPT_COUNT(System.Int16? value) { _ATTEMPT_COUNT = value; _ATTEMPT_COUNTFieldIsDirty = true; }
		protected virtual bool _ATTEMPT_COUNTFieldIsDirty { get; set; }

		protected System.Int16 _ACTIVE_EMP;
		protected virtual System.Int16 GetACTIVE_EMP() { return _ACTIVE_EMP; }
		protected virtual void SetACTIVE_EMP(System.Int16 value) { _ACTIVE_EMP = value; _ACTIVE_EMPFieldIsDirty = true; }
		protected virtual bool _ACTIVE_EMPFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_DT;
		protected virtual System.DateTime? GetMODIFIED_DT() { return _MODIFIED_DT; }
		protected virtual void SetMODIFIED_DT(System.DateTime? value) { _MODIFIED_DT = value; _MODIFIED_DTFieldIsDirty = true; }
		protected virtual bool _MODIFIED_DTFieldIsDirty { get; set; }

		protected System.String _UNIT;
		protected virtual System.String GetUNIT() { return _UNIT; }
		protected virtual void SetUNIT(System.String value) { _UNIT = value; _UNITFieldIsDirty = true; }
		protected virtual bool _UNITFieldIsDirty { get; set; }

		protected System.String _SUPERVISOR;
		protected virtual System.String GetSUPERVISOR() { return _SUPERVISOR; }
		protected virtual void SetSUPERVISOR(System.String value) { _SUPERVISOR = value; _SUPERVISORFieldIsDirty = true; }
		protected virtual bool _SUPERVISORFieldIsDirty { get; set; }

		protected System.String _MF_LOGIN;
		protected virtual System.String GetMF_LOGIN() { return _MF_LOGIN; }
		protected virtual void SetMF_LOGIN(System.String value) { _MF_LOGIN = value; _MF_LOGINFieldIsDirty = true; }
		protected virtual bool _MF_LOGINFieldIsDirty { get; set; }

		protected System.String _JOB;
		protected virtual System.String GetJOB() { return _JOB; }
		protected virtual void SetJOB(System.String value) { _JOB = value; _JOBFieldIsDirty = true; }
		protected virtual bool _JOBFieldIsDirty { get; set; }

		protected System.String _PHONE;
		protected virtual System.String GetPHONE() { return _PHONE; }
		protected virtual void SetPHONE(System.String value) { _PHONE = value; _PHONEFieldIsDirty = true; }
		protected virtual bool _PHONEFieldIsDirty { get; set; }

		protected System.String _ZIP;
		protected virtual System.String GetZIP() { return _ZIP; }
		protected virtual void SetZIP(System.String value) { _ZIP = value; _ZIPFieldIsDirty = true; }
		protected virtual bool _ZIPFieldIsDirty { get; set; }

		protected System.String _ADDR1;
		protected virtual System.String GetADDR1() { return _ADDR1; }
		protected virtual void SetADDR1(System.String value) { _ADDR1 = value; _ADDR1FieldIsDirty = true; }
		protected virtual bool _ADDR1FieldIsDirty { get; set; }

		protected System.String _FIRSTNAME;
		protected virtual System.String GetFIRSTNAME() { return _FIRSTNAME; }
		protected virtual void SetFIRSTNAME(System.String value) { _FIRSTNAME = value; _FIRSTNAMEFieldIsDirty = true; }
		protected virtual bool _FIRSTNAMEFieldIsDirty { get; set; }

		protected System.String _PRONOUN_POSS;
		protected virtual System.String GetPRONOUN_POSS() { return _PRONOUN_POSS; }
		protected virtual void SetPRONOUN_POSS(System.String value) { _PRONOUN_POSS = value; _PRONOUN_POSSFieldIsDirty = true; }
		protected virtual bool _PRONOUN_POSSFieldIsDirty { get; set; }

		protected System.Int64? _UT_STATE_BAR_NUMBER;
		protected virtual System.Int64? GetUT_STATE_BAR_NUMBER() { return _UT_STATE_BAR_NUMBER; }
		protected virtual void SetUT_STATE_BAR_NUMBER(System.Int64? value) { _UT_STATE_BAR_NUMBER = value; _UT_STATE_BAR_NUMBERFieldIsDirty = true; }
		protected virtual bool _UT_STATE_BAR_NUMBERFieldIsDirty { get; set; }

		protected System.String _TITLE;
		protected virtual System.String GetTITLE() { return _TITLE; }
		protected virtual void SetTITLE(System.String value) { _TITLE = value; _TITLEFieldIsDirty = true; }
		protected virtual bool _TITLEFieldIsDirty { get; set; }

		protected System.String _COMMENTS;
		protected virtual System.String GetCOMMENTS() { return _COMMENTS; }
		protected virtual void SetCOMMENTS(System.String value) { _COMMENTS = value; _COMMENTSFieldIsDirty = true; }
		protected virtual bool _COMMENTSFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_DT;
		protected virtual System.DateTime GetCREATED_DT() { return _CREATED_DT; }
		protected virtual void SetCREATED_DT(System.DateTime value) { _CREATED_DT = value; _CREATED_DTFieldIsDirty = true; }
		protected virtual bool _CREATED_DTFieldIsDirty { get; set; }

		protected System.String _USERID;
		protected virtual System.String GetUSERID() { return _USERID; }
		protected virtual void SetUSERID(System.String value) { _USERID = value; _USERIDFieldIsDirty = true; }
		protected virtual bool _USERIDFieldIsDirty { get; set; }

		protected System.String _MACHINETYPE;
		protected virtual System.String GetMACHINETYPE() { return _MACHINETYPE; }
		protected virtual void SetMACHINETYPE(System.String value) { _MACHINETYPE = value; _MACHINETYPEFieldIsDirty = true; }
		protected virtual bool _MACHINETYPEFieldIsDirty { get; set; }

		protected System.String _EMAILADDR;
		protected virtual System.String GetEMAILADDR() { return _EMAILADDR; }
		protected virtual void SetEMAILADDR(System.String value) { _EMAILADDR = value; _EMAILADDRFieldIsDirty = true; }
		protected virtual bool _EMAILADDRFieldIsDirty { get; set; }

		protected System.String _FAX;
		protected virtual System.String GetFAX() { return _FAX; }
		protected virtual void SetFAX(System.String value) { _FAX = value; _FAXFieldIsDirty = true; }
		protected virtual bool _FAXFieldIsDirty { get; set; }

		protected System.String _DEPT;
		protected virtual System.String GetDEPT() { return _DEPT; }
		protected virtual void SetDEPT(System.String value) { _DEPT = value; _DEPTFieldIsDirty = true; }
		protected virtual bool _DEPTFieldIsDirty { get; set; }

		protected System.String _STATE;
		protected virtual System.String GetSTATE() { return _STATE; }
		protected virtual void SetSTATE(System.String value) { _STATE = value; _STATEFieldIsDirty = true; }
		protected virtual bool _STATEFieldIsDirty { get; set; }

		protected System.String _CITY;
		protected virtual System.String GetCITY() { return _CITY; }
		protected virtual void SetCITY(System.String value) { _CITY = value; _CITYFieldIsDirty = true; }
		protected virtual bool _CITYFieldIsDirty { get; set; }

		#endregion

		#region Properties for table EMPLOYEE

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(35)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "ADDR2", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDR2 { get { return GetADDR2(); } set { SetADDR2(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(23)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "LASTNAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String LASTNAME { get { return GetLASTNAME(); } set { SetLASTNAME(value); } }

		[Cats.Bop.Notes.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "EMPLID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 EMPLID { get { return GetEMPLID(); } set { SetEMPLID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "PRONOUN", "VARCHAR2", typeof(System.String))]
		public virtual System.String PRONOUN { get { return GetPRONOUN(); } set { SetPRONOUN(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "LOCKED", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? LOCKED { get { return GetLOCKED(); } set { SetLOCKED(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "ATTEMPT_COUNT", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? ATTEMPT_COUNT { get { return GetATTEMPT_COUNT(); } set { SetATTEMPT_COUNT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "ACTIVE_EMP", "NUMBER", typeof(System.Int16))]
		public virtual System.Int16 ACTIVE_EMP { get { return GetACTIVE_EMP(); } set { SetACTIVE_EMP(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "MODIFIED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_DT { get { return GetMODIFIED_DT(); } set { SetMODIFIED_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "UNIT", "VARCHAR2", typeof(System.String))]
		public virtual System.String UNIT { get { return GetUNIT(); } set { SetUNIT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "SUPERVISOR", "VARCHAR2", typeof(System.String))]
		public virtual System.String SUPERVISOR { get { return GetSUPERVISOR(); } set { SetSUPERVISOR(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(5)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "MF_LOGIN", "VARCHAR2", typeof(System.String))]
		public virtual System.String MF_LOGIN { get { return GetMF_LOGIN(); } set { SetMF_LOGIN(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(3)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "JOB", "VARCHAR2", typeof(System.String))]
		public virtual System.String JOB { get { return GetJOB(); } set { SetJOB(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "PHONE", "VARCHAR2", typeof(System.String))]
		public virtual System.String PHONE { get { return GetPHONE(); } set { SetPHONE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "ZIP", "VARCHAR2", typeof(System.String))]
		public virtual System.String ZIP { get { return GetZIP(); } set { SetZIP(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(35)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "ADDR1", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDR1 { get { return GetADDR1(); } set { SetADDR1(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(13)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "FIRSTNAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String FIRSTNAME { get { return GetFIRSTNAME(); } set { SetFIRSTNAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "PRONOUN_POSS", "VARCHAR2", typeof(System.String))]
		public virtual System.String PRONOUN_POSS { get { return GetPRONOUN_POSS(); } set { SetPRONOUN_POSS(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "UT_STATE_BAR_NUMBER", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? UT_STATE_BAR_NUMBER { get { return GetUT_STATE_BAR_NUMBER(); } set { SetUT_STATE_BAR_NUMBER(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(40)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "TITLE", "VARCHAR2", typeof(System.String))]
		public virtual System.String TITLE { get { return GetTITLE(); } set { SetTITLE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(4000)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "COMMENTS", "VARCHAR2", typeof(System.String))]
		public virtual System.String COMMENTS { get { return GetCOMMENTS(); } set { SetCOMMENTS(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "CREATED_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_DT { get { return GetCREATED_DT(); } set { SetCREATED_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "USERID", "VARCHAR2", typeof(System.String))]
		public virtual System.String USERID { get { return GetUSERID(); } set { SetUSERID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "MACHINETYPE", "VARCHAR2", typeof(System.String))]
		public virtual System.String MACHINETYPE { get { return GetMACHINETYPE(); } set { SetMACHINETYPE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(40)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "EMAILADDR", "VARCHAR2", typeof(System.String))]
		public virtual System.String EMAILADDR { get { return GetEMAILADDR(); } set { SetEMAILADDR(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "FAX", "VARCHAR2", typeof(System.String))]
		public virtual System.String FAX { get { return GetFAX(); } set { SetFAX(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(25)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "DEPT", "VARCHAR2", typeof(System.String))]
		public virtual System.String DEPT { get { return GetDEPT(); } set { SetDEPT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "STATE", "VARCHAR2", typeof(System.String))]
		public virtual System.String STATE { get { return GetSTATE(); } set { SetSTATE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(19)]
		[Cats.Bop.Notes.Data.Models.Column("CATS_OWNER", "EMPLOYEE", "CITY", "VARCHAR2", typeof(System.String))]
		public virtual System.String CITY { get { return GetCITY(); } set { SetCITY(value); } }




		#endregion

		#region Constructors for table EMPLOYEEGen
		public EMPLOYEEGen()
		{
		}

		public EMPLOYEEGen(System.String ADDR2, System.String LASTNAME, System.Int64 EMPLID, System.String PRONOUN, System.Int16? LOCKED, System.Int16? ATTEMPT_COUNT, System.Int16 ACTIVE_EMP, System.Int64? MODIFIED_BY, System.DateTime? MODIFIED_DT, System.String UNIT, System.String SUPERVISOR, System.String MF_LOGIN, System.String JOB, System.String PHONE, System.String ZIP, System.String ADDR1, System.String FIRSTNAME, System.String PRONOUN_POSS, System.Int64? UT_STATE_BAR_NUMBER, System.String TITLE, System.String COMMENTS, System.Int64 CREATED_BY, System.DateTime CREATED_DT, System.String USERID, System.String MACHINETYPE, System.String EMAILADDR, System.String FAX, System.String DEPT, System.String STATE, System.String CITY) : this()
		{
			this._ADDR2 = ADDR2;
			this._LASTNAME = LASTNAME;
			this._EMPLID = EMPLID;
			this._PRONOUN = PRONOUN;
			this._LOCKED = LOCKED;
			this._ATTEMPT_COUNT = ATTEMPT_COUNT;
			this._ACTIVE_EMP = ACTIVE_EMP;
			this._MODIFIED_BY = MODIFIED_BY;
			this._MODIFIED_DT = MODIFIED_DT;
			this._UNIT = UNIT;
			this._SUPERVISOR = SUPERVISOR;
			this._MF_LOGIN = MF_LOGIN;
			this._JOB = JOB;
			this._PHONE = PHONE;
			this._ZIP = ZIP;
			this._ADDR1 = ADDR1;
			this._FIRSTNAME = FIRSTNAME;
			this._PRONOUN_POSS = PRONOUN_POSS;
			this._UT_STATE_BAR_NUMBER = UT_STATE_BAR_NUMBER;
			this._TITLE = TITLE;
			this._COMMENTS = COMMENTS;
			this._CREATED_BY = CREATED_BY;
			this._CREATED_DT = CREATED_DT;
			this._USERID = USERID;
			this._MACHINETYPE = MACHINETYPE;
			this._EMAILADDR = EMAILADDR;
			this._FAX = FAX;
			this._DEPT = DEPT;
			this._STATE = STATE;
			this._CITY = CITY;
		}
		#endregion

		#region Overrides
		public override void SetDirtyFields(bool value)
		{
			_ADDR2FieldIsDirty = value;
			_LASTNAMEFieldIsDirty = value;
			_EMPLIDFieldIsDirty = value;
			_PRONOUNFieldIsDirty = value;
			_LOCKEDFieldIsDirty = value;
			_ATTEMPT_COUNTFieldIsDirty = value;
			_ACTIVE_EMPFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_MODIFIED_DTFieldIsDirty = value;
			_UNITFieldIsDirty = value;
			_SUPERVISORFieldIsDirty = value;
			_MF_LOGINFieldIsDirty = value;
			_JOBFieldIsDirty = value;
			_PHONEFieldIsDirty = value;
			_ZIPFieldIsDirty = value;
			_ADDR1FieldIsDirty = value;
			_FIRSTNAMEFieldIsDirty = value;
			_PRONOUN_POSSFieldIsDirty = value;
			_UT_STATE_BAR_NUMBERFieldIsDirty = value;
			_TITLEFieldIsDirty = value;
			_COMMENTSFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_CREATED_DTFieldIsDirty = value;
			_USERIDFieldIsDirty = value;
			_MACHINETYPEFieldIsDirty = value;
			_EMAILADDRFieldIsDirty = value;
			_FAXFieldIsDirty = value;
			_DEPTFieldIsDirty = value;
			_STATEFieldIsDirty = value;
			_CITYFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _ADDR2FieldIsDirty
				|| _LASTNAMEFieldIsDirty
				|| _EMPLIDFieldIsDirty
				|| _PRONOUNFieldIsDirty
				|| _LOCKEDFieldIsDirty
				|| _ATTEMPT_COUNTFieldIsDirty
				|| _ACTIVE_EMPFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _MODIFIED_DTFieldIsDirty
				|| _UNITFieldIsDirty
				|| _SUPERVISORFieldIsDirty
				|| _MF_LOGINFieldIsDirty
				|| _JOBFieldIsDirty
				|| _PHONEFieldIsDirty
				|| _ZIPFieldIsDirty
				|| _ADDR1FieldIsDirty
				|| _FIRSTNAMEFieldIsDirty
				|| _PRONOUN_POSSFieldIsDirty
				|| _UT_STATE_BAR_NUMBERFieldIsDirty
				|| _TITLEFieldIsDirty
				|| _COMMENTSFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _CREATED_DTFieldIsDirty
				|| _USERIDFieldIsDirty
				|| _MACHINETYPEFieldIsDirty
				|| _EMAILADDRFieldIsDirty
				|| _FAXFieldIsDirty
				|| _DEPTFieldIsDirty
				|| _STATEFieldIsDirty
				|| _CITYFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_OWNER";
		}

		public override string TableName()
		{
			return "EMPLOYEE";
	}

		public override string PrimaryKeyFieldname()
		{
			return "TODO:FinishThis";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		// TODO: I don't know how EF wants us to handle references yet.
		//public override IEnumerable<string, string, string> ForeignKeys()
		//{
		//	return null;
		//}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_OWNER.EMPLOYEE")
				.Append(" { ")
				.Append("ADDR2")
				.Append(" = ")
				.Append(this.ADDR2.ToString())
				.Append("; ")
				.Append("LASTNAME")
				.Append(" = ")
				.Append(this.LASTNAME.ToString())
				.Append("; ")
				.Append("EMPLID")
				.Append(" = ")
				.Append(this.EMPLID.ToString())
				.Append("; ")
				.Append("PRONOUN")
				.Append(" = ")
				.Append(this.PRONOUN.ToString())
				.Append("; ")
				.Append("LOCKED")
				.Append(" = ")
				.Append(this.LOCKED.ToString())
				.Append("; ")
				.Append("ATTEMPT_COUNT")
				.Append(" = ")
				.Append(this.ATTEMPT_COUNT.ToString())
				.Append("; ")
				.Append("ACTIVE_EMP")
				.Append(" = ")
				.Append(this.ACTIVE_EMP.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("MODIFIED_DT")
				.Append(" = ")
				.Append(this.MODIFIED_DT.ToString())
				.Append("; ")
				.Append("UNIT")
				.Append(" = ")
				.Append(this.UNIT.ToString())
				.Append("; ")
				.Append("SUPERVISOR")
				.Append(" = ")
				.Append(this.SUPERVISOR.ToString())
				.Append("; ")
				.Append("MF_LOGIN")
				.Append(" = ")
				.Append(this.MF_LOGIN.ToString())
				.Append("; ")
				.Append("JOB")
				.Append(" = ")
				.Append(this.JOB.ToString())
				.Append("; ")
				.Append("PHONE")
				.Append(" = ")
				.Append(this.PHONE.ToString())
				.Append("; ")
				.Append("ZIP")
				.Append(" = ")
				.Append(this.ZIP.ToString())
				.Append("; ")
				.Append("ADDR1")
				.Append(" = ")
				.Append(this.ADDR1.ToString())
				.Append("; ")
				.Append("FIRSTNAME")
				.Append(" = ")
				.Append(this.FIRSTNAME.ToString())
				.Append("; ")
				.Append("PRONOUN_POSS")
				.Append(" = ")
				.Append(this.PRONOUN_POSS.ToString())
				.Append("; ")
				.Append("UT_STATE_BAR_NUMBER")
				.Append(" = ")
				.Append(this.UT_STATE_BAR_NUMBER.ToString())
				.Append("; ")
				.Append("TITLE")
				.Append(" = ")
				.Append(this.TITLE.ToString())
				.Append("; ")
				.Append("COMMENTS")
				.Append(" = ")
				.Append(this.COMMENTS.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("CREATED_DT")
				.Append(" = ")
				.Append(this.CREATED_DT.ToString())
				.Append("; ")
				.Append("USERID")
				.Append(" = ")
				.Append(this.USERID.ToString())
				.Append("; ")
				.Append("MACHINETYPE")
				.Append(" = ")
				.Append(this.MACHINETYPE.ToString())
				.Append("; ")
				.Append("EMAILADDR")
				.Append(" = ")
				.Append(this.EMAILADDR.ToString())
				.Append("; ")
				.Append("FAX")
				.Append(" = ")
				.Append(this.FAX.ToString())
				.Append("; ")
				.Append("DEPT")
				.Append(" = ")
				.Append(this.DEPT.ToString())
				.Append("; ")
				.Append("STATE")
				.Append(" = ")
				.Append(this.STATE.ToString())
				.Append("; ")
				.Append("CITY")
				.Append(" = ")
				.Append(this.CITY.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}

		#endregion
	}
}

