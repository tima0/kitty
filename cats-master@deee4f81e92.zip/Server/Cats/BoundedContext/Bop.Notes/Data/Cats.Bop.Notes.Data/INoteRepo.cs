using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Notes.Data.Models;

namespace Cats.Bop.Notes.Data.Interfaces
{
	public interface INoteRepository
	{
		IEnumerable<NotesModel> GetNotes(int count);
		IEnumerable<NotesModel> GetNotesByPID(int prtyId, int count);

	}
}
