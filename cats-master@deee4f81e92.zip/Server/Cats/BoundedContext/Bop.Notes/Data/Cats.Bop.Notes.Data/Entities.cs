using System;
using System.Collections.Generic;
using System.Text;

namespace Cats.Bop.Notes.Data.Models
{
	public class BOP_NOTE : BOP_NOTEGen
	{
	}
	public class BOP_NOTE_SOURCE_CODE : BOP_NOTE_SOURCE_CODEGen
	{
	}
	public class BOP_NOTE_TYPE : BOP_NOTE_TYPEGen
	{
	}
	public class BOP_NOTE_TYPE_CODE : BOP_NOTE_TYPE_CODEGen
	{
	}
	public class V_PARTIES2 : V_PARTIES2Gen
	{
	}
	public class EMPLOYEE : EMPLOYEEGen
	{
	}
}