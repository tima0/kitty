using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Notes.Data.Models;

namespace Cats.Bop.Notes.Data.Internals
{
	public static class ContextDBInitializer
	{
		public static void DisableCodeFirstMigrations()
		{
			// Disable code-first migrations.  This should be called from the host project's startup code.
			// See this page:  https://www.dotnetexpertguide.com/2012/10/aspnet-preapplicationstartmethod-example.html
			Database.SetInitializer<Cats.Bop.Notes.Data.Internals.DbContext>(null);
		}
	}

	public abstract partial class DbContextGen : System.Data.Entity.DbContext
	{
		public DbContextGen(string nameOrConnectionString) : base(nameOrConnectionString)
		{
			// Do not remove these lines!
			// These look like they do nothing, but it creates the only code reference to the Oracle assembly.
			// Without it, the dependency is deemed unnecessary by the linker and is not deployed to the web bin folder.
			var refFix1 = typeof(Oracle.ManagedDataAccess.Client.OracleConnection);
			System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(refFix1.AssemblyQualifiedName));
			var refFix2 = typeof(Oracle.ManagedDataAccess.EntityFramework.OracleConnectionFactory);
			System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(refFix2.AssemblyQualifiedName));
		}

		public abstract string GetDefaultSchemaName();

		public DbSet<BOP_NOTE> BopNote { get; set; }
		public DbSet<BOP_NOTE_SOURCE_CODE> BopNoteSourceCode { get; set; }
		public DbSet<BOP_NOTE_TYPE> BopNoteType { get; set; }
		public DbSet<BOP_NOTE_TYPE_CODE> BopNoteTypeCode { get; set; }
		public DbSet<V_PARTIES2> VParties2 { get; set; }
		public DbSet<EMPLOYEE> Employee { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.HasDefaultSchema(GetDefaultSchemaName());

			modelBuilder.Configurations.Add(new DbSetConfig_BopNote());
			modelBuilder.Configurations.Add(new DbSetConfig_BopNoteSourceCode());
			modelBuilder.Configurations.Add(new DbSetConfig_BopNoteType());
			modelBuilder.Configurations.Add(new DbSetConfig_BopNoteTypeCode());
			modelBuilder.Configurations.Add(new DbSetConfig_VParties2());
			modelBuilder.Configurations.Add(new DbSetConfig_Employee());
		}
	}

	public partial class DbSetConfigBase_BopNote : EntityTypeConfiguration<BOP_NOTE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
				this.HasKey(t => t.BOP_NOTE_ID);
				this.Property(p => p.IMAGEID)
					.HasColumnName("IMAGEID")
					.HasMaxLength(20)
					.IsOptional();
				this.Property(p => p.MODIFIED_BY)
					.HasColumnName("MODIFIED_BY")
					.IsOptional();
				this.Property(p => p.MODIFIED_BY).IsOptional();
				this.Property(p => p.CREATED_BY)
					.HasColumnName("CREATED_BY")
					.IsRequired();
				this.Property(p => p.CREATED_BY).IsRequired();
				this.Property(p => p.DESCR)
					.HasColumnName("DESCR")
					.HasMaxLength(50)
					.IsOptional();
				this.Property(p => p.CONTACT_EXT)
					.HasColumnName("CONTACT_EXT")
					.HasMaxLength(6)
					.IsOptional();
				this.Property(p => p.CONTACT_TITLE)
					.HasColumnName("CONTACT_TITLE")
					.HasMaxLength(50)
					.IsOptional();
				this.Property(p => p.EMPLID)
					.HasColumnName("EMPLID")
					.IsRequired();
				this.Property(p => p.EMPLID).IsRequired();
				this.Property(p => p.PRTY_ID)
					.HasColumnName("PRTY_ID")
					.IsRequired();
				this.Property(p => p.PRTY_ID).IsRequired();
				this.Property(p => p.BOP_PROSECUTION_ID)
					.HasColumnName("BOP_PROSECUTION_ID")
					.IsOptional();
				this.Property(p => p.BOP_PROSECUTION_ID).IsOptional();
				this.Property(p => p.BOP_NOTE_SOURCE_CD)
					.HasColumnName("BOP_NOTE_SOURCE_CD")
					.HasMaxLength(10)
					.IsRequired();
				this.Property(p => p.BOP_NOTE_ID)
					.HasColumnName("BOP_NOTE_ID")
					.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
					.IsRequired();
				this.Property(p => p.BOP_NOTE_ID).IsRequired();
				this.Property(p => p.LETTERS_LETTER_ID)
					.HasColumnName("LETTERS_LETTER_ID")
					.IsOptional();
				this.Property(p => p.LETTERS_LETTER_ID).IsOptional();
				this.Property(p => p.MODIFIED_TS).IsOptional();
				this.Property(p => p.CREATED_TS).IsRequired();
				this.Property(p => p.MACHINE_NAME)
					.HasColumnName("MACHINE_NAME")
					.HasMaxLength(256)
					.IsOptional();
				this.Property(p => p.NOTE)
					.HasColumnName("NOTE")
					.HasMaxLength(4000)
					.IsOptional();
				this.Property(p => p.CONTACT_PHONE)
					.HasColumnName("CONTACT_PHONE")
					.HasMaxLength(14)
					.IsOptional();
				this.Property(p => p.CONTACT_NAME)
					.HasColumnName("CONTACT_NAME")
					.HasMaxLength(50)
					.IsOptional();
				this.Property(p => p.BOP_GARNISHMENT_ID)
					.HasColumnName("BOP_GARNISHMENT_ID")
					.IsOptional();
				this.Property(p => p.BOP_GARNISHMENT_ID).IsOptional();
				this.ToTable("BOP_NOTE", "CATS_BOP_OWNER");
				// Foreign Key references.
				// CATS_BOP_OWNER.BOP_NOTE.BOP_NOTE_SOURCE_CD->CATS_BOP_OWNER.BOP_NOTE_SOURCE_CODE.BOP_NOTE_SOURCE_CD
				this.HasRequired(r1 => r1.RefToSingle_BopNoteSourceCode)
					.WithMany(r2 => r2.RefFrom_BopNote_BopNoteSourceCd_To_BopNoteSourceCd)
					.HasForeignKey(t => t.BOP_NOTE_SOURCE_CD);
		}

		public DbSetConfigBase_BopNote()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_BopNoteSourceCode : EntityTypeConfiguration<BOP_NOTE_SOURCE_CODE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
				this.HasKey(t => t.BOP_NOTE_SOURCE_CD);
				this.Property(p => p.LOAD_ORDER)
					.HasColumnName("LOAD_ORDER")
					.IsRequired();
				this.Property(p => p.LOAD_ORDER).IsRequired();
				this.Property(p => p.BOP_NOTE_SOURCE_CD)
					.HasColumnName("BOP_NOTE_SOURCE_CD")
					.HasMaxLength(10)
					.IsRequired();
				this.Property(p => p.DESCRIPTION)
					.HasColumnName("DESCRIPTION")
					.HasMaxLength(30)
					.IsRequired();
				this.ToTable("BOP_NOTE_SOURCE_CODE", "CATS_BOP_OWNER");
// Foreign Key references.
		}

		public DbSetConfigBase_BopNoteSourceCode()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_BopNoteType : EntityTypeConfiguration<BOP_NOTE_TYPE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
				this.HasKey(t => t.BOP_NOTE_TYPE_ID);
				this.Property(p => p.BOP_NOTE_TYPE_ID)
					.HasColumnName("BOP_NOTE_TYPE_ID")
					.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
					.IsRequired();
				this.Property(p => p.BOP_NOTE_TYPE_ID).IsRequired();
				this.Property(p => p.CREATED_TS).IsRequired();
				this.Property(p => p.CREATED_BY)
					.HasColumnName("CREATED_BY")
					.IsRequired();
				this.Property(p => p.CREATED_BY).IsRequired();
				this.Property(p => p.BOP_NOTE_TYPE_CD)
					.HasColumnName("BOP_NOTE_TYPE_CD")
					.HasMaxLength(10)
					.IsRequired();
				this.Property(p => p.BOP_NOTE_ID)
					.HasColumnName("BOP_NOTE_ID")
					.IsRequired();
				this.Property(p => p.BOP_NOTE_ID).IsRequired();
				this.ToTable("BOP_NOTE_TYPE", "CATS_BOP_OWNER");
				// Foreign Key references.
				// CATS_BOP_OWNER.BOP_NOTE_TYPE.BOP_NOTE_TYPE_CD->CATS_BOP_OWNER.BOP_NOTE_TYPE_CODE.BOP_NOTE_TYPE_CD
				this.HasRequired(r1 => r1.RefToSingle_BopNoteTypeCode)
					.WithMany(r2 => r2.RefFrom_BopNoteType_BopNoteTypeCd_To_BopNoteTypeCd)
					.HasForeignKey(t => t.BOP_NOTE_TYPE_CD);
				// CATS_BOP_OWNER.BOP_NOTE_TYPE.BOP_NOTE_ID->CATS_BOP_OWNER.BOP_NOTE.BOP_NOTE_ID
				this.HasRequired(r1 => r1.RefToSingle_BopNote)
					.WithMany(r2 => r2.RefFrom_BopNoteType_BopNoteId_To_BopNoteId)
					.HasForeignKey(t => t.BOP_NOTE_ID);
		}

		public DbSetConfigBase_BopNoteType()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_BopNoteTypeCode : EntityTypeConfiguration<BOP_NOTE_TYPE_CODE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
				this.HasKey(t => t.BOP_NOTE_TYPE_CD);
				this.Property(p => p.LOAD_ORDER)
					.HasColumnName("LOAD_ORDER")
					.IsRequired();
				this.Property(p => p.LOAD_ORDER).IsRequired();
				this.Property(p => p.DESCRIPTION)
					.HasColumnName("DESCRIPTION")
					.HasMaxLength(30)
					.IsRequired();
				this.Property(p => p.BOP_NOTE_TYPE_CD)
					.HasColumnName("BOP_NOTE_TYPE_CD")
					.HasMaxLength(10)
					.IsRequired();
				this.ToTable("BOP_NOTE_TYPE_CODE", "CATS_BOP_OWNER");
// Foreign Key references.
		}

		public DbSetConfigBase_BopNoteTypeCode()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_VParties2 : EntityTypeConfiguration<V_PARTIES2>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
				this.HasKey(t => t.PRTY_ID);
				this.Property(p => p.WRITE_OFF_IND)
					.HasColumnName("WRITE_OFF_IND")
					.IsRequired();
				this.Property(p => p.WRITE_OFF_IND).IsRequired();
				this.Property(p => p.FIRST_NAME)
					.HasColumnName("FIRST_NAME")
					.HasMaxLength(100)
					.IsRequired();
				this.Property(p => p.PRTY_ID)
					.HasColumnName("PRTY_ID")
					.IsRequired();
				this.Property(p => p.PRTY_ID).IsRequired();
				this.Property(p => p.BIRTH_DT).IsRequired();
				this.Property(p => p.PID)
					.HasColumnName("PID")
					.HasMaxLength(9)
					.IsOptional();
				this.Property(p => p.SSN)
					.HasColumnName("SSN")
					.HasMaxLength(9)
					.IsOptional();
				this.Property(p => p.DRIVERS_LICENSE_NBR)
					.HasColumnName("DRIVERS_LICENSE_NBR")
					.HasMaxLength(20)
					.IsOptional();
				this.Property(p => p.CLI_ID)
					.HasColumnName("CLI_ID")
					.IsOptional();
				this.Property(p => p.CLI_ID).IsOptional();
				this.Property(p => p.MOTHERS_MAIDEN_NAME)
					.HasColumnName("MOTHERS_MAIDEN_NAME")
					.HasMaxLength(80)
					.IsOptional();
				this.Property(p => p.EMAIL)
					.HasColumnName("EMAIL")
					.HasMaxLength(240)
					.IsOptional();
				this.Property(p => p.MIDDLE_NAME).IsOptional();
				this.Property(p => p.BAD_EMAIL_FLAG).IsOptional();
				this.Property(p => p.LAST_NAME)
					.HasColumnName("LAST_NAME")
					.HasMaxLength(120)
					.IsRequired();
				this.ToTable("V_PARTIES2", "CATS_BOP_OWNER");
// Foreign Key references.
		}

		public DbSetConfigBase_VParties2()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_Employee : EntityTypeConfiguration<EMPLOYEE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
				this.HasKey(t => t.EMPLID);
				this.Property(p => p.ADDR2)
					.HasColumnName("ADDR2")
					.HasMaxLength(35)
					.IsOptional();
				this.Property(p => p.LASTNAME)
					.HasColumnName("LASTNAME")
					.HasMaxLength(23)
					.IsOptional();
				this.Property(p => p.EMPLID)
					.HasColumnName("EMPLID")
					.IsRequired();
				this.Property(p => p.EMPLID).IsRequired();
				this.Property(p => p.PRONOUN)
					.HasColumnName("PRONOUN")
					.HasMaxLength(10)
					.IsOptional();
				this.Property(p => p.LOCKED)
					.HasColumnName("LOCKED")
					.IsOptional();
				this.Property(p => p.LOCKED).IsOptional();
				this.Property(p => p.ATTEMPT_COUNT)
					.HasColumnName("ATTEMPT_COUNT")
					.IsOptional();
				this.Property(p => p.ATTEMPT_COUNT).IsOptional();
				this.Property(p => p.ACTIVE_EMP)
					.HasColumnName("ACTIVE_EMP")
					.IsRequired();
				this.Property(p => p.ACTIVE_EMP).IsRequired();
				this.Property(p => p.MODIFIED_BY)
					.HasColumnName("MODIFIED_BY")
					.IsOptional();
				this.Property(p => p.MODIFIED_BY).IsOptional();
				this.Property(p => p.MODIFIED_DT).IsOptional();
				this.Property(p => p.UNIT)
					.HasColumnName("UNIT")
					.HasMaxLength(2)
					.IsOptional();
				this.Property(p => p.SUPERVISOR)
					.HasColumnName("SUPERVISOR")
					.HasMaxLength(1)
					.IsOptional();
				this.Property(p => p.MF_LOGIN)
					.HasColumnName("MF_LOGIN")
					.HasMaxLength(5)
					.IsOptional();
				this.Property(p => p.JOB)
					.HasColumnName("JOB")
					.HasMaxLength(3)
					.IsOptional();
				this.Property(p => p.PHONE)
					.HasColumnName("PHONE")
					.HasMaxLength(10)
					.IsOptional();
				this.Property(p => p.ZIP)
					.HasColumnName("ZIP")
					.HasMaxLength(9)
					.IsOptional();
				this.Property(p => p.ADDR1)
					.HasColumnName("ADDR1")
					.HasMaxLength(35)
					.IsOptional();
				this.Property(p => p.FIRSTNAME)
					.HasColumnName("FIRSTNAME")
					.HasMaxLength(13)
					.IsOptional();
				this.Property(p => p.PRONOUN_POSS)
					.HasColumnName("PRONOUN_POSS")
					.HasMaxLength(10)
					.IsOptional();
				this.Property(p => p.UT_STATE_BAR_NUMBER)
					.HasColumnName("UT_STATE_BAR_NUMBER")
					.IsOptional();
				this.Property(p => p.UT_STATE_BAR_NUMBER).IsOptional();
				this.Property(p => p.TITLE)
					.HasColumnName("TITLE")
					.HasMaxLength(40)
					.IsOptional();
				this.Property(p => p.COMMENTS)
					.HasColumnName("COMMENTS")
					.HasMaxLength(4000)
					.IsOptional();
				this.Property(p => p.CREATED_BY)
					.HasColumnName("CREATED_BY")
					.IsRequired();
				this.Property(p => p.CREATED_BY).IsRequired();
				this.Property(p => p.CREATED_DT).IsRequired();
				this.Property(p => p.USERID)
					.HasColumnName("USERID")
					.HasMaxLength(20)
					.IsOptional();
				this.Property(p => p.MACHINETYPE)
					.HasColumnName("MACHINETYPE")
					.HasMaxLength(1)
					.IsOptional();
				this.Property(p => p.EMAILADDR)
					.HasColumnName("EMAILADDR")
					.HasMaxLength(40)
					.IsOptional();
				this.Property(p => p.FAX)
					.HasColumnName("FAX")
					.HasMaxLength(10)
					.IsOptional();
				this.Property(p => p.DEPT)
					.HasColumnName("DEPT")
					.HasMaxLength(25)
					.IsOptional();
				this.Property(p => p.STATE)
					.HasColumnName("STATE")
					.HasMaxLength(2)
					.IsOptional();
				this.Property(p => p.CITY)
					.HasColumnName("CITY")
					.HasMaxLength(19)
					.IsOptional();
				this.ToTable("EMPLOYEE", "CATS_OWNER");
// Foreign Key references.
		}

		public DbSetConfigBase_Employee()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
}

