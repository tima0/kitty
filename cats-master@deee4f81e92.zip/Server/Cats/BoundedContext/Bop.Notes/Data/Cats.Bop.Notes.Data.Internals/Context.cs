using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Notes.Data.Internals
{

	public partial class DbContext : DbContextGen
	{
		public DbContext() : base("defaultCatsConnection")
		{
		}

		public override string GetDefaultSchemaName()
		{
			// TODO: Return the schema name here.  Example:
			//return "CATS_BOP_OWNER";
			throw new NotImplementedException($"You must implement the GetDefaultSchemaName() method of the {this.GetType().FullName} class.");
		}

		//public DbSet<BOP_NOTE> BopNote { get; set; }
		//public DbSet<BOP_NOTE_SOURCE_CODE> BopNoteSourceCode { get; set; }
		//public DbSet<BOP_NOTE_TYPE> BopNoteType { get; set; }
		//public DbSet<BOP_NOTE_TYPE_CODE> BopNoteTypeCode { get; set; }
		//public DbSet<V_PARTIES2> VParties2 { get; set; }
		//public DbSet<EMPLOYEE> Employee { get; set; }

	}

	public partial class DbSetConfig_BopNote : DbSetConfigBase_BopNote
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.BOP_NOTE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_BopNote() : base() { }
	}
	public partial class DbSetConfig_BopNoteSourceCode : DbSetConfigBase_BopNoteSourceCode
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.BOP_NOTE_SOURCE_CODE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_BopNoteSourceCode() : base() { }
	}
	public partial class DbSetConfig_BopNoteType : DbSetConfigBase_BopNoteType
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.BOP_NOTE_TYPE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_BopNoteType() : base() { }
	}
	public partial class DbSetConfig_BopNoteTypeCode : DbSetConfigBase_BopNoteTypeCode
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.BOP_NOTE_TYPE_CODE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_BopNoteTypeCode() : base() { }
	}
	public partial class DbSetConfig_VParties2 : DbSetConfigBase_VParties2
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.V_PARTIES2 table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_VParties2() : base() { }
	}
	public partial class DbSetConfig_Employee : DbSetConfigBase_Employee
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_OWNER.EMPLOYEE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_Employee() : base() { }
	}
}

