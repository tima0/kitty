using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Notes.Data.Interfaces;
using Cats.Bop.Notes.Data.Models;
using Cats.Logging;

namespace Cats.Bop.Notes.Data.Internals
{
	public class NotesRepository : INoteRepository
	{
		protected readonly Internals.DbContext _context;
		protected readonly ILogger _logger;

		public NotesRepository(Internals.DbContext context, Logging.ILogger logger)
		{
			_context = context;
			_logger = logger;
		}

		public IEnumerable<NotesModel> GetNotes(int count)
		{
			using (var scope = _logger.BeginScope($"GetNotes()"))
			{
				int c = Math.Max(100, count);
				try
				{
					var notes = this._context.BopNote
						.AsNoTracking()
						.Take(c);
					var enumNotes = notes.Select(n1 => new NotesModel());
					return enumNotes;
					//maybe we need this??
//					return notes == null
//						? null
//						: notes;
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, $"Error retrieving a list of {c} Claimants from database.");
					return null;
				}
			}
		}

		public IEnumerable<NotesModel> GetNotesByPID(int prtyId, int count)
		{
			using (var scope = _logger.BeginScope($"GetNotes()"))
			{
				int c = Math.Max(100, count);
				try
				{
					var notes = this._context.BopNote
						.AsNoTracking()
						.Where(x => x.PRTY_ID == prtyId)
						.Take(c);
					var enumNotes = notes.Select(n1 => new NotesModel());
					return enumNotes;
					//maybe we need this??
					//					return notes == null
					//						? null
					//						: notes;
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, $"Error retrieving a list of {c} Claimants from database.");
					return null;
				}
			}
		}
	}
}
