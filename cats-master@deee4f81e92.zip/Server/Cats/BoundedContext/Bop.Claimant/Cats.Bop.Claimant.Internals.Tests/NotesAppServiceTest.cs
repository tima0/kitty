using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using Xunit;
using Shouldly;
using Cats.Bop.Claimant.Data.Interfaces;

namespace Cats.Bop.Claimant.Internals.Tests
{
	public class NotesAppServiceTest
	{
		 [Fact]
		  public void AddressAppService_ReturnsProperObject()
		  {
			  // arrange
			  var mockRepo = new Mock<INotesRepository>();
			  mockRepo.Setup(m => m.GetNoteByNoteID(1))
				  .Returns(new Data.Models.NotesDataModel
				  {
					  BopNoteId = 1,
					  BopNoteSourceCd = "G",
					  PrtyId = 111,
					  Descr = "A DESCRIPTION",
					  Note = "THIS IS THE NOTE",
				  });


			  // act
			  var noteAppService = new NotesAppService(mockRepo.Object);
			  Cats.Bop.Claimant.Models.NotesModel address = noteAppService.GetNoteByNoteID(1);

			  // assert
			  address.BopNoteId.ShouldBe(1);
			  address.BopNoteSourceCd.ShouldBe("G");
			  address.PrtyId.ShouldBe(111);
			  address.Descr.ShouldBe("A DESCRIPTION");
			  address.Note.ShouldBe("THIS IS THE NOTE");
		  }
	}
}
