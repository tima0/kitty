using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Models;
using Moq;
using Xunit;
using Shouldly;

namespace Cats.Bop.Claimant.Internals.Tests
{
    public class AddressAppServiceTest
    {
        [Fact]
		public void AddressAppService_ReturnsProperObject()
		{
			// arrange
			var mockRepo = new Mock<IAddressRepository>();
			mockRepo.Setup(m => m.GetAddressByPartyId(1))
				.Returns(new Data.Models.AddressModel
				{
					PartyId = 1,
					AddressId = 333,
					Address1 = "123 NOWHERE",
					Address2 = string.Empty,
					City = "SALT LAKE CITY",
					State = "UT",
					Zip = "84111",
					BadAddressFlag = "0"
				});


			// act
			var addressAppService = new AddressAppService(mockRepo.Object);
			Cats.Bop.Claimant.Models.AddressModel address = addressAppService.GetAddressByPartyId(1);

			// assert
			address.PartyId.ShouldBe(1);
			address.Address1.ShouldBe("123 NOWHERE");
			address.Address2.ShouldBe(string.Empty);
			address.City.ShouldBe("SALT LAKE CITY");
			address.State.ShouldBe("UT");
			address.Zip.ShouldBe("84111");
			address.BadAddressFlag.ShouldBe("0");
			address.AddressCleansedCd.ShouldBeNull();
		}
    }
}
