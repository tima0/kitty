using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Models;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;

namespace Cats.Bop.Claimant
{
	public interface INotesAppService
	{
		NotesModel GetNoteByNoteID(long ID);
		ListEnvelope<NotesModel> GetNotesByPartyID(long PartyID, PageListParam page, OrderListParam order);
	}
}
