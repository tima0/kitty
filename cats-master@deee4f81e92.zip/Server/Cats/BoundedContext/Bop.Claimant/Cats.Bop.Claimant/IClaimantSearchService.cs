using Cats.Bop.Claimant.Models;
using System.Collections.Generic;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;


namespace Cats.Bop.Claimant
{
	public interface IClaimantSearchService
	{		
		ListEnvelope<ClaimantSearchResult> SearchClaimant(string searchTerm, PageListParam page, OrderListParam order);


		SearchResult GetSearchResults(string search, int page, int recordCount, string orderBy);
	}

}
