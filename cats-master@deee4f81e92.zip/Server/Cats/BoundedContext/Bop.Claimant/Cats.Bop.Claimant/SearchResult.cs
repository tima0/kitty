﻿using Cats.Bop.Claimant.Models;
using System;
using System.Collections.Generic;

namespace Cats.Bop.Claimant
{
	// TODO: This needs to be made generic
	public class SearchResult
	{
		public IEnumerable<ClaimantSearchResultModel> Contents { get; set; }

		public int TotalRecords { get; set; }

		public int PageSize { get; set; }

		public int PageNumber { get; set; }

		public int PageCount => TotalRecords / PageSize + 1;
	}
}
