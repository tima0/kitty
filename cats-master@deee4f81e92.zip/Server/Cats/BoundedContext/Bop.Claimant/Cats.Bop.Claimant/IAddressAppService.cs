using Cats.Bop.Claimant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant
{
    public interface IAddressAppService
    {
		AddressModel GetAddressByPartyId(long partyId);
		void UpdateAddress(Cats.Bop.Claimant.Models.AddressModel addressModel);
    }
}
