using Cats.Bop.Claimant.Models;
using DwsUI.Core.Collections;
using DwsUI.Core.ListParams;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant
{
	public interface IHoldAppService
	{
		HoldModel GetHoldByPartyId(long partyId,string holdType);
		ListEnvelope<HoldModel> GetAllHoldsForPartyId(long partyId, OrderListParam order);
	}
}
