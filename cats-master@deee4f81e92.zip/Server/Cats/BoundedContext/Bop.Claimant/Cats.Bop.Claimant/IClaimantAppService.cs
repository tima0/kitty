using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Models;

namespace Cats.Bop.Claimant
{
	public interface IClaimantAppService
	{
		ClaimantAppModel GetClaimantByPartyId(long partyId);
		// TODO: Replace this with ClaimantSearch.
		IEnumerable<ClaimantAppModel> GetClaimants(int count);
	}
}
