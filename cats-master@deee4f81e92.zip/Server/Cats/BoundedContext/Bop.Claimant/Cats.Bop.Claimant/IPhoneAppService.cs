using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Models;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;


namespace Cats.Bop.Claimant
{
	public interface IPhoneAppService
	{
		PhoneModel GetPhone(long partyId, string phonetype);
		ListEnvelope<PhoneModel> GetPhones(long partyId, PageListParam page, OrderListParam order);
	}
}
