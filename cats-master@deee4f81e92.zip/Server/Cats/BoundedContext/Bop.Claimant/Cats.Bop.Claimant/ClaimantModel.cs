using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Models
{
	//public class ClaimantModel
	//{
	//	public long PartyId { get; set; }
	//	public string PID { get; set; }
	//	public string SSN { get; set; }
	//	public long? CliId { get; set; }
	//	public string FirstName { get; set; }
	//	public string MiddleName { get; set; }
	//	public string LastName { get; set; }
	//	public string Email { get; set; }
	//	public string BadEmailFlag { get; set; }  // 1 byte / 1 char
	//	public DateTime BirthDate { get; set; }
	//	public string DriversLicenseNumber { get; set; }
	//	public string MothersMaidenName { get; set; }
	//	public bool WriteOffIndicator { get; set; } // number, 0 or 1
	//}

	/// <summary> An app model class to go with DB table V_CLAIMANT. </summary>
	public class ClaimantAppModel
	{
		public System.String BadEmailFlag { get; set; }
		public System.String Email { get; set; }
		public System.Int64 PartyId { get; set; }
		public System.String FirstName { get; set; }
		public System.String SSN { get; set; }
		public System.Int64 CliId { get; set; }
		public System.String DriversLicenseNumber { get; set; }
		public System.String MiddleName { get; set; }
		public System.String LastName { get; set; }
		public System.Int16 WriteOffInd { get; set; }
		public System.String MothersMaidenName { get; set; }
		public System.DateTime BirthDt { get; set; }
		public System.String PID { get; set; }
	}
}
