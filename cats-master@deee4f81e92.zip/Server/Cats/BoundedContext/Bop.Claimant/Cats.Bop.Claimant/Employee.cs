using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Models
{
    public class Employee
    {
		public System.Int32? UT_STATE_BAR_NUMBER { get; set; }
		public System.String PRONOUN { get; set; }
		public System.String PRONOUN_POSS { get; set; }
		public System.Int64 EMPLID { get; set; }
		public System.String FIRSTNAME { get; set; }
		public System.String LASTNAME { get; set; }
		public System.String ADDR1 { get; set; }
		public System.String ADDR2 { get; set; }
		public System.String CITY { get; set; }
		public System.String STATE { get; set; }
		public System.String ZIP { get; set; }
		public System.String DEPT { get; set; }
		public System.String PHONE { get; set; }
		public System.String FAX { get; set; }
		public System.String EMAILADDR { get; set; }
		public System.String JOB { get; set; }
		public System.String MACHINETYPE { get; set; }
		public System.String MF_LOGIN { get; set; }
		public System.String USERID { get; set; }
		public System.String SUPERVISOR { get; set; }
		public System.String UNIT { get; set; }
		public System.DateTime CREATED_DT { get; set; }
		public System.Int64 CREATED_BY { get; set; }
		public System.DateTime? MODIFIED_DT { get; set; }
		public System.Int64? MODIFIED_BY { get; set; }
		public System.Int16 ACTIVE_EMP { get; set; }
		public System.String COMMENTS { get; set; }
		public System.String TITLE { get; set; }
		public System.Int16? ATTEMPT_COUNT { get; set; }
		public System.Int16? LOCKED { get; set; }
	}



}
