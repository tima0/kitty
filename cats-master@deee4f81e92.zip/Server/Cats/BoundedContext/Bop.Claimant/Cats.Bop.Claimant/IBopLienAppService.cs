using Cats.Bop.Claimant.Models;
using Cats.Core.Liens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant
{
    public interface IBopLienAppService
    {
		void ExecuteLienAction(BopLienModel bopLien, ActionCode actionCode, DateTime dateRun);
		void ProcessLien(BopLienModel bopLien, DateTime dateRun);
		IEnumerable<BopLienModel> GetBopLiensFaults();
		IEnumerable<BopLienModel> GetBopLiensFraud();

	}
}
