using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant
{
	public class ClaimantSearchEnvelope
	{
		public IEnumerable<Models.ClaimantSearchResult> SearchResults { get; set; }

		public int ClaimantCount { get; set; }

		public int PageSize { get; set; }

		public int PageNumber { get; set; }

		public int PageCount { get; set; }

		public string OrderBy { get; set; }
	}
}
