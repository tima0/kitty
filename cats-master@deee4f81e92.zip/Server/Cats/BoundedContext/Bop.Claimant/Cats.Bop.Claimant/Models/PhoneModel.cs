using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Models
{
	public class PhoneModel
	{
		public long PartyId { get; set; }
		public string Phone { get; set; }
		public string PhoneType { get; set; }
		public long CpId { get; set; }
		public long CliId { get; set; }
		public string BadPhoneFlag { get; set; }

	}	
}
