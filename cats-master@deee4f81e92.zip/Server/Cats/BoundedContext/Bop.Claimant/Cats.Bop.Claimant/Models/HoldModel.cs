using System;

namespace Cats.Bop.Claimant
{
	public class HoldModel
	{
		public bool Active { get; set; }
		public string HoldType { get; set; }
		public string ReasonHoldSet { get; set; }
		public DateTime DateHoldSet { get; set; }
		public DateTime DateHoldWillBeRemoved { get; set; }
		public string HoldSetBy { get; set; }
		public string HoldLastChangedBy { get; set; }
	}
}

