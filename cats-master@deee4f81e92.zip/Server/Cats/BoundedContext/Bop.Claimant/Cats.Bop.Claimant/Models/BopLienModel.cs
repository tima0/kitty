using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Models
{
    public class BopLienModel
    {
		public long LienId;
		public DateTime? DateFiled;
		public DateTime? EstablishedDate;
		public decimal? RestartBalanceWhen28Sent;
		public decimal? CurrentRestartBalance;
		public decimal? ArBalance;
		public decimal? FiledLienAmount;
		public decimal? PenaltyBalanceAmount;
		public decimal? PenaltyDueAmount;
		public decimal? PenaltyFiledAmount;
		public bool CanceledDebt;
		public decimal? ChargeOffAmount;
		public decimal? PenaltyForcedAmount;
		public DateTime? LastCertifiedPaymentDate;
		public DateTime? LastNonCertifiedPaymentDate;
		public decimal? BalanceChangeNeedRestart;
		public bool HasAdminHold;
		public bool HasAppealHold;
		public bool HasBankruptcy;
		public bool HasInstallmentAgreement;
		public string LastActionCode;
		public DateTime? LastActionDate;
		public string PreviousState;
		public DateTime? LastCorrespondenceDate;
		public DateTime? FirstWait10Day;
		public DateTime? FirstWaitToFile;
		public string LienType;
	}
}
