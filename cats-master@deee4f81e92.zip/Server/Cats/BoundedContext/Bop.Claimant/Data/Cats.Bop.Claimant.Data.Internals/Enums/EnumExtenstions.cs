﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;

namespace Cats.Bop.Claimant.Internals.Enums
{
	//TODO: Will want to put this somewhere else
	public static class EnumExtension
	{
		public static T ToEnum<T>(this string str)
		{
			if (String.IsNullOrEmpty(str))
				return default(T);

			var enumType = typeof(T);
			foreach (var name in Enum.GetNames(enumType))
			{
				var enumField = enumType.GetField(name);

				var enumMemberAttribute = ((EnumMemberAttribute[])enumField
					.GetCustomAttributes(typeof(EnumMemberAttribute), true))
					.SingleOrDefault();

				var _enum = (T)Enum.Parse(enumType, name);

				if (enumMemberAttribute != null && enumMemberAttribute.Value == str)
				{
					return _enum;
				}
				else if (str.Length == 1 && str[0] == Convert.ToChar(_enum))
				{
					return _enum;
				}
				else if (name == str)
				{
					return _enum;
				}
				else
				{
					var descriptionAttribute = ((DescriptionAttribute[])enumField
						.GetCustomAttributes(typeof(DescriptionAttribute), true))
					.SingleOrDefault();

					if (descriptionAttribute != null && descriptionAttribute.Description == str)
					{
						return _enum;
					}
				}
			}

			throw new InvalidCastException(str + " was not found in the " + typeof(T).ToString() + " enum");
		}

		/// <summary>
		/// Attempts to convert str to enum.  If fails, sets enumVal equal to default and returns false.
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="str"></param>
		/// <param name="enumVal"></param>
		/// <returns></returns>
		public static bool TryToEnum<T>(this string str, out T enumVal)
		{
			try
			{
				enumVal = str.ToEnum<T>();
				return true;
			}
			catch
			{
				enumVal = default(T);
			}

			return false;
		}

		/// <summary>
		/// Gets the string in the DescriptionAttribute attribute if one is present on the
		/// member. Otherwise it returns the identifier.
		/// </summary>
		/// <param name="enumValue">The member to get the description for.</param>
		/// <param name="defaultIfEmpty">If set to false, empty string will be returned if no descritpion available.</param>
		/// <returns>
		/// Gets the string in the DescriptionAttribute attribute if one is present on the
		/// member. Otherwise it returns the identifier.
		/// </returns>
		public static string GetDescription(this Enum enumValue, bool defaultIfEmpty = true)
		{
			var attribute = enumValue.GetEnumAttribute<DescriptionAttribute>() as DescriptionAttribute;
			if (attribute != null)
			{
				return attribute.Description;
			}

			return defaultIfEmpty ? enumValue.GetIdentifierName() : String.Empty;
		}


		/// <summary>
		/// Gets the name of the identifier for the Enum member.
		/// </summary>
		/// <param name="enumValue">The member to get the identifier for.</param>
		/// <returns>The identifier as a string of the Enum member.</returns>
		public static string GetIdentifierName(this Enum enumValue)
		{
			return enumValue.ToString();
		}

		/// <summary>
		/// Gets the value of an enum. The value type can be specified and the rules
		/// used for retrieving the value differ by type.
		/// </summary>
		/// <typeparam name="T">
		/// The type of the return value. Possible types are string,  
		/// byte, sbyte, short, ushort, int, uint, long, ulong. It's important
		/// to know which value an enum can return before requesting that
		/// type as an InvalidCastException will be thrown if the type is not
		/// supported by the definition of the Enum.
		/// </typeparam>
		/// <param name="enumValue">The Enum member to be evaluated.</param>
		/// <returns>The value as indicated by the generic type argument.</returns>
		public static T GetValue<T>(this Enum enumValue)
		{
			Type t = typeof(T);
			if (t == typeof(string))
			{
				return (T)(object)enumValue.GetValueAsString();
			}
			else if (t == typeof(byte) || t == typeof(sbyte) || t == typeof(short) || t == typeof(ushort) || t == typeof(int) || t == typeof(uint) || t == typeof(long) || t == typeof(ulong))
			{
				return enumValue.GetValueAsWholeNumber<T>();
			}
			else
			{
				throw new InvalidCastException();
			}
		}

		/// <summary>
		/// Generic function to get attribute of Enum
		/// </summary>
		/// <typeparam name="TAttribute">The attribute class</typeparam>
		/// <param name="value">the enum</param>
		/// <returns></returns>
		public static TAttribute GetEnumAttribute<TAttribute>(this Enum value) where TAttribute : Attribute
		{
			try
			{
				var type = value.GetType();
				string name = Enum.GetName(type, value);
				if (string.IsNullOrWhiteSpace(name))
					return null;

				return type.GetField(name)
					.GetCustomAttributes(false)
					.OfType<TAttribute>()
					.FirstOrDefault();
			}
			catch
			{
				//no enum return null
				return null;
			}
		}

		private static string GetValueAsString(this Enum enumValue)
		{
			try
			{
				var enumMemberAttribute = enumValue.GetEnumAttribute<EnumMemberAttribute>();
				if (enumMemberAttribute != null)
				{
					return enumMemberAttribute.Value;
				}

				char? ch = GetValueAsChar(enumValue);
				if (ch.HasValue)
				{
					return ch.GetValueOrDefault().ToString();
				}

				//NOTE: Cannot cast enum member to string. Consider adding an EnumMemberAttribute to the member or specifying A-Z, a-z and 0-9 as the value.
				return null;
			}
			catch
			{
				//no enum return null
				return null;
			}
		}

		private static char? GetValueAsChar(this Enum enumValue)
		{
			try
			{
				var field = enumValue.GetType().GetField(enumValue.ToString());
				if (field == null)
					return null;

				int unboxedValue = (int)field.GetValue(enumValue);
				char characterValue = (char)unboxedValue;

				if (characterValue >= '0' && characterValue <= '9' || characterValue >= 'A' && characterValue <= 'Z' || characterValue >= 'a' && characterValue <= 'z')
					return characterValue;

				return null;
			}
			catch
			{
				//no enum return null
				return null;
			}

		}

		private static T GetValueAsWholeNumber<T>(this Enum enumValue)
		{
			Type t = Enum.GetUnderlyingType(enumValue.GetType());

			if (t != typeof(T))
				throw new InvalidCastException(string.Format("Cannot cast enum member to {0} because the underlying enum type is {1}.", typeof(T).Name, t.Name));

			object o = enumValue.GetType().GetField(enumValue.ToString()).GetValue(enumValue);
			object knownValue = Convert.ChangeType(o, t);
			return (T)knownValue;
		}
	}
}
