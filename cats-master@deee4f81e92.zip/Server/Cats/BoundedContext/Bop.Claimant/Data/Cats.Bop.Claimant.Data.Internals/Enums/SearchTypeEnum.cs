﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace Cats.Bop.Claimant.Data.Internals.Enums
{
	public enum SearchTypeEnum
	{
		[EnumMember(Value = "")]
		[Description("Unknown")]
		Unknown,

		[EnumMember(Value = "1")]
		[Description("Search By ID")]
		ById,

		[EnumMember(Value = "2")]
		[Description("Search By Name")]
		ByName,

		[EnumMember(Value = "3")]
		[Description("Search By Address")]
		ByAddress
	}
}
