using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Data.Internals;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Data.Models;
using System.Text.RegularExpressions;
using DwsUI.Core.ListParams;
using DwsUI.Core.Data.Collections;

namespace Cats.Bop.Claimant.Data.Internals
{
	public class ClaimantSearch
	{

		public PagedList<ClaimantSearchResults> DoClaimantSearch(string searchStr, PageListParam page, OrderListParam orderBy, DbContext context)
		{
			PagedList<ClaimantSearchResults> _result;

			var _claimantSearch = new ClaimantSearch();
			//return _claimantSearch.FakeSearch(searchStr);


			if (Regex.IsMatch(searchStr, @"^[0-9]+$"))
				_result = _claimantSearch.ClaimantIDSearch(searchStr, page, orderBy, context);
			else if (Regex.IsMatch(searchStr, @"^[a-zA-Z]+$"))
				_result = _claimantSearch.ClaimantNameSearch(searchStr, page, orderBy, context);
			else if (Regex.IsMatch(searchStr, @"^[a-zA-Z0-9 #]+$"))
				_result = _claimantSearch.ClaimantAddressSearch(searchStr, page, orderBy, context);
			else
				_result = null;

			return _result;

		}

		private PagedList<ClaimantSearchResults> ClaimantIDSearch(string searchStr, PageListParam page, OrderListParam orderBy, DbContext context)
		{

			int _intSearch = Int32.Parse(searchStr);
			var result1 = (from p in context.VClaimant
						   join a in context.VClaimantAddress
							 on p.PRTY_ID equals a.PRTY_ID
						   where p.SSN.Contains(searchStr.Trim())
							  || p.PID == searchStr.Trim()
								 || p.PRTY_ID == _intSearch

						   select new
						   {
							   p.PRTY_ID,
							   p.PID,
							   p.FIRST_NAME,
							   p.LAST_NAME,
							   p.SSN,
							   a.ADDRESS1,
							   a.CITY,
							   a.STATE,
							   a.ZIP,
							   opCount = (from o in context.VOpgroup
										  where o.PRTY_ID.Equals(p.PRTY_ID)
										  select o.PRTY_ID).Count(),

							   opBalance = (from o in context.VOpgroup
											where o.PRTY_ID.Equals(p.PRTY_ID)
											select o.OP_BAL_AMT).Sum(),

							   searchVal = p.SSN.Contains(searchStr.Trim()) ? "SSN" :
										   p.PID == searchStr.Trim() ? "PID" :
										   p.PRTY_ID == _intSearch ? "Prty_ID" : ""
						   });

			var result2 =
			(from p in context.VClaimant
			 join a in context.VClaimantAddress
			   on p.PRTY_ID equals a.PRTY_ID
			 join g in context.VOpgroup
			   on p.PRTY_ID equals g.PRTY_ID
			 where g.OPGRP_ID == _intSearch

			 select new
			 {
				 p.PRTY_ID,
				 p.PID,
				 p.FIRST_NAME,
				 p.LAST_NAME,
				 p.SSN,
				 a.ADDRESS1,
				 a.CITY,
				 a.STATE,
				 a.ZIP,
				 opCount = (from o in context.VOpgroup
							where o.PRTY_ID.Equals(p.PRTY_ID)
							select o.PRTY_ID).Count(),

				 opBalance = (from o in context.VOpgroup
							  where o.PRTY_ID.Equals(p.PRTY_ID)
							  select o.OP_BAL_AMT).Sum(),

				 searchVal = g.OPGRP_ID == _intSearch ? "BopID" : ""
			 });

			// TODO: This join is totally wrong.  
			var result3 =
						  (from p in context.VClaimant
			 			  join a in context.VClaimantAddress
			 				on p.PRTY_ID equals a.PRTY_ID
			 			  join g in context.VOpgroup
			 				on p.PRTY_ID equals g.PRTY_ID
			 			  join l in context.LienBop
			 				on g.OPGRP_ID equals l.OPGRP_ID
			 			  join lm in context.LienMaster
			 				on l.OPGRP_ID equals lm.LIEN_MASTER_ID
			 			  where lm.LIEN_MASTER_ID == _intSearch || lm.CASE_NUMBER == searchStr

						   select new
						   {
							   p.PRTY_ID,
							   p.PID,
							   p.FIRST_NAME,
							   p.LAST_NAME,
							   p.SSN,
							   a.ADDRESS1,
							   a.CITY,
							   a.STATE,
							   a.ZIP,
							   opCount = (from o in context.VOpgroup
										  where o.PRTY_ID.Equals(p.PRTY_ID)
										  select o.PRTY_ID).Count(),

							   opBalance = (from o in context.VOpgroup
											where o.PRTY_ID.Equals(p.PRTY_ID)
											select o.OP_BAL_AMT).Sum(),

							   searchVal = lm.LIEN_MASTER_ID == _intSearch ? "Lien Master" :
											 lm.CASE_NUMBER == searchStr ? "Case_Number" : ""
						   });



			IQueryable<ClaimantSearchResults> list =
				result1
				.Union(result2)
				.Union(result3)
				.Select(w => new ClaimantSearchResults
				{
					PartyId = w.PRTY_ID,
					PId = w.PID,
					FirstName = w.FIRST_NAME,
					LastName = w.LAST_NAME,
					SSN = w.SSN,
					Address1 = w.ADDRESS1,
					City = w.CITY,
					State = w.STATE,
					Zip = w.ZIP,
					OpCount = w.opCount,
					OpBal = w.opBalance,
					SearchVal = w.searchVal
				}).OrderByParam(s => s.OrderBy(o => o.SSN), orderBy);

			return PagedList<ClaimantSearchResults>.Create(list, page);
		}

		private PagedList<ClaimantSearchResults> ClaimantNameSearch(string searchStr, PageListParam page, OrderListParam orderBy, DbContext context)
		{
			string _searchStr = searchStr.ToUpper();
			var results = (from p in context.VClaimant
						   join a in context.VClaimantAddress
							 on p.PRTY_ID equals a.PRTY_ID
						   where p.FIRST_NAME.StartsWith(_searchStr.Trim())
							  || p.LAST_NAME.StartsWith(_searchStr.Trim())
						   select new
						   {
							   p.PRTY_ID,
							   p.PID,
							   p.FIRST_NAME,
							   p.LAST_NAME,
							   p.SSN,
							   a.ADDRESS1,
							   a.CITY,
							   a.STATE,
							   a.ZIP,
							   opCount = (from o in context.VOpgroup
										  where o.PRTY_ID.Equals(p.PRTY_ID)
										  select o.PRTY_ID).Count(),

							   opBalance = (from o in context.VOpgroup
											where o.PRTY_ID.Equals(p.PRTY_ID)
											select o.OP_BAL_AMT).Sum(),

							   searchVal = p.FIRST_NAME.StartsWith(_searchStr) ? "First_Name" :
											p.LAST_NAME.StartsWith(_searchStr) ? "Last_Name" : ""
						   });


			var list = results.Select(w => new ClaimantSearchResults
			{
				PartyId = w.PRTY_ID,
				PId = w.PID,
				FirstName = w.FIRST_NAME,
				LastName = w.LAST_NAME,
				SSN = w.SSN,
				Address1 = w.ADDRESS1,
				City = w.CITY,
				State = w.STATE,
				Zip = w.ZIP,
				OpCount = w.opCount,
				OpBal = w.opBalance,
				SearchVal = w.searchVal
			}).OrderByParam(s => s.OrderBy(o => o.LastName).ThenBy(o => o.FirstName), orderBy);

			return PagedList<ClaimantSearchResults>.Create(list, page);
		}

		private PagedList<ClaimantSearchResults> ClaimantAddressSearch(string searchStr, PageListParam page, OrderListParam orderBy, DbContext context)
		{
			// TODO: This search does NOT behave entirely.  if you search for "A1" or "B1", you get ten rows whose addr1 and addr2 do NOT start with "A1 or "B1".
			string _searchStr = searchStr.ToUpper().Trim();

			var results = (from p in context.VClaimant
						   join a in context.VClaimantAddress on p.PRTY_ID equals a.PRTY_ID
						   where a.ADDRESS1.StartsWith(_searchStr) || a.ADDRESS2.StartsWith(_searchStr)
						   select new
						   {
							   p.PRTY_ID,
							   p.PID,
							   p.FIRST_NAME,
							   p.LAST_NAME,
							   p.SSN,
							   a.ADDRESS1,
							   a.CITY,
							   a.STATE,
							   a.ZIP,
							   opCount = (from o in context.VOpgroup
										  where o.PRTY_ID.Equals(p.PRTY_ID)
										  select o.PRTY_ID).Count(),

							   opBalance = (from o in context.VOpgroup
											where o.PRTY_ID.Equals(p.PRTY_ID)
											select o.OP_BAL_AMT).Sum(),

							   searchVal = a.ADDRESS1.StartsWith(_searchStr) ? "Address1" :
											a.ADDRESS2.StartsWith(_searchStr) ? "Address2" : ""
						   });

			var list = results.Select(w => new ClaimantSearchResults
			{
				PartyId = w.PRTY_ID,
				PId = w.PID,
				FirstName = w.FIRST_NAME,
				LastName = w.LAST_NAME,
				SSN = w.SSN,
				Address1 = w.ADDRESS1,
				City = w.CITY,
				State = w.STATE,
				Zip = w.ZIP,
				OpCount = w.opCount,
				OpBal = w.opBalance,
				SearchVal = w.searchVal
			}).OrderByParam(s => s.OrderBy(o => o.Address1), orderBy);

			return PagedList<ClaimantSearchResults>.Create(list, page);
		}
	}
}
