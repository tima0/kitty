using Cats.Bop.Claimant.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

namespace Cats.Bop.Claimant.Data.Internals
{
    public partial class DbContext
	{
		public string ValidateAddress(AddressModel address)
		{
			return this.PKG_CatsBopOwner_UwAddressPkg_ValidateAddress(
				address.Address1,
				address.Address2,
				address.City,
				address.State,
				address.Zip,
				"M")
				.SingleOrDefault();
		}

		public string UpdateAddress(AddressModel address)
		{
			string result = ValidateAddress(address);

			if (result == null)
			{
				this.PKG_CatsBopOwner_UwAddressPkg_UpdateAddress(
					address.AddressId,
					address.Address1,
					address.Address2,
					address.City,
					address.State,
					address.Zip);
			}

			return result;
		}

		//public string ValidateAddress(AddressModel address)
		//{			
		//	var paramAddress1 = new OracleParameter("P_ADDR1", OracleDbType.Varchar2);
		//	var paramAddress2 = new OracleParameter("P_ADDR2", OracleDbType.Varchar2);
		//	var paramCity = new OracleParameter("P_CITY", OracleDbType.Varchar2);
		//	var paramState = new OracleParameter("P_STATE", OracleDbType.Varchar2);
		//	var paramZip = new OracleParameter("P_ZIP", OracleDbType.Varchar2);
		//	var paramUsageType = new OracleParameter("P_USAGE_TYPE_CD", OracleDbType.Varchar2);

		//	paramAddress1.Value = address.Address1;
		//	paramAddress2.Value = address.Address2;
		//	paramCity.Value = address.City;
		//	paramState.Value = address.State;
		//	paramZip.Value = address.Zip;
		//	paramUsageType.Value = "M";

		//	OracleParameter[] sqlParams = new OracleParameter[] { paramAddress1, paramAddress2, paramCity, paramState, paramZip, paramUsageType };

		//	var sql = "SELECT CATS_BOP_OWNER.UW_ADDRESS_PKG.VALIDATE_ADDRESS(:P_ADDR1, :P_ADDR2, :P_CITY, :P_STATE, :P_ZIP, :P_USAGE_TYPE_CD) FROM DUAL";
		//	return this.Database.SqlQuery<string>(sql, sqlParams).SingleOrDefault();
		//}

		//public string UpdateAddress(AddressModel address)
		//{
		//	var result = ValidateAddress(address);
		//	if (result == null)
		//	{
		//		var paramAddressId = new OracleParameter("PADDR_ID", OracleDbType.Int32);
		//		var paramAddress1 = new OracleParameter("P_ADDR1", OracleDbType.Varchar2);
		//		var paramAddress2 = new OracleParameter("P_ADDR2", OracleDbType.Varchar2);
		//		var paramCity = new OracleParameter("P_CITY", OracleDbType.Varchar2);
		//		var paramState = new OracleParameter("P_STATE", OracleDbType.Varchar2);
		//		var paramZip = new OracleParameter("P_ZIP", OracleDbType.Varchar2);

		//		paramAddressId.Value = address.AddressId;
		//		paramAddress1.Value = address.Address1;
		//		paramAddress2.Value = address.Address2;
		//		paramCity.Value = address.City;
		//		paramState.Value = address.State;
		//		paramZip.Value = address.Zip;

		//		var sql = "begin CATS_BOP_OWNER.UW_ADDRESS_PKG.UPDATE_ADDRESS(:PADDR_ID, :P_ADDR1, :P_ADDR2, :P_CITY, :P_STATE, :P_ZIP); end;";
		//		var sqlParams = new OracleParameter[] { paramAddressId, paramAddress1, paramAddress2, paramCity, paramState, paramZip };
		//		this.Database.ExecuteSqlCommand(sql, sqlParams);
		//	}

		//	return result;
		//}
	}
}
