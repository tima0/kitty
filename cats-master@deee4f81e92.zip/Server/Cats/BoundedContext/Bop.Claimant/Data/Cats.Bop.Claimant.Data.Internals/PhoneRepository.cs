using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Logging;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Data.Models;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;
using DwsUI.Core.Data.Collections;


namespace Cats.Bop.Claimant.Data.Internals
{
	public class PhoneRepository: IPhoneRepository
	{
		protected readonly Internals.DbContext _context;
		protected readonly ILogger _logger;

		public PhoneRepository(Internals.DbContext context, ILogger logger)
		{
			_context = context;
			_logger = logger;
		}

		public V_CLAIMANT_PHONE GetPhone(long partyId, string PhoneType)
		{
			using (var scope = _logger.BeginScope($"GetPhoneByPartyIDAndType({partyId}-{PhoneType})"))
			{
				try
				{
					return this._context.VClaimantPhone.AsNoTracking()
						.Where(x => x.PRTY_ID == partyId && x.TYPE_CD == PhoneType)
						.SingleOrDefault();
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, $"Error querying Phone by PartyIDAndType {partyId}-{PhoneType} from database.");
					return null;
				}
			}
		}

		public IPagedList<V_CLAIMANT_PHONE> GetPhones(long partyId, PageListParam page, OrderListParam orderBy)
		{
			using (var scope = _logger.BeginScope($"GetPhones({partyId})"))
			{
				var query = this._context.VClaimantPhone.AsNoTracking()
					.Where(x => x.PRTY_ID == partyId).
					OrderByParam(q => (q.OrderBy(s => s.TYPE_CD)), orderBy);

				return PagedList<V_CLAIMANT_PHONE>.Create(query, page);
			}
		}
	}
}
