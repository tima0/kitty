using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;
using DwsUI.Core.Logging;
using Cats.Bop.Claimant.Data.Models;

namespace Cats.Bop.Claimant.Data.Internals
{
	public static class ContextDBInitializer
	{
		public static void DisableCodeFirstMigrations()
		{
			// Disable code-first migrations.  This should be called from the host project's startup code.
			// See this page:  https://www.dotnetexpertguide.com/2012/10/aspnet-preapplicationstartmethod-example.html
			Database.SetInitializer<Cats.Bop.Claimant.Data.Internals.DbContext>(null);
		}
	}

	public abstract partial class DbContextGen : System.Data.Entity.DbContext
	{
		public DbContextGen(string nameOrConnectionString, ILogger logger) : base(nameOrConnectionString)
		{
			// Do not remove these lines!
			// These look like they do nothing, but it creates the only code reference to the Oracle assembly.
			// Without it, the dependency is deemed unnecessary by the linker and is not deployed to the web bin folder.
			var refFix1 = typeof(Oracle.ManagedDataAccess.Client.OracleConnection);
			System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(refFix1.AssemblyQualifiedName));
			var refFix2 = typeof(Oracle.ManagedDataAccess.EntityFramework.OracleConnectionFactory);
			System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(refFix2.AssemblyQualifiedName));
			
			this.Database.Log = s => logger.LogDebug(s);
		}

		public virtual string GetDefaultSchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public DbSet<HOLD> Hold { get; set; }
		public DbSet<HOLD_TYPE_CODE> HoldTypeCode { get; set; }
		public DbSet<LIEN_BOP> LienBop { get; set; }
		public DbSet<NOTE> Note { get; set; }
		public DbSet<NOTE_SOURCE_CODE> NoteSourceCode { get; set; }
		public DbSet<NOTE_TYPE> NoteType { get; set; }
		public DbSet<NOTE_TYPE_CODE> NoteTypeCode { get; set; }
		public DbSet<V_CLAIMANT> VClaimant { get; set; }
		public DbSet<V_CLAIMANT_ADDRESS> VClaimantAddress { get; set; }
		public DbSet<V_CLAIMANT_PHONE> VClaimantPhone { get; set; }
		public DbSet<V_OPGROUP> VOpgroup { get; set; }
		public DbSet<EMPLOYEE> Employee { get; set; }
		public DbSet<VM_POSTAL_CODE> VmPostalCode { get; set; }
		public DbSet<LIEN_MASTER> LienMaster { get; set; }
		public DbSet<LIEN_STATE_HISTORY> LienStateHistory { get; set; }
		public DbSet<OP_CAUSE_CODES> OpCauseCodes { get; set; }
		public DbSet<OP_CLASS_CODES> OpClassCodes { get; set; }
		public DbSet<OP_SOURCE_CODES> OpSourceCodes { get; set; }
		public DbSet<OP_TRANSACTIONS> OpTransactions { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.HasDefaultSchema(GetDefaultSchemaName());

			modelBuilder.Configurations.Add(new DbSetConfig_Hold());
			modelBuilder.Configurations.Add(new DbSetConfig_HoldTypeCode());
			modelBuilder.Configurations.Add(new DbSetConfig_LienBop());
			modelBuilder.Configurations.Add(new DbSetConfig_Note());
			modelBuilder.Configurations.Add(new DbSetConfig_NoteSourceCode());
			modelBuilder.Configurations.Add(new DbSetConfig_NoteType());
			modelBuilder.Configurations.Add(new DbSetConfig_NoteTypeCode());
			modelBuilder.Configurations.Add(new DbSetConfig_VClaimant());
			modelBuilder.Configurations.Add(new DbSetConfig_VClaimantAddress());
			modelBuilder.Configurations.Add(new DbSetConfig_VClaimantPhone());
			modelBuilder.Configurations.Add(new DbSetConfig_VOpgroup());
			modelBuilder.Configurations.Add(new DbSetConfig_Employee());
			modelBuilder.Configurations.Add(new DbSetConfig_VmPostalCode());
			modelBuilder.Configurations.Add(new DbSetConfig_LienMaster());
			modelBuilder.Configurations.Add(new DbSetConfig_LienStateHistory());
			modelBuilder.Configurations.Add(new DbSetConfig_OpCauseCodes());
			modelBuilder.Configurations.Add(new DbSetConfig_OpClassCodes());
			modelBuilder.Configurations.Add(new DbSetConfig_OpSourceCodes());
			modelBuilder.Configurations.Add(new DbSetConfig_OpTransactions());
		}
	}

	public partial class DbSetConfigBase_Hold : EntityTypeConfiguration<HOLD>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.HOLD_ID);
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.MODIFIED_TS).IsOptional();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.CLOSED_DT).IsOptional();
			this.Property(p => p.REMOVE_HOLD_DT).IsOptional();
			this.Property(p => p.REASON)
				.HasColumnName("REASON")
				.HasMaxLength(200)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.HOLD_TYPE_CD)
				.HasColumnName("HOLD_TYPE_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.PRTY_ID)
				.HasColumnName("PRTY_ID")
				.IsRequired();
			this.Property(p => p.PRTY_ID).IsRequired();
			this.Property(p => p.HOLD_ID)
				.HasColumnName("HOLD_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.HOLD_ID).IsRequired();
			this.ToTable("HOLD", "CATS_BOP_OWNER");

			// Foreign key references.
			// CATS_BOP_OWNER.HOLD.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasRequired(r1 => r1.Ref_Employee_CreatedBy)
				.WithMany(r2 => r2.RefMany_Hold_CreatedBy)
				.HasForeignKey(t => t.CREATED_BY);
			// CATS_BOP_OWNER.HOLD.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasOptional(r1 => r1.Ref_Employee_ModifiedBy)
				.WithMany(r2 => r2.RefMany_Hold_ModifiedBy)
				.HasForeignKey(t => t.MODIFIED_BY);
			// CATS_BOP_OWNER.HOLD.HOLD_TYPE_CD->CATS_BOP_OWNER.HOLD_TYPE_CODE.HOLD_TYPE_CD
			this.HasRequired(r1 => r1.Ref_HoldTypeCode)
				.WithMany(r2 => r2.RefMany_Hold_HoldTypeCd)
				.HasForeignKey(t => t.HOLD_TYPE_CD);
		}

		public DbSetConfigBase_Hold()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_HoldTypeCode : EntityTypeConfiguration<HOLD_TYPE_CODE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.HOLD_TYPE_CD);
			this.Property(p => p.HOLD_TYPE_CD)
				.HasColumnName("HOLD_TYPE_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.DESCRIPTION)
				.HasColumnName("DESCRIPTION")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("HOLD_TYPE_CODE", "CATS_BOP_OWNER");
		}

		public DbSetConfigBase_HoldTypeCode()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_LienBop : EntityTypeConfiguration<LIEN_BOP>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.LIEN_BOP_ID);
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.OPGRP_ID)
				.HasColumnName("OPGRP_ID")
				.IsRequired();
			this.Property(p => p.OPGRP_ID).IsRequired();
			this.Property(p => p.LIEN_MASTER_ID)
				.HasColumnName("LIEN_MASTER_ID")
				.IsRequired();
			this.Property(p => p.LIEN_MASTER_ID).IsRequired();
			this.Property(p => p.LIEN_BOP_ID)
				.HasColumnName("LIEN_BOP_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.LIEN_BOP_ID).IsRequired();
			this.ToTable("LIEN_BOP", "CATS_BOP_OWNER");

			// Foreign key references.
			// CATS_BOP_OWNER.LIEN_BOP.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasRequired(r1 => r1.Ref_Employee)
				.WithMany(r2 => r2.RefMany_LienBop_CreatedBy)
				.HasForeignKey(t => t.CREATED_BY);
			// CATS_BOP_OWNER.LIEN_BOP.LIEN_MASTER_ID->CATS_LEGAL_OWNER.LIEN_MASTER.LIEN_MASTER_ID
			this.HasRequired(r1 => r1.Ref_LienMaster)
				.WithMany(r2 => r2.RefMany_LienBop_LienMasterId)
				.HasForeignKey(t => t.LIEN_MASTER_ID);
		}

		public DbSetConfigBase_LienBop()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_Note : EntityTypeConfiguration<NOTE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.NOTE_ID);
			this.Property(p => p.LETTERS_LETTER_ID)
				.HasColumnName("LETTERS_LETTER_ID")
				.IsOptional();
			this.Property(p => p.LETTERS_LETTER_ID).IsOptional();
			this.Property(p => p.IMAGEID)
				.HasColumnName("IMAGEID")
				.HasMaxLength(20)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.MODIFIED_TS).IsOptional();
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.MACHINE_NAME)
				.HasColumnName("MACHINE_NAME")
				.HasMaxLength(256)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.NOTE_CONTENT)
				.HasColumnName("NOTE_CONTENT")
				.HasMaxLength(4000)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.DESCRIPTION)
				.HasColumnName("DESCRIPTION")
				.HasMaxLength(50)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CONTACT_EXT)
				.HasColumnName("CONTACT_EXT")
				.HasMaxLength(6)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CONTACT_PHONE)
				.HasColumnName("CONTACT_PHONE")
				.HasMaxLength(14)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CONTACT_TITLE)
				.HasColumnName("CONTACT_TITLE")
				.HasMaxLength(50)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CONTACT_NAME)
				.HasColumnName("CONTACT_NAME")
				.HasMaxLength(50)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PRTY_ID)
				.HasColumnName("PRTY_ID")
				.IsRequired();
			this.Property(p => p.PRTY_ID).IsRequired();
			this.Property(p => p.GARNISHMENT_ID)
				.HasColumnName("GARNISHMENT_ID")
				.IsOptional();
			this.Property(p => p.GARNISHMENT_ID).IsOptional();
			this.Property(p => p.PROSECUTION_ID)
				.HasColumnName("PROSECUTION_ID")
				.IsOptional();
			this.Property(p => p.PROSECUTION_ID).IsOptional();
			this.Property(p => p.NOTE_SOURCE_CD)
				.HasColumnName("NOTE_SOURCE_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.NOTE_ID)
				.HasColumnName("NOTE_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.NOTE_ID).IsRequired();
			this.ToTable("NOTE", "CATS_BOP_OWNER");

			// Foreign key references.
			// CATS_BOP_OWNER.NOTE.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasRequired(r1 => r1.Ref_Employee_CreatedBy)
				.WithMany(r2 => r2.RefMany_Note_CreatedBy)
				.HasForeignKey(t => t.CREATED_BY);
			// CATS_BOP_OWNER.NOTE.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasOptional(r1 => r1.Ref_Employee_ModifiedBy)
				.WithMany(r2 => r2.RefMany_Note_ModifiedBy)
				.HasForeignKey(t => t.MODIFIED_BY);
			// CATS_BOP_OWNER.NOTE.NOTE_SOURCE_CD->CATS_BOP_OWNER.NOTE_SOURCE_CODE.NOTE_SOURCE_CD
			this.HasRequired(r1 => r1.Ref_NoteSourceCode)
				.WithMany(r2 => r2.RefMany_Note_NoteSourceCd)
				.HasForeignKey(t => t.NOTE_SOURCE_CD);
			// CATS_BOP_OWNER.NOTE.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
			this.HasRequired(r1 => r1.Ref_VClaimant)
				.WithMany(r2 => r2.RefMany_Note_PrtyId)
				.HasForeignKey(t => t.PRTY_ID);
		}

		public DbSetConfigBase_Note()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_NoteSourceCode : EntityTypeConfiguration<NOTE_SOURCE_CODE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.NOTE_SOURCE_CD);
			this.Property(p => p.LOAD_ORDER)
				.HasColumnName("LOAD_ORDER")
				.IsRequired();
			this.Property(p => p.LOAD_ORDER).IsRequired();
			this.Property(p => p.DESCRIPTION)
				.HasColumnName("DESCRIPTION")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.NOTE_SOURCE_CD)
				.HasColumnName("NOTE_SOURCE_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("NOTE_SOURCE_CODE", "CATS_BOP_OWNER");
		}

		public DbSetConfigBase_NoteSourceCode()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_NoteType : EntityTypeConfiguration<NOTE_TYPE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.NOTE_TYPE_ID);
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.NOTE_TYPE_CD)
				.HasColumnName("NOTE_TYPE_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.NOTE_ID)
				.HasColumnName("NOTE_ID")
				.IsRequired();
			this.Property(p => p.NOTE_ID).IsRequired();
			this.Property(p => p.NOTE_TYPE_ID)
				.HasColumnName("NOTE_TYPE_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.NOTE_TYPE_ID).IsRequired();
			this.ToTable("NOTE_TYPE", "CATS_BOP_OWNER");

			// Foreign key references.
			// CATS_BOP_OWNER.NOTE_TYPE.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasRequired(r1 => r1.Ref_Employee)
				.WithMany(r2 => r2.RefMany_NoteType_CreatedBy)
				.HasForeignKey(t => t.CREATED_BY);
			// CATS_BOP_OWNER.NOTE_TYPE.NOTE_TYPE_CD->CATS_BOP_OWNER.NOTE_TYPE_CODE.NOTE_TYPE_CD
			this.HasRequired(r1 => r1.Ref_NoteTypeCode)
				.WithMany(r2 => r2.RefMany_NoteType_NoteTypeCd)
				.HasForeignKey(t => t.NOTE_TYPE_CD);
		}

		public DbSetConfigBase_NoteType()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_NoteTypeCode : EntityTypeConfiguration<NOTE_TYPE_CODE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.NOTE_TYPE_CD);
			this.Property(p => p.LOAD_ORDER)
				.HasColumnName("LOAD_ORDER")
				.IsRequired();
			this.Property(p => p.LOAD_ORDER).IsRequired();
			this.Property(p => p.DESCRIPTION)
				.HasColumnName("DESCRIPTION")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.NOTE_TYPE_CD)
				.HasColumnName("NOTE_TYPE_CD")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("NOTE_TYPE_CODE", "CATS_BOP_OWNER");
		}

		public DbSetConfigBase_NoteTypeCode()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_VClaimant : EntityTypeConfiguration<V_CLAIMANT>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.PRTY_ID);
			this.Property(p => p.BAD_EMAIL_FLAG)
				.HasColumnName("BAD_EMAIL_FLAG")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.EMAIL)
				.HasColumnName("EMAIL")
				.HasMaxLength(240)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PRTY_ID)
				.HasColumnName("PRTY_ID")
				.IsRequired();
			this.Property(p => p.PRTY_ID).IsRequired();
			this.Property(p => p.MIDDLE_NAME)
				.HasColumnName("MIDDLE_NAME")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.SSN)
				.HasColumnName("SSN")
				.HasMaxLength(9)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CLI_ID)
				.HasColumnName("CLI_ID")
				.IsRequired();
			this.Property(p => p.CLI_ID).IsRequired();
			this.Property(p => p.DRIVERS_LICENSE_NUMBER)
				.HasColumnName("DRIVERS_LICENSE_NUMBER")
				.HasMaxLength(20)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.LAST_NAME)
				.HasColumnName("LAST_NAME")
				.HasMaxLength(120)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.FIRST_NAME)
				.HasColumnName("FIRST_NAME")
				.HasMaxLength(100)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.WRITE_OFF_IND)
				.HasColumnName("WRITE_OFF_IND")
				.IsRequired();
			this.Property(p => p.WRITE_OFF_IND).IsRequired();
			this.Property(p => p.MOTHERS_MAIDEN_NAME)
				.HasColumnName("MOTHERS_MAIDEN_NAME")
				.HasMaxLength(80)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.BIRTH_DT).IsRequired();
			this.Property(p => p.PID)
				.HasColumnName("PID")
				.HasMaxLength(9)
				.IsUnicode(false)
				.IsOptional();
			this.ToTable("V_CLAIMANT", "CATS_BOP_OWNER");
		}

		public DbSetConfigBase_VClaimant()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_VClaimantAddress : EntityTypeConfiguration<V_CLAIMANT_ADDRESS>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.CAU_ID);
			this.Property(p => p.CITY)
				.HasColumnName("CITY")
				.HasMaxLength(28)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.FOREIGN_STATE_OR_PROVINCE)
				.HasColumnName("FOREIGN_STATE_OR_PROVINCE")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ZIP)
				.HasColumnName("ZIP")
				.HasMaxLength(9)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ADDRESS_CLEANSED_CD)
				.HasColumnName("ADDRESS_CLEANSED_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.FOREIGN_POSTAL_CODE)
				.HasColumnName("FOREIGN_POSTAL_CODE")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CADR_ID)
				.HasColumnName("CADR_ID")
				.IsRequired();
			this.Property(p => p.CADR_ID).IsRequired();
			this.Property(p => p.CAU_ID)
				.HasColumnName("CAU_ID")
				.IsRequired();
			this.Property(p => p.CAU_ID).IsRequired();
			this.Property(p => p.PRTY_ID)
				.HasColumnName("PRTY_ID")
				.IsRequired();
			this.Property(p => p.PRTY_ID).IsRequired();
			this.Property(p => p.BAD_ADDRESS_FLAG)
				.HasColumnName("BAD_ADDRESS_FLAG")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.STATE)
				.HasColumnName("STATE")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ADDRESS1)
				.HasColumnName("ADDRESS1")
				.HasMaxLength(140)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ADDRESS2)
				.HasColumnName("ADDRESS2")
				.HasMaxLength(35)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.FOREIGN_COUNTRY)
				.HasColumnName("FOREIGN_COUNTRY")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsOptional();
			this.ToTable("V_CLAIMANT_ADDRESS", "CATS_BOP_OWNER");

			// Foreign key references.
			// CATS_BOP_OWNER.V_CLAIMANT_ADDRESS.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
			this.HasRequired(r1 => r1.Ref_VClaimant)
				.WithMany(r2 => r2.RefMany_VClaimantAddress)
				.HasForeignKey(t => t.PRTY_ID);
		}

		public DbSetConfigBase_VClaimantAddress()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_VClaimantPhone : EntityTypeConfiguration<V_CLAIMANT_PHONE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.CP_ID);
			this.Property(p => p.CP_ID)
				.HasColumnName("CP_ID")
				.IsRequired();
			this.Property(p => p.CP_ID).IsRequired();
			this.Property(p => p.CLI_ID)
				.HasColumnName("CLI_ID")
				.IsRequired();
			this.Property(p => p.CLI_ID).IsRequired();
			this.Property(p => p.PHONE)
				.HasColumnName("PHONE")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.PRTY_ID)
				.HasColumnName("PRTY_ID")
				.IsRequired();
			this.Property(p => p.PRTY_ID).IsRequired();
			this.Property(p => p.TYPE_CD)
				.HasColumnName("TYPE_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.BAD_PHONE_FLAG)
				.HasColumnName("BAD_PHONE_FLAG")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsOptional();
			this.ToTable("V_CLAIMANT_PHONE", "CATS_BOP_OWNER");

			// Foreign key references.
			// CATS_BOP_OWNER.V_CLAIMANT_PHONE.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
			this.HasRequired(r1 => r1.Ref_VClaimant)
				.WithMany(r2 => r2.RefMany_VClaimantPhone)
				.HasForeignKey(t => t.PRTY_ID);
		}

		public DbSetConfigBase_VClaimantPhone()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_VOpgroup : EntityTypeConfiguration<V_OPGROUP>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.OPGRP_ID);
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.STIM_OFFSET_RCVRY_AMT)
				.HasColumnName("STIM_OFFSET_RCVRY_AMT")
				.IsOptional();
			this.Property(p => p.STIM_OFFSET_RCVRY_AMT).IsOptional();
			this.Property(p => p.ISS_ID)
				.HasColumnName("ISS_ID")
				.IsOptional();
			this.Property(p => p.ISS_ID).IsOptional();
			this.Property(p => p.PENALTY_AMT)
				.HasColumnName("PENALTY_AMT")
				.IsRequired();
			this.Property(p => p.PENALTY_AMT).IsRequired();
			this.Property(p => p.CLM_ID)
				.HasColumnName("CLM_ID")
				.IsRequired();
			this.Property(p => p.CLM_ID).IsRequired();
			this.Property(p => p.PROGRAM_TYP)
				.HasColumnName("PROGRAM_TYP")
				.HasMaxLength(400)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.STIM_PENALTY_AMT)
				.HasColumnName("STIM_PENALTY_AMT")
				.IsOptional();
			this.Property(p => p.STIM_PENALTY_AMT).IsOptional();
			this.Property(p => p.PROSECUTION_BEG_DT).IsOptional();
			this.Property(p => p.ESTABLISH_DT).IsRequired();
			this.Property(p => p.WRITE_OFF_IND)
				.HasColumnName("WRITE_OFF_IND")
				.IsRequired();
			this.Property(p => p.WRITE_OFF_IND).IsRequired();
			this.Property(p => p.COST_AMT)
				.HasColumnName("COST_AMT")
				.IsRequired();
			this.Property(p => p.COST_AMT).IsRequired();
			this.Property(p => p.CANCEL_OP_BAL_AMT)
				.HasColumnName("CANCEL_OP_BAL_AMT")
				.IsOptional();
			this.Property(p => p.CANCEL_OP_BAL_AMT).IsOptional();
			this.Property(p => p.STATE_CD)
				.HasColumnName("STATE_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.OP_AMT)
				.HasColumnName("OP_AMT")
				.IsRequired();
			this.Property(p => p.OP_AMT).IsRequired();
			this.Property(p => p.NOTIFY_DT).IsOptional();
			this.Property(p => p.INTEREST_AMT)
				.HasColumnName("INTEREST_AMT")
				.IsRequired();
			this.Property(p => p.INTEREST_AMT).IsRequired();
			this.Property(p => p.OFFSET_RCVRY_AMT)
				.HasColumnName("OFFSET_RCVRY_AMT")
				.IsRequired();
			this.Property(p => p.OFFSET_RCVRY_AMT).IsRequired();
			this.Property(p => p.PROSECUTION_END_DT).IsOptional();
			this.Property(p => p.RECOVERY_LOGIC_CD)
				.HasColumnName("RECOVERY_LOGIC_CD")
				.IsOptional();
			this.Property(p => p.RECOVERY_LOGIC_CD).IsOptional();
			this.Property(p => p.WRITE_OFF_DT).IsOptional();
			this.Property(p => p.OPSRC_CD)
				.HasColumnName("OPSRC_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.FUND_CD)
				.HasColumnName("FUND_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.REMOVED_DT).IsOptional();
			this.Property(p => p.REQ_ISS_ID)
				.HasColumnName("REQ_ISS_ID")
				.IsRequired();
			this.Property(p => p.REQ_ISS_ID).IsRequired();
			this.Property(p => p.FRAUD_IND)
				.HasColumnName("FRAUD_IND")
				.IsOptional();
			this.Property(p => p.FRAUD_IND).IsOptional();
			this.Property(p => p.OOS_OP_DT).IsOptional();
			this.Property(p => p.PARENT_OPGRP_ID)
				.HasColumnName("PARENT_OPGRP_ID")
				.IsOptional();
			this.Property(p => p.PARENT_OPGRP_ID).IsOptional();
			this.Property(p => p.WRITTEN_OFF_AMT)
				.HasColumnName("WRITTEN_OFF_AMT")
				.IsRequired();
			this.Property(p => p.WRITTEN_OFF_AMT).IsRequired();
			this.Property(p => p.CASH_RCVRY_AMT)
				.HasColumnName("CASH_RCVRY_AMT")
				.IsRequired();
			this.Property(p => p.CASH_RCVRY_AMT).IsRequired();
			this.Property(p => p.OP_BAL_AMT)
				.HasColumnName("OP_BAL_AMT")
				.IsRequired();
			this.Property(p => p.OP_BAL_AMT).IsRequired();
			this.Property(p => p.AP_DCKT_RES_ID)
				.HasColumnName("AP_DCKT_RES_ID")
				.IsOptional();
			this.Property(p => p.AP_DCKT_RES_ID).IsOptional();
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.PROSECUTION_IND)
				.HasColumnName("PROSECUTION_IND")
				.IsOptional();
			this.Property(p => p.PROSECUTION_IND).IsOptional();
			this.Property(p => p.MAIL_IND)
				.HasColumnName("MAIL_IND")
				.IsOptional();
			this.Property(p => p.MAIL_IND).IsOptional();
			this.Property(p => p.OPCLS_CD)
				.HasColumnName("OPCLS_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.OPGRP_DSP_DT).IsOptional();
			this.Property(p => p.CHARGE_OFF_AMT)
				.HasColumnName("CHARGE_OFF_AMT")
				.IsRequired();
			this.Property(p => p.CHARGE_OFF_AMT).IsRequired();
			this.Property(p => p.WAIVE_AMT)
				.HasColumnName("WAIVE_AMT")
				.IsRequired();
			this.Property(p => p.WAIVE_AMT).IsRequired();
			this.Property(p => p.APPEAL_HOLD_IND)
				.HasColumnName("APPEAL_HOLD_IND")
				.IsOptional();
			this.Property(p => p.APPEAL_HOLD_IND).IsOptional();
			this.Property(p => p.PRTY_ID)
				.HasColumnName("PRTY_ID")
				.IsRequired();
			this.Property(p => p.PRTY_ID).IsRequired();
			this.Property(p => p.OPGRP_ID)
				.HasColumnName("OPGRP_ID")
				.IsRequired();
			this.Property(p => p.OPGRP_ID).IsRequired();
			this.Property(p => p.STIM_OP_AMT)
				.HasColumnName("STIM_OP_AMT")
				.IsOptional();
			this.Property(p => p.STIM_OP_AMT).IsOptional();
			this.Property(p => p.OPCSE_CD)
				.HasColumnName("OPCSE_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.BKCY_IND)
				.HasColumnName("BKCY_IND")
				.IsOptional();
			this.Property(p => p.BKCY_IND).IsOptional();
			this.Property(p => p.MODIFIED_DT).IsOptional();
			this.Property(p => p.FINES_AMT)
				.HasColumnName("FINES_AMT")
				.IsRequired();
			this.Property(p => p.FINES_AMT).IsRequired();
			this.Property(p => p.RSPAGT_CD)
				.HasColumnName("RSPAGT_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.CREATED_DT).IsRequired();
			this.Property(p => p.OPGRP_DSP_CD)
				.HasColumnName("OPGRP_DSP_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("V_OPGROUP", "CATS_BOP_OWNER");

			// Foreign key references.
			// CATS_BOP_OWNER.V_OPGROUP.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
			this.HasRequired(r1 => r1.Ref_VClaimant)
				.WithMany(r2 => r2.RefMany_VOpgroup_PrtyId)
				.HasForeignKey(t => t.PRTY_ID);
			// CATS_BOP_OWNER.V_OPGROUP.OPCSE_CD->CUBS_OWNER.OP_CAUSE_CODES.OPCSE_CD
			this.HasRequired(r1 => r1.Ref_OpCauseCodes)
				.WithMany(r2 => r2.RefMany_VOpgroup_OpcseCd)
				.HasForeignKey(t => t.OPCSE_CD);
			// CATS_BOP_OWNER.V_OPGROUP.OPCLS_CD->CUBS_OWNER.OP_CLASS_CODES.OPCLS_CD
			this.HasRequired(r1 => r1.Ref_OpClassCodes)
				.WithMany(r2 => r2.RefMany_VOpgroup_OpclsCd)
				.HasForeignKey(t => t.OPCLS_CD);
			// CATS_BOP_OWNER.V_OPGROUP.OPSRC_CD->CUBS_OWNER.OP_SOURCE_CODES.OPSRC_CD
			this.HasRequired(r1 => r1.Ref_OpSourceCodes)
				.WithMany(r2 => r2.RefMany_VOpgroup_OpsrcCd)
				.HasForeignKey(t => t.OPSRC_CD);
		}

		public DbSetConfigBase_VOpgroup()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_Employee : EntityTypeConfiguration<EMPLOYEE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.EMPLOYEE_ID);
			this.Property(p => p.PRONOUN_POSS)
				.HasColumnName("PRONOUN_POSS")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PRONOUN)
				.HasColumnName("PRONOUN")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.MODIFIED_TS).IsOptional();
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.USERID)
				.HasColumnName("USERID")
				.HasMaxLength(20)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.EMAILADDR)
				.HasColumnName("EMAILADDR")
				.HasMaxLength(40)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.FAX)
				.HasColumnName("FAX")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PHONE)
				.HasColumnName("PHONE")
				.HasMaxLength(10)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.DEPARTMENT)
				.HasColumnName("DEPARTMENT")
				.HasMaxLength(25)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ZIP)
				.HasColumnName("ZIP")
				.HasMaxLength(9)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.STATE)
				.HasColumnName("STATE")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CITY)
				.HasColumnName("CITY")
				.HasMaxLength(19)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ADDRESS2)
				.HasColumnName("ADDRESS2")
				.HasMaxLength(35)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ADDRESS1)
				.HasColumnName("ADDRESS1")
				.HasMaxLength(35)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.LASTNAME)
				.HasColumnName("LASTNAME")
				.HasMaxLength(25)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.FIRSTNAME)
				.HasColumnName("FIRSTNAME")
				.HasMaxLength(20)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.EMPLOYEE_ID)
				.HasColumnName("EMPLOYEE_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.EMPLOYEE_ID).IsRequired();
			this.ToTable("EMPLOYEE", "CATS_CORE_OWNER");
		}

		public DbSetConfigBase_Employee()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_VmPostalCode : EntityTypeConfiguration<VM_POSTAL_CODE>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.ZIP);
			this.Property(p => p.COUNTY_FIPS)
				.HasColumnName("COUNTY_FIPS")
				.HasMaxLength(5)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.COUNTY_NAME)
				.HasColumnName("COUNTY_NAME")
				.HasMaxLength(40)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.STATE)
				.HasColumnName("STATE")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.CITY)
				.HasColumnName("CITY")
				.HasMaxLength(28)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.ZIP)
				.HasColumnName("ZIP")
				.HasMaxLength(5)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("VM_POSTAL_CODE", "CATS_CORE_OWNER");
		}

		public DbSetConfigBase_VmPostalCode()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_LienMaster : EntityTypeConfiguration<LIEN_MASTER>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.LIEN_MASTER_ID);
			this.Property(p => p.RESTART_AMOUNT)
				.HasColumnName("RESTART_AMOUNT")
				.IsOptional();
			this.Property(p => p.RESTART_AMOUNT).IsOptional();
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.MODIFIED_DT).IsOptional();
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.CONPEN_FORCED_AMOUNT)
				.HasColumnName("CONPEN_FORCED_AMOUNT")
				.IsOptional();
			this.Property(p => p.CONPEN_FORCED_AMOUNT).IsOptional();
			this.Property(p => p.CONPEN_FILED_AMOUNT)
				.HasColumnName("CONPEN_FILED_AMOUNT")
				.IsOptional();
			this.Property(p => p.CONPEN_FILED_AMOUNT).IsOptional();
			this.Property(p => p.AMEND_IND)
				.HasColumnName("AMEND_IND")
				.IsRequired();
			this.Property(p => p.AMEND_IND).IsRequired();
			this.Property(p => p.PREV_FILED_LIEN_MASTER_ID)
				.HasColumnName("PREV_FILED_LIEN_MASTER_ID")
				.IsOptional();
			this.Property(p => p.PREV_FILED_LIEN_MASTER_ID).IsOptional();
			this.Property(p => p.PAYOFF_ID)
				.HasColumnName("PAYOFF_ID")
				.IsOptional();
			this.Property(p => p.PAYOFF_ID).IsOptional();
			this.Property(p => p.ORIGINAL_AMOUNT)
				.HasColumnName("ORIGINAL_AMOUNT")
				.IsRequired();
			this.Property(p => p.ORIGINAL_AMOUNT).IsRequired();
			this.Property(p => p.FILED_AMOUNT)
				.HasColumnName("FILED_AMOUNT")
				.IsOptional();
			this.Property(p => p.FILED_AMOUNT).IsOptional();
			this.Property(p => p.DT_PAID_OFF).IsOptional();
			this.Property(p => p.DT_ISSUED).IsOptional();
			this.Property(p => p.DT_REFILED).IsOptional();
			this.Property(p => p.DT_FILED).IsOptional();
			this.Property(p => p.DT_ESTABLISHED).IsOptional();
			this.Property(p => p.FIPS)
				.HasColumnName("FIPS")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.JUDGE)
				.HasColumnName("JUDGE")
				.HasMaxLength(50)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.CASE_NUMBER)
				.HasColumnName("CASE_NUMBER")
				.HasMaxLength(13)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ACCRUAL)
				.HasColumnName("ACCRUAL")
				.IsRequired();
			this.Property(p => p.ACCRUAL).IsRequired();
			this.Property(p => p.FILED_IND)
				.HasColumnName("FILED_IND")
				.IsRequired();
			this.Property(p => p.FILED_IND).IsRequired();
			this.Property(p => p.LIEN_STATE_CD_CHANGE_DT).IsRequired();
			this.Property(p => p.LIEN_STATE_CD)
				.HasColumnName("LIEN_STATE_CD")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.LIEN_MASTER_ID)
				.HasColumnName("LIEN_MASTER_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.LIEN_MASTER_ID).IsRequired();
			this.ToTable("LIEN_MASTER", "CATS_LEGAL_OWNER");

			// Foreign key references.
			// CATS_LEGAL_OWNER.LIEN_MASTER.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasOptional(r1 => r1.Ref_Employee)
				.WithMany(r2 => r2.RefMany_LienMaster)
				.HasForeignKey(t => t.MODIFIED_BY);
		}

		public DbSetConfigBase_LienMaster()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_LienStateHistory : EntityTypeConfiguration<LIEN_STATE_HISTORY>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.LIEN_STATE_HISTORY_ID);
			this.Property(p => p.CREATED_TS).IsRequired();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.REASON)
				.HasColumnName("REASON")
				.HasMaxLength(1000)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.LIEN_STATE_CD)
				.HasColumnName("LIEN_STATE_CD")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.ACTION_DT).IsRequired();
			this.Property(p => p.LIEN_MASTER_ID)
				.HasColumnName("LIEN_MASTER_ID")
				.IsRequired();
			this.Property(p => p.LIEN_MASTER_ID).IsRequired();
			this.Property(p => p.LIEN_STATE_HISTORY_ID)
				.HasColumnName("LIEN_STATE_HISTORY_ID")
				.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
				.IsRequired();
			this.Property(p => p.LIEN_STATE_HISTORY_ID).IsRequired();
			this.ToTable("LIEN_STATE_HISTORY", "CATS_LEGAL_OWNER");

			// Foreign key references.
			// CATS_LEGAL_OWNER.LIEN_STATE_HISTORY.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
			this.HasRequired(r1 => r1.Ref_Employee)
				.WithMany(r2 => r2.RefMany_LienStateHistory_CreatedBy)
				.HasForeignKey(t => t.CREATED_BY);
			// CATS_LEGAL_OWNER.LIEN_STATE_HISTORY.LIEN_MASTER_ID->CATS_LEGAL_OWNER.LIEN_MASTER.LIEN_MASTER_ID
			this.HasRequired(r1 => r1.Ref_LienMaster)
				.WithMany(r2 => r2.RefMany_LienStateHistory_LienMasterId)
				.HasForeignKey(t => t.LIEN_MASTER_ID);
		}

		public DbSetConfigBase_LienStateHistory()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_OpCauseCodes : EntityTypeConfiguration<OP_CAUSE_CODES>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.OPCSE_CD);
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.END_DT).IsOptional();
			this.Property(p => p.BEG_DT).IsRequired();
			this.Property(p => p.MODIFIED_DT).IsOptional();
			this.Property(p => p.OPCSE_CD)
				.HasColumnName("OPCSE_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.TXT)
				.HasColumnName("TXT")
				.HasMaxLength(200)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.CREATED_DT).IsRequired();
			this.Property(p => p.DESCR)
				.HasColumnName("DESCR")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("OP_CAUSE_CODES", "CUBS_OWNER");

			// Foreign key references.
		}

		public DbSetConfigBase_OpCauseCodes()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_OpClassCodes : EntityTypeConfiguration<OP_CLASS_CODES>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.OPCLS_CD);
			this.Property(p => p.PRIORITY)
				.HasColumnName("PRIORITY")
				.IsRequired();
			this.Property(p => p.PRIORITY).IsRequired();
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.END_DT).IsOptional();
			this.Property(p => p.BEG_DT).IsRequired();
			this.Property(p => p.CREATED_DT).IsRequired();
			this.Property(p => p.OPCLS_CD)
				.HasColumnName("OPCLS_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.MODIFIED_DT).IsOptional();
			this.Property(p => p.DESCR)
				.HasColumnName("DESCR")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("OP_CLASS_CODES", "CUBS_OWNER");

			// Foreign key references.
		}

		public DbSetConfigBase_OpClassCodes()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_OpSourceCodes : EntityTypeConfiguration<OP_SOURCE_CODES>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.OPSRC_CD);
			this.Property(p => p.DOMAIN)
				.HasColumnName("DOMAIN")
				.HasMaxLength(30)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.END_DT).IsOptional();
			this.Property(p => p.BEG_DT).IsRequired();
			this.Property(p => p.MODIFIED_DT).IsOptional();
			this.Property(p => p.OPSRC_CD)
				.HasColumnName("OPSRC_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.BC_EMPR_RQRD_IND)
				.HasColumnName("BC_EMPR_RQRD_IND")
				.IsOptional();
			this.Property(p => p.BC_EMPR_RQRD_IND).IsOptional();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.CREATED_DT).IsRequired();
			this.Property(p => p.DESCR)
				.HasColumnName("DESCR")
				.HasMaxLength(60)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("OP_SOURCE_CODES", "CUBS_OWNER");

			// Foreign key references.
		}

		public DbSetConfigBase_OpSourceCodes()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
	public partial class DbSetConfigBase_OpTransactions : EntityTypeConfiguration<OP_TRANSACTIONS>
	{
		public virtual void BeforeConfig() { }
		public virtual void AfterConfig() { }
		protected virtual void Config()
		{
			this.HasKey(t => t.OPTRANS_ID);
			this.Property(p => p.MODIFIED_DT).IsOptional();
			this.Property(p => p.CREATED_DT).IsRequired();
			this.Property(p => p.REV_IND)
				.HasColumnName("REV_IND")
				.IsRequired();
			this.Property(p => p.REV_IND).IsRequired();
			this.Property(p => p.AMT)
				.HasColumnName("AMT")
				.IsOptional();
			this.Property(p => p.AMT).IsOptional();
			this.Property(p => p.ISS_ID)
				.HasColumnName("ISS_ID")
				.IsOptional();
			this.Property(p => p.ISS_ID).IsOptional();
			this.Property(p => p.RSPAGT_CD)
				.HasColumnName("RSPAGT_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.OPCLS_CD)
				.HasColumnName("OPCLS_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.CLM_ID)
				.HasColumnName("CLM_ID")
				.IsRequired();
			this.Property(p => p.CLM_ID).IsRequired();
			this.Property(p => p.PARENT_OPTRANS_ID)
				.HasColumnName("PARENT_OPTRANS_ID")
				.IsOptional();
			this.Property(p => p.PARENT_OPTRANS_ID).IsOptional();
			this.Property(p => p.PARENT_OPGRP_ID)
				.HasColumnName("PARENT_OPGRP_ID")
				.IsOptional();
			this.Property(p => p.PARENT_OPGRP_ID).IsOptional();
			this.Property(p => p.WO_IND)
				.HasColumnName("WO_IND")
				.IsOptional();
			this.Property(p => p.WO_IND).IsOptional();
			this.Property(p => p.MDD_ID)
				.HasColumnName("MDD_ID")
				.IsOptional();
			this.Property(p => p.MDD_ID).IsOptional();
			this.Property(p => p.OPGRP_ID)
				.HasColumnName("OPGRP_ID")
				.IsOptional();
			this.Property(p => p.OPGRP_ID).IsOptional();
			this.Property(p => p.INIT_RCVRY_AMT)
				.HasColumnName("INIT_RCVRY_AMT")
				.IsOptional();
			this.Property(p => p.INIT_RCVRY_AMT).IsOptional();
			this.Property(p => p.OFFSET_RCVRY_AMT)
				.HasColumnName("OFFSET_RCVRY_AMT")
				.IsOptional();
			this.Property(p => p.OFFSET_RCVRY_AMT).IsOptional();
			this.Property(p => p.RCVRY_REV_IND)
				.HasColumnName("RCVRY_REV_IND")
				.IsOptional();
			this.Property(p => p.RCVRY_REV_IND).IsOptional();
			this.Property(p => p.PMT_TRANS_ID)
				.HasColumnName("PMT_TRANS_ID")
				.IsOptional();
			this.Property(p => p.PMT_TRANS_ID).IsOptional();
			this.Property(p => p.CONSUMED_RCVRY_AMT)
				.HasColumnName("CONSUMED_RCVRY_AMT")
				.IsOptional();
			this.Property(p => p.CONSUMED_RCVRY_AMT).IsOptional();
			this.Property(p => p.RCVRY_CD)
				.HasColumnName("RCVRY_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.ORIG_OP_AMT)
				.HasColumnName("ORIG_OP_AMT")
				.IsOptional();
			this.Property(p => p.ORIG_OP_AMT).IsOptional();
			this.Property(p => p.ADJRQC_CD)
				.HasColumnName("ADJRQC_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.SIBLING_AMT)
				.HasColumnName("SIBLING_AMT")
				.IsOptional();
			this.Property(p => p.SIBLING_AMT).IsOptional();
			this.Property(p => p.DECISION_DT).IsOptional();
			this.Property(p => p.PROCESS_STATE)
				.HasColumnName("PROCESS_STATE")
				.IsOptional();
			this.Property(p => p.PROCESS_STATE).IsOptional();
			this.Property(p => p.REQ_ISS_ID)
				.HasColumnName("REQ_ISS_ID")
				.IsRequired();
			this.Property(p => p.REQ_ISS_ID).IsRequired();
			this.Property(p => p.PENALTY_CD)
				.HasColumnName("PENALTY_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PRIORITY)
				.HasColumnName("PRIORITY")
				.IsOptional();
			this.Property(p => p.PRIORITY).IsOptional();
			this.Property(p => p.PENALTY_AMT)
				.HasColumnName("PENALTY_AMT")
				.IsOptional();
			this.Property(p => p.PENALTY_AMT).IsOptional();
			this.Property(p => p.WAIVE_AMT)
				.HasColumnName("WAIVE_AMT")
				.IsOptional();
			this.Property(p => p.WAIVE_AMT).IsOptional();
			this.Property(p => p.SETUP_BAL)
				.HasColumnName("SETUP_BAL")
				.IsOptional();
			this.Property(p => p.SETUP_BAL).IsOptional();
			this.Property(p => p.ESTABLISH_DT).IsRequired();
			this.Property(p => p.MODIFIED_BY)
				.HasColumnName("MODIFIED_BY")
				.IsOptional();
			this.Property(p => p.MODIFIED_BY).IsOptional();
			this.Property(p => p.CREATED_BY)
				.HasColumnName("CREATED_BY")
				.IsRequired();
			this.Property(p => p.CREATED_BY).IsRequired();
			this.Property(p => p.STATE_CD)
				.HasColumnName("STATE_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.RCVRY_ID)
				.HasColumnName("RCVRY_ID")
				.IsOptional();
			this.Property(p => p.RCVRY_ID).IsOptional();
			this.Property(p => p.CC_BWE_DT).IsOptional();
			this.Property(p => p.ADJREQ_ID)
				.HasColumnName("ADJREQ_ID")
				.IsOptional();
			this.Property(p => p.ADJREQ_ID).IsOptional();
			this.Property(p => p.OPCSE_CD)
				.HasColumnName("OPCSE_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.OPSRC_CD)
				.HasColumnName("OPSRC_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.PRTY_ID)
				.HasColumnName("PRTY_ID")
				.IsRequired();
			this.Property(p => p.PRTY_ID).IsRequired();
			this.Property(p => p.OPTRANS_CD)
				.HasColumnName("OPTRANS_CD")
				.HasMaxLength(2)
				.IsUnicode(false)
				.IsRequired();
			this.Property(p => p.OPTRANS_ID)
				.HasColumnName("OPTRANS_ID")
				.IsRequired();
			this.Property(p => p.OPTRANS_ID).IsRequired();
			this.Property(p => p.CANCEL_OP_BAL_AMT)
				.HasColumnName("CANCEL_OP_BAL_AMT")
				.IsOptional();
			this.Property(p => p.CANCEL_OP_BAL_AMT).IsOptional();
			this.Property(p => p.COMMENTS)
				.HasColumnName("COMMENTS")
				.HasMaxLength(50)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.PMT_PROG_CD)
				.HasColumnName("PMT_PROG_CD")
				.HasMaxLength(5)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.OFFSET_REDUCTION_AMT)
				.HasColumnName("OFFSET_REDUCTION_AMT")
				.IsOptional();
			this.Property(p => p.OFFSET_REDUCTION_AMT).IsOptional();
			this.Property(p => p.CASH_RCVRY_AMT)
				.HasColumnName("CASH_RCVRY_AMT")
				.IsOptional();
			this.Property(p => p.CASH_RCVRY_AMT).IsOptional();
			this.Property(p => p.OP_PROG_CD)
				.HasColumnName("OP_PROG_CD")
				.HasMaxLength(5)
				.IsUnicode(false)
				.IsOptional();
			this.Property(p => p.RCVRY_PRIORITY)
				.HasColumnName("RCVRY_PRIORITY")
				.IsOptional();
			this.Property(p => p.RCVRY_PRIORITY).IsOptional();
			this.Property(p => p.AVAIL_RCVRY_AMT)
				.HasColumnName("AVAIL_RCVRY_AMT")
				.IsOptional();
			this.Property(p => p.AVAIL_RCVRY_AMT).IsOptional();
			this.Property(p => p.MANUAL_TRANS_IND)
				.HasColumnName("MANUAL_TRANS_IND")
				.IsOptional();
			this.Property(p => p.MANUAL_TRANS_IND).IsOptional();
			this.Property(p => p.MANUAL_SPLIT_IND)
				.HasColumnName("MANUAL_SPLIT_IND")
				.IsOptional();
			this.Property(p => p.MANUAL_SPLIT_IND).IsOptional();
			this.Property(p => p.SIBLING_PRIORITY)
				.HasColumnName("SIBLING_PRIORITY")
				.IsOptional();
			this.Property(p => p.SIBLING_PRIORITY).IsOptional();
			this.Property(p => p.FRAUD_PARENT_OPTRANS_ID)
				.HasColumnName("FRAUD_PARENT_OPTRANS_ID")
				.IsOptional();
			this.Property(p => p.FRAUD_PARENT_OPTRANS_ID).IsOptional();
			this.Property(p => p.SPLIT_IND)
				.HasColumnName("SPLIT_IND")
				.IsOptional();
			this.Property(p => p.SPLIT_IND).IsOptional();
			this.Property(p => p.FRAUD_AMT)
				.HasColumnName("FRAUD_AMT")
				.IsOptional();
			this.Property(p => p.FRAUD_AMT).IsOptional();
			this.Property(p => p.CHARGE_OFF_AMT)
				.HasColumnName("CHARGE_OFF_AMT")
				.IsOptional();
			this.Property(p => p.CHARGE_OFF_AMT).IsOptional();
			this.Property(p => p.PARENT_SETUP_OPTRANS_ID)
				.HasColumnName("PARENT_SETUP_OPTRANS_ID")
				.IsOptional();
			this.Property(p => p.PARENT_SETUP_OPTRANS_ID).IsOptional();
			this.Property(p => p.OPTYP_CD)
				.HasColumnName("OPTYP_CD")
				.HasMaxLength(1)
				.IsUnicode(false)
				.IsRequired();
			this.ToTable("OP_TRANSACTIONS", "CUBS_OWNER");

			// Foreign key references.
			// CUBS_OWNER.OP_TRANSACTIONS.OPCSE_CD->CUBS_OWNER.OP_CAUSE_CODES.OPCSE_CD
			this.HasRequired(r1 => r1.Ref_OpCauseCodes)
				.WithMany(r2 => r2.RefMany_OpTransactions_OpcseCd)
				.HasForeignKey(t => t.OPCSE_CD);
			// CUBS_OWNER.OP_TRANSACTIONS.OPCLS_CD->CUBS_OWNER.OP_CLASS_CODES.OPCLS_CD
			this.HasRequired(r1 => r1.Ref_OpClassCodes)
				.WithMany(r2 => r2.RefMany_OpTransactions_OpclsCd)
				.HasForeignKey(t => t.OPCLS_CD);
			// CUBS_OWNER.OP_TRANSACTIONS.OPSRC_CD->CUBS_OWNER.OP_SOURCE_CODES.OPSRC_CD
			this.HasRequired(r1 => r1.Ref_OpSourceCodes)
				.WithMany(r2 => r2.RefMany_OpTransactions_OpsrcCd)
				.HasForeignKey(t => t.OPSRC_CD);
			// CUBS_OWNER.OP_TRANSACTIONS.PARENT_OPTRANS_ID->CUBS_OWNER.OP_TRANSACTIONS.OPTRANS_ID
			this.HasOptional(r1 => r1.Ref_OpTransactions_ParentOptransId)
				.WithMany(r2 => r2.RefMany_OpTransactions_ParentOptransId)
				.HasForeignKey(t => t.PARENT_OPTRANS_ID);
			// CUBS_OWNER.OP_TRANSACTIONS.FRAUD_PARENT_OPTRANS_ID->CUBS_OWNER.OP_TRANSACTIONS.OPTRANS_ID
			this.HasOptional(r1 => r1.Ref_OpTransactions_FraudParentOptransId)
				.WithMany(r2 => r2.RefMany_OpTransactions_FraudParentOptransId)
				.HasForeignKey(t => t.FRAUD_PARENT_OPTRANS_ID);
			// CUBS_OWNER.OP_TRANSACTIONS.OPGRP_ID->CATS_BOP_OWNER.V_OPGROUP.OPGRP_ID
			this.HasOptional(r1 => r1.Ref_VOpgroup)
				.WithMany(r2 => r2.RefMany_OpTransactions_OpgrpId)
				.HasForeignKey(t => t.OPGRP_ID);
		}

		public DbSetConfigBase_OpTransactions()
		{
			BeforeConfig();
			Config();
			AfterConfig();
		}
	}
}

