using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace Cats.Bop.Claimant.Data.Internals
{
	public partial class DbContextGen : System.Data.Entity.DbContext
	{
		public virtual IEnumerable<System.Int64> PKG_CatsBopOwner_ClaimantSearchPkg_Fngetclaimantsearchcount(
			 System.String inInsearch,  System.Int64 inInsearchtype)
		{
			var parms = new List<OracleParameter>();

			var parm0 = new OracleParameter("inInsearch", inInsearch);
			parm0.Direction = ParameterDirection.Input;
			parms.Add(parm0);

			var parm1 = new OracleParameter("inInsearchtype", inInsearchtype);
			parm1.Direction = ParameterDirection.Input;
			parms.Add(parm1);

			string sql = "SELECT CATS_BOP_OWNER.CLAIMANT_SEARCH_PKG.FNGETCLAIMANTSEARCHCOUNT(:inInsearch, :inInsearchtype) FROM DUAL";
			IEnumerable<System.Int64> result = this.Database.SqlQuery<System.Int64>(sql, parms.ToArray());
			return result;
		}

		public virtual int PKG_CatsBopOwner_UwAddressPkg_UpdateAddress(
			 System.Int64 inPaddrId,  System.String inPAddr1,  System.String inPAddr2,  System.String inPCity,  System.String inPState,  System.String inPZip)
		{
			var parms = new List<OracleParameter>();

			var parm0 = new OracleParameter("inPaddrId", inPaddrId);
			parm0.Direction = ParameterDirection.Input;
			parms.Add(parm0);

			var parm1 = new OracleParameter("inPAddr1", inPAddr1);
			parm1.Direction = ParameterDirection.Input;
			parms.Add(parm1);

			var parm2 = new OracleParameter("inPAddr2", inPAddr2);
			parm2.Direction = ParameterDirection.Input;
			parms.Add(parm2);

			var parm3 = new OracleParameter("inPCity", inPCity);
			parm3.Direction = ParameterDirection.Input;
			parms.Add(parm3);

			var parm4 = new OracleParameter("inPState", inPState);
			parm4.Direction = ParameterDirection.Input;
			parms.Add(parm4);

			var parm5 = new OracleParameter("inPZip", inPZip);
			parm5.Direction = ParameterDirection.Input;
			parms.Add(parm5);

			string sql = "CATS_BOP_OWNER.UW_ADDRESS_PKG.UPDATE_ADDRESS(:inPaddrId, :inPAddr1, :inPAddr2, :inPCity, :inPState, :inPZip)";
			int result = this.Database.ExecuteSqlCommand(sql, parms.ToArray());
			return result;
		}

		public virtual IEnumerable<System.String> PKG_CatsBopOwner_UwAddressPkg_ValidateAddress(
			 System.String inPAddr1,  System.String inPAddr2,  System.String inPCity,  System.String inPState,  System.String inPZip,  System.String inPUsageTypeCd)
		{
			var parms = new List<OracleParameter>();

			var parm0 = new OracleParameter("inPAddr1", inPAddr1);
			parm0.Direction = ParameterDirection.Input;
			parms.Add(parm0);

			var parm1 = new OracleParameter("inPAddr2", inPAddr2);
			parm1.Direction = ParameterDirection.Input;
			parms.Add(parm1);

			var parm2 = new OracleParameter("inPCity", inPCity);
			parm2.Direction = ParameterDirection.Input;
			parms.Add(parm2);

			var parm3 = new OracleParameter("inPState", inPState);
			parm3.Direction = ParameterDirection.Input;
			parms.Add(parm3);

			var parm4 = new OracleParameter("inPZip", inPZip);
			parm4.Direction = ParameterDirection.Input;
			parms.Add(parm4);

			var parm5 = new OracleParameter("inPUsageTypeCd", inPUsageTypeCd);
			parm5.Direction = ParameterDirection.Input;
			parms.Add(parm5);

			string sql = "SELECT CATS_BOP_OWNER.UW_ADDRESS_PKG.VALIDATE_ADDRESS(:inPAddr1, :inPAddr2, :inPCity, :inPState, :inPZip, :inPUsageTypeCd) FROM DUAL";
			IEnumerable<System.String> result = this.Database.SqlQuery<System.String>(sql, parms.ToArray());
			return result;
		}

	}
}

