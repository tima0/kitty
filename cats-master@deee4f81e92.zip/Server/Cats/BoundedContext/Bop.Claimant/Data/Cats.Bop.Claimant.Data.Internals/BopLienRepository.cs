using Cats.Bop.Claimant.Data.Interfaces;
using DwsUI.Core.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Data.Models;
using DwsUI.Core;
using System.Data.Entity;
using Cats.Core.Liens;

namespace Cats.Bop.Claimant.Data.Internals
{
	public class BopLienRepository : IBopLienRepository
	{
		private readonly Internals.DbContext _context;

		public BopLienRepository(Internals.DbContext context, ILogger logger)
		{
			_context = context;
		}

		public BopLienModel GetBopLiens(long lienId)
		{
			var query = from lienMaster in this._context.LienMaster
						join lienBop in this._context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
						join opGroup in this._context.VOpgroup on lienBop.OPGRP_ID equals opGroup.OPGRP_ID
						where lienMaster.LIEN_MASTER_ID == lienId
						group opGroup by new
						{
							lienMaster.LIEN_MASTER_ID,
							lienMaster.RESTART_AMOUNT,
							lienMaster.DT_FILED,
							lienMaster.DT_REFILED,
							lienMaster.ORIGINAL_AMOUNT,
							lienMaster.FILED_AMOUNT,
							lienMaster.CONPEN_FORCED_AMOUNT,
							lienMaster.CONPEN_FILED_AMOUNT,
							lienMaster.LIEN_STATE_CD,
							lienMaster.LIEN_STATE_CD_CHANGE_DT,
							opGroup.OPGRP_DSP_CD

						} into g
						select new BopLienModel
						{
							LienId = g.Key.LIEN_MASTER_ID,
							DateFiled = g.Key.DT_REFILED ?? g.Key.DT_FILED,
							EstablishedDate = g.Min(opGroup => opGroup.ESTABLISH_DT),
							RestartBalanceWhen28Sent = g.Key.RESTART_AMOUNT,
							CurrentRestartBalance = g.Sum(opGroup => opGroup.OP_AMT + opGroup.PENALTY_AMT), 
							ArBalance = g.Sum(opGroup => (from op in this._context.VOpgroup
														  where op.OPGRP_ID == opGroup.OPGRP_ID && DbFunctions.TruncateTime(DateTime.Now) >= DbFunctions.TruncateTime(DbFunctions.AddDays(op.ESTABLISH_DT, 17))
														  select op.OP_BAL_AMT).FirstOrDefault()),
							FiledLienAmount = g.Key.FILED_AMOUNT,

							PenaltyBalanceAmount = g.Sum(opGroup => (from op in this._context.VOpgroup
																	 where op.PRTY_ID == opGroup.PRTY_ID && op.OPGRP_ID == opGroup.OPGRP_ID
																	 select op.OP_BAL_AMT).FirstOrDefault() -

																	 (from opTrans in this._context.OpTransactions
																	  where opTrans.OPGRP_ID == opGroup.OPGRP_ID && opTrans.OPTRANS_CD == "2" && opTrans.OPTYP_CD == "I" && opTrans.REV_IND == 0
																	  select opTrans.AMT).FirstOrDefault()),

							PenaltyDueAmount = g.Sum(opGroup => this._context.VOpgroup
																	.Where((bop) => bop.PRTY_ID == opGroup.PRTY_ID && bop.OPGRP_ID == opGroup.OPGRP_ID)
																	.Select((bop) => bop.OP_AMT + bop.PENALTY_AMT).FirstOrDefault()),
							PenaltyFiledAmount = g.Key.CONPEN_FILED_AMOUNT,
							CanceledDebt = g.Key.OPGRP_DSP_CD == "Y",
							ChargeOffAmount = g.Sum(opGroup => opGroup.CHARGE_OFF_AMT),
							PenaltyForcedAmount = g.Key.CONPEN_FORCED_AMOUNT,
							LastCertifiedPaymentDate = null,//TODO this.LastCertifiedPaymentDate(g.Key.LIEN_MASTER_ID),
							LastNonCertifiedPaymentDate = null,//TODO this.LastNonCertifiedPaymentDate(g.Key.LIEN_MASTER_ID),
							BalanceChangeNeedRestart = 0,
							HasAdminHold = g.Select((opGroup => this._context.Hold
															.Count((hold) => hold.PRTY_ID == opGroup.PRTY_ID && hold.HOLD_TYPE_CD == "AD") > 0)).FirstOrDefault(),
							HasAppealHold = false, //g.Min(opGroup => this.HasAppealHold(opGroup.OPGRP_ID)),
							HasBankruptcy = false,//TODO g.Min(opGroup => this.HasBankruptcy(opGroup.OPGRP_ID)),
							HasInstallmentAgreement = false,//TODO g.Min(opGroup => this.HasInstallmentAgreement(opGroup.PRTY_ID)),
							LastActionCode = g.Key.LIEN_STATE_CD,
							LastActionDate = g.Key.LIEN_STATE_CD_CHANGE_DT,
							LienType = g.Min(opGroup => opGroup.OPCLS_CD),

							PreviousState = (from s in this._context.LienStateHistory
											 where s.LIEN_STATE_HISTORY_ID == (this._context.LienStateHistory
																			   .Where(x => x.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID /*&& x.LIEN_STATE_CD != g.Key.LIEN_STATE_CD blank previousState causes problems */)
																			   .Max(x => x.LIEN_STATE_HISTORY_ID))
											 select s.LIEN_STATE_CD).FirstOrDefault(),

							LastCorrespondenceDate = (from s in this._context.LienStateHistory
													  where s.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && (s.LIEN_STATE_CD == "28PRINTED" || s.LIEN_STATE_CD == "10DAYPRINTED")
													  select s.ACTION_DT).Max(),

							FirstWait10Day = (from s in this._context.LienStateHistory
											  where s.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && s.LIEN_STATE_CD == "WAIT10DAY" &&
												s.ACTION_DT >= ((from x in this._context.LienStateHistory
																 where x.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && x.LIEN_STATE_CD == "28PRINTED"
																 select x.ACTION_DT).DefaultIfEmpty(DbFunctions.AddDays(s.ACTION_DT, -1).Value).Max())
											  select s.ACTION_DT).Min(),

							FirstWaitToFile = (from s in this._context.LienStateHistory
											   where s.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && s.LIEN_STATE_CD == "WAITTOFILE" &&
												 s.ACTION_DT >= ((from x in this._context.LienStateHistory
																  where x.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && x.LIEN_STATE_CD == "10DAYPRINTED"
																  select x.ACTION_DT).DefaultIfEmpty(DbFunctions.AddDays(s.ACTION_DT, -1).Value).Max())
											   select s.ACTION_DT).Min()
						};

			return query.SingleOrDefault();
		}

		public IEnumerable<BopLienModel> GetBopLiens(Interfaces.BopType bopType)
		{
			var bopTypeString = ((char)int.Parse(bopType.ToString("D"))).ToString();
			var query = from lienMaster in this._context.LienMaster							
						join lienBop in this._context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
						join opGroup in this._context.VOpgroup on lienBop.OPGRP_ID equals opGroup.OPGRP_ID							
						where opGroup.OPCLS_CD == bopTypeString &&
							!(lienMaster.LIEN_STATE_CD == "WITHDRAWN" || lienMaster.LIEN_STATE_CD == "SATISFIED" || lienMaster.LIEN_STATE_CD == "ARPAID" || lienMaster.LIEN_STATE_CD == "DONOTFILE" ||
								 lienMaster.LIEN_STATE_CD == "REFILEQUEUE" || lienMaster.LIEN_STATE_CD == "NOTFILED")
						group opGroup by new
						{
							lienMaster.LIEN_MASTER_ID,
							lienMaster.RESTART_AMOUNT,
							lienMaster.DT_FILED,
							lienMaster.DT_REFILED,
							lienMaster.ORIGINAL_AMOUNT,
							lienMaster.FILED_AMOUNT,
							lienMaster.CONPEN_FORCED_AMOUNT,
							lienMaster.CONPEN_FILED_AMOUNT,
							lienMaster.LIEN_STATE_CD,
							lienMaster.LIEN_STATE_CD_CHANGE_DT,
							opGroup.OPGRP_DSP_CD
						} into g						
						select new BopLienModel
						{
							LienId = g.Key.LIEN_MASTER_ID,
							DateFiled = g.Key.DT_REFILED ?? g.Key.DT_FILED,
							EstablishedDate = g.Min(opGroup => opGroup.ESTABLISH_DT),
							RestartBalanceWhen28Sent = g.Key.RESTART_AMOUNT,
							CurrentRestartBalance = g.Sum(opGroup => opGroup.OP_AMT + opGroup.PENALTY_AMT),
							ArBalance = g.Sum(opGroup => (from op in this._context.VOpgroup
														  where op.OPGRP_ID == opGroup.OPGRP_ID && DbFunctions.TruncateTime(DateTime.Now) >= DbFunctions.TruncateTime(DbFunctions.AddDays(op.ESTABLISH_DT, 17))
														  select op.OP_BAL_AMT).FirstOrDefault()),
							FiledLienAmount = g.Key.FILED_AMOUNT,

							PenaltyBalanceAmount = g.Sum(opGroup => (from op in this._context.VOpgroup
																	 where op.PRTY_ID == opGroup.PRTY_ID && op.OPGRP_ID == opGroup.OPGRP_ID
																	 select op.OP_BAL_AMT).FirstOrDefault() -
																	 
																	 (from opTrans in this._context.OpTransactions
																	  where opTrans.OPGRP_ID == opGroup.OPGRP_ID && opTrans.OPTRANS_CD == "2" && opTrans.OPTYP_CD == "I" && opTrans.REV_IND == 0
																	  select opTrans.AMT).FirstOrDefault()),

							PenaltyDueAmount = g.Sum(opGroup => this._context.VOpgroup
																	.Where((bop) => bop.PRTY_ID == opGroup.PRTY_ID && bop.OPGRP_ID == opGroup.OPGRP_ID)
																	.Select((bop) => bop.OP_AMT + bop.PENALTY_AMT).FirstOrDefault()),
							PenaltyFiledAmount = g.Key.CONPEN_FILED_AMOUNT,
							CanceledDebt = g.Key.OPGRP_DSP_CD == "Y",
							ChargeOffAmount = g.Sum(opGroup => opGroup.CHARGE_OFF_AMT),
							PenaltyForcedAmount = g.Key.CONPEN_FORCED_AMOUNT,
							LastCertifiedPaymentDate = null,//TODO this.LastCertifiedPaymentDate(g.Key.LIEN_MASTER_ID),
							LastNonCertifiedPaymentDate = null,//TODO this.LastNonCertifiedPaymentDate(g.Key.LIEN_MASTER_ID),
							BalanceChangeNeedRestart = 0,
							HasAdminHold = g.Select((opGroup => this._context.Hold
															.Count((hold) => hold.PRTY_ID == opGroup.PRTY_ID && hold.HOLD_TYPE_CD == "AD") > 0)).FirstOrDefault(),
							HasAppealHold = false, //TODO g.Min(opGroup => this.HasAppealHold(opGroup.OPGRP_ID)),
							HasBankruptcy = false,//TODO g.Min(opGroup => this.HasBankruptcy(opGroup.OPGRP_ID)),
							HasInstallmentAgreement = false,//TODO g.Min(opGroup => this.HasInstallmentAgreement(opGroup.PRTY_ID)),
							LastActionCode = g.Key.LIEN_STATE_CD,
							LastActionDate = g.Key.LIEN_STATE_CD_CHANGE_DT,
							LienType = g.Min(opGroup => opGroup.OPCLS_CD),			

							PreviousState = (from s in this._context.LienStateHistory
											 where s.LIEN_STATE_HISTORY_ID == (this._context.LienStateHistory
																			   .Where(x => x.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID /*&& x.LIEN_STATE_CD != g.Key.LIEN_STATE_CD blank previousState causes problems */)
																			   .Max(x => x.LIEN_STATE_HISTORY_ID))
											 select s.LIEN_STATE_CD).FirstOrDefault(),

							LastCorrespondenceDate = (from s in this._context.LienStateHistory
													  where s.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && (s.LIEN_STATE_CD == "28PRINTED" || s.LIEN_STATE_CD == "10DAYPRINTED")
													  select s.ACTION_DT).Max(),

							FirstWait10Day = (from s in this._context.LienStateHistory
											  where s.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && s.LIEN_STATE_CD == "WAIT10DAY" &&
												s.ACTION_DT >= ((from x in this._context.LienStateHistory
																 where x.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && x.LIEN_STATE_CD == "28PRINTED"
																 select x.ACTION_DT).DefaultIfEmpty(DbFunctions.AddDays(s.ACTION_DT, -1).Value).Max())
											  select s.ACTION_DT).Min(),

							FirstWaitToFile = (from s in this._context.LienStateHistory
											   where s.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && s.LIEN_STATE_CD == "WAITTOFILE" &&
												 s.ACTION_DT >= ((from x in this._context.LienStateHistory
																  where x.LIEN_MASTER_ID == g.Key.LIEN_MASTER_ID && x.LIEN_STATE_CD == "10DAYPRINTED"
																  select x.ACTION_DT).DefaultIfEmpty(DbFunctions.AddDays(s.ACTION_DT, -1).Value).Max())
											   select s.ACTION_DT).Min()
						};
		
			return query.ToList();
		}

		public decimal? GetBopBalance(long bopId)
		{
			var query = from op in this._context.VOpgroup
						where op.OPGRP_ID == bopId && DbFunctions.TruncateTime(DateTime.Now) >= DbFunctions.TruncateTime(DbFunctions.AddDays(op.ESTABLISH_DT, 17))
						select op.OP_BAL_AMT;

			return query.SingleOrDefault();
		}

		public void PickupARFromPaidBopFault()
		{
			var query = from lienMaster in this._context.LienMaster
						join lienBop in this._context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
						join opGroup in this._context.VOpgroup on lienBop.OPGRP_ID equals opGroup.OPGRP_ID
						where opGroup.OPCLS_CD == "R" && lienMaster.LIEN_STATE_CD == "ARPAID"
							&& DbFunctions.TruncateTime(DateTime.Now) > DbFunctions.TruncateTime(DbFunctions.AddDays(opGroup.ESTABLISH_DT, 17))
							&& opGroup.OP_BAL_AMT > 0
						select new
						{
							PartyId = opGroup.PRTY_ID,
							BopId = opGroup.OPGRP_ID,
							BalanceAmount = opGroup.OP_BAL_AMT,
							StateCode = opGroup.OPCLS_CD,
							LienId = lienMaster.LIEN_MASTER_ID
						};

			foreach (var result in query.AsEnumerable())
			{
				UpdateLastAction(result.LienId, "AR", null, 6);
			}

		}

		public void PickupNewBopFaultAR()
		{
			var query = from opGroup in this._context.VOpgroup
						where opGroup.OPCLS_CD == "R" && opGroup.OP_BAL_AMT > 0
							&& DbFunctions.TruncateTime(DateTime.Now) > DbFunctions.TruncateTime(DbFunctions.AddDays(opGroup.ESTABLISH_DT, 15))
							&& (from lm in this._context.LienMaster
								join lienBop in this._context.LienBop on lm.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
								join op in this._context.VOpgroup on lienBop.OPGRP_ID equals op.OPGRP_ID
								where op.PRTY_ID == opGroup.PRTY_ID && (lm.LIEN_STATE_CD == "SATISFIED" || lm.LIEN_STATE_CD == "WITHDRAWN")
								select 1).Any()
							&& !((from lm in this._context.LienMaster
								  join lienBop in this._context.LienBop on lm.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
								  join op in this._context.VOpgroup on lienBop.OPGRP_ID equals op.OPGRP_ID
								  where op.PRTY_ID == opGroup.PRTY_ID && !(lm.LIEN_STATE_CD == "SATISFIED" || lm.LIEN_STATE_CD == "WITHDRAWN")
								  select 1).Any())
						select new
						{
							OpGroupId = opGroup.OPGRP_ID,
							PartyId = opGroup.PRTY_ID,
							StateCode = opGroup.OPCLS_CD,
							BalanceAmount = opGroup.OP_BAL_AMT
						};

			foreach(var result in query.AsEnumerable())
			{
				var lien = new LIEN_MASTER
				{
					LIEN_STATE_CD = "REFILEQUEUE",
					LIEN_STATE_CD_CHANGE_DT = DateTime.Now,
					FILED_IND = 0,
					FIPS = GetBopPips(result.PartyId),
					DT_ESTABLISHED = DateTime.Now,					
					ORIGINAL_AMOUNT = result.BalanceAmount,
					CREATED_TS = DateTime.Now				
				};
				this._context.LienMaster.Add(lien);
							
				var stateHistory = new LIEN_STATE_HISTORY
				{
					ACTION_DT = DateTime.Now,
					LIEN_STATE_CD = "REFILEQUEUE",
					CREATED_BY = 6,
					CREATED_TS = DateTime.Now,
					Ref_LienMaster = lien
				};
				this._context.LienStateHistory.Add(stateHistory);

				var lienBop = new LIEN_BOP
				{
					OPGRP_ID = result.OpGroupId,
					CREATED_BY = 6,
					CREATED_TS = DateTime.Now,
					Ref_LienMaster = lien
				};
				this._context.LienBop.Add(lienBop);
			}

			// TODO HasAppealHold and HasAppealHoldDelay code
			var query2 = from op in this._context.VOpgroup
							let HasAppealHold = op.OPGRP_ID < 0
							let HasAppealHoldDelay = op.OPGRP_ID < 0
					where op.OPCLS_CD == "R" && op.OP_BAL_AMT > 0
						&& !HasAppealHold
						&& !HasAppealHoldDelay
						&& DbFunctions.TruncateTime(DbFunctions.AddDays(op.ESTABLISH_DT, 18)) <= DbFunctions.TruncateTime(DateTime.Now)
						&& !((from lienBop in this._context.LienBop
								where lienBop.OPGRP_ID == op.OPGRP_ID
								select 1).Any())
					select new
					{
						OpGroupId = op.OPGRP_ID,
						PartyId = op.PRTY_ID,
						StateCode = op.OPCLS_CD,
						BalanceAmount = op.OP_BAL_AMT,
						EstablishedDate = op.ESTABLISH_DT
					};

			foreach(var result in query2.AsEnumerable())
			{
				// since we can't use .PostDate() in the query, we do it here
				var postDate = result.EstablishedDate.AddDays(18).PostDate().Date;
				if (postDate > DateTime.Now.Date)
				{
					continue;
				}

				var lien = new LIEN_MASTER
				{
					LIEN_STATE_CD = "AR",
					LIEN_STATE_CD_CHANGE_DT = DateTime.Now,
					FILED_IND = 0,
					FIPS = GetBopPips(result.PartyId),
					DT_ESTABLISHED = DateTime.Now,
					ORIGINAL_AMOUNT = result.BalanceAmount,
					CREATED_TS = DateTime.Now
				};
				this._context.LienMaster.Add(lien);

				var stateHistory = new LIEN_STATE_HISTORY
				{
					ACTION_DT = DateTime.Now,
					LIEN_STATE_CD = "AR",
					CREATED_BY = 6,
					CREATED_TS = DateTime.Now,
					Ref_LienMaster = lien
				};
				this._context.LienStateHistory.Add(stateHistory);

				var lienBop = new LIEN_BOP
				{
					OPGRP_ID = result.OpGroupId,
					CREATED_BY = 6,
					CREATED_TS = DateTime.Now,
					Ref_LienMaster = lien
				};
				this._context.LienBop.Add(lienBop);
			}

			this._context.SaveChanges();
		}

		public string GetBopPips(long partyId)
		{
			var result = string.Empty;
			var query = from zip in this._context.VmPostalCode
						join address in this._context.VClaimantAddress on zip.ZIP equals address.ZIP
						where address.PRTY_ID == partyId
						select new
						{
						Fips = zip.COUNTY_FIPS,
						State = zip.STATE
						};
			var fips = query.FirstOrDefault();
			if (fips == null || fips?.State != "UT")
			{
				result = "35";
			}
			else
			{
				result = fips.Fips;
			}

			return result;
		}

		public void PickupNewBopFraudAR()
		{
			var qry = from op in this._context.VOpgroup
					  where op.OPCLS_CD == "F" && DbFunctions.TruncateTime(DateTime.Now) > DbFunctions.TruncateTime(DbFunctions.AddDays(op.ESTABLISH_DT, 15))
					 && ( from lienMaster in _context.LienMaster
						  join lienBop in _context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
						  where lienBop.OPGRP_ID == op.OPGRP_ID && (lienMaster.LIEN_STATE_CD == "SATISFIED"  || lienMaster.LIEN_STATE_CD == "WITHDRAWN")
						  select lienMaster.LIEN_MASTER_ID).Any()
					&& !((from lienMaster in _context.LienMaster
						join lienBop in _context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
						where lienBop.OPGRP_ID == op.OPGRP_ID && (lienMaster.LIEN_STATE_CD == "SATISFIED" || lienMaster.LIEN_STATE_CD == "WITHDRAWN")
						  select lienMaster.LIEN_MASTER_ID).Any())
					select new {
						BopID = op.OPGRP_ID,
						PartyID = op.PRTY_ID,
						OPType = op.OPCLS_CD,
						Balance = op.OP_BAL_AMT };
			foreach(var op in qry.AsEnumerable())
			{
				var lien = new LIEN_MASTER
				{
					LIEN_STATE_CD = "REFILEQUEUE",
					LIEN_STATE_CD_CHANGE_DT = DateTime.Now,
					FILED_IND = 0,
					FIPS = this.GetBopPips(op.PartyID),
					DT_ESTABLISHED = DateTime.Now.Date,
					ORIGINAL_AMOUNT = op.Balance,
					CREATED_TS = DateTime.Now,
   
				};
				this._context.LienMaster.Add(lien);

				var lienHist = new LIEN_STATE_HISTORY
				{					
					Ref_LienMaster = lien,
					ACTION_DT = DateTime.Now,
					LIEN_STATE_CD = "REFILEQUEUE",
					CREATED_BY = 6, //6 = batch runner id
					CREATED_TS = DateTime.Now
				};
				this._context.LienStateHistory.Add(lienHist);

				var lienBop = new LIEN_BOP
				{
					Ref_LienMaster = lien,
					OPGRP_ID = op.BopID,
					CREATED_BY = 6,
					CREATED_TS = DateTime.Now
				};
				this._context.LienBop.Add(lienBop);
			}
		}
		public void PickupARFromPaidBopFraud()
		{
			var qry = from op in this._context.VOpgroup
					  join lienBop in _context.LienBop
					  on op.OPGRP_ID equals lienBop.LIEN_BOP_ID
					  join lm in _context.LienMaster
					  on lienBop.LIEN_MASTER_ID equals lm.LIEN_MASTER_ID
					  where (op.OPCLS_CD == "F"
						&& lm.LIEN_STATE_CD == "ARPAID"
						&& DbFunctions.TruncateTime(DateTime.Now) > DbFunctions.TruncateTime(DbFunctions.AddDays(op.ESTABLISH_DT, 17)))
					  select new { lienBop.LIEN_MASTER_ID };
			foreach( var lien in qry)
			{
				UpdateLastAction(lien.LIEN_MASTER_ID, "AR", null,  6);
			}	
		}

		public void PickupBopFraud10DayPrint()
		{
			/*
			FIRST_NAME
	FOREIGN_COUNTRY
	STATE
				ZIP
				FOREIGN_STATE_OR_PROVINCE
				FOREIGN_POSTAL_CODE
				FOREIGN_COUNTRY
				ADDRESS1
				ADDRESS2
				CITY
				tmpState
				tmpZIP
				tmpCountry
				ForeignBit
				LIENID
				PARTYID
				AMTDUE
				//
				*/
	//var qry = from this.

		//	  todo: AddressModel query.  
		}


		public void UpdateLastAction(long lienId, string lastAction, string reason, int performedBy)
		{			
			LIEN_MASTER lien = this._context.LienMaster.Single(lm => lm.LIEN_MASTER_ID == lienId);
			string priorAction = lien.LIEN_STATE_CD;
			var partyId = (from lienMaster in this._context.LienMaster
						  join lienBop in this._context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
						  join opGroup in this._context.VOpgroup on lienBop.OPGRP_ID equals opGroup.OPGRP_ID
						  where lienMaster.LIEN_MASTER_ID == lienId
						  select opGroup.PRTY_ID).SingleOrDefault();

			if (lastAction == "SENTTOFILE")
			{			
				lien.FIPS = this.GetBopPips(partyId);
			}

			if (lastAction == "MANUALAMEND" || lastAction == "SENTTOCOURT" || (lastAction == "FILED" && priorAction == "ARINCREASE"))
			{
				var query = from lienMaster in this._context.LienMaster
							join lienBop in this._context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
							join opGroup in this._context.VOpgroup on lienBop.OPGRP_ID equals opGroup.OPGRP_ID
							where lienMaster.LIEN_MASTER_ID == lienId
							group opGroup by new
							{
								lienMaster.LIEN_MASTER_ID
							} into g
							select new
							{
								Balance = g.Sum(opGroup => this.GetPenaltyDue(opGroup.PRTY_ID, opGroup.OPGRP_ID)),
							};
				lien.CONPEN_FORCED_AMOUNT = query.SingleOrDefault()?.Balance;
			}

			if (lastAction == "FILEACCEPT" || lastAction == "MANUALFILING" || lastAction == "SATISFIED" || lastAction == "WITHDRAWN" || lastAction == "FILED" || lastAction == "EXPIRED")
			{
				short isFiled = 0;
				if (lastAction == "FILEACCEPT" || lastAction == "MANUALFILING" || lastAction == "FILED")
				{
					isFiled = 1;
				}
				else if (lastAction == "SATISFIED" || lastAction == "WITHDRAWN" || lastAction == "EXPIRED" || lastAction == "SATISFIED" || lastAction == "WIDTHDRAWN")
				{
					isFiled = 0;
				}

				lien.LIEN_STATE_CD = lastAction;
				lien.LIEN_STATE_CD_CHANGE_DT = DateTime.Now;
				lien.FILED_IND = isFiled;
				lien.MODIFIED_BY = performedBy;
				lien.MODIFIED_DT = DateTime.Now;
			}
			else
			{
				lien.LIEN_STATE_CD = lastAction;
				lien.LIEN_STATE_CD_CHANGE_DT = DateTime.Now;
				lien.MODIFIED_BY = performedBy;
				lien.MODIFIED_DT = DateTime.Now;
			}

			var stateHistory = new LIEN_STATE_HISTORY
			{
				ACTION_DT = DateTime.Now,
				LIEN_STATE_CD = lastAction,
				REASON = reason,
				CREATED_BY = performedBy,
				CREATED_TS = DateTime.Now,
				Ref_LienMaster = lien
			};
			this._context.LienStateHistory.Add(stateHistory);

			if (lastAction == "SENTTOCOURT")
			{
				lien.DT_ISSUED = DateTime.Now.Date;
			}

			if (lastAction == "28PRINTED")
			{				
				var bal28 = from lienMaster in this._context.LienMaster
							join lienBop in this._context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
							join opGroup in this._context.VOpgroup on lienBop.OPGRP_ID equals opGroup.OPGRP_ID
							where lienMaster.LIEN_MASTER_ID == lienId
							group opGroup by new
							{
								lienMaster.LIEN_MASTER_ID
							} into g
							select new
							{
								Balance = g.Sum(opGroup => GetBopBalance(opGroup.OPGRP_ID))
							};

				var balance = bal28.SingleOrDefault()?.Balance;
				if (balance.HasValue)
				{
					lien.ORIGINAL_AMOUNT = balance.Value;
				}
				lien.RESTART_AMOUNT = GetRestartAmount(lienId);				
			}
			this._context.SaveChanges();
		}

		public decimal? GetRestartAmount(long lienId)
		{
			var query = from lm in this._context.LienMaster
						join lb in this._context.LienBop on lm.LIEN_MASTER_ID equals lb.LIEN_MASTER_ID
						join op in this._context.VOpgroup on lb.OPGRP_ID equals op.OPGRP_ID
						where lm.LIEN_MASTER_ID == lienId
						group op by new
						{
							lm.LIEN_MASTER_ID
						} into g
						select new
						{
							RestartAmount = g.Sum(op => op.OP_AMT + op.PENALTY_AMT)
						};

			return query.SingleOrDefault()?.RestartAmount;
		}
		
		public bool HasAdminHold(long partyId)
		{
			var result = this._context.Hold.AsNoTracking()
				.Count((hold) => hold.PRTY_ID == partyId && hold.HOLD_TYPE_CD == "AD") > 0;
			return result;
		}

		//TODO HasAppealHold
		public bool HasAppealHold(long bopId)
		{
			return false;
		}

		//TODO HasAppealHoldDelay
		public bool HasAppealHoldDelay(long bopId)
		{

			return false;
		}

		public decimal GetPenaltyBalance(long partyId, long bopId)
		{
			var balance = this._context.VOpgroup.AsNoTracking()
				.Where((op) => op.PRTY_ID == partyId && op.OPGRP_ID == bopId)
				.SingleOrDefault()?.OP_BAL_AMT ?? 0;

			var interest = this._context.OpTransactions.AsNoTracking()
				.Where((opTrans) => opTrans.OPGRP_ID == bopId && opTrans.OPTRANS_CD == "2" && opTrans.OPTYP_CD == "I" && opTrans.REV_IND == 0)
				.Sum((opTrans) => opTrans.AMT) ?? 0;

			return balance - interest;
		}

		public decimal GetPenaltyDue(long partyId, long bopId)
		{
			var result = this._context.VOpgroup.AsNoTracking()
				.Where((bop) => bop.PRTY_ID == partyId && bop.OPGRP_ID == bopId)
				.Select((bop) => bop.OP_AMT + bop.PENALTY_AMT);

			return result.Single();
		}

		public bool NonCertifiedPayment(long lienId)
		{
			// TODO: FTI OWNER TABLE
			return false;
		}

		public DateTime? LastCertifiedPaymentDate(long lienId)
		{
			// TODO: FTI OWNER TABLE
			return null;
		}

		public DateTime? LastNonCertifiedPaymentDate(long lienId)
		{
			// TODO: FTI OWNER TABLE
			return null;
		}

		public bool HasBankruptcy(long bopId)
		{
			// TODO: BK_MASTER
			return false;
		}

		public bool HasInstallmentAgreement(long partyId)
		{
			// this function sholde re-implement the stored procedure CATS_OWNER.LIEN_PACKARGE.bop_ia_ind

			// there is a three year rule in the stored procedure.  this should get the date for this.  
			DateTime v3YrFromLastCharge = this._context.VOpgroup.AsNoTracking()
				.Where(
					(grp) => grp.PRTY_ID == partyId
					&& grp.ESTABLISH_DT == this._context.VOpgroup.Max(g2 => g2.ESTABLISH_DT))
					.Select((grp) => grp.ESTABLISH_DT).Max();

			v3YrFromLastCharge = v3YrFromLastCharge.AddYears(3);

			//TODO:  need to have access to Installment agreement before we can finish this.  
			//this is a start, but it will probably change.  
//			var todo = this._context.VInatalmentAgreement.AsNoTracking()
//				.Where((bop) => bop.PRTY_ID == partyId)
//				.Select((bop) => bop.);

			return false;

		}

		public IEnumerable<BopLienLetterModel> GetBopLienLetterInfo(Interfaces.BopType bopType, StateCode stateCode)
		{
			var bopTypeString = ((char)int.Parse(bopType.ToString("D"))).ToString();
			var query = from lienMaster in this._context.LienMaster
						join lienBop in this._context.LienBop on lienMaster.LIEN_MASTER_ID equals lienBop.LIEN_MASTER_ID
						join opGroup in this._context.VOpgroup on lienBop.OPGRP_ID equals opGroup.OPGRP_ID
						join claimantAddress in this._context.VClaimantAddress on opGroup.PRTY_ID equals claimantAddress.PRTY_ID
						join party in this._context.VClaimant on opGroup.PRTY_ID equals party.PRTY_ID						
						where opGroup.OPCLS_CD == bopTypeString && lienMaster.LIEN_STATE_CD == stateCode.ToStateCodeString()
						orderby claimantAddress.ZIP
						select new BopLienLetterModel
						{
							Address1 = claimantAddress.ADDRESS1,
							Address2 = claimantAddress.ADDRESS2,
							AmountDue = (from op in this._context.VOpgroup
										 where op.OPGRP_ID == opGroup.OPGRP_ID && DbFunctions.TruncateTime(DateTime.Now) >= DbFunctions.TruncateTime(DbFunctions.AddDays(op.ESTABLISH_DT, 17))
										 select op.OP_BAL_AMT).FirstOrDefault(),
							BopId = opGroup.OPGRP_ID,
							BopType = opGroup.OPCLS_CD,
							City = claimantAddress.CITY,
							FirstName = party.FIRST_NAME,
							LastName = party.LAST_NAME,
							ForeignCountry = claimantAddress.FOREIGN_COUNTRY,
							ForeignPostalCode = claimantAddress.FOREIGN_POSTAL_CODE,
							ForeignStateOrProvince = claimantAddress.FOREIGN_STATE_OR_PROVINCE,							
							LienId = lienMaster.LIEN_MASTER_ID,
							PartyId = opGroup.PRTY_ID,
							PID = party.PID,
							SSN = party.SSN,
							State = claimantAddress.STATE,
							Zip = claimantAddress.ZIP
						};

			return query.ToList();
		}
	}
}
