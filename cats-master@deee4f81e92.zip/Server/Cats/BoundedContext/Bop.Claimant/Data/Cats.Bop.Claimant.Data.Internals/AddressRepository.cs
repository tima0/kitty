using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Data.Models;
using DwsUI.Core;
using DwsUI.Core.Logging;
using System;
using System.Linq;

namespace Cats.Bop.Claimant.Data.Internals
{
	public class AddressRepository : IAddressRepository
	{
		protected readonly Internals.DbContext _context;
		protected readonly ILogger _logger;

		public AddressRepository(Internals.DbContext context, ILogger logger)
		{
			_context = context;
			_logger = logger;
		}

		public AddressModel GetAddressByPartyId(long partyId)
		{
			using (var scope = _logger.BeginScope($"GetAddressByPartyId({partyId})"))
			{
				try
				{
					var c = _context.VClaimantAddress.AsNoTracking()
						.SingleOrDefault(x => x.Ref_VClaimant.PRTY_ID == partyId);

					return c == null ? null : new AddressModel().LoadFromVAddress(c);
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, $"Error querying Claimant Address by Party Id {partyId} from database.");
					return null;
				}
			}
		}

		public void UpdateAddress(AddressModel address)
		{
			try
			{
				var result = this._context.UpdateAddress(address);
				if (result != null)
					throw new ValidationException(result);
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Error updating Claimant Address with PartyId {address.PartyId}.");
				throw;
			}
		}
	}
}
