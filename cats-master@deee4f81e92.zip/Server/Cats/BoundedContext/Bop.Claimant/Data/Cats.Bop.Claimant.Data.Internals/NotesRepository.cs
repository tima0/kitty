using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Data.Models;
using DwsUI.Core.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;
using DwsUI.Core.Data.Collections;

namespace Cats.Bop.Claimant.Data.Internals
{
	public class NotesRepository : INotesRepository
	{
		protected readonly Internals.DbContext _context;
		protected readonly ILogger _logger;

		public NotesRepository(Internals.DbContext context, ILogger logger)
		{
			_context = context;
			_logger = logger;
		}

		public NotesDataModel GetNoteByNoteID(long NoteID)
		{
		  using (var scope = _logger.BeginScope($"GetNoteByNoteID({NoteID})"))
	   	  {
			var c2 = this._context.Note
				.AsNoTracking();

			var c = c2.SingleOrDefault(x => x.NOTE_ID == NoteID);
		  }
		  return null;
		}



		public IPagedList<NOTE> GetNotesByPartyID(long PartyID, PageListParam page, OrderListParam orderBy)
		{
			using (var scope = _logger.BeginScope($"GetNotesByPartyID({PartyID})"))
			{
				var query = this._context.Note.AsNoTracking()					
					.Where(x => x.PRTY_ID == PartyID)					
					.OrderByParam(q => (q.OrderByDescending(s => s.CREATED_TS)), orderBy);
				return PagedList<NOTE>.Create(query, page);
			}
		}
	}
}
