using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Entity;
using Cats.Bop.Claimant.Data.Internals;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Data.Models;
using System.Text.RegularExpressions;
using DwsUI.Core.Logging;
using Oracle.ManagedDataAccess.Client;
using Cats.Bop.Claimant.Data.StoredProcedure;
using Cats.Bop.Claimant.Data.Internals.Enums;
using Cats.Bop.Claimant.Internals.Enums;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;
using Cats.Core;

namespace Cats.Bop.Claimant.Data.Internals
{

	public static class ClaimantTypeExtensions
	{
		// Example conversion method.
		// Convert a single object to another type of object.
		// TODO: These entity types have changed.  Fix it.
		//public static Cats.Bop.Claimant.Data.Models.ClaimantSearchResults LoadIDSearch(this Cats.Bop.Claimant.Data.Models.ClaimantSearchResults crs, V_CLIENT vclient, V_PARTIES vparties, V_CLIENT_ADDRESS vclientaddress)
		//{
		//	crs.PrtyId = vparties.PRTY_ID;
		//	crs.PId = vparties.PID;
		//	crs.FirstName = vclient.FIRST_NAME;
		//	crs.LastName = vclient.LAST_NAME;
		//	crs.SSN = vparties.SSN;
		//	crs.Address1 = vclientaddress.ADDR1;
		//	crs.City = vclientaddress.CITY;
		//	crs.State = vclientaddress.STATE;
		//	crs.Zip = vclientaddress.ZIP;
		//	return crs;
		//}
	}


	public class ClaimantRepository : IClaimantRepository
	{
		protected readonly Internals.DbContext _context;
		protected readonly ILogger _logger;

		public ClaimantRepository(Internals.DbContext context, ILogger logger)
		{
			_context = context;
			_logger = logger;
		}

		public ClaimantSearchResults Get(int id)
		{
			throw new NotImplementedException();
			//return Context.VClientAddress.First();
		}

		public ClaimantModel GetClaimantByPartyId(long partyId)
		{
			using (var scope = _logger.BeginScope($"GetClaimant({partyId})"))
			{
				try
				{
					var c2 = this._context.VClaimant
						.AsNoTracking();

					var c = c2.SingleOrDefault(x => x.PRTY_ID == partyId);
					return c == null
						? null
						: new ClaimantModel().LoadFromVClaimant(c);
					//: new ClaimantModel()
					//{
					//	PartyId = result.PRTY_ID,
					//	PID = result.PID,
					//	SSN = result.SSN,
					//	CliId = result.CLI_ID,
					//	LastName = result.LAST_NAME,
					//	FirstName = result.FIRST_NAME,
					//	MiddleName = result.MIDDLE_NAME,
					//	Email = result.EMAIL,
					//	BadEmailFlag = result.BAD_EMAIL_FLAG,
					//	BirthDate = result.BIRTH_DT,
					//	DriversLicenseNumber = result.DRIVERS_LICENSE_NBR,
					//	MothersMaidenName = result.MOTHERS_MAIDEN_NAME,
					//	WriteOffIndicator = result.WRITE_OFF_IND != 0
					//};
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, $"Error querying Claimant by partyId {partyId} from database.");
					return null;
				}
			}
		}

		public IEnumerable<ClaimantModel> GetClaimants(int count)
		{
			using (var scope = _logger.BeginScope($"GetClaimants()"))
			{
				int c = Math.Max(100, count);
				try
				{
					var vclaimants = this._context.VClaimant
						.AsNoTracking()
						.Take(c);

					return vclaimants.ToClaimants();
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, $"Error retrieving a list of {c} Claimants from database.");
					throw;
				}
			}
		}

		public Models.EMPLOYEE GetEmployee(long id)
		{
			using (var scope = _logger.BeginScope())
			{
				try
				{
					var emp = this._context.Employee
						.FirstOrDefault(e => e.EMPLOYEE_ID.Equals(id));
					return emp;
				}
				catch (Exception ex)
				{
					_logger.LogError(ex, $"Error retrieving Employee ({id}).");
					throw;
				}
			}
		}

		public IEnumerable<ClaimantSearchResultData> GetSearchResults(string search, int page, int recordCount, string orderBy)
		{
			try
			{
				var searchType = GetSearchType(search);

				var parameters = new List<OracleParameter>();
				parameters.Add(new OracleParameter("inSearch", search));
				parameters.Add(new OracleParameter("inSearchType", searchType.GetValue<int>()));
				parameters.Add(new OracleParameter("inPage", page));
				parameters.Add(new OracleParameter("inRecordCount", recordCount));
				parameters.Add(new OracleParameter("inOrderBy", orderBy));
				parameters.Add(new OracleParameter("outResults", OracleDbType.RefCursor, System.Data.ParameterDirection.Output));

				var sql = "BEGIN CATS_BOP_OWNER.CLAIMANT_SEARCH_PKG.spDoClaimantSearch(:inSearch, :inSearchType, :inPage, :inRecordCount, :inOrderBy, :outResults); END;";

				return _context.Database
					.SqlQuery<ClaimantSearchResultData>(sql, parameters.ToArray())
					.ToList();
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Error performing search for {search} ");
				throw;
			}
		}

		public int GetSearchResultCount(string search)
		{
			try
			{
				var searchType = GetSearchType(search);

				var parameters = new List<OracleParameter>();
				parameters.Add(new OracleParameter("inSearch", search));
				parameters.Add(new OracleParameter("inSearchType", searchType.GetValue<int>()));

				var sql = "SELECT CATS_BOP_OWNER.CLAIMANT_SEARCH_PKG.fnGetClaimantSearchCount (:inSearch, :inSearchType) FROM DUAL";

				return _context.Database
					.SqlQuery<int>(sql, parameters.ToArray())
					.Single();

			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"Error performing search for {search} ");
				throw;
			}
		}

		private SearchTypeEnum GetSearchType(string search)
		{
			var searchType = SearchTypeEnum.Unknown;

			if (Regex.IsMatch(search, @"^[a-zA-Z]+$")) // Name
			{
				searchType = SearchTypeEnum.ByName;
			}
			else if (Regex.IsMatch(search, @"^[a-zA-Z0-9]+$")) // Address
			{
				searchType = SearchTypeEnum.ByAddress;
			}
			else if (Regex.IsMatch(search, @"^[0-9]+$")) // ID
			{
				searchType = SearchTypeEnum.ById;
			}
			else
			{
				throw new Exception("Unable to determine type of search");
			}

			return searchType;
		}

		public IPagedList<ClaimantSearchResults> FindClaimants(string searchTerm, PageListParam page, OrderListParam order)
		{
			string searchStr = searchTerm.ToUpper();
			var _claimantSearch = new ClaimantSearch();

			//return _claimantSearch.FakeSearch(searchStr);

			return _claimantSearch.DoClaimantSearch(searchStr, page, order, _context);

		}

		//public IGenericRepository<T> GenericRepository<T>() where T : class
		//{
		//	return new GenericRepository<T>(_context);
		//}
	}
}
