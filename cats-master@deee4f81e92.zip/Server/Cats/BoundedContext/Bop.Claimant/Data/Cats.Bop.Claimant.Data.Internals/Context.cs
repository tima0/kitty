using DwsUI.Core.Logging;

namespace Cats.Bop.Claimant.Data.Internals
{

	public partial class DbContext : DbContextGen
	{
		public DbContext(ILogger logger) : base("defaultCatsConnection", logger)
		{
		}

		//public DbSet<HOLD> Hold { get; set; }
		//public DbSet<HOLD_TYPE_CODE> HoldTypeCode { get; set; }
		//public DbSet<LIEN_BOP> LienBop { get; set; }
		//public DbSet<NOTE> Note { get; set; }
		//public DbSet<NOTE_SOURCE_CODE> NoteSourceCode { get; set; }
		//public DbSet<NOTE_TYPE> NoteType { get; set; }
		//public DbSet<NOTE_TYPE_CODE> NoteTypeCode { get; set; }
		//public DbSet<V_CLAIMANT> VClaimant { get; set; }
		//public DbSet<V_CLAIMANT_ADDRESS> VClaimantAddress { get; set; }
		//public DbSet<V_CLAIMANT_PHONE> VClaimantPhone { get; set; }
		//public DbSet<V_OPGROUP> VOpgroup { get; set; }
		//public DbSet<EMPLOYEE> Employee { get; set; }
		//public DbSet<VM_POSTAL_CODE> VmPostalCode { get; set; }
		//public DbSet<LIEN_MASTER> LienMaster { get; set; }
		//public DbSet<LIEN_STATE_HISTORY> LienStateHistory { get; set; }
		//public DbSet<OP_CAUSE_CODES> OpCauseCodes { get; set; }
		//public DbSet<OP_CLASS_CODES> OpClassCodes { get; set; }
		//public DbSet<OP_SOURCE_CODES> OpSourceCodes { get; set; }
		//public DbSet<OP_TRANSACTIONS> OpTransactions { get; set; }

	}

	public partial class DbSetConfig_Hold : DbSetConfigBase_Hold
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.HOLD table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_Hold() : base() { }
	}
	public partial class DbSetConfig_HoldTypeCode : DbSetConfigBase_HoldTypeCode
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.HOLD_TYPE_CODE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_HoldTypeCode() : base() { }
	}
	public partial class DbSetConfig_LienBop : DbSetConfigBase_LienBop
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.LIEN_BOP table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_LienBop() : base() { }
	}
	public partial class DbSetConfig_Note : DbSetConfigBase_Note
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.NOTE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_Note() : base() { }
	}
	public partial class DbSetConfig_NoteSourceCode : DbSetConfigBase_NoteSourceCode
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.NOTE_SOURCE_CODE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_NoteSourceCode() : base() { }
	}
	public partial class DbSetConfig_NoteType : DbSetConfigBase_NoteType
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.NOTE_TYPE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_NoteType() : base() { }
	}
	public partial class DbSetConfig_NoteTypeCode : DbSetConfigBase_NoteTypeCode
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.NOTE_TYPE_CODE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_NoteTypeCode() : base() { }
	}
	public partial class DbSetConfig_VClaimant : DbSetConfigBase_VClaimant
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.V_CLAIMANT table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_VClaimant() : base() { }
	}
	public partial class DbSetConfig_VClaimantAddress : DbSetConfigBase_VClaimantAddress
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.V_CLAIMANT_ADDRESS table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_VClaimantAddress() : base() { }
	}
	public partial class DbSetConfig_VClaimantPhone : DbSetConfigBase_VClaimantPhone
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.V_CLAIMANT_PHONE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_VClaimantPhone() : base() { }
	}
	public partial class DbSetConfig_VOpgroup : DbSetConfigBase_VOpgroup
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_BOP_OWNER.V_OPGROUP table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_VOpgroup() : base() { }
	}
	public partial class DbSetConfig_Employee : DbSetConfigBase_Employee
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_CORE_OWNER.EMPLOYEE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_Employee() : base() { }
	}
	public partial class DbSetConfig_VmPostalCode : DbSetConfigBase_VmPostalCode
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_CORE_OWNER.VM_POSTAL_CODE table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_VmPostalCode() : base() { }
	}
	public partial class DbSetConfig_LienMaster : DbSetConfigBase_LienMaster
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_LEGAL_OWNER.LIEN_MASTER table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_LienMaster() : base() { }
	}
	public partial class DbSetConfig_LienStateHistory : DbSetConfigBase_LienStateHistory
	{
		//Devs can use these overrides to augment the DbContext configuration for the CATS_LEGAL_OWNER.LIEN_STATE_HISTORY table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_LienStateHistory() : base() { }
	}
	public partial class DbSetConfig_OpCauseCodes : DbSetConfigBase_OpCauseCodes
	{
		//Devs can use these overrides to augment the DbContext configuration for the CUBS_OWNER.OP_CAUSE_CODES table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_OpCauseCodes() : base() { }
	}
	public partial class DbSetConfig_OpClassCodes : DbSetConfigBase_OpClassCodes
	{
		//Devs can use these overrides to augment the DbContext configuration for the CUBS_OWNER.OP_CLASS_CODES table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_OpClassCodes() : base() { }
	}
	public partial class DbSetConfig_OpSourceCodes : DbSetConfigBase_OpSourceCodes
	{
		//Devs can use these overrides to augment the DbContext configuration for the CUBS_OWNER.OP_SOURCE_CODES table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_OpSourceCodes() : base() { }
	}
	public partial class DbSetConfig_OpTransactions : DbSetConfigBase_OpTransactions
	{
		//Devs can use these overrides to augment the DbContext configuration for the CUBS_OWNER.OP_TRANSACTIONS table.
		//public override void BeforeConfig() { }
		//public override void AfterConfig() { }

		// Developers should not introduce a new .ctor.  ALWAYS OVERLOAD THE BEFORECONFIG() AND AFTERCONFIG() METHODS INSTEAD!
		// If you have to do it anyway, it should look EXACTLY like this.
		//public DbSetConfig_OpTransactions() : base() { }
	}
}

