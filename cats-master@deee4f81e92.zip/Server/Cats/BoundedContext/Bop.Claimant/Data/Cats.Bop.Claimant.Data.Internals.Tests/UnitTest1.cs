using System;
using System.Linq;
using Xunit;
using Shouldly;
using System.Collections.Generic;
using System.Data.Entity;
using Moq;
using Cats.Bop.Claimant.Data;
using Cats.Bop.Claimant.Data.Models;
using DwsUI.Core.Logging;

namespace Cats.Bop.Claimant.Data.Internals.Tests
{
	public class DbMocks
	{
		/* TODO:  This needs to be moved to a central assembly which has an EF6 Nuget reference.
		 * These have been managed in another branch.  Merge first, move afterward. */
		// From the EF6 documentation
		public static DbSet<T> MockGenericDbSet<T>(List<T> inMemoryData) where T : class
		{
			if (inMemoryData == null)
				inMemoryData = new List<T>();

			var mockDbSet = new Mock<DbSet<T>>();
			var queryableData = inMemoryData.AsQueryable();

			mockDbSet.Setup(m => m.Add(It.IsAny<T>())).Callback<T>(inMemoryData.Add);
			// Copied from EF6 documentation
			mockDbSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(queryableData.Provider);
			mockDbSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(queryableData.Expression);
			mockDbSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(queryableData.ElementType);
			mockDbSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(queryableData.GetEnumerator());
			// Per Julie Lerman, "Entity Framework In The Enterprise".  We may not want these in every case.
			mockDbSet.Setup(x => x.AsNoTracking()).Returns(mockDbSet.Object);
			mockDbSet.Setup(x => x.Include(It.IsAny<string>())).Returns(mockDbSet.Object);
			return mockDbSet.Object;

			////If you are using async in EF, you can include this but must also have the 
			//// Test Doubles classes from here: https://msdn.microsoft.com/en-us/library/dn314429.aspx#async
			//mockDbSet.As(IDbAsyncEnumerable < T >> ()
			//	.Setup(m => m.GGetAsyncEnumerator())
			//	.Returns(new TestDbAsyncEnummerator<T>(querryableData.GetEnumerator()));
			//mockDbSet.As<IQueryable<T>>()
			//	.Setup(m => m.Provider)
			//	.Returns(new TestDbAsyncQueryProvider<T>(queryableData.Provider));

			// If you choose not to mock, you can probably also use the classes here, under "Service To Be Tested"
			// https://msdn.microsoft.com/en-us/library/dn314431(v=vs.113).aspx
		}
	}

	// We should not be using an instance of DbContext because we should not be unit testing the database or the context.
	// We should be using an instance of the repository.  It requires a DbContext.  It should be provided to
	// the constructor (not injected, for now) and it should be mocked.  It should not be a real DbContext.
	// To provide a real DbContext, we would have to create NuGet references to Entity Framework, provide
	// connection info in the config file and ultimately would be testing against a real database.  All of these
	// are capital no-nos.
	public class UnitTest1
	{
		private Cats.Bop.Claimant.Data.Internals.DbContext _context;
		private ILogger _logger;
		private Cats.Bop.Claimant.Data.Interfaces.IClaimantRepository _repo;

		private List<LIEN_MASTER> CreateDefaultData()
		{
			return Enumerable.Range(0, 5)
				.Select(i =>
					new LIEN_MASTER()
					{
						ACCRUAL = Convert.ToDecimal(i) * 0.01m,
						CASE_NUMBER = i.ToString() + (i + 1).ToString() + (i + 2).ToString() + (i + 3).ToString(),
						AMEND_IND = 0,
						DT_ESTABLISHED = DateTime.Parse("2018-01-02"),
						FIPS = i.ToString() + (i + 1).ToString(),
						JUDGE = "Judy",
						ORIGINAL_AMOUNT = Convert.ToDecimal(i + 1) * 0.01m,
						LIEN_MASTER_ID = 1,
						LIEN_STATE_CD = "UT",
						RESTART_AMOUNT = Convert.ToDecimal(i + 2) * 0.01m,
						FILED_AMOUNT = Convert.ToDecimal(i) * 0.01m,
						MODIFIED_BY = 7070,
						CREATED_TS = DateTime.Parse("2018-02-03")
					})
				.ToList();
		}
				
			

		public UnitTest1()
		{
			
			this._logger = new LimboLogger();
			this._context = new Cats.Bop.Claimant.Data.Internals.DbContext(_logger);
			this._repo = new Cats.Bop.Claimant.Data.Internals.ClaimantRepository(_context, _logger);
		}

		[Fact]
		public void DbFetchTestOnLienMaster()
		{
			this._context.ShouldNotBeNull();
			var lm = this._context.LienMaster.FirstOrDefault();
			lm.ShouldNotBeNull();
			var t = lm.GetType();
			t.ShouldNotBeNull();
			var f = lm.PrimaryKeyFieldname();
			f.ShouldNotBeNull();
			var p = t.GetProperty(f);
			p.ShouldNotBeNull();
			var v = p.GetValue(lm); 
			v.ShouldNotBeNull();
			//lm.GetType().GetProperty(lm.PrimaryKeyFieldname()).GetValue(lm).ShouldNotBeNull();
		}

		[Fact]
		public void ValidationShouldSucceedOnExistingLienMasterRows()
		{
			this._context.ShouldNotBeNull();

			List<string> errorList = new List<string>();
			bool validationResult = this._context.LienMaster
				.Take(10)
				.ToList()
				.All(lm => lm.Validate(e => errorList.Add(e)));
			validationResult.ShouldBeTrue();
		}

		[Fact]
		public void MaxLengthValidationShouldPassForShortValues()
		{
			List<string> errorList = new List<string>();

			var lmList = Enumerable.Range(0, 8)
				.Select(i => new LIEN_MASTER() { FIPS = i.ToString() + (i + 1).ToString() })
				.ToList();

			bool validationResult = lmList.All(lm => lm.Validate(e => errorList.Add(e)));

			validationResult.ShouldBeTrue();
			errorList.Count().ShouldBe(0);
		}

		[Fact]
		public void MaxLengthValidationShouldFailForLongValues()
		{
			List<string> errorList = new List<string>();
			var lmList = Enumerable.Range(0, 8)
				.Select(i => new LIEN_MASTER() { FIPS = i.ToString() + (i + 1).ToString() })
				.ToList();


			lmList.ForEach(lm => lm.FIPS = lm.FIPS + "_123");
			bool validationResult = lmList.All(lm => lm.Validate(e => errorList.Add(e)));

			validationResult.ShouldBeFalse();
			errorList.Count.ShouldBeGreaterThan(0);
			errorList.First().ShouldStartWith("Length");
		}

		[Fact]
		public void MaxLengthValidationShouldPassForEmptyStrings()
		{
			List<string> errorList = new List<string>();

			var lmList = Enumerable.Range(0, 8)
				.Select(i => new LIEN_MASTER() {
					FIPS = string.Empty,
					CASE_NUMBER = string.Empty,
					LIEN_STATE_CD = string.Empty})
				.ToList();
			bool prevalidationResult = lmList.All(lm => lm.Validate(e => errorList.Add(e)));
			prevalidationResult.ShouldBeTrue();
			errorList.Count().ShouldBe(0);
		}

		[Fact]
		public void GeneralMockDbFunctionSelectTest()
		{
			var dbset = DbMocks.MockGenericDbSet<LIEN_MASTER>(this.CreateDefaultData());
			var lm = dbset
				.OrderBy(x => x.FIPS)
				.FirstOrDefault();

			lm.ShouldNotBeNull();
			lm.FIPS.ShouldBe("01");
		}

		[Fact]
		public void GeneralMockDbFunctionUpdateTest()
		{
			// Mock the DB.
			var data = this.CreateDefaultData();
			var lmDbSet = DbMocks.MockGenericDbSet<LIEN_MASTER>(data);
			var ctx = new DbContext(_logger) { LienMaster = lmDbSet };

			// Read from the DB.
			var countBeforeUpdate = ctx.LienMaster.Count(x => x.FIPS == "99");
			var lienmasterToBeChanged = ctx.LienMaster
				.OrderBy(x => x.FIPS)
				.FirstOrDefault();

			// Change a lien master and save it back.
			lienmasterToBeChanged.FIPS = "99";
			ctx.SaveChanges();

			// Requery and make sure it's changed.
			var lienmasterLowestFipsAfterUpdate = ctx.LienMaster
				.OrderBy(x => x.FIPS)
				.FirstOrDefault();
			var countAfterUpdate = ctx.LienMaster.Count(x => x.FIPS == "99");

			var lienmasterHighestFipsAfterUpdate = ctx.LienMaster
				.OrderByDescending(x => x.FIPS)
				.FirstOrDefault();

			lienmasterToBeChanged.FIPS.ShouldBe("99");
			decimal.Parse(lienmasterLowestFipsAfterUpdate.FIPS).ShouldBeGreaterThan(1m);
			decimal.Parse(lienmasterLowestFipsAfterUpdate.FIPS).ShouldBeLessThan(99m);
			decimal.Parse(lienmasterHighestFipsAfterUpdate.FIPS).ShouldBe(99m);
			countBeforeUpdate.ShouldBe(0);
			countAfterUpdate.ShouldBe(1);
		}

		[Fact]
		public void GeneralMockDbFunctionInsertTest()
		{
			// Mock the DB./
			var data = this.CreateDefaultData();
			var lmDbSet = DbMocks.MockGenericDbSet<LIEN_MASTER>(data);
			var ctx = new DbContext(_logger) { LienMaster = lmDbSet };
			var countOfMatchesBeforeInsert = ctx.LienMaster.Count(x => x.FIPS == "99");

			// Insert a new record.
			var lienmasterToInsert = (LIEN_MASTER) data.First().Clone();
			lienmasterToInsert.FIPS = "99";
			ctx.LienMaster.Add(lienmasterToInsert);
			ctx.SaveChanges();

			// Requery and make sure it's changed.
			var countOfMatchesAfterInsert = ctx.LienMaster.Count(x => x.FIPS == "99");

			countOfMatchesBeforeInsert.ShouldBe(0);
			countOfMatchesAfterInsert.ShouldBe(1);
		}
	}
}
