using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cats.Bop.Claimant.Data.Internals.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("State of Utah")]
[assembly: AssemblyProduct("Cats.Bop.Claimant.Data.Internals.Tests")]
[assembly: AssemblyCopyright("Copyright © State of Utah 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("0a774800-12fb-4072-a75b-15c68c40f1c5")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
