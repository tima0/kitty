using Cats.Bop.Claimant.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Collections;
using DwsUI.Core.ListParams;
          
namespace Cats.Bop.Claimant.Data.Interfaces
{
	public interface INotesRepository
	{
		NotesDataModel GetNoteByNoteID(long BopNoteID);
		IPagedList<NOTE> GetNotesByPartyID(long PartyID, PageListParam page, OrderListParam orderBy);
	}
}
