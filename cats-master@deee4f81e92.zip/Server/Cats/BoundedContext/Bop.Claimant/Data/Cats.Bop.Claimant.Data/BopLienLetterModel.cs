using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Models
{
    public class BopLienLetterModel
    {
		public long LienId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Address1 { get; set; }
		public string Address2 { get; set; }
		public string City { get; set; }
		public string State { get; set; }
		public string ForeignStateOrProvince { get; set; }
		public string ForeignPostalCode { get; set; }
		public string ForeignCountry { get; set; }
		public string BopType { get; set; }
		public long BopId { get; set; }
		public string SSN { get; set; }
		public long PartyId { get; set; }
		public string PID { get; set; }
		public decimal? AmountDue { get; set; }
		public string Zip { get; set; }
    }
}
