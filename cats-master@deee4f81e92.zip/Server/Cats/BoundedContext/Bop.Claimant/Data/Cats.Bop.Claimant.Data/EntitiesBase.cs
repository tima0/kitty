using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Models
{
	public interface IEntityBase
	{
	}

	public interface ICloneableEntity
	{
		EntityBase Clone();
		EntityBase DeepClone();
	}


	public abstract partial class EntityBase : IEntityBase, ICloneableEntity
	{
		public abstract void SetDirtyFields(bool value);
		public abstract bool HasDirtyFields();
		public abstract string SchemaName();
		public abstract string TableName();
		public abstract string PrimaryKeyFieldname();
		public abstract bool HasPrimaryKey();
		public abstract bool HasForeignKeys();
		public abstract IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys();
		public abstract bool HasCompositePrimaryKey();
		public virtual EntityBase Clone() { return (EntityBase)this.MemberwiseClone(); }
		public abstract EntityBase DeepClone();

		public virtual List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(EntityBase)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			return myAttributes.ToList();
		}

		public virtual bool Validate(Action<string> errorHandler = null)
		{
			bool result = true;
			var validationAttributes = GetAllAttributes()
				.Where(x => x.Attr is CatsNetModelFieldValidationAttribute);

			result = result && validationAttributes
				.All(x => ((CatsNetModelFieldValidationAttribute)x.Attr)
					.Validate(x.Prop.Name, x.Prop.GetValue(this), err => errorHandler(err)));

			return result;
		}
	}

	public abstract class HOLDBase : EntityBase, IEntityBase
	{
		public HOLDBase() { }
	}
	public abstract class HOLD_TYPE_CODEBase : EntityBase, IEntityBase
	{
		public HOLD_TYPE_CODEBase() { }
	}
	public abstract class LIEN_BOPBase : EntityBase, IEntityBase
	{
		public LIEN_BOPBase() { }
	}
	public abstract class NOTEBase : EntityBase, IEntityBase
	{
		public NOTEBase() { }
	}
	public abstract class NOTE_SOURCE_CODEBase : EntityBase, IEntityBase
	{
		public NOTE_SOURCE_CODEBase() { }
	}
	public abstract class NOTE_TYPEBase : EntityBase, IEntityBase
	{
		public NOTE_TYPEBase() { }
	}
	public abstract class NOTE_TYPE_CODEBase : EntityBase, IEntityBase
	{
		public NOTE_TYPE_CODEBase() { }
	}
	public abstract class V_CLAIMANTBase : EntityBase, IEntityBase
	{
		public V_CLAIMANTBase() { }
	}
	public abstract class V_CLAIMANT_ADDRESSBase : EntityBase, IEntityBase
	{
		public V_CLAIMANT_ADDRESSBase() { }
	}
	public abstract class V_CLAIMANT_PHONEBase : EntityBase, IEntityBase
	{
		public V_CLAIMANT_PHONEBase() { }
	}
	public abstract class V_OPGROUPBase : EntityBase, IEntityBase
	{
		public V_OPGROUPBase() { }
	}
	public abstract class EMPLOYEEBase : EntityBase, IEntityBase
	{
		public EMPLOYEEBase() { }
	}
	public abstract class VM_POSTAL_CODEBase : EntityBase, IEntityBase
	{
		public VM_POSTAL_CODEBase() { }
	}
	public abstract class LIEN_MASTERBase : EntityBase, IEntityBase
	{
		public LIEN_MASTERBase() { }
	}
	public abstract class LIEN_STATE_HISTORYBase : EntityBase, IEntityBase
	{
		public LIEN_STATE_HISTORYBase() { }
	}
	public abstract class OP_CAUSE_CODESBase : EntityBase, IEntityBase
	{
		public OP_CAUSE_CODESBase() { }
	}
	public abstract class OP_CLASS_CODESBase : EntityBase, IEntityBase
	{
		public OP_CLASS_CODESBase() { }
	}
	public abstract class OP_SOURCE_CODESBase : EntityBase, IEntityBase
	{
		public OP_SOURCE_CODESBase() { }
	}
	public abstract class OP_TRANSACTIONSBase : EntityBase, IEntityBase
	{
		public OP_TRANSACTIONSBase() { }
	}
}


