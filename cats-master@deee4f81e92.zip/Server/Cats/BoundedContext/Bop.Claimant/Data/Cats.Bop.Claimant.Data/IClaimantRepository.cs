using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;
using Cats.Bop.Claimant.Data.Models;
using Cats.Bop.Claimant.Data.StoredProcedure;
using Cats.Bop.Claimant.Data.Internals;
using Cats.Core;

namespace Cats.Bop.Claimant.Data.Interfaces
{
    public interface IClaimantRepository
    {
		ClaimantModel GetClaimantByPartyId(long partyId);
		EMPLOYEE GetEmployee(long id); 
		IEnumerable<ClaimantModel> GetClaimants(int count);
		ClaimantSearchResults Get(int Id);
		IPagedList<ClaimantSearchResults> FindClaimants(string searchTerm, PageListParam page, OrderListParam order);
		IEnumerable<ClaimantSearchResultData> GetSearchResults(string search, int page, int recordCount, string orderBy);
		int GetSearchResultCount(string search);
		//IGenericRepository<T> GenericRepository<T>() where T: class;
	}
}

