using System;

namespace Cats.Bop.Claimant
{
	public interface IHoldRepository
	{
	}
}
