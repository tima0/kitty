using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Data.Models;
using DwsUI.Core.Collections;
using DwsUI.Core.ListParams;

namespace Cats.Bop.Claimant.Data.Interfaces
{
	public interface IPhoneRepository
	{

			V_CLAIMANT_PHONE GetPhone(long partyId, string PhoneType);
		    IPagedList<V_CLAIMANT_PHONE> GetPhones(long partyId, PageListParam page, OrderListParam order);
	}


}
