using Cats.Bop.Claimant.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Interfaces
{
    public interface IAddressRepository
    {
		AddressModel GetAddressByPartyId(long partyId);
		void UpdateAddress(AddressModel address);
    }
}
