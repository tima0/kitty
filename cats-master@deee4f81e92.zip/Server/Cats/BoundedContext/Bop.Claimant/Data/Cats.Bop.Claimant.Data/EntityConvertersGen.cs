/****************************************************************************
 * WARNING!  
 * 
 * The classes in this file are for assistance only.  They are not intended
 * to be used directly or consumed blindly.  They are generated starting points
 * based on the tables in the database.  
 * 
 * The conversions herein represent conversions which will surely be needed
 * in your code.  However, you will likely need to modify your app model to 
 * conform to your business needs.  The conversions will need to be modified
 * to match.
 * 
 * Copy and paste the conversion code for the table(s) in question to your 
 * appservice code and modify it as  needed or disregard this code entirely 
 * and write your own.
 * 
 ***************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Models
{
	#region HOLD
	///// <summary> A sample app model class to go with DB table HOLD. </summary>
	//public static class HoldModel
	//{
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.DateTime?  ModifiedTs { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.DateTime  CreatedTs { get; set; }
	//	public System.DateTime?  ClosedDt { get; set; }
	//	public System.DateTime?  RemoveHoldDt { get; set; }
	//	public System.String  Reason { get; set; }
	//	public System.String  HoldTypeCd { get; set; }
	//	public System.Int64  PrtyId { get; set; }
	//	public System.Int64  HoldId { get; set; }
	//}

	///// <summary> A sample extensions class for the Hold app model. </summary>
	//public class HOLDExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static Hold ToAppModel(this HOLD entity) 
		//{
		//	return new Hold().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static Hold LoadFromEntity(this Hold appModel, HOLD entity) 
		//{
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.ModifiedTs = entity.MODIFIED_TS;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.CreatedTs = entity.CREATED_TS;
		//	appModel.ClosedDt = entity.CLOSED_DT;
		//	appModel.RemoveHoldDt = entity.REMOVE_HOLD_DT;
		//	appModel.Reason = entity.REASON;
		//	appModel.HoldTypeCd = entity.HOLD_TYPE_CD;
		//	appModel.PrtyId = entity.PRTY_ID;
		//	appModel.HoldId = entity.HOLD_ID;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static HOLD ToEntity(this Hold appModel) 
		//{
		//	return new HOLD().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static HOLD LoadFromAppModel(this HOLD entity, Hold appModel) 
		//{
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.MODIFIED_TS = appModel.ModifiedTs;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.CREATED_TS = appModel.CreatedTs;
		//	entity.CLOSED_DT = appModel.ClosedDt;
		//	entity.REMOVE_HOLD_DT = appModel.RemoveHoldDt;
		//	entity.REASON = appModel.Reason;
		//	entity.HOLD_TYPE_CD = appModel.HoldTypeCd;
		//	entity.PRTY_ID = appModel.PrtyId;
		//	entity.HOLD_ID = appModel.HoldId;
		//	return entity;
		//}
	//}
	#endregion


	#region HOLD_TYPE_CODE
	///// <summary> A sample app model class to go with DB table HOLD_TYPE_CODE. </summary>
	//public static class HoldTypeCodeModel
	//{
	//	public System.String  HoldTypeCd { get; set; }
	//	public System.String  Description { get; set; }
	//}

	///// <summary> A sample extensions class for the HoldTypeCode app model. </summary>
	//public class HOLD_TYPE_CODEExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static HoldTypeCode ToAppModel(this HOLD_TYPE_CODE entity) 
		//{
		//	return new HoldTypeCode().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static HoldTypeCode LoadFromEntity(this HoldTypeCode appModel, HOLD_TYPE_CODE entity) 
		//{
		//	appModel.HoldTypeCd = entity.HOLD_TYPE_CD;
		//	appModel.Description = entity.DESCRIPTION;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static HOLD_TYPE_CODE ToEntity(this HoldTypeCode appModel) 
		//{
		//	return new HOLD_TYPE_CODE().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static HOLD_TYPE_CODE LoadFromAppModel(this HOLD_TYPE_CODE entity, HoldTypeCode appModel) 
		//{
		//	entity.HOLD_TYPE_CD = appModel.HoldTypeCd;
		//	entity.DESCRIPTION = appModel.Description;
		//	return entity;
		//}
	//}
	#endregion


	#region LIEN_BOP
	///// <summary> A sample app model class to go with DB table LIEN_BOP. </summary>
	//public static class LienBopModel
	//{
	//	public System.DateTime  CreatedTs { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.Int64  OpgrpId { get; set; }
	//	public System.Int64  LienMasterId { get; set; }
	//	public System.Int64  LienBopId { get; set; }
	//}

	///// <summary> A sample extensions class for the LienBop app model. </summary>
	//public class LIEN_BOPExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static LienBop ToAppModel(this LIEN_BOP entity) 
		//{
		//	return new LienBop().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static LienBop LoadFromEntity(this LienBop appModel, LIEN_BOP entity) 
		//{
		//	appModel.CreatedTs = entity.CREATED_TS;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.OpgrpId = entity.OPGRP_ID;
		//	appModel.LienMasterId = entity.LIEN_MASTER_ID;
		//	appModel.LienBopId = entity.LIEN_BOP_ID;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static LIEN_BOP ToEntity(this LienBop appModel) 
		//{
		//	return new LIEN_BOP().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static LIEN_BOP LoadFromAppModel(this LIEN_BOP entity, LienBop appModel) 
		//{
		//	entity.CREATED_TS = appModel.CreatedTs;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.OPGRP_ID = appModel.OpgrpId;
		//	entity.LIEN_MASTER_ID = appModel.LienMasterId;
		//	entity.LIEN_BOP_ID = appModel.LienBopId;
		//	return entity;
		//}
	//}
	#endregion


	#region NOTE
	///// <summary> A sample app model class to go with DB table NOTE. </summary>
	//public static class NoteModel
	//{
	//	public System.Int64?  LettersLetterId { get; set; }
	//	public System.String  Imageid { get; set; }
	//	public System.DateTime?  ModifiedTs { get; set; }
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.DateTime  CreatedTs { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.String  MachineName { get; set; }
	//	public System.String  NoteContent { get; set; }
	//	public System.String  Description { get; set; }
	//	public System.String  ContactExt { get; set; }
	//	public System.String  ContactPhone { get; set; }
	//	public System.String  ContactTitle { get; set; }
	//	public System.String  ContactName { get; set; }
	//	public System.Int64  PrtyId { get; set; }
	//	public System.Int64?  GarnishmentId { get; set; }
	//	public System.Int64?  ProsecutionId { get; set; }
	//	public System.String  NoteSourceCd { get; set; }
	//	public System.Int64  NoteId { get; set; }
	//}

	///// <summary> A sample extensions class for the Note app model. </summary>
	//public class NOTEExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static Note ToAppModel(this NOTE entity) 
		//{
		//	return new Note().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static Note LoadFromEntity(this Note appModel, NOTE entity) 
		//{
		//	appModel.LettersLetterId = entity.LETTERS_LETTER_ID;
		//	appModel.Imageid = entity.IMAGEID;
		//	appModel.ModifiedTs = entity.MODIFIED_TS;
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.CreatedTs = entity.CREATED_TS;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.MachineName = entity.MACHINE_NAME;
		//	appModel.NoteContent = entity.NOTE_CONTENT;
		//	appModel.Description = entity.DESCRIPTION;
		//	appModel.ContactExt = entity.CONTACT_EXT;
		//	appModel.ContactPhone = entity.CONTACT_PHONE;
		//	appModel.ContactTitle = entity.CONTACT_TITLE;
		//	appModel.ContactName = entity.CONTACT_NAME;
		//	appModel.PrtyId = entity.PRTY_ID;
		//	appModel.GarnishmentId = entity.GARNISHMENT_ID;
		//	appModel.ProsecutionId = entity.PROSECUTION_ID;
		//	appModel.NoteSourceCd = entity.NOTE_SOURCE_CD;
		//	appModel.NoteId = entity.NOTE_ID;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static NOTE ToEntity(this Note appModel) 
		//{
		//	return new NOTE().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static NOTE LoadFromAppModel(this NOTE entity, Note appModel) 
		//{
		//	entity.LETTERS_LETTER_ID = appModel.LettersLetterId;
		//	entity.IMAGEID = appModel.Imageid;
		//	entity.MODIFIED_TS = appModel.ModifiedTs;
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.CREATED_TS = appModel.CreatedTs;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.MACHINE_NAME = appModel.MachineName;
		//	entity.NOTE_CONTENT = appModel.NoteContent;
		//	entity.DESCRIPTION = appModel.Description;
		//	entity.CONTACT_EXT = appModel.ContactExt;
		//	entity.CONTACT_PHONE = appModel.ContactPhone;
		//	entity.CONTACT_TITLE = appModel.ContactTitle;
		//	entity.CONTACT_NAME = appModel.ContactName;
		//	entity.PRTY_ID = appModel.PrtyId;
		//	entity.GARNISHMENT_ID = appModel.GarnishmentId;
		//	entity.PROSECUTION_ID = appModel.ProsecutionId;
		//	entity.NOTE_SOURCE_CD = appModel.NoteSourceCd;
		//	entity.NOTE_ID = appModel.NoteId;
		//	return entity;
		//}
	//}
	#endregion


	#region NOTE_SOURCE_CODE
	///// <summary> A sample app model class to go with DB table NOTE_SOURCE_CODE. </summary>
	//public static class NoteSourceCodeModel
	//{
	//	public System.Int64  LoadOrder { get; set; }
	//	public System.String  Description { get; set; }
	//	public System.String  NoteSourceCd { get; set; }
	//}

	///// <summary> A sample extensions class for the NoteSourceCode app model. </summary>
	//public class NOTE_SOURCE_CODEExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static NoteSourceCode ToAppModel(this NOTE_SOURCE_CODE entity) 
		//{
		//	return new NoteSourceCode().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static NoteSourceCode LoadFromEntity(this NoteSourceCode appModel, NOTE_SOURCE_CODE entity) 
		//{
		//	appModel.LoadOrder = entity.LOAD_ORDER;
		//	appModel.Description = entity.DESCRIPTION;
		//	appModel.NoteSourceCd = entity.NOTE_SOURCE_CD;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static NOTE_SOURCE_CODE ToEntity(this NoteSourceCode appModel) 
		//{
		//	return new NOTE_SOURCE_CODE().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static NOTE_SOURCE_CODE LoadFromAppModel(this NOTE_SOURCE_CODE entity, NoteSourceCode appModel) 
		//{
		//	entity.LOAD_ORDER = appModel.LoadOrder;
		//	entity.DESCRIPTION = appModel.Description;
		//	entity.NOTE_SOURCE_CD = appModel.NoteSourceCd;
		//	return entity;
		//}
	//}
	#endregion


	#region NOTE_TYPE
	///// <summary> A sample app model class to go with DB table NOTE_TYPE. </summary>
	//public static class NoteTypeModel
	//{
	//	public System.DateTime  CreatedTs { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.String  NoteTypeCd { get; set; }
	//	public System.Int64  NoteId { get; set; }
	//	public System.Int64  NoteTypeId { get; set; }
	//}

	///// <summary> A sample extensions class for the NoteType app model. </summary>
	//public class NOTE_TYPEExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static NoteType ToAppModel(this NOTE_TYPE entity) 
		//{
		//	return new NoteType().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static NoteType LoadFromEntity(this NoteType appModel, NOTE_TYPE entity) 
		//{
		//	appModel.CreatedTs = entity.CREATED_TS;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.NoteTypeCd = entity.NOTE_TYPE_CD;
		//	appModel.NoteId = entity.NOTE_ID;
		//	appModel.NoteTypeId = entity.NOTE_TYPE_ID;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static NOTE_TYPE ToEntity(this NoteType appModel) 
		//{
		//	return new NOTE_TYPE().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static NOTE_TYPE LoadFromAppModel(this NOTE_TYPE entity, NoteType appModel) 
		//{
		//	entity.CREATED_TS = appModel.CreatedTs;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.NOTE_TYPE_CD = appModel.NoteTypeCd;
		//	entity.NOTE_ID = appModel.NoteId;
		//	entity.NOTE_TYPE_ID = appModel.NoteTypeId;
		//	return entity;
		//}
	//}
	#endregion


	#region NOTE_TYPE_CODE
	///// <summary> A sample app model class to go with DB table NOTE_TYPE_CODE. </summary>
	//public static class NoteTypeCodeModel
	//{
	//	public System.Int64  LoadOrder { get; set; }
	//	public System.String  Description { get; set; }
	//	public System.String  NoteTypeCd { get; set; }
	//}

	///// <summary> A sample extensions class for the NoteTypeCode app model. </summary>
	//public class NOTE_TYPE_CODEExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static NoteTypeCode ToAppModel(this NOTE_TYPE_CODE entity) 
		//{
		//	return new NoteTypeCode().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static NoteTypeCode LoadFromEntity(this NoteTypeCode appModel, NOTE_TYPE_CODE entity) 
		//{
		//	appModel.LoadOrder = entity.LOAD_ORDER;
		//	appModel.Description = entity.DESCRIPTION;
		//	appModel.NoteTypeCd = entity.NOTE_TYPE_CD;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static NOTE_TYPE_CODE ToEntity(this NoteTypeCode appModel) 
		//{
		//	return new NOTE_TYPE_CODE().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static NOTE_TYPE_CODE LoadFromAppModel(this NOTE_TYPE_CODE entity, NoteTypeCode appModel) 
		//{
		//	entity.LOAD_ORDER = appModel.LoadOrder;
		//	entity.DESCRIPTION = appModel.Description;
		//	entity.NOTE_TYPE_CD = appModel.NoteTypeCd;
		//	return entity;
		//}
	//}
	#endregion


	#region V_CLAIMANT
	///// <summary> A sample app model class to go with DB table V_CLAIMANT. </summary>
	//public static class VClaimantModel
	//{
	//	public System.String  BadEmailFlag { get; set; }
	//	public System.String  Email { get; set; }
	//	public System.Int64  PrtyId { get; set; }
	//	public System.String  MiddleName { get; set; }
	//	public System.String  Ssn { get; set; }
	//	public System.Int64  CliId { get; set; }
	//	public System.String  DriversLicenseNumber { get; set; }
	//	public System.String  LastName { get; set; }
	//	public System.String  FirstName { get; set; }
	//	public System.Int16  WriteOffInd { get; set; }
	//	public System.String  MothersMaidenName { get; set; }
	//	public System.DateTime  BirthDt { get; set; }
	//	public System.String  Pid { get; set; }
	//}

	///// <summary> A sample extensions class for the VClaimant app model. </summary>
	//public class V_CLAIMANTExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static VClaimant ToAppModel(this V_CLAIMANT entity) 
		//{
		//	return new VClaimant().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static VClaimant LoadFromEntity(this VClaimant appModel, V_CLAIMANT entity) 
		//{
		//	appModel.BadEmailFlag = entity.BAD_EMAIL_FLAG;
		//	appModel.Email = entity.EMAIL;
		//	appModel.PrtyId = entity.PRTY_ID;
		//	appModel.MiddleName = entity.MIDDLE_NAME;
		//	appModel.Ssn = entity.SSN;
		//	appModel.CliId = entity.CLI_ID;
		//	appModel.DriversLicenseNumber = entity.DRIVERS_LICENSE_NUMBER;
		//	appModel.LastName = entity.LAST_NAME;
		//	appModel.FirstName = entity.FIRST_NAME;
		//	appModel.WriteOffInd = entity.WRITE_OFF_IND;
		//	appModel.MothersMaidenName = entity.MOTHERS_MAIDEN_NAME;
		//	appModel.BirthDt = entity.BIRTH_DT;
		//	appModel.Pid = entity.PID;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static V_CLAIMANT ToEntity(this VClaimant appModel) 
		//{
		//	return new V_CLAIMANT().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static V_CLAIMANT LoadFromAppModel(this V_CLAIMANT entity, VClaimant appModel) 
		//{
		//	entity.BAD_EMAIL_FLAG = appModel.BadEmailFlag;
		//	entity.EMAIL = appModel.Email;
		//	entity.PRTY_ID = appModel.PrtyId;
		//	entity.MIDDLE_NAME = appModel.MiddleName;
		//	entity.SSN = appModel.Ssn;
		//	entity.CLI_ID = appModel.CliId;
		//	entity.DRIVERS_LICENSE_NUMBER = appModel.DriversLicenseNumber;
		//	entity.LAST_NAME = appModel.LastName;
		//	entity.FIRST_NAME = appModel.FirstName;
		//	entity.WRITE_OFF_IND = appModel.WriteOffInd;
		//	entity.MOTHERS_MAIDEN_NAME = appModel.MothersMaidenName;
		//	entity.BIRTH_DT = appModel.BirthDt;
		//	entity.PID = appModel.Pid;
		//	return entity;
		//}
	//}
	#endregion


	#region V_CLAIMANT_ADDRESS
	///// <summary> A sample app model class to go with DB table V_CLAIMANT_ADDRESS. </summary>
	//public static class VClaimantAddressModel
	//{
	//	public System.String  City { get; set; }
	//	public System.String  ForeignStateOrProvince { get; set; }
	//	public System.String  Zip { get; set; }
	//	public System.String  AddressCleansedCd { get; set; }
	//	public System.Int64  CadrId { get; set; }
	//	public System.Int64  CauId { get; set; }
	//	public System.Int64  PrtyId { get; set; }
	//	public System.String  BadAddressFlag { get; set; }
	//	public System.String  State { get; set; }
	//	public System.String  Address1 { get; set; }
	//	public System.String  Address2 { get; set; }
	//}

	///// <summary> A sample extensions class for the VClaimantAddress app model. </summary>
	//public class V_CLAIMANT_ADDRESSExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static VClaimantAddress ToAppModel(this V_CLAIMANT_ADDRESS entity) 
		//{
		//	return new VClaimantAddress().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static VClaimantAddress LoadFromEntity(this VClaimantAddress appModel, V_CLAIMANT_ADDRESS entity) 
		//{
		//	appModel.City = entity.CITY;
		//	appModel.ForeignStateOrProvince = entity.FOREIGN_STATE_OR_PROVINCE;
		//	appModel.Zip = entity.ZIP;
		//	appModel.AddressCleansedCd = entity.ADDRESS_CLEANSED_CD;
		//	appModel.CadrId = entity.CADR_ID;
		//	appModel.CauId = entity.CAU_ID;
		//	appModel.PrtyId = entity.PRTY_ID;
		//	appModel.BadAddressFlag = entity.BAD_ADDRESS_FLAG;
		//	appModel.State = entity.STATE;
		//	appModel.Address1 = entity.ADDRESS1;
		//	appModel.Address2 = entity.ADDRESS2;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static V_CLAIMANT_ADDRESS ToEntity(this VClaimantAddress appModel) 
		//{
		//	return new V_CLAIMANT_ADDRESS().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static V_CLAIMANT_ADDRESS LoadFromAppModel(this V_CLAIMANT_ADDRESS entity, VClaimantAddress appModel) 
		//{
		//	entity.CITY = appModel.City;
		//	entity.FOREIGN_STATE_OR_PROVINCE = appModel.ForeignStateOrProvince;
		//	entity.ZIP = appModel.Zip;
		//	entity.ADDRESS_CLEANSED_CD = appModel.AddressCleansedCd;
		//	entity.CADR_ID = appModel.CadrId;
		//	entity.CAU_ID = appModel.CauId;
		//	entity.PRTY_ID = appModel.PrtyId;
		//	entity.BAD_ADDRESS_FLAG = appModel.BadAddressFlag;
		//	entity.STATE = appModel.State;
		//	entity.ADDRESS1 = appModel.Address1;
		//	entity.ADDRESS2 = appModel.Address2;
		//	return entity;
		//}
	//}
	#endregion


	#region V_CLAIMANT_PHONE
	///// <summary> A sample app model class to go with DB table V_CLAIMANT_PHONE. </summary>
	//public static class VClaimantPhoneModel
	//{
	//	public System.Int64  CpId { get; set; }
	//	public System.Int64  CliId { get; set; }
	//	public System.String  Phone { get; set; }
	//	public System.Int64  PrtyId { get; set; }
	//	public System.String  TypeCd { get; set; }
	//	public System.String  BadPhoneFlag { get; set; }
	//}

	///// <summary> A sample extensions class for the VClaimantPhone app model. </summary>
	//public class V_CLAIMANT_PHONEExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static VClaimantPhone ToAppModel(this V_CLAIMANT_PHONE entity) 
		//{
		//	return new VClaimantPhone().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static VClaimantPhone LoadFromEntity(this VClaimantPhone appModel, V_CLAIMANT_PHONE entity) 
		//{
		//	appModel.CpId = entity.CP_ID;
		//	appModel.CliId = entity.CLI_ID;
		//	appModel.Phone = entity.PHONE;
		//	appModel.PrtyId = entity.PRTY_ID;
		//	appModel.TypeCd = entity.TYPE_CD;
		//	appModel.BadPhoneFlag = entity.BAD_PHONE_FLAG;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static V_CLAIMANT_PHONE ToEntity(this VClaimantPhone appModel) 
		//{
		//	return new V_CLAIMANT_PHONE().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static V_CLAIMANT_PHONE LoadFromAppModel(this V_CLAIMANT_PHONE entity, VClaimantPhone appModel) 
		//{
		//	entity.CP_ID = appModel.CpId;
		//	entity.CLI_ID = appModel.CliId;
		//	entity.PHONE = appModel.Phone;
		//	entity.PRTY_ID = appModel.PrtyId;
		//	entity.TYPE_CD = appModel.TypeCd;
		//	entity.BAD_PHONE_FLAG = appModel.BadPhoneFlag;
		//	return entity;
		//}
	//}
	#endregion


	#region V_OPGROUP
	///// <summary> A sample app model class to go with DB table V_OPGROUP. </summary>
	//public static class VOpgroupModel
	//{
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.Decimal?  StimOffsetRcvryAmt { get; set; }
	//	public System.Int64?  IssId { get; set; }
	//	public System.Decimal  PenaltyAmt { get; set; }
	//	public System.Int64  ClmId { get; set; }
	//	public System.String  ProgramTyp { get; set; }
	//	public System.Decimal?  StimPenaltyAmt { get; set; }
	//	public System.DateTime?  ProsecutionBegDt { get; set; }
	//	public System.DateTime  EstablishDt { get; set; }
	//	public System.Int16  WriteOffInd { get; set; }
	//	public System.Decimal  CostAmt { get; set; }
	//	public System.Decimal?  CancelOpBalAmt { get; set; }
	//	public System.String  StateCd { get; set; }
	//	public System.Decimal  OpAmt { get; set; }
	//	public System.DateTime?  NotifyDt { get; set; }
	//	public System.Decimal  InterestAmt { get; set; }
	//	public System.Decimal  OffsetRcvryAmt { get; set; }
	//	public System.DateTime?  ProsecutionEndDt { get; set; }
	//	public System.Int64?  RecoveryLogicCd { get; set; }
	//	public System.DateTime?  WriteOffDt { get; set; }
	//	public System.String  OpsrcCd { get; set; }
	//	public System.String  FundCd { get; set; }
	//	public System.DateTime?  RemovedDt { get; set; }
	//	public System.Int64  ReqIssId { get; set; }
	//	public System.Int16?  FraudInd { get; set; }
	//	public System.DateTime?  OosOpDt { get; set; }
	//	public System.Int64?  ParentOpgrpId { get; set; }
	//	public System.Decimal  WrittenOffAmt { get; set; }
	//	public System.Decimal  CashRcvryAmt { get; set; }
	//	public System.Decimal  OpBalAmt { get; set; }
	//	public System.Int64?  ApDcktResId { get; set; }
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.Int16?  ProsecutionInd { get; set; }
	//	public System.Int16?  MailInd { get; set; }
	//	public System.String  OpclsCd { get; set; }
	//	public System.DateTime?  OpgrpDspDt { get; set; }
	//	public System.Decimal  ChargeOffAmt { get; set; }
	//	public System.Decimal  WaiveAmt { get; set; }
	//	public System.Int16?  AppealHoldInd { get; set; }
	//	public System.Int64  PrtyId { get; set; }
	//	public System.Int64  OpgrpId { get; set; }
	//	public System.Decimal?  StimOpAmt { get; set; }
	//	public System.String  OpcseCd { get; set; }
	//	public System.Int16?  BkcyInd { get; set; }
	//	public System.DateTime?  ModifiedDt { get; set; }
	//	public System.Decimal  FinesAmt { get; set; }
	//	public System.String  RspagtCd { get; set; }
	//	public System.DateTime  CreatedDt { get; set; }
	//	public System.String  OpgrpDspCd { get; set; }
	//}

	///// <summary> A sample extensions class for the VOpgroup app model. </summary>
	//public class V_OPGROUPExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static VOpgroup ToAppModel(this V_OPGROUP entity) 
		//{
		//	return new VOpgroup().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static VOpgroup LoadFromEntity(this VOpgroup appModel, V_OPGROUP entity) 
		//{
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.StimOffsetRcvryAmt = entity.STIM_OFFSET_RCVRY_AMT;
		//	appModel.IssId = entity.ISS_ID;
		//	appModel.PenaltyAmt = entity.PENALTY_AMT;
		//	appModel.ClmId = entity.CLM_ID;
		//	appModel.ProgramTyp = entity.PROGRAM_TYP;
		//	appModel.StimPenaltyAmt = entity.STIM_PENALTY_AMT;
		//	appModel.ProsecutionBegDt = entity.PROSECUTION_BEG_DT;
		//	appModel.EstablishDt = entity.ESTABLISH_DT;
		//	appModel.WriteOffInd = entity.WRITE_OFF_IND;
		//	appModel.CostAmt = entity.COST_AMT;
		//	appModel.CancelOpBalAmt = entity.CANCEL_OP_BAL_AMT;
		//	appModel.StateCd = entity.STATE_CD;
		//	appModel.OpAmt = entity.OP_AMT;
		//	appModel.NotifyDt = entity.NOTIFY_DT;
		//	appModel.InterestAmt = entity.INTEREST_AMT;
		//	appModel.OffsetRcvryAmt = entity.OFFSET_RCVRY_AMT;
		//	appModel.ProsecutionEndDt = entity.PROSECUTION_END_DT;
		//	appModel.RecoveryLogicCd = entity.RECOVERY_LOGIC_CD;
		//	appModel.WriteOffDt = entity.WRITE_OFF_DT;
		//	appModel.OpsrcCd = entity.OPSRC_CD;
		//	appModel.FundCd = entity.FUND_CD;
		//	appModel.RemovedDt = entity.REMOVED_DT;
		//	appModel.ReqIssId = entity.REQ_ISS_ID;
		//	appModel.FraudInd = entity.FRAUD_IND;
		//	appModel.OosOpDt = entity.OOS_OP_DT;
		//	appModel.ParentOpgrpId = entity.PARENT_OPGRP_ID;
		//	appModel.WrittenOffAmt = entity.WRITTEN_OFF_AMT;
		//	appModel.CashRcvryAmt = entity.CASH_RCVRY_AMT;
		//	appModel.OpBalAmt = entity.OP_BAL_AMT;
		//	appModel.ApDcktResId = entity.AP_DCKT_RES_ID;
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.ProsecutionInd = entity.PROSECUTION_IND;
		//	appModel.MailInd = entity.MAIL_IND;
		//	appModel.OpclsCd = entity.OPCLS_CD;
		//	appModel.OpgrpDspDt = entity.OPGRP_DSP_DT;
		//	appModel.ChargeOffAmt = entity.CHARGE_OFF_AMT;
		//	appModel.WaiveAmt = entity.WAIVE_AMT;
		//	appModel.AppealHoldInd = entity.APPEAL_HOLD_IND;
		//	appModel.PrtyId = entity.PRTY_ID;
		//	appModel.OpgrpId = entity.OPGRP_ID;
		//	appModel.StimOpAmt = entity.STIM_OP_AMT;
		//	appModel.OpcseCd = entity.OPCSE_CD;
		//	appModel.BkcyInd = entity.BKCY_IND;
		//	appModel.ModifiedDt = entity.MODIFIED_DT;
		//	appModel.FinesAmt = entity.FINES_AMT;
		//	appModel.RspagtCd = entity.RSPAGT_CD;
		//	appModel.CreatedDt = entity.CREATED_DT;
		//	appModel.OpgrpDspCd = entity.OPGRP_DSP_CD;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static V_OPGROUP ToEntity(this VOpgroup appModel) 
		//{
		//	return new V_OPGROUP().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static V_OPGROUP LoadFromAppModel(this V_OPGROUP entity, VOpgroup appModel) 
		//{
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.STIM_OFFSET_RCVRY_AMT = appModel.StimOffsetRcvryAmt;
		//	entity.ISS_ID = appModel.IssId;
		//	entity.PENALTY_AMT = appModel.PenaltyAmt;
		//	entity.CLM_ID = appModel.ClmId;
		//	entity.PROGRAM_TYP = appModel.ProgramTyp;
		//	entity.STIM_PENALTY_AMT = appModel.StimPenaltyAmt;
		//	entity.PROSECUTION_BEG_DT = appModel.ProsecutionBegDt;
		//	entity.ESTABLISH_DT = appModel.EstablishDt;
		//	entity.WRITE_OFF_IND = appModel.WriteOffInd;
		//	entity.COST_AMT = appModel.CostAmt;
		//	entity.CANCEL_OP_BAL_AMT = appModel.CancelOpBalAmt;
		//	entity.STATE_CD = appModel.StateCd;
		//	entity.OP_AMT = appModel.OpAmt;
		//	entity.NOTIFY_DT = appModel.NotifyDt;
		//	entity.INTEREST_AMT = appModel.InterestAmt;
		//	entity.OFFSET_RCVRY_AMT = appModel.OffsetRcvryAmt;
		//	entity.PROSECUTION_END_DT = appModel.ProsecutionEndDt;
		//	entity.RECOVERY_LOGIC_CD = appModel.RecoveryLogicCd;
		//	entity.WRITE_OFF_DT = appModel.WriteOffDt;
		//	entity.OPSRC_CD = appModel.OpsrcCd;
		//	entity.FUND_CD = appModel.FundCd;
		//	entity.REMOVED_DT = appModel.RemovedDt;
		//	entity.REQ_ISS_ID = appModel.ReqIssId;
		//	entity.FRAUD_IND = appModel.FraudInd;
		//	entity.OOS_OP_DT = appModel.OosOpDt;
		//	entity.PARENT_OPGRP_ID = appModel.ParentOpgrpId;
		//	entity.WRITTEN_OFF_AMT = appModel.WrittenOffAmt;
		//	entity.CASH_RCVRY_AMT = appModel.CashRcvryAmt;
		//	entity.OP_BAL_AMT = appModel.OpBalAmt;
		//	entity.AP_DCKT_RES_ID = appModel.ApDcktResId;
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.PROSECUTION_IND = appModel.ProsecutionInd;
		//	entity.MAIL_IND = appModel.MailInd;
		//	entity.OPCLS_CD = appModel.OpclsCd;
		//	entity.OPGRP_DSP_DT = appModel.OpgrpDspDt;
		//	entity.CHARGE_OFF_AMT = appModel.ChargeOffAmt;
		//	entity.WAIVE_AMT = appModel.WaiveAmt;
		//	entity.APPEAL_HOLD_IND = appModel.AppealHoldInd;
		//	entity.PRTY_ID = appModel.PrtyId;
		//	entity.OPGRP_ID = appModel.OpgrpId;
		//	entity.STIM_OP_AMT = appModel.StimOpAmt;
		//	entity.OPCSE_CD = appModel.OpcseCd;
		//	entity.BKCY_IND = appModel.BkcyInd;
		//	entity.MODIFIED_DT = appModel.ModifiedDt;
		//	entity.FINES_AMT = appModel.FinesAmt;
		//	entity.RSPAGT_CD = appModel.RspagtCd;
		//	entity.CREATED_DT = appModel.CreatedDt;
		//	entity.OPGRP_DSP_CD = appModel.OpgrpDspCd;
		//	return entity;
		//}
	//}
	#endregion


	#region EMPLOYEE
	///// <summary> A sample app model class to go with DB table EMPLOYEE. </summary>
	//public static class EmployeeModel
	//{
	//	public System.String  PronounPoss { get; set; }
	//	public System.String  Pronoun { get; set; }
	//	public System.DateTime?  ModifiedTs { get; set; }
	//	public System.DateTime  CreatedTs { get; set; }
	//	public System.String  Userid { get; set; }
	//	public System.String  Emailaddr { get; set; }
	//	public System.String  Fax { get; set; }
	//	public System.String  Phone { get; set; }
	//	public System.String  Department { get; set; }
	//	public System.String  Zip { get; set; }
	//	public System.String  State { get; set; }
	//	public System.String  City { get; set; }
	//	public System.String  Address2 { get; set; }
	//	public System.String  Address1 { get; set; }
	//	public System.String  Lastname { get; set; }
	//	public System.String  Firstname { get; set; }
	//	public System.Int64  EmployeeId { get; set; }
	//}

	///// <summary> A sample extensions class for the Employee app model. </summary>
	//public class EMPLOYEEExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static Employee ToAppModel(this EMPLOYEE entity) 
		//{
		//	return new Employee().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static Employee LoadFromEntity(this Employee appModel, EMPLOYEE entity) 
		//{
		//	appModel.PronounPoss = entity.PRONOUN_POSS;
		//	appModel.Pronoun = entity.PRONOUN;
		//	appModel.ModifiedTs = entity.MODIFIED_TS;
		//	appModel.CreatedTs = entity.CREATED_TS;
		//	appModel.Userid = entity.USERID;
		//	appModel.Emailaddr = entity.EMAILADDR;
		//	appModel.Fax = entity.FAX;
		//	appModel.Phone = entity.PHONE;
		//	appModel.Department = entity.DEPARTMENT;
		//	appModel.Zip = entity.ZIP;
		//	appModel.State = entity.STATE;
		//	appModel.City = entity.CITY;
		//	appModel.Address2 = entity.ADDRESS2;
		//	appModel.Address1 = entity.ADDRESS1;
		//	appModel.Lastname = entity.LASTNAME;
		//	appModel.Firstname = entity.FIRSTNAME;
		//	appModel.EmployeeId = entity.EMPLOYEE_ID;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static EMPLOYEE ToEntity(this Employee appModel) 
		//{
		//	return new EMPLOYEE().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static EMPLOYEE LoadFromAppModel(this EMPLOYEE entity, Employee appModel) 
		//{
		//	entity.PRONOUN_POSS = appModel.PronounPoss;
		//	entity.PRONOUN = appModel.Pronoun;
		//	entity.MODIFIED_TS = appModel.ModifiedTs;
		//	entity.CREATED_TS = appModel.CreatedTs;
		//	entity.USERID = appModel.Userid;
		//	entity.EMAILADDR = appModel.Emailaddr;
		//	entity.FAX = appModel.Fax;
		//	entity.PHONE = appModel.Phone;
		//	entity.DEPARTMENT = appModel.Department;
		//	entity.ZIP = appModel.Zip;
		//	entity.STATE = appModel.State;
		//	entity.CITY = appModel.City;
		//	entity.ADDRESS2 = appModel.Address2;
		//	entity.ADDRESS1 = appModel.Address1;
		//	entity.LASTNAME = appModel.Lastname;
		//	entity.FIRSTNAME = appModel.Firstname;
		//	entity.EMPLOYEE_ID = appModel.EmployeeId;
		//	return entity;
		//}
	//}
	#endregion


	#region LIEN_MASTER
	///// <summary> A sample app model class to go with DB table LIEN_MASTER. </summary>
	//public static class LienMasterModel
	//{
	//	public System.Decimal?  RestartAmount { get; set; }
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.DateTime?  ModifiedDt { get; set; }
	//	public System.DateTime  CreatedTs { get; set; }
	//	public System.Decimal?  ConpenForcedAmount { get; set; }
	//	public System.Decimal?  ConpenFiledAmount { get; set; }
	//	public System.Int16  AmendInd { get; set; }
	//	public System.Int64?  PrevFiledLienMasterId { get; set; }
	//	public System.Int64?  PayoffId { get; set; }
	//	public System.Decimal  OriginalAmount { get; set; }
	//	public System.Decimal?  FiledAmount { get; set; }
	//	public System.DateTime?  DtPaidOff { get; set; }
	//	public System.DateTime?  DtIssued { get; set; }
	//	public System.DateTime?  DtRefiled { get; set; }
	//	public System.DateTime?  DtFiled { get; set; }
	//	public System.DateTime?  DtEstablished { get; set; }
	//	public System.String  Fips { get; set; }
	//	public System.String  Judge { get; set; }
	//	public System.String  CaseNumber { get; set; }
	//	public System.Decimal  Accrual { get; set; }
	//	public System.Int16  FiledInd { get; set; }
	//	public System.DateTime  LienStateCdChangeDt { get; set; }
	//	public System.String  LienStateCd { get; set; }
	//	public System.Int64  LienMasterId { get; set; }
	//}

	///// <summary> A sample extensions class for the LienMaster app model. </summary>
	//public class LIEN_MASTERExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static LienMaster ToAppModel(this LIEN_MASTER entity) 
		//{
		//	return new LienMaster().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static LienMaster LoadFromEntity(this LienMaster appModel, LIEN_MASTER entity) 
		//{
		//	appModel.RestartAmount = entity.RESTART_AMOUNT;
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.ModifiedDt = entity.MODIFIED_DT;
		//	appModel.CreatedTs = entity.CREATED_TS;
		//	appModel.ConpenForcedAmount = entity.CONPEN_FORCED_AMOUNT;
		//	appModel.ConpenFiledAmount = entity.CONPEN_FILED_AMOUNT;
		//	appModel.AmendInd = entity.AMEND_IND;
		//	appModel.PrevFiledLienMasterId = entity.PREV_FILED_LIEN_MASTER_ID;
		//	appModel.PayoffId = entity.PAYOFF_ID;
		//	appModel.OriginalAmount = entity.ORIGINAL_AMOUNT;
		//	appModel.FiledAmount = entity.FILED_AMOUNT;
		//	appModel.DtPaidOff = entity.DT_PAID_OFF;
		//	appModel.DtIssued = entity.DT_ISSUED;
		//	appModel.DtRefiled = entity.DT_REFILED;
		//	appModel.DtFiled = entity.DT_FILED;
		//	appModel.DtEstablished = entity.DT_ESTABLISHED;
		//	appModel.Fips = entity.FIPS;
		//	appModel.Judge = entity.JUDGE;
		//	appModel.CaseNumber = entity.CASE_NUMBER;
		//	appModel.Accrual = entity.ACCRUAL;
		//	appModel.FiledInd = entity.FILED_IND;
		//	appModel.LienStateCdChangeDt = entity.LIEN_STATE_CD_CHANGE_DT;
		//	appModel.LienStateCd = entity.LIEN_STATE_CD;
		//	appModel.LienMasterId = entity.LIEN_MASTER_ID;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static LIEN_MASTER ToEntity(this LienMaster appModel) 
		//{
		//	return new LIEN_MASTER().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static LIEN_MASTER LoadFromAppModel(this LIEN_MASTER entity, LienMaster appModel) 
		//{
		//	entity.RESTART_AMOUNT = appModel.RestartAmount;
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.MODIFIED_DT = appModel.ModifiedDt;
		//	entity.CREATED_TS = appModel.CreatedTs;
		//	entity.CONPEN_FORCED_AMOUNT = appModel.ConpenForcedAmount;
		//	entity.CONPEN_FILED_AMOUNT = appModel.ConpenFiledAmount;
		//	entity.AMEND_IND = appModel.AmendInd;
		//	entity.PREV_FILED_LIEN_MASTER_ID = appModel.PrevFiledLienMasterId;
		//	entity.PAYOFF_ID = appModel.PayoffId;
		//	entity.ORIGINAL_AMOUNT = appModel.OriginalAmount;
		//	entity.FILED_AMOUNT = appModel.FiledAmount;
		//	entity.DT_PAID_OFF = appModel.DtPaidOff;
		//	entity.DT_ISSUED = appModel.DtIssued;
		//	entity.DT_REFILED = appModel.DtRefiled;
		//	entity.DT_FILED = appModel.DtFiled;
		//	entity.DT_ESTABLISHED = appModel.DtEstablished;
		//	entity.FIPS = appModel.Fips;
		//	entity.JUDGE = appModel.Judge;
		//	entity.CASE_NUMBER = appModel.CaseNumber;
		//	entity.ACCRUAL = appModel.Accrual;
		//	entity.FILED_IND = appModel.FiledInd;
		//	entity.LIEN_STATE_CD_CHANGE_DT = appModel.LienStateCdChangeDt;
		//	entity.LIEN_STATE_CD = appModel.LienStateCd;
		//	entity.LIEN_MASTER_ID = appModel.LienMasterId;
		//	return entity;
		//}
	//}
	#endregion


	#region OP_CAUSE_CODES
	///// <summary> A sample app model class to go with DB table OP_CAUSE_CODES. </summary>
	//public static class OpCauseCodesModel
	//{
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.DateTime?  EndDt { get; set; }
	//	public System.DateTime  BegDt { get; set; }
	//	public System.DateTime?  ModifiedDt { get; set; }
	//	public System.String  OpcseCd { get; set; }
	//	public System.String  Txt { get; set; }
	//	public System.DateTime  CreatedDt { get; set; }
	//	public System.String  Descr { get; set; }
	//}

	///// <summary> A sample extensions class for the OpCauseCodes app model. </summary>
	//public class OP_CAUSE_CODESExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static OpCauseCodes ToAppModel(this OP_CAUSE_CODES entity) 
		//{
		//	return new OpCauseCodes().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static OpCauseCodes LoadFromEntity(this OpCauseCodes appModel, OP_CAUSE_CODES entity) 
		//{
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.EndDt = entity.END_DT;
		//	appModel.BegDt = entity.BEG_DT;
		//	appModel.ModifiedDt = entity.MODIFIED_DT;
		//	appModel.OpcseCd = entity.OPCSE_CD;
		//	appModel.Txt = entity.TXT;
		//	appModel.CreatedDt = entity.CREATED_DT;
		//	appModel.Descr = entity.DESCR;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static OP_CAUSE_CODES ToEntity(this OpCauseCodes appModel) 
		//{
		//	return new OP_CAUSE_CODES().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static OP_CAUSE_CODES LoadFromAppModel(this OP_CAUSE_CODES entity, OpCauseCodes appModel) 
		//{
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.END_DT = appModel.EndDt;
		//	entity.BEG_DT = appModel.BegDt;
		//	entity.MODIFIED_DT = appModel.ModifiedDt;
		//	entity.OPCSE_CD = appModel.OpcseCd;
		//	entity.TXT = appModel.Txt;
		//	entity.CREATED_DT = appModel.CreatedDt;
		//	entity.DESCR = appModel.Descr;
		//	return entity;
		//}
	//}
	#endregion


	#region OP_CLASS_CODES
	///// <summary> A sample app model class to go with DB table OP_CLASS_CODES. </summary>
	//public static class OpClassCodesModel
	//{
	//	public System.Int64  Priority { get; set; }
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.DateTime?  EndDt { get; set; }
	//	public System.DateTime  BegDt { get; set; }
	//	public System.DateTime  CreatedDt { get; set; }
	//	public System.String  OpclsCd { get; set; }
	//	public System.DateTime?  ModifiedDt { get; set; }
	//	public System.String  Descr { get; set; }
	//}

	///// <summary> A sample extensions class for the OpClassCodes app model. </summary>
	//public class OP_CLASS_CODESExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static OpClassCodes ToAppModel(this OP_CLASS_CODES entity) 
		//{
		//	return new OpClassCodes().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static OpClassCodes LoadFromEntity(this OpClassCodes appModel, OP_CLASS_CODES entity) 
		//{
		//	appModel.Priority = entity.PRIORITY;
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.EndDt = entity.END_DT;
		//	appModel.BegDt = entity.BEG_DT;
		//	appModel.CreatedDt = entity.CREATED_DT;
		//	appModel.OpclsCd = entity.OPCLS_CD;
		//	appModel.ModifiedDt = entity.MODIFIED_DT;
		//	appModel.Descr = entity.DESCR;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static OP_CLASS_CODES ToEntity(this OpClassCodes appModel) 
		//{
		//	return new OP_CLASS_CODES().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static OP_CLASS_CODES LoadFromAppModel(this OP_CLASS_CODES entity, OpClassCodes appModel) 
		//{
		//	entity.PRIORITY = appModel.Priority;
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.END_DT = appModel.EndDt;
		//	entity.BEG_DT = appModel.BegDt;
		//	entity.CREATED_DT = appModel.CreatedDt;
		//	entity.OPCLS_CD = appModel.OpclsCd;
		//	entity.MODIFIED_DT = appModel.ModifiedDt;
		//	entity.DESCR = appModel.Descr;
		//	return entity;
		//}
	//}
	#endregion


	#region OP_SOURCE_CODES
	///// <summary> A sample app model class to go with DB table OP_SOURCE_CODES. </summary>
	//public static class OpSourceCodesModel
	//{
	//	public System.String  Domain { get; set; }
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.DateTime?  EndDt { get; set; }
	//	public System.DateTime  BegDt { get; set; }
	//	public System.DateTime?  ModifiedDt { get; set; }
	//	public System.String  OpsrcCd { get; set; }
	//	public System.Int16?  BcEmprRqrdInd { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.DateTime  CreatedDt { get; set; }
	//	public System.String  Descr { get; set; }
	//}

	///// <summary> A sample extensions class for the OpSourceCodes app model. </summary>
	//public class OP_SOURCE_CODESExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static OpSourceCodes ToAppModel(this OP_SOURCE_CODES entity) 
		//{
		//	return new OpSourceCodes().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static OpSourceCodes LoadFromEntity(this OpSourceCodes appModel, OP_SOURCE_CODES entity) 
		//{
		//	appModel.Domain = entity.DOMAIN;
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.EndDt = entity.END_DT;
		//	appModel.BegDt = entity.BEG_DT;
		//	appModel.ModifiedDt = entity.MODIFIED_DT;
		//	appModel.OpsrcCd = entity.OPSRC_CD;
		//	appModel.BcEmprRqrdInd = entity.BC_EMPR_RQRD_IND;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.CreatedDt = entity.CREATED_DT;
		//	appModel.Descr = entity.DESCR;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static OP_SOURCE_CODES ToEntity(this OpSourceCodes appModel) 
		//{
		//	return new OP_SOURCE_CODES().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static OP_SOURCE_CODES LoadFromAppModel(this OP_SOURCE_CODES entity, OpSourceCodes appModel) 
		//{
		//	entity.DOMAIN = appModel.Domain;
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.END_DT = appModel.EndDt;
		//	entity.BEG_DT = appModel.BegDt;
		//	entity.MODIFIED_DT = appModel.ModifiedDt;
		//	entity.OPSRC_CD = appModel.OpsrcCd;
		//	entity.BC_EMPR_RQRD_IND = appModel.BcEmprRqrdInd;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.CREATED_DT = appModel.CreatedDt;
		//	entity.DESCR = appModel.Descr;
		//	return entity;
		//}
	//}
	#endregion


	#region OP_TRANSACTIONS
	///// <summary> A sample app model class to go with DB table OP_TRANSACTIONS. </summary>
	//public static class OpTransactionsModel
	//{
	//	public System.DateTime?  ModifiedDt { get; set; }
	//	public System.DateTime  CreatedDt { get; set; }
	//	public System.Int16  RevInd { get; set; }
	//	public System.Decimal?  Amt { get; set; }
	//	public System.Int64?  IssId { get; set; }
	//	public System.String  RspagtCd { get; set; }
	//	public System.String  OpclsCd { get; set; }
	//	public System.Int64  ClmId { get; set; }
	//	public System.Int64?  ParentOptransId { get; set; }
	//	public System.Int64?  ParentOpgrpId { get; set; }
	//	public System.Int16?  WoInd { get; set; }
	//	public System.Int64?  MddId { get; set; }
	//	public System.Int64?  OpgrpId { get; set; }
	//	public System.Decimal?  InitRcvryAmt { get; set; }
	//	public System.Decimal?  OffsetRcvryAmt { get; set; }
	//	public System.Int16?  RcvryRevInd { get; set; }
	//	public System.Int64?  PmtTransId { get; set; }
	//	public System.Decimal?  ConsumedRcvryAmt { get; set; }
	//	public System.String  RcvryCd { get; set; }
	//	public System.Decimal?  OrigOpAmt { get; set; }
	//	public System.String  AdjrqcCd { get; set; }
	//	public System.Decimal?  SiblingAmt { get; set; }
	//	public System.DateTime?  DecisionDt { get; set; }
	//	public System.Int64?  ProcessState { get; set; }
	//	public System.Int64  ReqIssId { get; set; }
	//	public System.String  PenaltyCd { get; set; }
	//	public System.Int64?  Priority { get; set; }
	//	public System.Decimal?  PenaltyAmt { get; set; }
	//	public System.Decimal?  WaiveAmt { get; set; }
	//	public System.Decimal?  SetupBal { get; set; }
	//	public System.DateTime  EstablishDt { get; set; }
	//	public System.Int64?  ModifiedBy { get; set; }
	//	public System.Int64  CreatedBy { get; set; }
	//	public System.String  StateCd { get; set; }
	//	public System.Int64?  RcvryId { get; set; }
	//	public System.DateTime?  CcBweDt { get; set; }
	//	public System.Int64?  AdjreqId { get; set; }
	//	public System.String  OpcseCd { get; set; }
	//	public System.String  OpsrcCd { get; set; }
	//	public System.Int64  PrtyId { get; set; }
	//	public System.String  OptransCd { get; set; }
	//	public System.Int64  OptransId { get; set; }
	//	public System.Decimal?  CancelOpBalAmt { get; set; }
	//	public System.String  Comments { get; set; }
	//	public System.String  PmtProgCd { get; set; }
	//	public System.Decimal?  OffsetReductionAmt { get; set; }
	//	public System.Decimal?  CashRcvryAmt { get; set; }
	//	public System.String  OpProgCd { get; set; }
	//	public System.Int64?  RcvryPriority { get; set; }
	//	public System.Decimal?  AvailRcvryAmt { get; set; }
	//	public System.Int16?  ManualTransInd { get; set; }
	//	public System.Int16?  ManualSplitInd { get; set; }
	//	public System.Int64?  SiblingPriority { get; set; }
	//	public System.Int64?  FraudParentOptransId { get; set; }
	//	public System.Int16?  SplitInd { get; set; }
	//	public System.Decimal?  FraudAmt { get; set; }
	//	public System.Decimal?  ChargeOffAmt { get; set; }
	//	public System.Int64?  ParentSetupOptransId { get; set; }
	//	public System.String  OptypCd { get; set; }
	//}

	///// <summary> A sample extensions class for the OpTransactions app model. </summary>
	//public class OP_TRANSACTIONSExtensions
	//{
		///// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static OpTransactions ToAppModel(this OP_TRANSACTIONS entity) 
		//{
		//	return new OpTransactions().LoadFromEntity(entity);
		//}

		///// <summary> Copies property values from an entity to an existing app model. </summary>
		//public static OpTransactions LoadFromEntity(this OpTransactions appModel, OP_TRANSACTIONS entity) 
		//{
		//	appModel.ModifiedDt = entity.MODIFIED_DT;
		//	appModel.CreatedDt = entity.CREATED_DT;
		//	appModel.RevInd = entity.REV_IND;
		//	appModel.Amt = entity.AMT;
		//	appModel.IssId = entity.ISS_ID;
		//	appModel.RspagtCd = entity.RSPAGT_CD;
		//	appModel.OpclsCd = entity.OPCLS_CD;
		//	appModel.ClmId = entity.CLM_ID;
		//	appModel.ParentOptransId = entity.PARENT_OPTRANS_ID;
		//	appModel.ParentOpgrpId = entity.PARENT_OPGRP_ID;
		//	appModel.WoInd = entity.WO_IND;
		//	appModel.MddId = entity.MDD_ID;
		//	appModel.OpgrpId = entity.OPGRP_ID;
		//	appModel.InitRcvryAmt = entity.INIT_RCVRY_AMT;
		//	appModel.OffsetRcvryAmt = entity.OFFSET_RCVRY_AMT;
		//	appModel.RcvryRevInd = entity.RCVRY_REV_IND;
		//	appModel.PmtTransId = entity.PMT_TRANS_ID;
		//	appModel.ConsumedRcvryAmt = entity.CONSUMED_RCVRY_AMT;
		//	appModel.RcvryCd = entity.RCVRY_CD;
		//	appModel.OrigOpAmt = entity.ORIG_OP_AMT;
		//	appModel.AdjrqcCd = entity.ADJRQC_CD;
		//	appModel.SiblingAmt = entity.SIBLING_AMT;
		//	appModel.DecisionDt = entity.DECISION_DT;
		//	appModel.ProcessState = entity.PROCESS_STATE;
		//	appModel.ReqIssId = entity.REQ_ISS_ID;
		//	appModel.PenaltyCd = entity.PENALTY_CD;
		//	appModel.Priority = entity.PRIORITY;
		//	appModel.PenaltyAmt = entity.PENALTY_AMT;
		//	appModel.WaiveAmt = entity.WAIVE_AMT;
		//	appModel.SetupBal = entity.SETUP_BAL;
		//	appModel.EstablishDt = entity.ESTABLISH_DT;
		//	appModel.ModifiedBy = entity.MODIFIED_BY;
		//	appModel.CreatedBy = entity.CREATED_BY;
		//	appModel.StateCd = entity.STATE_CD;
		//	appModel.RcvryId = entity.RCVRY_ID;
		//	appModel.CcBweDt = entity.CC_BWE_DT;
		//	appModel.AdjreqId = entity.ADJREQ_ID;
		//	appModel.OpcseCd = entity.OPCSE_CD;
		//	appModel.OpsrcCd = entity.OPSRC_CD;
		//	appModel.PrtyId = entity.PRTY_ID;
		//	appModel.OptransCd = entity.OPTRANS_CD;
		//	appModel.OptransId = entity.OPTRANS_ID;
		//	appModel.CancelOpBalAmt = entity.CANCEL_OP_BAL_AMT;
		//	appModel.Comments = entity.COMMENTS;
		//	appModel.PmtProgCd = entity.PMT_PROG_CD;
		//	appModel.OffsetReductionAmt = entity.OFFSET_REDUCTION_AMT;
		//	appModel.CashRcvryAmt = entity.CASH_RCVRY_AMT;
		//	appModel.OpProgCd = entity.OP_PROG_CD;
		//	appModel.RcvryPriority = entity.RCVRY_PRIORITY;
		//	appModel.AvailRcvryAmt = entity.AVAIL_RCVRY_AMT;
		//	appModel.ManualTransInd = entity.MANUAL_TRANS_IND;
		//	appModel.ManualSplitInd = entity.MANUAL_SPLIT_IND;
		//	appModel.SiblingPriority = entity.SIBLING_PRIORITY;
		//	appModel.FraudParentOptransId = entity.FRAUD_PARENT_OPTRANS_ID;
		//	appModel.SplitInd = entity.SPLIT_IND;
		//	appModel.FraudAmt = entity.FRAUD_AMT;
		//	appModel.ChargeOffAmt = entity.CHARGE_OFF_AMT;
		//	appModel.ParentSetupOptransId = entity.PARENT_SETUP_OPTRANS_ID;
		//	appModel.OptypCd = entity.OPTYP_CD;
		//	return appModel;
		//}

		///// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		//public static OP_TRANSACTIONS ToEntity(this OpTransactions appModel) 
		//{
		//	return new OP_TRANSACTIONS().LoadFromAppModel(appModel);
		//}

		///// <summary> Copies property values from an app model to an entity. </summary>
		//public static OP_TRANSACTIONS LoadFromAppModel(this OP_TRANSACTIONS entity, OpTransactions appModel) 
		//{
		//	entity.MODIFIED_DT = appModel.ModifiedDt;
		//	entity.CREATED_DT = appModel.CreatedDt;
		//	entity.REV_IND = appModel.RevInd;
		//	entity.AMT = appModel.Amt;
		//	entity.ISS_ID = appModel.IssId;
		//	entity.RSPAGT_CD = appModel.RspagtCd;
		//	entity.OPCLS_CD = appModel.OpclsCd;
		//	entity.CLM_ID = appModel.ClmId;
		//	entity.PARENT_OPTRANS_ID = appModel.ParentOptransId;
		//	entity.PARENT_OPGRP_ID = appModel.ParentOpgrpId;
		//	entity.WO_IND = appModel.WoInd;
		//	entity.MDD_ID = appModel.MddId;
		//	entity.OPGRP_ID = appModel.OpgrpId;
		//	entity.INIT_RCVRY_AMT = appModel.InitRcvryAmt;
		//	entity.OFFSET_RCVRY_AMT = appModel.OffsetRcvryAmt;
		//	entity.RCVRY_REV_IND = appModel.RcvryRevInd;
		//	entity.PMT_TRANS_ID = appModel.PmtTransId;
		//	entity.CONSUMED_RCVRY_AMT = appModel.ConsumedRcvryAmt;
		//	entity.RCVRY_CD = appModel.RcvryCd;
		//	entity.ORIG_OP_AMT = appModel.OrigOpAmt;
		//	entity.ADJRQC_CD = appModel.AdjrqcCd;
		//	entity.SIBLING_AMT = appModel.SiblingAmt;
		//	entity.DECISION_DT = appModel.DecisionDt;
		//	entity.PROCESS_STATE = appModel.ProcessState;
		//	entity.REQ_ISS_ID = appModel.ReqIssId;
		//	entity.PENALTY_CD = appModel.PenaltyCd;
		//	entity.PRIORITY = appModel.Priority;
		//	entity.PENALTY_AMT = appModel.PenaltyAmt;
		//	entity.WAIVE_AMT = appModel.WaiveAmt;
		//	entity.SETUP_BAL = appModel.SetupBal;
		//	entity.ESTABLISH_DT = appModel.EstablishDt;
		//	entity.MODIFIED_BY = appModel.ModifiedBy;
		//	entity.CREATED_BY = appModel.CreatedBy;
		//	entity.STATE_CD = appModel.StateCd;
		//	entity.RCVRY_ID = appModel.RcvryId;
		//	entity.CC_BWE_DT = appModel.CcBweDt;
		//	entity.ADJREQ_ID = appModel.AdjreqId;
		//	entity.OPCSE_CD = appModel.OpcseCd;
		//	entity.OPSRC_CD = appModel.OpsrcCd;
		//	entity.PRTY_ID = appModel.PrtyId;
		//	entity.OPTRANS_CD = appModel.OptransCd;
		//	entity.OPTRANS_ID = appModel.OptransId;
		//	entity.CANCEL_OP_BAL_AMT = appModel.CancelOpBalAmt;
		//	entity.COMMENTS = appModel.Comments;
		//	entity.PMT_PROG_CD = appModel.PmtProgCd;
		//	entity.OFFSET_REDUCTION_AMT = appModel.OffsetReductionAmt;
		//	entity.CASH_RCVRY_AMT = appModel.CashRcvryAmt;
		//	entity.OP_PROG_CD = appModel.OpProgCd;
		//	entity.RCVRY_PRIORITY = appModel.RcvryPriority;
		//	entity.AVAIL_RCVRY_AMT = appModel.AvailRcvryAmt;
		//	entity.MANUAL_TRANS_IND = appModel.ManualTransInd;
		//	entity.MANUAL_SPLIT_IND = appModel.ManualSplitInd;
		//	entity.SIBLING_PRIORITY = appModel.SiblingPriority;
		//	entity.FRAUD_PARENT_OPTRANS_ID = appModel.FraudParentOptransId;
		//	entity.SPLIT_IND = appModel.SplitInd;
		//	entity.FRAUD_AMT = appModel.FraudAmt;
		//	entity.CHARGE_OFF_AMT = appModel.ChargeOffAmt;
		//	entity.PARENT_SETUP_OPTRANS_ID = appModel.ParentSetupOptransId;
		//	entity.OPTYP_CD = appModel.OptypCd;
		//	return entity;
		//}
	//}
	#endregion


}

