using Cats.Bop.Claimant.Data.Models;
using Cats.Core.Liens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Interfaces
{
	public enum BopType { Fault = 'R', Fraud = 'F' }

	public interface IBopLienRepository
    {
		BopLienModel GetBopLiens(long lienId);
		IEnumerable<BopLienModel> GetBopLiens(BopType bopType);
		IEnumerable<BopLienLetterModel> GetBopLienLetterInfo(BopType bopType, StateCode stateCode);

		void PickupNewBopFaultAR();
		void PickupARFromPaidBopFault();
		void PickupNewBopFraudAR();
		void PickupARFromPaidBopFraud();
		void UpdateLastAction(long lienId, string lastAction, string reason, int performedBy);

	}
}
