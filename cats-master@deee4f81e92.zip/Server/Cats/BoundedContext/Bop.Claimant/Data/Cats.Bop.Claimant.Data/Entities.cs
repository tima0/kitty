using System;
using System.Collections.Generic;
using System.Linq;

namespace Cats.Bop.Claimant.Data.Models
{
	public class HOLD : HOLDGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(HOLD)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class HOLD_TYPE_CODE : HOLD_TYPE_CODEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(HOLD_TYPE_CODE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class LIEN_BOP : LIEN_BOPGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(LIEN_BOP)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class NOTE : NOTEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class NOTE_SOURCE_CODE : NOTE_SOURCE_CODEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTE_SOURCE_CODE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class NOTE_TYPE : NOTE_TYPEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTE_TYPE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class NOTE_TYPE_CODE : NOTE_TYPE_CODEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTE_TYPE_CODE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class V_CLAIMANT : V_CLAIMANTGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_CLAIMANT)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class V_CLAIMANT_ADDRESS : V_CLAIMANT_ADDRESSGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_CLAIMANT_ADDRESS)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class V_CLAIMANT_PHONE : V_CLAIMANT_PHONEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_CLAIMANT_PHONE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class V_OPGROUP : V_OPGROUPGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_OPGROUP)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class EMPLOYEE : EMPLOYEEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(EMPLOYEE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class VM_POSTAL_CODE : VM_POSTAL_CODEGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(VM_POSTAL_CODE)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class LIEN_MASTER : LIEN_MASTERGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(LIEN_MASTER)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class LIEN_STATE_HISTORY : LIEN_STATE_HISTORYGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(LIEN_STATE_HISTORY)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class OP_CAUSE_CODES : OP_CAUSE_CODESGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_CAUSE_CODES)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class OP_CLASS_CODES : OP_CLASS_CODESGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_CLASS_CODES)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class OP_SOURCE_CODES : OP_SOURCE_CODESGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_SOURCE_CODES)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
	public class OP_TRANSACTIONS : OP_TRANSACTIONSGen
	{
		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_TRANSACTIONS)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}
	}
}