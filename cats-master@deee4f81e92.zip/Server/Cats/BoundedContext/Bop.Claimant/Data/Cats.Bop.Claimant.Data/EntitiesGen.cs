using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Models
{

	//Reference to -> CATS_BOP_OWNER.HOLD.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_BOP_OWNER.HOLD.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_BOP_OWNER.HOLD.HOLD_TYPE_CD->CATS_BOP_OWNER.HOLD_TYPE_CODE.HOLD_TYPE_CD
	//Reference to -> CATS_BOP_OWNER.HOLD.PRTY_ID->..
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "HOLD")]
	public partial class HOLDGen : HOLDBase
	{
		#region Property backing stores for table HOLD
		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_TS;
		protected virtual System.DateTime? GetMODIFIED_TS() { return _MODIFIED_TS; }
		protected virtual void SetMODIFIED_TS(System.DateTime? value) { _MODIFIED_TS = value; _MODIFIED_TSFieldIsDirty = true; }
		protected virtual bool _MODIFIED_TSFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.DateTime? _CLOSED_DT;
		protected virtual System.DateTime? GetCLOSED_DT() { return _CLOSED_DT; }
		protected virtual void SetCLOSED_DT(System.DateTime? value) { _CLOSED_DT = value; _CLOSED_DTFieldIsDirty = true; }
		protected virtual bool _CLOSED_DTFieldIsDirty { get; set; }

		protected System.DateTime? _REMOVE_HOLD_DT;
		protected virtual System.DateTime? GetREMOVE_HOLD_DT() { return _REMOVE_HOLD_DT; }
		protected virtual void SetREMOVE_HOLD_DT(System.DateTime? value) { _REMOVE_HOLD_DT = value; _REMOVE_HOLD_DTFieldIsDirty = true; }
		protected virtual bool _REMOVE_HOLD_DTFieldIsDirty { get; set; }

		protected System.String _REASON;
		protected virtual System.String GetREASON() { return _REASON; }
		protected virtual void SetREASON(System.String value) { _REASON = value; _REASONFieldIsDirty = true; }
		protected virtual bool _REASONFieldIsDirty { get; set; }

		protected System.String _HOLD_TYPE_CD;
		protected virtual System.String GetHOLD_TYPE_CD() { return _HOLD_TYPE_CD; }
		protected virtual void SetHOLD_TYPE_CD(System.String value) { _HOLD_TYPE_CD = value; _HOLD_TYPE_CDFieldIsDirty = true; }
		protected virtual bool _HOLD_TYPE_CDFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.Int64 _HOLD_ID;
		protected virtual System.Int64 GetHOLD_ID() { return _HOLD_ID; }
		protected virtual void SetHOLD_ID(System.Int64 value) { _HOLD_ID = value; _HOLD_IDFieldIsDirty = true; }
		protected virtual bool _HOLD_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table HOLD

		[ReferenceTo("CATS_BOP_OWNER", "HOLD", "MODIFIED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "MODIFIED_TS", "TIMESTAMP(6)", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_TS { get { return GetMODIFIED_TS(); } set { SetMODIFIED_TS(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "HOLD", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "CLOSED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? CLOSED_DT { get { return GetCLOSED_DT(); } set { SetCLOSED_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "REMOVE_HOLD_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? REMOVE_HOLD_DT { get { return GetREMOVE_HOLD_DT(); } set { SetREMOVE_HOLD_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(200)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "REASON", "VARCHAR2", typeof(System.String))]
		public virtual System.String REASON { get { return GetREASON(); } set { SetREASON(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "HOLD", "HOLD_TYPE_CD", "CATS_BOP_OWNER", "HOLD_TYPE_CODE", "HOLD_TYPE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "HOLD_TYPE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String HOLD_TYPE_CD { get { return GetHOLD_TYPE_CD(); } set { SetHOLD_TYPE_CD(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "HOLD", "PRTY_ID", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD", "HOLD_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 HOLD_ID { get { return GetHOLD_ID(); } set { SetHOLD_ID(value); } }


		public virtual EMPLOYEE Ref_Employee_CreatedBy { get; set; }
		public virtual EMPLOYEE Ref_Employee_ModifiedBy { get; set; }
		public virtual HOLD_TYPE_CODE Ref_HoldTypeCode { get; set; }
		// Ignoring dead-end RefTo from CATS_BOP_OWNER.HOLD.PRTY_ID->...

		#endregion

		#region Constructors for table HOLDGen
		public HOLDGen()
		{
		}

		public HOLDGen(System.Int64? MODIFIED_BY, System.DateTime? MODIFIED_TS, System.Int64 CREATED_BY, System.DateTime CREATED_TS, System.DateTime? CLOSED_DT, System.DateTime? REMOVE_HOLD_DT, System.String REASON, System.String HOLD_TYPE_CD, System.Int64 PRTY_ID, System.Int64 HOLD_ID) : this()
		{
			this._MODIFIED_BY = MODIFIED_BY;
			this._MODIFIED_TS = MODIFIED_TS;
			this._CREATED_BY = CREATED_BY;
			this._CREATED_TS = CREATED_TS;
			this._CLOSED_DT = CLOSED_DT;
			this._REMOVE_HOLD_DT = REMOVE_HOLD_DT;
			this._REASON = REASON;
			this._HOLD_TYPE_CD = HOLD_TYPE_CD;
			this._PRTY_ID = PRTY_ID;
			this._HOLD_ID = HOLD_ID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(HOLDGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_MODIFIED_BYFieldIsDirty = value;
			_MODIFIED_TSFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_CREATED_TSFieldIsDirty = value;
			_CLOSED_DTFieldIsDirty = value;
			_REMOVE_HOLD_DTFieldIsDirty = value;
			_REASONFieldIsDirty = value;
			_HOLD_TYPE_CDFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_HOLD_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _MODIFIED_BYFieldIsDirty
				|| _MODIFIED_TSFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _CREATED_TSFieldIsDirty
				|| _CLOSED_DTFieldIsDirty
				|| _REMOVE_HOLD_DTFieldIsDirty
				|| _REASONFieldIsDirty
				|| _HOLD_TYPE_CDFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _HOLD_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "HOLD";
		}

		public override string PrimaryKeyFieldname()
		{
			return "HOLD_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (HOLD)this.Clone();
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.MODIFIED_TS = this.MODIFIED_TS;
			result.CREATED_BY = this.CREATED_BY;
			result.CREATED_TS = this.CREATED_TS;
			result.CLOSED_DT = this.CLOSED_DT;
			result.REMOVE_HOLD_DT = this.REMOVE_HOLD_DT;
			result.REASON = this.REASON;
			result.HOLD_TYPE_CD = this.HOLD_TYPE_CD;
			result.PRTY_ID = this.PRTY_ID;
			result.HOLD_ID = this.HOLD_ID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.HOLD")
				.Append(" { ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("MODIFIED_TS")
				.Append(" = ")
				.Append(this.MODIFIED_TS.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("CLOSED_DT")
				.Append(" = ")
				.Append(this.CLOSED_DT.ToString())
				.Append("; ")
				.Append("REMOVE_HOLD_DT")
				.Append(" = ")
				.Append(this.REMOVE_HOLD_DT.ToString())
				.Append("; ")
				.Append("REASON")
				.Append(" = ")
				.Append(this.REASON.ToString())
				.Append("; ")
				.Append("HOLD_TYPE_CD")
				.Append(" = ")
				.Append(this.HOLD_TYPE_CD.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("HOLD_ID")
				.Append(" = ")
				.Append(this.HOLD_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//ReferencedBy -> CATS_BOP_OWNER.HOLD.HOLD_TYPE_CD->CATS_BOP_OWNER.HOLD_TYPE_CODE.HOLD_TYPE_CD
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "HOLD_TYPE_CODE")]
	public partial class HOLD_TYPE_CODEGen : HOLD_TYPE_CODEBase
	{
		#region Property backing stores for table HOLD_TYPE_CODE
		protected System.String _HOLD_TYPE_CD;
		protected virtual System.String GetHOLD_TYPE_CD() { return _HOLD_TYPE_CD; }
		protected virtual void SetHOLD_TYPE_CD(System.String value) { _HOLD_TYPE_CD = value; _HOLD_TYPE_CDFieldIsDirty = true; }
		protected virtual bool _HOLD_TYPE_CDFieldIsDirty { get; set; }

		protected System.String _DESCRIPTION;
		protected virtual System.String GetDESCRIPTION() { return _DESCRIPTION; }
		protected virtual void SetDESCRIPTION(System.String value) { _DESCRIPTION = value; _DESCRIPTIONFieldIsDirty = true; }
		protected virtual bool _DESCRIPTIONFieldIsDirty { get; set; }

		#endregion

		#region Properties for table HOLD_TYPE_CODE

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "HOLD", "HOLD_TYPE_CD", "CATS_BOP_OWNER", "HOLD_TYPE_CODE", "HOLD_TYPE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD_TYPE_CODE", "HOLD_TYPE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String HOLD_TYPE_CD { get { return GetHOLD_TYPE_CD(); } set { SetHOLD_TYPE_CD(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "HOLD_TYPE_CODE", "DESCRIPTION", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCRIPTION { get { return GetDESCRIPTION(); } set { SetDESCRIPTION(value); } }


		public virtual ICollection<HOLD> RefMany_Hold_HoldTypeCd { get; set; }

		#endregion

		#region Constructors for table HOLD_TYPE_CODEGen
		public HOLD_TYPE_CODEGen()
		{
		}

		public HOLD_TYPE_CODEGen(System.String HOLD_TYPE_CD, System.String DESCRIPTION) : this()
		{
			this._HOLD_TYPE_CD = HOLD_TYPE_CD;
			this._DESCRIPTION = DESCRIPTION;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(HOLD_TYPE_CODEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_HOLD_TYPE_CDFieldIsDirty = value;
			_DESCRIPTIONFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _HOLD_TYPE_CDFieldIsDirty
				|| _DESCRIPTIONFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "HOLD_TYPE_CODE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "HOLD_TYPE_CD";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_BOP_OWNER", "HOLD", "HOLD_TYPE_CD", "CATS_BOP_OWNER", "HOLD_TYPE_CODE", "HOLD_TYPE_CD");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (HOLD_TYPE_CODE)this.Clone();
			result.HOLD_TYPE_CD = this.HOLD_TYPE_CD;
			result.DESCRIPTION = this.DESCRIPTION;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.HOLD_TYPE_CODE")
				.Append(" { ")
				.Append("HOLD_TYPE_CD")
				.Append(" = ")
				.Append(this.HOLD_TYPE_CD.ToString())
				.Append("; ")
				.Append("DESCRIPTION")
				.Append(" = ")
				.Append(this.DESCRIPTION.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_BOP_OWNER.LIEN_BOP.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_BOP_OWNER.LIEN_BOP.LIEN_MASTER_ID->CATS_LEGAL_OWNER.LIEN_MASTER.LIEN_MASTER_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "LIEN_BOP")]
	public partial class LIEN_BOPGen : LIEN_BOPBase
	{
		#region Property backing stores for table LIEN_BOP
		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.Int64 _OPGRP_ID;
		protected virtual System.Int64 GetOPGRP_ID() { return _OPGRP_ID; }
		protected virtual void SetOPGRP_ID(System.Int64 value) { _OPGRP_ID = value; _OPGRP_IDFieldIsDirty = true; }
		protected virtual bool _OPGRP_IDFieldIsDirty { get; set; }

		protected System.Int64 _LIEN_MASTER_ID;
		protected virtual System.Int64 GetLIEN_MASTER_ID() { return _LIEN_MASTER_ID; }
		protected virtual void SetLIEN_MASTER_ID(System.Int64 value) { _LIEN_MASTER_ID = value; _LIEN_MASTER_IDFieldIsDirty = true; }
		protected virtual bool _LIEN_MASTER_IDFieldIsDirty { get; set; }

		protected System.Int64 _LIEN_BOP_ID;
		protected virtual System.Int64 GetLIEN_BOP_ID() { return _LIEN_BOP_ID; }
		protected virtual void SetLIEN_BOP_ID(System.Int64 value) { _LIEN_BOP_ID = value; _LIEN_BOP_IDFieldIsDirty = true; }
		protected virtual bool _LIEN_BOP_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table LIEN_BOP

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "LIEN_BOP", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "LIEN_BOP", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "LIEN_BOP", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "LIEN_BOP", "OPGRP_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 OPGRP_ID { get { return GetOPGRP_ID(); } set { SetOPGRP_ID(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "LIEN_BOP", "LIEN_MASTER_ID", "CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_MASTER_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "LIEN_BOP", "LIEN_MASTER_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LIEN_MASTER_ID { get { return GetLIEN_MASTER_ID(); } set { SetLIEN_MASTER_ID(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "LIEN_BOP", "LIEN_BOP_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LIEN_BOP_ID { get { return GetLIEN_BOP_ID(); } set { SetLIEN_BOP_ID(value); } }


		public virtual EMPLOYEE Ref_Employee { get; set; }
		public virtual LIEN_MASTER Ref_LienMaster { get; set; }

		#endregion

		#region Constructors for table LIEN_BOPGen
		public LIEN_BOPGen()
		{
		}

		public LIEN_BOPGen(System.DateTime CREATED_TS, System.Int64 CREATED_BY, System.Int64 OPGRP_ID, System.Int64 LIEN_MASTER_ID, System.Int64 LIEN_BOP_ID) : this()
		{
			this._CREATED_TS = CREATED_TS;
			this._CREATED_BY = CREATED_BY;
			this._OPGRP_ID = OPGRP_ID;
			this._LIEN_MASTER_ID = LIEN_MASTER_ID;
			this._LIEN_BOP_ID = LIEN_BOP_ID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(LIEN_BOPGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_CREATED_TSFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_OPGRP_IDFieldIsDirty = value;
			_LIEN_MASTER_IDFieldIsDirty = value;
			_LIEN_BOP_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _CREATED_TSFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _OPGRP_IDFieldIsDirty
				|| _LIEN_MASTER_IDFieldIsDirty
				|| _LIEN_BOP_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "LIEN_BOP";
		}

		public override string PrimaryKeyFieldname()
		{
			return "LIEN_BOP_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (LIEN_BOP)this.Clone();
			result.CREATED_TS = this.CREATED_TS;
			result.CREATED_BY = this.CREATED_BY;
			result.OPGRP_ID = this.OPGRP_ID;
			result.LIEN_MASTER_ID = this.LIEN_MASTER_ID;
			result.LIEN_BOP_ID = this.LIEN_BOP_ID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.LIEN_BOP")
				.Append(" { ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("OPGRP_ID")
				.Append(" = ")
				.Append(this.OPGRP_ID.ToString())
				.Append("; ")
				.Append("LIEN_MASTER_ID")
				.Append(" = ")
				.Append(this.LIEN_MASTER_ID.ToString())
				.Append("; ")
				.Append("LIEN_BOP_ID")
				.Append(" = ")
				.Append(this.LIEN_BOP_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_BOP_OWNER.NOTE.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_BOP_OWNER.NOTE.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_BOP_OWNER.NOTE.NOTE_SOURCE_CD->CATS_BOP_OWNER.NOTE_SOURCE_CODE.NOTE_SOURCE_CD
	//Reference to -> CATS_BOP_OWNER.NOTE.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "NOTE")]
	public partial class NOTEGen : NOTEBase
	{
		#region Property backing stores for table NOTE
		protected System.Int64? _LETTERS_LETTER_ID;
		protected virtual System.Int64? GetLETTERS_LETTER_ID() { return _LETTERS_LETTER_ID; }
		protected virtual void SetLETTERS_LETTER_ID(System.Int64? value) { _LETTERS_LETTER_ID = value; _LETTERS_LETTER_IDFieldIsDirty = true; }
		protected virtual bool _LETTERS_LETTER_IDFieldIsDirty { get; set; }

		protected System.String _IMAGEID;
		protected virtual System.String GetIMAGEID() { return _IMAGEID; }
		protected virtual void SetIMAGEID(System.String value) { _IMAGEID = value; _IMAGEIDFieldIsDirty = true; }
		protected virtual bool _IMAGEIDFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_TS;
		protected virtual System.DateTime? GetMODIFIED_TS() { return _MODIFIED_TS; }
		protected virtual void SetMODIFIED_TS(System.DateTime? value) { _MODIFIED_TS = value; _MODIFIED_TSFieldIsDirty = true; }
		protected virtual bool _MODIFIED_TSFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.String _MACHINE_NAME;
		protected virtual System.String GetMACHINE_NAME() { return _MACHINE_NAME; }
		protected virtual void SetMACHINE_NAME(System.String value) { _MACHINE_NAME = value; _MACHINE_NAMEFieldIsDirty = true; }
		protected virtual bool _MACHINE_NAMEFieldIsDirty { get; set; }

		protected System.String _NOTE_CONTENT;
		protected virtual System.String GetNOTE_CONTENT() { return _NOTE_CONTENT; }
		protected virtual void SetNOTE_CONTENT(System.String value) { _NOTE_CONTENT = value; _NOTE_CONTENTFieldIsDirty = true; }
		protected virtual bool _NOTE_CONTENTFieldIsDirty { get; set; }

		protected System.String _DESCRIPTION;
		protected virtual System.String GetDESCRIPTION() { return _DESCRIPTION; }
		protected virtual void SetDESCRIPTION(System.String value) { _DESCRIPTION = value; _DESCRIPTIONFieldIsDirty = true; }
		protected virtual bool _DESCRIPTIONFieldIsDirty { get; set; }

		protected System.String _CONTACT_EXT;
		protected virtual System.String GetCONTACT_EXT() { return _CONTACT_EXT; }
		protected virtual void SetCONTACT_EXT(System.String value) { _CONTACT_EXT = value; _CONTACT_EXTFieldIsDirty = true; }
		protected virtual bool _CONTACT_EXTFieldIsDirty { get; set; }

		protected System.String _CONTACT_PHONE;
		protected virtual System.String GetCONTACT_PHONE() { return _CONTACT_PHONE; }
		protected virtual void SetCONTACT_PHONE(System.String value) { _CONTACT_PHONE = value; _CONTACT_PHONEFieldIsDirty = true; }
		protected virtual bool _CONTACT_PHONEFieldIsDirty { get; set; }

		protected System.String _CONTACT_TITLE;
		protected virtual System.String GetCONTACT_TITLE() { return _CONTACT_TITLE; }
		protected virtual void SetCONTACT_TITLE(System.String value) { _CONTACT_TITLE = value; _CONTACT_TITLEFieldIsDirty = true; }
		protected virtual bool _CONTACT_TITLEFieldIsDirty { get; set; }

		protected System.String _CONTACT_NAME;
		protected virtual System.String GetCONTACT_NAME() { return _CONTACT_NAME; }
		protected virtual void SetCONTACT_NAME(System.String value) { _CONTACT_NAME = value; _CONTACT_NAMEFieldIsDirty = true; }
		protected virtual bool _CONTACT_NAMEFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.Int64? _GARNISHMENT_ID;
		protected virtual System.Int64? GetGARNISHMENT_ID() { return _GARNISHMENT_ID; }
		protected virtual void SetGARNISHMENT_ID(System.Int64? value) { _GARNISHMENT_ID = value; _GARNISHMENT_IDFieldIsDirty = true; }
		protected virtual bool _GARNISHMENT_IDFieldIsDirty { get; set; }

		protected System.Int64? _PROSECUTION_ID;
		protected virtual System.Int64? GetPROSECUTION_ID() { return _PROSECUTION_ID; }
		protected virtual void SetPROSECUTION_ID(System.Int64? value) { _PROSECUTION_ID = value; _PROSECUTION_IDFieldIsDirty = true; }
		protected virtual bool _PROSECUTION_IDFieldIsDirty { get; set; }

		protected System.String _NOTE_SOURCE_CD;
		protected virtual System.String GetNOTE_SOURCE_CD() { return _NOTE_SOURCE_CD; }
		protected virtual void SetNOTE_SOURCE_CD(System.String value) { _NOTE_SOURCE_CD = value; _NOTE_SOURCE_CDFieldIsDirty = true; }
		protected virtual bool _NOTE_SOURCE_CDFieldIsDirty { get; set; }

		protected System.Int64 _NOTE_ID;
		protected virtual System.Int64 GetNOTE_ID() { return _NOTE_ID; }
		protected virtual void SetNOTE_ID(System.Int64 value) { _NOTE_ID = value; _NOTE_IDFieldIsDirty = true; }
		protected virtual bool _NOTE_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table NOTE

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "LETTERS_LETTER_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? LETTERS_LETTER_ID { get { return GetLETTERS_LETTER_ID(); } set { SetLETTERS_LETTER_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "IMAGEID", "VARCHAR2", typeof(System.String))]
		public virtual System.String IMAGEID { get { return GetIMAGEID(); } set { SetIMAGEID(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "MODIFIED_TS", "TIMESTAMP(6)", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_TS { get { return GetMODIFIED_TS(); } set { SetMODIFIED_TS(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "NOTE", "MODIFIED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "NOTE", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(256)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "MACHINE_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String MACHINE_NAME { get { return GetMACHINE_NAME(); } set { SetMACHINE_NAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(4000)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "NOTE_CONTENT", "VARCHAR2", typeof(System.String))]
		public virtual System.String NOTE_CONTENT { get { return GetNOTE_CONTENT(); } set { SetNOTE_CONTENT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "DESCRIPTION", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCRIPTION { get { return GetDESCRIPTION(); } set { SetDESCRIPTION(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(6)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "CONTACT_EXT", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_EXT { get { return GetCONTACT_EXT(); } set { SetCONTACT_EXT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(14)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "CONTACT_PHONE", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_PHONE { get { return GetCONTACT_PHONE(); } set { SetCONTACT_PHONE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "CONTACT_TITLE", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_TITLE { get { return GetCONTACT_TITLE(); } set { SetCONTACT_TITLE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "CONTACT_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String CONTACT_NAME { get { return GetCONTACT_NAME(); } set { SetCONTACT_NAME(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "NOTE", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "GARNISHMENT_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? GARNISHMENT_ID { get { return GetGARNISHMENT_ID(); } set { SetGARNISHMENT_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "PROSECUTION_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PROSECUTION_ID { get { return GetPROSECUTION_ID(); } set { SetPROSECUTION_ID(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "NOTE", "NOTE_SOURCE_CD", "CATS_BOP_OWNER", "NOTE_SOURCE_CODE", "NOTE_SOURCE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "NOTE_SOURCE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String NOTE_SOURCE_CD { get { return GetNOTE_SOURCE_CD(); } set { SetNOTE_SOURCE_CD(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE", "NOTE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 NOTE_ID { get { return GetNOTE_ID(); } set { SetNOTE_ID(value); } }


		public virtual EMPLOYEE Ref_Employee_CreatedBy { get; set; }
		public virtual EMPLOYEE Ref_Employee_ModifiedBy { get; set; }
		public virtual NOTE_SOURCE_CODE Ref_NoteSourceCode { get; set; }
		public virtual V_CLAIMANT Ref_VClaimant { get; set; }

		#endregion

		#region Constructors for table NOTEGen
		public NOTEGen()
		{
		}

		public NOTEGen(System.Int64? LETTERS_LETTER_ID, System.String IMAGEID, System.DateTime? MODIFIED_TS, System.Int64? MODIFIED_BY, System.DateTime CREATED_TS, System.Int64 CREATED_BY, System.String MACHINE_NAME, System.String NOTE_CONTENT, System.String DESCRIPTION, System.String CONTACT_EXT, System.String CONTACT_PHONE, System.String CONTACT_TITLE, System.String CONTACT_NAME, System.Int64 PRTY_ID, System.Int64? GARNISHMENT_ID, System.Int64? PROSECUTION_ID, System.String NOTE_SOURCE_CD, System.Int64 NOTE_ID) : this()
		{
			this._LETTERS_LETTER_ID = LETTERS_LETTER_ID;
			this._IMAGEID = IMAGEID;
			this._MODIFIED_TS = MODIFIED_TS;
			this._MODIFIED_BY = MODIFIED_BY;
			this._CREATED_TS = CREATED_TS;
			this._CREATED_BY = CREATED_BY;
			this._MACHINE_NAME = MACHINE_NAME;
			this._NOTE_CONTENT = NOTE_CONTENT;
			this._DESCRIPTION = DESCRIPTION;
			this._CONTACT_EXT = CONTACT_EXT;
			this._CONTACT_PHONE = CONTACT_PHONE;
			this._CONTACT_TITLE = CONTACT_TITLE;
			this._CONTACT_NAME = CONTACT_NAME;
			this._PRTY_ID = PRTY_ID;
			this._GARNISHMENT_ID = GARNISHMENT_ID;
			this._PROSECUTION_ID = PROSECUTION_ID;
			this._NOTE_SOURCE_CD = NOTE_SOURCE_CD;
			this._NOTE_ID = NOTE_ID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_LETTERS_LETTER_IDFieldIsDirty = value;
			_IMAGEIDFieldIsDirty = value;
			_MODIFIED_TSFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_CREATED_TSFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_MACHINE_NAMEFieldIsDirty = value;
			_NOTE_CONTENTFieldIsDirty = value;
			_DESCRIPTIONFieldIsDirty = value;
			_CONTACT_EXTFieldIsDirty = value;
			_CONTACT_PHONEFieldIsDirty = value;
			_CONTACT_TITLEFieldIsDirty = value;
			_CONTACT_NAMEFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_GARNISHMENT_IDFieldIsDirty = value;
			_PROSECUTION_IDFieldIsDirty = value;
			_NOTE_SOURCE_CDFieldIsDirty = value;
			_NOTE_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _LETTERS_LETTER_IDFieldIsDirty
				|| _IMAGEIDFieldIsDirty
				|| _MODIFIED_TSFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _CREATED_TSFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _MACHINE_NAMEFieldIsDirty
				|| _NOTE_CONTENTFieldIsDirty
				|| _DESCRIPTIONFieldIsDirty
				|| _CONTACT_EXTFieldIsDirty
				|| _CONTACT_PHONEFieldIsDirty
				|| _CONTACT_TITLEFieldIsDirty
				|| _CONTACT_NAMEFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _GARNISHMENT_IDFieldIsDirty
				|| _PROSECUTION_IDFieldIsDirty
				|| _NOTE_SOURCE_CDFieldIsDirty
				|| _NOTE_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "NOTE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "NOTE_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (NOTE)this.Clone();
			result.LETTERS_LETTER_ID = this.LETTERS_LETTER_ID;
			result.IMAGEID = this.IMAGEID;
			result.MODIFIED_TS = this.MODIFIED_TS;
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.CREATED_TS = this.CREATED_TS;
			result.CREATED_BY = this.CREATED_BY;
			result.MACHINE_NAME = this.MACHINE_NAME;
			result.NOTE_CONTENT = this.NOTE_CONTENT;
			result.DESCRIPTION = this.DESCRIPTION;
			result.CONTACT_EXT = this.CONTACT_EXT;
			result.CONTACT_PHONE = this.CONTACT_PHONE;
			result.CONTACT_TITLE = this.CONTACT_TITLE;
			result.CONTACT_NAME = this.CONTACT_NAME;
			result.PRTY_ID = this.PRTY_ID;
			result.GARNISHMENT_ID = this.GARNISHMENT_ID;
			result.PROSECUTION_ID = this.PROSECUTION_ID;
			result.NOTE_SOURCE_CD = this.NOTE_SOURCE_CD;
			result.NOTE_ID = this.NOTE_ID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.NOTE")
				.Append(" { ")
				.Append("LETTERS_LETTER_ID")
				.Append(" = ")
				.Append(this.LETTERS_LETTER_ID.ToString())
				.Append("; ")
				.Append("IMAGEID")
				.Append(" = ")
				.Append(this.IMAGEID.ToString())
				.Append("; ")
				.Append("MODIFIED_TS")
				.Append(" = ")
				.Append(this.MODIFIED_TS.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("MACHINE_NAME")
				.Append(" = ")
				.Append(this.MACHINE_NAME.ToString())
				.Append("; ")
				.Append("NOTE_CONTENT")
				.Append(" = ")
				.Append(this.NOTE_CONTENT.ToString())
				.Append("; ")
				.Append("DESCRIPTION")
				.Append(" = ")
				.Append(this.DESCRIPTION.ToString())
				.Append("; ")
				.Append("CONTACT_EXT")
				.Append(" = ")
				.Append(this.CONTACT_EXT.ToString())
				.Append("; ")
				.Append("CONTACT_PHONE")
				.Append(" = ")
				.Append(this.CONTACT_PHONE.ToString())
				.Append("; ")
				.Append("CONTACT_TITLE")
				.Append(" = ")
				.Append(this.CONTACT_TITLE.ToString())
				.Append("; ")
				.Append("CONTACT_NAME")
				.Append(" = ")
				.Append(this.CONTACT_NAME.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("GARNISHMENT_ID")
				.Append(" = ")
				.Append(this.GARNISHMENT_ID.ToString())
				.Append("; ")
				.Append("PROSECUTION_ID")
				.Append(" = ")
				.Append(this.PROSECUTION_ID.ToString())
				.Append("; ")
				.Append("NOTE_SOURCE_CD")
				.Append(" = ")
				.Append(this.NOTE_SOURCE_CD.ToString())
				.Append("; ")
				.Append("NOTE_ID")
				.Append(" = ")
				.Append(this.NOTE_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//ReferencedBy -> CATS_BOP_OWNER.NOTE.NOTE_SOURCE_CD->CATS_BOP_OWNER.NOTE_SOURCE_CODE.NOTE_SOURCE_CD
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "NOTE_SOURCE_CODE")]
	public partial class NOTE_SOURCE_CODEGen : NOTE_SOURCE_CODEBase
	{
		#region Property backing stores for table NOTE_SOURCE_CODE
		protected System.Int64 _LOAD_ORDER;
		protected virtual System.Int64 GetLOAD_ORDER() { return _LOAD_ORDER; }
		protected virtual void SetLOAD_ORDER(System.Int64 value) { _LOAD_ORDER = value; _LOAD_ORDERFieldIsDirty = true; }
		protected virtual bool _LOAD_ORDERFieldIsDirty { get; set; }

		protected System.String _DESCRIPTION;
		protected virtual System.String GetDESCRIPTION() { return _DESCRIPTION; }
		protected virtual void SetDESCRIPTION(System.String value) { _DESCRIPTION = value; _DESCRIPTIONFieldIsDirty = true; }
		protected virtual bool _DESCRIPTIONFieldIsDirty { get; set; }

		protected System.String _NOTE_SOURCE_CD;
		protected virtual System.String GetNOTE_SOURCE_CD() { return _NOTE_SOURCE_CD; }
		protected virtual void SetNOTE_SOURCE_CD(System.String value) { _NOTE_SOURCE_CD = value; _NOTE_SOURCE_CDFieldIsDirty = true; }
		protected virtual bool _NOTE_SOURCE_CDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table NOTE_SOURCE_CODE

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_SOURCE_CODE", "LOAD_ORDER", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LOAD_ORDER { get { return GetLOAD_ORDER(); } set { SetLOAD_ORDER(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_SOURCE_CODE", "DESCRIPTION", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCRIPTION { get { return GetDESCRIPTION(); } set { SetDESCRIPTION(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "NOTE", "NOTE_SOURCE_CD", "CATS_BOP_OWNER", "NOTE_SOURCE_CODE", "NOTE_SOURCE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_SOURCE_CODE", "NOTE_SOURCE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String NOTE_SOURCE_CD { get { return GetNOTE_SOURCE_CD(); } set { SetNOTE_SOURCE_CD(value); } }


		public virtual ICollection<NOTE> RefMany_Note_NoteSourceCd { get; set; }

		#endregion

		#region Constructors for table NOTE_SOURCE_CODEGen
		public NOTE_SOURCE_CODEGen()
		{
		}

		public NOTE_SOURCE_CODEGen(System.Int64 LOAD_ORDER, System.String DESCRIPTION, System.String NOTE_SOURCE_CD) : this()
		{
			this._LOAD_ORDER = LOAD_ORDER;
			this._DESCRIPTION = DESCRIPTION;
			this._NOTE_SOURCE_CD = NOTE_SOURCE_CD;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTE_SOURCE_CODEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_LOAD_ORDERFieldIsDirty = value;
			_DESCRIPTIONFieldIsDirty = value;
			_NOTE_SOURCE_CDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _LOAD_ORDERFieldIsDirty
				|| _DESCRIPTIONFieldIsDirty
				|| _NOTE_SOURCE_CDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "NOTE_SOURCE_CODE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "NOTE_SOURCE_CD";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_BOP_OWNER", "NOTE", "NOTE_SOURCE_CD", "CATS_BOP_OWNER", "NOTE_SOURCE_CODE", "NOTE_SOURCE_CD");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (NOTE_SOURCE_CODE)this.Clone();
			result.LOAD_ORDER = this.LOAD_ORDER;
			result.DESCRIPTION = this.DESCRIPTION;
			result.NOTE_SOURCE_CD = this.NOTE_SOURCE_CD;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.NOTE_SOURCE_CODE")
				.Append(" { ")
				.Append("LOAD_ORDER")
				.Append(" = ")
				.Append(this.LOAD_ORDER.ToString())
				.Append("; ")
				.Append("DESCRIPTION")
				.Append(" = ")
				.Append(this.DESCRIPTION.ToString())
				.Append("; ")
				.Append("NOTE_SOURCE_CD")
				.Append(" = ")
				.Append(this.NOTE_SOURCE_CD.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_BOP_OWNER.NOTE_TYPE.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_BOP_OWNER.NOTE_TYPE.NOTE_TYPE_CD->CATS_BOP_OWNER.NOTE_TYPE_CODE.NOTE_TYPE_CD
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "NOTE_TYPE")]
	public partial class NOTE_TYPEGen : NOTE_TYPEBase
	{
		#region Property backing stores for table NOTE_TYPE
		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.String _NOTE_TYPE_CD;
		protected virtual System.String GetNOTE_TYPE_CD() { return _NOTE_TYPE_CD; }
		protected virtual void SetNOTE_TYPE_CD(System.String value) { _NOTE_TYPE_CD = value; _NOTE_TYPE_CDFieldIsDirty = true; }
		protected virtual bool _NOTE_TYPE_CDFieldIsDirty { get; set; }

		protected System.Int64 _NOTE_ID;
		protected virtual System.Int64 GetNOTE_ID() { return _NOTE_ID; }
		protected virtual void SetNOTE_ID(System.Int64 value) { _NOTE_ID = value; _NOTE_IDFieldIsDirty = true; }
		protected virtual bool _NOTE_IDFieldIsDirty { get; set; }

		protected System.Int64 _NOTE_TYPE_ID;
		protected virtual System.Int64 GetNOTE_TYPE_ID() { return _NOTE_TYPE_ID; }
		protected virtual void SetNOTE_TYPE_ID(System.Int64 value) { _NOTE_TYPE_ID = value; _NOTE_TYPE_IDFieldIsDirty = true; }
		protected virtual bool _NOTE_TYPE_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table NOTE_TYPE

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "NOTE_TYPE", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "NOTE_TYPE", "NOTE_TYPE_CD", "CATS_BOP_OWNER", "NOTE_TYPE_CODE", "NOTE_TYPE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE", "NOTE_TYPE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String NOTE_TYPE_CD { get { return GetNOTE_TYPE_CD(); } set { SetNOTE_TYPE_CD(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE", "NOTE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 NOTE_ID { get { return GetNOTE_ID(); } set { SetNOTE_ID(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE", "NOTE_TYPE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 NOTE_TYPE_ID { get { return GetNOTE_TYPE_ID(); } set { SetNOTE_TYPE_ID(value); } }


		public virtual EMPLOYEE Ref_Employee { get; set; }
		public virtual NOTE_TYPE_CODE Ref_NoteTypeCode { get; set; }

		#endregion

		#region Constructors for table NOTE_TYPEGen
		public NOTE_TYPEGen()
		{
		}

		public NOTE_TYPEGen(System.DateTime CREATED_TS, System.Int64 CREATED_BY, System.String NOTE_TYPE_CD, System.Int64 NOTE_ID, System.Int64 NOTE_TYPE_ID) : this()
		{
			this._CREATED_TS = CREATED_TS;
			this._CREATED_BY = CREATED_BY;
			this._NOTE_TYPE_CD = NOTE_TYPE_CD;
			this._NOTE_ID = NOTE_ID;
			this._NOTE_TYPE_ID = NOTE_TYPE_ID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTE_TYPEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_CREATED_TSFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_NOTE_TYPE_CDFieldIsDirty = value;
			_NOTE_IDFieldIsDirty = value;
			_NOTE_TYPE_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _CREATED_TSFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _NOTE_TYPE_CDFieldIsDirty
				|| _NOTE_IDFieldIsDirty
				|| _NOTE_TYPE_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "NOTE_TYPE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "NOTE_TYPE_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (NOTE_TYPE)this.Clone();
			result.CREATED_TS = this.CREATED_TS;
			result.CREATED_BY = this.CREATED_BY;
			result.NOTE_TYPE_CD = this.NOTE_TYPE_CD;
			result.NOTE_ID = this.NOTE_ID;
			result.NOTE_TYPE_ID = this.NOTE_TYPE_ID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.NOTE_TYPE")
				.Append(" { ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("NOTE_TYPE_CD")
				.Append(" = ")
				.Append(this.NOTE_TYPE_CD.ToString())
				.Append("; ")
				.Append("NOTE_ID")
				.Append(" = ")
				.Append(this.NOTE_ID.ToString())
				.Append("; ")
				.Append("NOTE_TYPE_ID")
				.Append(" = ")
				.Append(this.NOTE_TYPE_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//ReferencedBy -> CATS_BOP_OWNER.NOTE_TYPE.NOTE_TYPE_CD->CATS_BOP_OWNER.NOTE_TYPE_CODE.NOTE_TYPE_CD
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "NOTE_TYPE_CODE")]
	public partial class NOTE_TYPE_CODEGen : NOTE_TYPE_CODEBase
	{
		#region Property backing stores for table NOTE_TYPE_CODE
		protected System.Int64 _LOAD_ORDER;
		protected virtual System.Int64 GetLOAD_ORDER() { return _LOAD_ORDER; }
		protected virtual void SetLOAD_ORDER(System.Int64 value) { _LOAD_ORDER = value; _LOAD_ORDERFieldIsDirty = true; }
		protected virtual bool _LOAD_ORDERFieldIsDirty { get; set; }

		protected System.String _DESCRIPTION;
		protected virtual System.String GetDESCRIPTION() { return _DESCRIPTION; }
		protected virtual void SetDESCRIPTION(System.String value) { _DESCRIPTION = value; _DESCRIPTIONFieldIsDirty = true; }
		protected virtual bool _DESCRIPTIONFieldIsDirty { get; set; }

		protected System.String _NOTE_TYPE_CD;
		protected virtual System.String GetNOTE_TYPE_CD() { return _NOTE_TYPE_CD; }
		protected virtual void SetNOTE_TYPE_CD(System.String value) { _NOTE_TYPE_CD = value; _NOTE_TYPE_CDFieldIsDirty = true; }
		protected virtual bool _NOTE_TYPE_CDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table NOTE_TYPE_CODE

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE_CODE", "LOAD_ORDER", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LOAD_ORDER { get { return GetLOAD_ORDER(); } set { SetLOAD_ORDER(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE_CODE", "DESCRIPTION", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCRIPTION { get { return GetDESCRIPTION(); } set { SetDESCRIPTION(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "NOTE_TYPE", "NOTE_TYPE_CD", "CATS_BOP_OWNER", "NOTE_TYPE_CODE", "NOTE_TYPE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "NOTE_TYPE_CODE", "NOTE_TYPE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String NOTE_TYPE_CD { get { return GetNOTE_TYPE_CD(); } set { SetNOTE_TYPE_CD(value); } }


		public virtual ICollection<NOTE_TYPE> RefMany_NoteType_NoteTypeCd { get; set; }

		#endregion

		#region Constructors for table NOTE_TYPE_CODEGen
		public NOTE_TYPE_CODEGen()
		{
		}

		public NOTE_TYPE_CODEGen(System.Int64 LOAD_ORDER, System.String DESCRIPTION, System.String NOTE_TYPE_CD) : this()
		{
			this._LOAD_ORDER = LOAD_ORDER;
			this._DESCRIPTION = DESCRIPTION;
			this._NOTE_TYPE_CD = NOTE_TYPE_CD;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(NOTE_TYPE_CODEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_LOAD_ORDERFieldIsDirty = value;
			_DESCRIPTIONFieldIsDirty = value;
			_NOTE_TYPE_CDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _LOAD_ORDERFieldIsDirty
				|| _DESCRIPTIONFieldIsDirty
				|| _NOTE_TYPE_CDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "NOTE_TYPE_CODE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "NOTE_TYPE_CD";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_BOP_OWNER", "NOTE_TYPE", "NOTE_TYPE_CD", "CATS_BOP_OWNER", "NOTE_TYPE_CODE", "NOTE_TYPE_CD");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (NOTE_TYPE_CODE)this.Clone();
			result.LOAD_ORDER = this.LOAD_ORDER;
			result.DESCRIPTION = this.DESCRIPTION;
			result.NOTE_TYPE_CD = this.NOTE_TYPE_CD;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.NOTE_TYPE_CODE")
				.Append(" { ")
				.Append("LOAD_ORDER")
				.Append(" = ")
				.Append(this.LOAD_ORDER.ToString())
				.Append("; ")
				.Append("DESCRIPTION")
				.Append(" = ")
				.Append(this.DESCRIPTION.ToString())
				.Append("; ")
				.Append("NOTE_TYPE_CD")
				.Append(" = ")
				.Append(this.NOTE_TYPE_CD.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//ReferencedBy -> CATS_BOP_OWNER.V_OPGROUP.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	//ReferencedBy -> CATS_BOP_OWNER.V_CLAIMANT_ADDRESS.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	//ReferencedBy -> CATS_BOP_OWNER.V_CLAIMANT_PHONE.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	//ReferencedBy -> CATS_BOP_OWNER.NOTE.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "V_CLAIMANT")]
	public partial class V_CLAIMANTGen : V_CLAIMANTBase
	{
		#region Property backing stores for table V_CLAIMANT
		protected System.String _BAD_EMAIL_FLAG;
		protected virtual System.String GetBAD_EMAIL_FLAG() { return _BAD_EMAIL_FLAG; }
		protected virtual void SetBAD_EMAIL_FLAG(System.String value) { _BAD_EMAIL_FLAG = value; _BAD_EMAIL_FLAGFieldIsDirty = true; }
		protected virtual bool _BAD_EMAIL_FLAGFieldIsDirty { get; set; }

		protected System.String _EMAIL;
		protected virtual System.String GetEMAIL() { return _EMAIL; }
		protected virtual void SetEMAIL(System.String value) { _EMAIL = value; _EMAILFieldIsDirty = true; }
		protected virtual bool _EMAILFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.String _MIDDLE_NAME;
		protected virtual System.String GetMIDDLE_NAME() { return _MIDDLE_NAME; }
		protected virtual void SetMIDDLE_NAME(System.String value) { _MIDDLE_NAME = value; _MIDDLE_NAMEFieldIsDirty = true; }
		protected virtual bool _MIDDLE_NAMEFieldIsDirty { get; set; }

		protected System.String _SSN;
		protected virtual System.String GetSSN() { return _SSN; }
		protected virtual void SetSSN(System.String value) { _SSN = value; _SSNFieldIsDirty = true; }
		protected virtual bool _SSNFieldIsDirty { get; set; }

		protected System.Int64 _CLI_ID;
		protected virtual System.Int64 GetCLI_ID() { return _CLI_ID; }
		protected virtual void SetCLI_ID(System.Int64 value) { _CLI_ID = value; _CLI_IDFieldIsDirty = true; }
		protected virtual bool _CLI_IDFieldIsDirty { get; set; }

		protected System.String _DRIVERS_LICENSE_NUMBER;
		protected virtual System.String GetDRIVERS_LICENSE_NUMBER() { return _DRIVERS_LICENSE_NUMBER; }
		protected virtual void SetDRIVERS_LICENSE_NUMBER(System.String value) { _DRIVERS_LICENSE_NUMBER = value; _DRIVERS_LICENSE_NUMBERFieldIsDirty = true; }
		protected virtual bool _DRIVERS_LICENSE_NUMBERFieldIsDirty { get; set; }

		protected System.String _LAST_NAME;
		protected virtual System.String GetLAST_NAME() { return _LAST_NAME; }
		protected virtual void SetLAST_NAME(System.String value) { _LAST_NAME = value; _LAST_NAMEFieldIsDirty = true; }
		protected virtual bool _LAST_NAMEFieldIsDirty { get; set; }

		protected System.String _FIRST_NAME;
		protected virtual System.String GetFIRST_NAME() { return _FIRST_NAME; }
		protected virtual void SetFIRST_NAME(System.String value) { _FIRST_NAME = value; _FIRST_NAMEFieldIsDirty = true; }
		protected virtual bool _FIRST_NAMEFieldIsDirty { get; set; }

		protected System.Int16 _WRITE_OFF_IND;
		protected virtual System.Int16 GetWRITE_OFF_IND() { return _WRITE_OFF_IND; }
		protected virtual void SetWRITE_OFF_IND(System.Int16 value) { _WRITE_OFF_IND = value; _WRITE_OFF_INDFieldIsDirty = true; }
		protected virtual bool _WRITE_OFF_INDFieldIsDirty { get; set; }

		protected System.String _MOTHERS_MAIDEN_NAME;
		protected virtual System.String GetMOTHERS_MAIDEN_NAME() { return _MOTHERS_MAIDEN_NAME; }
		protected virtual void SetMOTHERS_MAIDEN_NAME(System.String value) { _MOTHERS_MAIDEN_NAME = value; _MOTHERS_MAIDEN_NAMEFieldIsDirty = true; }
		protected virtual bool _MOTHERS_MAIDEN_NAMEFieldIsDirty { get; set; }

		protected System.DateTime _BIRTH_DT;
		protected virtual System.DateTime GetBIRTH_DT() { return _BIRTH_DT; }
		protected virtual void SetBIRTH_DT(System.DateTime value) { _BIRTH_DT = value; _BIRTH_DTFieldIsDirty = true; }
		protected virtual bool _BIRTH_DTFieldIsDirty { get; set; }

		protected System.String _PID;
		protected virtual System.String GetPID() { return _PID; }
		protected virtual void SetPID(System.String value) { _PID = value; _PIDFieldIsDirty = true; }
		protected virtual bool _PIDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table V_CLAIMANT

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "BAD_EMAIL_FLAG", "CHAR", typeof(System.String))]
		public virtual System.String BAD_EMAIL_FLAG { get { return GetBAD_EMAIL_FLAG(); } set { SetBAD_EMAIL_FLAG(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(240)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "EMAIL", "VARCHAR2", typeof(System.String))]
		public virtual System.String EMAIL { get { return GetEMAIL(); } set { SetEMAIL(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "V_OPGROUP", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "MIDDLE_NAME", "CHAR", typeof(System.String))]
		public virtual System.String MIDDLE_NAME { get { return GetMIDDLE_NAME(); } set { SetMIDDLE_NAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "SSN", "VARCHAR2", typeof(System.String))]
		public virtual System.String SSN { get { return GetSSN(); } set { SetSSN(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "CLI_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CLI_ID { get { return GetCLI_ID(); } set { SetCLI_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "DRIVERS_LICENSE_NUMBER", "VARCHAR2", typeof(System.String))]
		public virtual System.String DRIVERS_LICENSE_NUMBER { get { return GetDRIVERS_LICENSE_NUMBER(); } set { SetDRIVERS_LICENSE_NUMBER(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(120)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "LAST_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String LAST_NAME { get { return GetLAST_NAME(); } set { SetLAST_NAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(100)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "FIRST_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String FIRST_NAME { get { return GetFIRST_NAME(); } set { SetFIRST_NAME(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "WRITE_OFF_IND", "NUMBER", typeof(System.Int16))]
		public virtual System.Int16 WRITE_OFF_IND { get { return GetWRITE_OFF_IND(); } set { SetWRITE_OFF_IND(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(80)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "MOTHERS_MAIDEN_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String MOTHERS_MAIDEN_NAME { get { return GetMOTHERS_MAIDEN_NAME(); } set { SetMOTHERS_MAIDEN_NAME(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "BIRTH_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime BIRTH_DT { get { return GetBIRTH_DT(); } set { SetBIRTH_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT", "PID", "VARCHAR2", typeof(System.String))]
		public virtual System.String PID { get { return GetPID(); } set { SetPID(value); } }


		public virtual ICollection<V_OPGROUP> RefMany_VOpgroup_PrtyId { get; set; }
		public virtual ICollection<V_CLAIMANT_ADDRESS> RefMany_VClaimantAddress { get; set; }
		public virtual ICollection<V_CLAIMANT_PHONE> RefMany_VClaimantPhone { get; set; }
		public virtual ICollection<NOTE> RefMany_Note_PrtyId { get; set; }

		#endregion

		#region Constructors for table V_CLAIMANTGen
		public V_CLAIMANTGen()
		{
		}

		public V_CLAIMANTGen(System.String BAD_EMAIL_FLAG, System.String EMAIL, System.Int64 PRTY_ID, System.String MIDDLE_NAME, System.String SSN, System.Int64 CLI_ID, System.String DRIVERS_LICENSE_NUMBER, System.String LAST_NAME, System.String FIRST_NAME, System.Int16 WRITE_OFF_IND, System.String MOTHERS_MAIDEN_NAME, System.DateTime BIRTH_DT, System.String PID) : this()
		{
			this._BAD_EMAIL_FLAG = BAD_EMAIL_FLAG;
			this._EMAIL = EMAIL;
			this._PRTY_ID = PRTY_ID;
			this._MIDDLE_NAME = MIDDLE_NAME;
			this._SSN = SSN;
			this._CLI_ID = CLI_ID;
			this._DRIVERS_LICENSE_NUMBER = DRIVERS_LICENSE_NUMBER;
			this._LAST_NAME = LAST_NAME;
			this._FIRST_NAME = FIRST_NAME;
			this._WRITE_OFF_IND = WRITE_OFF_IND;
			this._MOTHERS_MAIDEN_NAME = MOTHERS_MAIDEN_NAME;
			this._BIRTH_DT = BIRTH_DT;
			this._PID = PID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_CLAIMANTGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_BAD_EMAIL_FLAGFieldIsDirty = value;
			_EMAILFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_MIDDLE_NAMEFieldIsDirty = value;
			_SSNFieldIsDirty = value;
			_CLI_IDFieldIsDirty = value;
			_DRIVERS_LICENSE_NUMBERFieldIsDirty = value;
			_LAST_NAMEFieldIsDirty = value;
			_FIRST_NAMEFieldIsDirty = value;
			_WRITE_OFF_INDFieldIsDirty = value;
			_MOTHERS_MAIDEN_NAMEFieldIsDirty = value;
			_BIRTH_DTFieldIsDirty = value;
			_PIDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _BAD_EMAIL_FLAGFieldIsDirty
				|| _EMAILFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _MIDDLE_NAMEFieldIsDirty
				|| _SSNFieldIsDirty
				|| _CLI_IDFieldIsDirty
				|| _DRIVERS_LICENSE_NUMBERFieldIsDirty
				|| _LAST_NAMEFieldIsDirty
				|| _FIRST_NAMEFieldIsDirty
				|| _WRITE_OFF_INDFieldIsDirty
				|| _MOTHERS_MAIDEN_NAMEFieldIsDirty
				|| _BIRTH_DTFieldIsDirty
				|| _PIDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "V_CLAIMANT";
		}

		public override string PrimaryKeyFieldname()
		{
			return "PRTY_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_BOP_OWNER", "V_OPGROUP", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID");
			yield return ("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID");
			yield return ("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID");
			yield return ("CATS_BOP_OWNER", "NOTE", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (V_CLAIMANT)this.Clone();
			result.BAD_EMAIL_FLAG = this.BAD_EMAIL_FLAG;
			result.EMAIL = this.EMAIL;
			result.PRTY_ID = this.PRTY_ID;
			result.MIDDLE_NAME = this.MIDDLE_NAME;
			result.SSN = this.SSN;
			result.CLI_ID = this.CLI_ID;
			result.DRIVERS_LICENSE_NUMBER = this.DRIVERS_LICENSE_NUMBER;
			result.LAST_NAME = this.LAST_NAME;
			result.FIRST_NAME = this.FIRST_NAME;
			result.WRITE_OFF_IND = this.WRITE_OFF_IND;
			result.MOTHERS_MAIDEN_NAME = this.MOTHERS_MAIDEN_NAME;
			result.BIRTH_DT = this.BIRTH_DT;
			result.PID = this.PID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.V_CLAIMANT")
				.Append(" { ")
				.Append("BAD_EMAIL_FLAG")
				.Append(" = ")
				.Append(this.BAD_EMAIL_FLAG.ToString())
				.Append("; ")
				.Append("EMAIL")
				.Append(" = ")
				.Append(this.EMAIL.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("MIDDLE_NAME")
				.Append(" = ")
				.Append(this.MIDDLE_NAME.ToString())
				.Append("; ")
				.Append("SSN")
				.Append(" = ")
				.Append(this.SSN.ToString())
				.Append("; ")
				.Append("CLI_ID")
				.Append(" = ")
				.Append(this.CLI_ID.ToString())
				.Append("; ")
				.Append("DRIVERS_LICENSE_NUMBER")
				.Append(" = ")
				.Append(this.DRIVERS_LICENSE_NUMBER.ToString())
				.Append("; ")
				.Append("LAST_NAME")
				.Append(" = ")
				.Append(this.LAST_NAME.ToString())
				.Append("; ")
				.Append("FIRST_NAME")
				.Append(" = ")
				.Append(this.FIRST_NAME.ToString())
				.Append("; ")
				.Append("WRITE_OFF_IND")
				.Append(" = ")
				.Append(this.WRITE_OFF_IND.ToString())
				.Append("; ")
				.Append("MOTHERS_MAIDEN_NAME")
				.Append(" = ")
				.Append(this.MOTHERS_MAIDEN_NAME.ToString())
				.Append("; ")
				.Append("BIRTH_DT")
				.Append(" = ")
				.Append(this.BIRTH_DT.ToString())
				.Append("; ")
				.Append("PID")
				.Append(" = ")
				.Append(this.PID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_BOP_OWNER.V_CLAIMANT_ADDRESS.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS")]
	public partial class V_CLAIMANT_ADDRESSGen : V_CLAIMANT_ADDRESSBase
	{
		#region Property backing stores for table V_CLAIMANT_ADDRESS
		protected System.String _CITY;
		protected virtual System.String GetCITY() { return _CITY; }
		protected virtual void SetCITY(System.String value) { _CITY = value; _CITYFieldIsDirty = true; }
		protected virtual bool _CITYFieldIsDirty { get; set; }

		protected System.String _FOREIGN_STATE_OR_PROVINCE;
		protected virtual System.String GetFOREIGN_STATE_OR_PROVINCE() { return _FOREIGN_STATE_OR_PROVINCE; }
		protected virtual void SetFOREIGN_STATE_OR_PROVINCE(System.String value) { _FOREIGN_STATE_OR_PROVINCE = value; _FOREIGN_STATE_OR_PROVINCEFieldIsDirty = true; }
		protected virtual bool _FOREIGN_STATE_OR_PROVINCEFieldIsDirty { get; set; }

		protected System.String _ZIP;
		protected virtual System.String GetZIP() { return _ZIP; }
		protected virtual void SetZIP(System.String value) { _ZIP = value; _ZIPFieldIsDirty = true; }
		protected virtual bool _ZIPFieldIsDirty { get; set; }

		protected System.String _ADDRESS_CLEANSED_CD;
		protected virtual System.String GetADDRESS_CLEANSED_CD() { return _ADDRESS_CLEANSED_CD; }
		protected virtual void SetADDRESS_CLEANSED_CD(System.String value) { _ADDRESS_CLEANSED_CD = value; _ADDRESS_CLEANSED_CDFieldIsDirty = true; }
		protected virtual bool _ADDRESS_CLEANSED_CDFieldIsDirty { get; set; }

		protected System.String _FOREIGN_POSTAL_CODE;
		protected virtual System.String GetFOREIGN_POSTAL_CODE() { return _FOREIGN_POSTAL_CODE; }
		protected virtual void SetFOREIGN_POSTAL_CODE(System.String value) { _FOREIGN_POSTAL_CODE = value; _FOREIGN_POSTAL_CODEFieldIsDirty = true; }
		protected virtual bool _FOREIGN_POSTAL_CODEFieldIsDirty { get; set; }

		protected System.Int64 _CADR_ID;
		protected virtual System.Int64 GetCADR_ID() { return _CADR_ID; }
		protected virtual void SetCADR_ID(System.Int64 value) { _CADR_ID = value; _CADR_IDFieldIsDirty = true; }
		protected virtual bool _CADR_IDFieldIsDirty { get; set; }

		protected System.Int64 _CAU_ID;
		protected virtual System.Int64 GetCAU_ID() { return _CAU_ID; }
		protected virtual void SetCAU_ID(System.Int64 value) { _CAU_ID = value; _CAU_IDFieldIsDirty = true; }
		protected virtual bool _CAU_IDFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.String _BAD_ADDRESS_FLAG;
		protected virtual System.String GetBAD_ADDRESS_FLAG() { return _BAD_ADDRESS_FLAG; }
		protected virtual void SetBAD_ADDRESS_FLAG(System.String value) { _BAD_ADDRESS_FLAG = value; _BAD_ADDRESS_FLAGFieldIsDirty = true; }
		protected virtual bool _BAD_ADDRESS_FLAGFieldIsDirty { get; set; }

		protected System.String _STATE;
		protected virtual System.String GetSTATE() { return _STATE; }
		protected virtual void SetSTATE(System.String value) { _STATE = value; _STATEFieldIsDirty = true; }
		protected virtual bool _STATEFieldIsDirty { get; set; }

		protected System.String _ADDRESS1;
		protected virtual System.String GetADDRESS1() { return _ADDRESS1; }
		protected virtual void SetADDRESS1(System.String value) { _ADDRESS1 = value; _ADDRESS1FieldIsDirty = true; }
		protected virtual bool _ADDRESS1FieldIsDirty { get; set; }

		protected System.String _ADDRESS2;
		protected virtual System.String GetADDRESS2() { return _ADDRESS2; }
		protected virtual void SetADDRESS2(System.String value) { _ADDRESS2 = value; _ADDRESS2FieldIsDirty = true; }
		protected virtual bool _ADDRESS2FieldIsDirty { get; set; }

		protected System.String _FOREIGN_COUNTRY;
		protected virtual System.String GetFOREIGN_COUNTRY() { return _FOREIGN_COUNTRY; }
		protected virtual void SetFOREIGN_COUNTRY(System.String value) { _FOREIGN_COUNTRY = value; _FOREIGN_COUNTRYFieldIsDirty = true; }
		protected virtual bool _FOREIGN_COUNTRYFieldIsDirty { get; set; }

		#endregion

		#region Properties for table V_CLAIMANT_ADDRESS

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(28)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "CITY", "VARCHAR2", typeof(System.String))]
		public virtual System.String CITY { get { return GetCITY(); } set { SetCITY(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "FOREIGN_STATE_OR_PROVINCE", "VARCHAR2", typeof(System.String))]
		public virtual System.String FOREIGN_STATE_OR_PROVINCE { get { return GetFOREIGN_STATE_OR_PROVINCE(); } set { SetFOREIGN_STATE_OR_PROVINCE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "ZIP", "VARCHAR2", typeof(System.String))]
		public virtual System.String ZIP { get { return GetZIP(); } set { SetZIP(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "ADDRESS_CLEANSED_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDRESS_CLEANSED_CD { get { return GetADDRESS_CLEANSED_CD(); } set { SetADDRESS_CLEANSED_CD(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "FOREIGN_POSTAL_CODE", "VARCHAR2", typeof(System.String))]
		public virtual System.String FOREIGN_POSTAL_CODE { get { return GetFOREIGN_POSTAL_CODE(); } set { SetFOREIGN_POSTAL_CODE(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "CADR_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CADR_ID { get { return GetCADR_ID(); } set { SetCADR_ID(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "CAU_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CAU_ID { get { return GetCAU_ID(); } set { SetCAU_ID(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "BAD_ADDRESS_FLAG", "CHAR", typeof(System.String))]
		public virtual System.String BAD_ADDRESS_FLAG { get { return GetBAD_ADDRESS_FLAG(); } set { SetBAD_ADDRESS_FLAG(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "STATE", "CHAR", typeof(System.String))]
		public virtual System.String STATE { get { return GetSTATE(); } set { SetSTATE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(140)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "ADDRESS1", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDRESS1 { get { return GetADDRESS1(); } set { SetADDRESS1(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(35)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "ADDRESS2", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDRESS2 { get { return GetADDRESS2(); } set { SetADDRESS2(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_ADDRESS", "FOREIGN_COUNTRY", "VARCHAR2", typeof(System.String))]
		public virtual System.String FOREIGN_COUNTRY { get { return GetFOREIGN_COUNTRY(); } set { SetFOREIGN_COUNTRY(value); } }


		public virtual V_CLAIMANT Ref_VClaimant { get; set; }

		#endregion

		#region Constructors for table V_CLAIMANT_ADDRESSGen
		public V_CLAIMANT_ADDRESSGen()
		{
		}

		public V_CLAIMANT_ADDRESSGen(System.String CITY, System.String FOREIGN_STATE_OR_PROVINCE, System.String ZIP, System.String ADDRESS_CLEANSED_CD, System.String FOREIGN_POSTAL_CODE, System.Int64 CADR_ID, System.Int64 CAU_ID, System.Int64 PRTY_ID, System.String BAD_ADDRESS_FLAG, System.String STATE, System.String ADDRESS1, System.String ADDRESS2, System.String FOREIGN_COUNTRY) : this()
		{
			this._CITY = CITY;
			this._FOREIGN_STATE_OR_PROVINCE = FOREIGN_STATE_OR_PROVINCE;
			this._ZIP = ZIP;
			this._ADDRESS_CLEANSED_CD = ADDRESS_CLEANSED_CD;
			this._FOREIGN_POSTAL_CODE = FOREIGN_POSTAL_CODE;
			this._CADR_ID = CADR_ID;
			this._CAU_ID = CAU_ID;
			this._PRTY_ID = PRTY_ID;
			this._BAD_ADDRESS_FLAG = BAD_ADDRESS_FLAG;
			this._STATE = STATE;
			this._ADDRESS1 = ADDRESS1;
			this._ADDRESS2 = ADDRESS2;
			this._FOREIGN_COUNTRY = FOREIGN_COUNTRY;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_CLAIMANT_ADDRESSGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_CITYFieldIsDirty = value;
			_FOREIGN_STATE_OR_PROVINCEFieldIsDirty = value;
			_ZIPFieldIsDirty = value;
			_ADDRESS_CLEANSED_CDFieldIsDirty = value;
			_FOREIGN_POSTAL_CODEFieldIsDirty = value;
			_CADR_IDFieldIsDirty = value;
			_CAU_IDFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_BAD_ADDRESS_FLAGFieldIsDirty = value;
			_STATEFieldIsDirty = value;
			_ADDRESS1FieldIsDirty = value;
			_ADDRESS2FieldIsDirty = value;
			_FOREIGN_COUNTRYFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _CITYFieldIsDirty
				|| _FOREIGN_STATE_OR_PROVINCEFieldIsDirty
				|| _ZIPFieldIsDirty
				|| _ADDRESS_CLEANSED_CDFieldIsDirty
				|| _FOREIGN_POSTAL_CODEFieldIsDirty
				|| _CADR_IDFieldIsDirty
				|| _CAU_IDFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _BAD_ADDRESS_FLAGFieldIsDirty
				|| _STATEFieldIsDirty
				|| _ADDRESS1FieldIsDirty
				|| _ADDRESS2FieldIsDirty
				|| _FOREIGN_COUNTRYFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "V_CLAIMANT_ADDRESS";
		}

		public override string PrimaryKeyFieldname()
		{
			return "CAU_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (V_CLAIMANT_ADDRESS)this.Clone();
			result.CITY = this.CITY;
			result.FOREIGN_STATE_OR_PROVINCE = this.FOREIGN_STATE_OR_PROVINCE;
			result.ZIP = this.ZIP;
			result.ADDRESS_CLEANSED_CD = this.ADDRESS_CLEANSED_CD;
			result.FOREIGN_POSTAL_CODE = this.FOREIGN_POSTAL_CODE;
			result.CADR_ID = this.CADR_ID;
			result.CAU_ID = this.CAU_ID;
			result.PRTY_ID = this.PRTY_ID;
			result.BAD_ADDRESS_FLAG = this.BAD_ADDRESS_FLAG;
			result.STATE = this.STATE;
			result.ADDRESS1 = this.ADDRESS1;
			result.ADDRESS2 = this.ADDRESS2;
			result.FOREIGN_COUNTRY = this.FOREIGN_COUNTRY;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.V_CLAIMANT_ADDRESS")
				.Append(" { ")
				.Append("CITY")
				.Append(" = ")
				.Append(this.CITY.ToString())
				.Append("; ")
				.Append("FOREIGN_STATE_OR_PROVINCE")
				.Append(" = ")
				.Append(this.FOREIGN_STATE_OR_PROVINCE.ToString())
				.Append("; ")
				.Append("ZIP")
				.Append(" = ")
				.Append(this.ZIP.ToString())
				.Append("; ")
				.Append("ADDRESS_CLEANSED_CD")
				.Append(" = ")
				.Append(this.ADDRESS_CLEANSED_CD.ToString())
				.Append("; ")
				.Append("FOREIGN_POSTAL_CODE")
				.Append(" = ")
				.Append(this.FOREIGN_POSTAL_CODE.ToString())
				.Append("; ")
				.Append("CADR_ID")
				.Append(" = ")
				.Append(this.CADR_ID.ToString())
				.Append("; ")
				.Append("CAU_ID")
				.Append(" = ")
				.Append(this.CAU_ID.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("BAD_ADDRESS_FLAG")
				.Append(" = ")
				.Append(this.BAD_ADDRESS_FLAG.ToString())
				.Append("; ")
				.Append("STATE")
				.Append(" = ")
				.Append(this.STATE.ToString())
				.Append("; ")
				.Append("ADDRESS1")
				.Append(" = ")
				.Append(this.ADDRESS1.ToString())
				.Append("; ")
				.Append("ADDRESS2")
				.Append(" = ")
				.Append(this.ADDRESS2.ToString())
				.Append("; ")
				.Append("FOREIGN_COUNTRY")
				.Append(" = ")
				.Append(this.FOREIGN_COUNTRY.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_BOP_OWNER.V_CLAIMANT_PHONE.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "V_CLAIMANT_PHONE")]
	public partial class V_CLAIMANT_PHONEGen : V_CLAIMANT_PHONEBase
	{
		#region Property backing stores for table V_CLAIMANT_PHONE
		protected System.Int64 _CP_ID;
		protected virtual System.Int64 GetCP_ID() { return _CP_ID; }
		protected virtual void SetCP_ID(System.Int64 value) { _CP_ID = value; _CP_IDFieldIsDirty = true; }
		protected virtual bool _CP_IDFieldIsDirty { get; set; }

		protected System.Int64 _CLI_ID;
		protected virtual System.Int64 GetCLI_ID() { return _CLI_ID; }
		protected virtual void SetCLI_ID(System.Int64 value) { _CLI_ID = value; _CLI_IDFieldIsDirty = true; }
		protected virtual bool _CLI_IDFieldIsDirty { get; set; }

		protected System.String _PHONE;
		protected virtual System.String GetPHONE() { return _PHONE; }
		protected virtual void SetPHONE(System.String value) { _PHONE = value; _PHONEFieldIsDirty = true; }
		protected virtual bool _PHONEFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.String _TYPE_CD;
		protected virtual System.String GetTYPE_CD() { return _TYPE_CD; }
		protected virtual void SetTYPE_CD(System.String value) { _TYPE_CD = value; _TYPE_CDFieldIsDirty = true; }
		protected virtual bool _TYPE_CDFieldIsDirty { get; set; }

		protected System.String _BAD_PHONE_FLAG;
		protected virtual System.String GetBAD_PHONE_FLAG() { return _BAD_PHONE_FLAG; }
		protected virtual void SetBAD_PHONE_FLAG(System.String value) { _BAD_PHONE_FLAG = value; _BAD_PHONE_FLAGFieldIsDirty = true; }
		protected virtual bool _BAD_PHONE_FLAGFieldIsDirty { get; set; }

		#endregion

		#region Properties for table V_CLAIMANT_PHONE

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "CP_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CP_ID { get { return GetCP_ID(); } set { SetCP_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "CLI_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CLI_ID { get { return GetCLI_ID(); } set { SetCLI_ID(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "PHONE", "CHAR", typeof(System.String))]
		public virtual System.String PHONE { get { return GetPHONE(); } set { SetPHONE(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "TYPE_CD", "CHAR", typeof(System.String))]
		public virtual System.String TYPE_CD { get { return GetTYPE_CD(); } set { SetTYPE_CD(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_CLAIMANT_PHONE", "BAD_PHONE_FLAG", "CHAR", typeof(System.String))]
		public virtual System.String BAD_PHONE_FLAG { get { return GetBAD_PHONE_FLAG(); } set { SetBAD_PHONE_FLAG(value); } }


		public virtual V_CLAIMANT Ref_VClaimant { get; set; }

		#endregion

		#region Constructors for table V_CLAIMANT_PHONEGen
		public V_CLAIMANT_PHONEGen()
		{
		}

		public V_CLAIMANT_PHONEGen(System.Int64 CP_ID, System.Int64 CLI_ID, System.String PHONE, System.Int64 PRTY_ID, System.String TYPE_CD, System.String BAD_PHONE_FLAG) : this()
		{
			this._CP_ID = CP_ID;
			this._CLI_ID = CLI_ID;
			this._PHONE = PHONE;
			this._PRTY_ID = PRTY_ID;
			this._TYPE_CD = TYPE_CD;
			this._BAD_PHONE_FLAG = BAD_PHONE_FLAG;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_CLAIMANT_PHONEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_CP_IDFieldIsDirty = value;
			_CLI_IDFieldIsDirty = value;
			_PHONEFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_TYPE_CDFieldIsDirty = value;
			_BAD_PHONE_FLAGFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _CP_IDFieldIsDirty
				|| _CLI_IDFieldIsDirty
				|| _PHONEFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _TYPE_CDFieldIsDirty
				|| _BAD_PHONE_FLAGFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "V_CLAIMANT_PHONE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "CP_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (V_CLAIMANT_PHONE)this.Clone();
			result.CP_ID = this.CP_ID;
			result.CLI_ID = this.CLI_ID;
			result.PHONE = this.PHONE;
			result.PRTY_ID = this.PRTY_ID;
			result.TYPE_CD = this.TYPE_CD;
			result.BAD_PHONE_FLAG = this.BAD_PHONE_FLAG;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.V_CLAIMANT_PHONE")
				.Append(" { ")
				.Append("CP_ID")
				.Append(" = ")
				.Append(this.CP_ID.ToString())
				.Append("; ")
				.Append("CLI_ID")
				.Append(" = ")
				.Append(this.CLI_ID.ToString())
				.Append("; ")
				.Append("PHONE")
				.Append(" = ")
				.Append(this.PHONE.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("TYPE_CD")
				.Append(" = ")
				.Append(this.TYPE_CD.ToString())
				.Append("; ")
				.Append("BAD_PHONE_FLAG")
				.Append(" = ")
				.Append(this.BAD_PHONE_FLAG.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_BOP_OWNER.V_OPGROUP.PRTY_ID->CATS_BOP_OWNER.V_CLAIMANT.PRTY_ID
	//Reference to -> CATS_BOP_OWNER.V_OPGROUP.OPCSE_CD->CUBS_OWNER.OP_CAUSE_CODES.OPCSE_CD
	//Reference to -> CATS_BOP_OWNER.V_OPGROUP.OPCLS_CD->CUBS_OWNER.OP_CLASS_CODES.OPCLS_CD
	//Reference to -> CATS_BOP_OWNER.V_OPGROUP.OPSRC_CD->CUBS_OWNER.OP_SOURCE_CODES.OPSRC_CD
	//ReferencedBy -> CUBS_OWNER.OP_TRANSACTIONS.OPGRP_ID->CATS_BOP_OWNER.V_OPGROUP.OPGRP_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_BOP_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_BOP_OWNER", "V_OPGROUP")]
	public partial class V_OPGROUPGen : V_OPGROUPBase
	{
		#region Property backing stores for table V_OPGROUP
		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.Decimal? _STIM_OFFSET_RCVRY_AMT;
		protected virtual System.Decimal? GetSTIM_OFFSET_RCVRY_AMT() { return _STIM_OFFSET_RCVRY_AMT; }
		protected virtual void SetSTIM_OFFSET_RCVRY_AMT(System.Decimal? value) { _STIM_OFFSET_RCVRY_AMT = value; _STIM_OFFSET_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _STIM_OFFSET_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.Int64? _ISS_ID;
		protected virtual System.Int64? GetISS_ID() { return _ISS_ID; }
		protected virtual void SetISS_ID(System.Int64? value) { _ISS_ID = value; _ISS_IDFieldIsDirty = true; }
		protected virtual bool _ISS_IDFieldIsDirty { get; set; }

		protected System.Decimal _PENALTY_AMT;
		protected virtual System.Decimal GetPENALTY_AMT() { return _PENALTY_AMT; }
		protected virtual void SetPENALTY_AMT(System.Decimal value) { _PENALTY_AMT = value; _PENALTY_AMTFieldIsDirty = true; }
		protected virtual bool _PENALTY_AMTFieldIsDirty { get; set; }

		protected System.Int64 _CLM_ID;
		protected virtual System.Int64 GetCLM_ID() { return _CLM_ID; }
		protected virtual void SetCLM_ID(System.Int64 value) { _CLM_ID = value; _CLM_IDFieldIsDirty = true; }
		protected virtual bool _CLM_IDFieldIsDirty { get; set; }

		protected System.String _PROGRAM_TYP;
		protected virtual System.String GetPROGRAM_TYP() { return _PROGRAM_TYP; }
		protected virtual void SetPROGRAM_TYP(System.String value) { _PROGRAM_TYP = value; _PROGRAM_TYPFieldIsDirty = true; }
		protected virtual bool _PROGRAM_TYPFieldIsDirty { get; set; }

		protected System.Decimal? _STIM_PENALTY_AMT;
		protected virtual System.Decimal? GetSTIM_PENALTY_AMT() { return _STIM_PENALTY_AMT; }
		protected virtual void SetSTIM_PENALTY_AMT(System.Decimal? value) { _STIM_PENALTY_AMT = value; _STIM_PENALTY_AMTFieldIsDirty = true; }
		protected virtual bool _STIM_PENALTY_AMTFieldIsDirty { get; set; }

		protected System.DateTime? _PROSECUTION_BEG_DT;
		protected virtual System.DateTime? GetPROSECUTION_BEG_DT() { return _PROSECUTION_BEG_DT; }
		protected virtual void SetPROSECUTION_BEG_DT(System.DateTime? value) { _PROSECUTION_BEG_DT = value; _PROSECUTION_BEG_DTFieldIsDirty = true; }
		protected virtual bool _PROSECUTION_BEG_DTFieldIsDirty { get; set; }

		protected System.DateTime _ESTABLISH_DT;
		protected virtual System.DateTime GetESTABLISH_DT() { return _ESTABLISH_DT; }
		protected virtual void SetESTABLISH_DT(System.DateTime value) { _ESTABLISH_DT = value; _ESTABLISH_DTFieldIsDirty = true; }
		protected virtual bool _ESTABLISH_DTFieldIsDirty { get; set; }

		protected System.Int16 _WRITE_OFF_IND;
		protected virtual System.Int16 GetWRITE_OFF_IND() { return _WRITE_OFF_IND; }
		protected virtual void SetWRITE_OFF_IND(System.Int16 value) { _WRITE_OFF_IND = value; _WRITE_OFF_INDFieldIsDirty = true; }
		protected virtual bool _WRITE_OFF_INDFieldIsDirty { get; set; }

		protected System.Decimal _COST_AMT;
		protected virtual System.Decimal GetCOST_AMT() { return _COST_AMT; }
		protected virtual void SetCOST_AMT(System.Decimal value) { _COST_AMT = value; _COST_AMTFieldIsDirty = true; }
		protected virtual bool _COST_AMTFieldIsDirty { get; set; }

		protected System.Decimal? _CANCEL_OP_BAL_AMT;
		protected virtual System.Decimal? GetCANCEL_OP_BAL_AMT() { return _CANCEL_OP_BAL_AMT; }
		protected virtual void SetCANCEL_OP_BAL_AMT(System.Decimal? value) { _CANCEL_OP_BAL_AMT = value; _CANCEL_OP_BAL_AMTFieldIsDirty = true; }
		protected virtual bool _CANCEL_OP_BAL_AMTFieldIsDirty { get; set; }

		protected System.String _STATE_CD;
		protected virtual System.String GetSTATE_CD() { return _STATE_CD; }
		protected virtual void SetSTATE_CD(System.String value) { _STATE_CD = value; _STATE_CDFieldIsDirty = true; }
		protected virtual bool _STATE_CDFieldIsDirty { get; set; }

		protected System.Decimal _OP_AMT;
		protected virtual System.Decimal GetOP_AMT() { return _OP_AMT; }
		protected virtual void SetOP_AMT(System.Decimal value) { _OP_AMT = value; _OP_AMTFieldIsDirty = true; }
		protected virtual bool _OP_AMTFieldIsDirty { get; set; }

		protected System.DateTime? _NOTIFY_DT;
		protected virtual System.DateTime? GetNOTIFY_DT() { return _NOTIFY_DT; }
		protected virtual void SetNOTIFY_DT(System.DateTime? value) { _NOTIFY_DT = value; _NOTIFY_DTFieldIsDirty = true; }
		protected virtual bool _NOTIFY_DTFieldIsDirty { get; set; }

		protected System.Decimal _INTEREST_AMT;
		protected virtual System.Decimal GetINTEREST_AMT() { return _INTEREST_AMT; }
		protected virtual void SetINTEREST_AMT(System.Decimal value) { _INTEREST_AMT = value; _INTEREST_AMTFieldIsDirty = true; }
		protected virtual bool _INTEREST_AMTFieldIsDirty { get; set; }

		protected System.Decimal _OFFSET_RCVRY_AMT;
		protected virtual System.Decimal GetOFFSET_RCVRY_AMT() { return _OFFSET_RCVRY_AMT; }
		protected virtual void SetOFFSET_RCVRY_AMT(System.Decimal value) { _OFFSET_RCVRY_AMT = value; _OFFSET_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _OFFSET_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.DateTime? _PROSECUTION_END_DT;
		protected virtual System.DateTime? GetPROSECUTION_END_DT() { return _PROSECUTION_END_DT; }
		protected virtual void SetPROSECUTION_END_DT(System.DateTime? value) { _PROSECUTION_END_DT = value; _PROSECUTION_END_DTFieldIsDirty = true; }
		protected virtual bool _PROSECUTION_END_DTFieldIsDirty { get; set; }

		protected System.Int64? _RECOVERY_LOGIC_CD;
		protected virtual System.Int64? GetRECOVERY_LOGIC_CD() { return _RECOVERY_LOGIC_CD; }
		protected virtual void SetRECOVERY_LOGIC_CD(System.Int64? value) { _RECOVERY_LOGIC_CD = value; _RECOVERY_LOGIC_CDFieldIsDirty = true; }
		protected virtual bool _RECOVERY_LOGIC_CDFieldIsDirty { get; set; }

		protected System.DateTime? _WRITE_OFF_DT;
		protected virtual System.DateTime? GetWRITE_OFF_DT() { return _WRITE_OFF_DT; }
		protected virtual void SetWRITE_OFF_DT(System.DateTime? value) { _WRITE_OFF_DT = value; _WRITE_OFF_DTFieldIsDirty = true; }
		protected virtual bool _WRITE_OFF_DTFieldIsDirty { get; set; }

		protected System.String _OPSRC_CD;
		protected virtual System.String GetOPSRC_CD() { return _OPSRC_CD; }
		protected virtual void SetOPSRC_CD(System.String value) { _OPSRC_CD = value; _OPSRC_CDFieldIsDirty = true; }
		protected virtual bool _OPSRC_CDFieldIsDirty { get; set; }

		protected System.String _FUND_CD;
		protected virtual System.String GetFUND_CD() { return _FUND_CD; }
		protected virtual void SetFUND_CD(System.String value) { _FUND_CD = value; _FUND_CDFieldIsDirty = true; }
		protected virtual bool _FUND_CDFieldIsDirty { get; set; }

		protected System.DateTime? _REMOVED_DT;
		protected virtual System.DateTime? GetREMOVED_DT() { return _REMOVED_DT; }
		protected virtual void SetREMOVED_DT(System.DateTime? value) { _REMOVED_DT = value; _REMOVED_DTFieldIsDirty = true; }
		protected virtual bool _REMOVED_DTFieldIsDirty { get; set; }

		protected System.Int64 _REQ_ISS_ID;
		protected virtual System.Int64 GetREQ_ISS_ID() { return _REQ_ISS_ID; }
		protected virtual void SetREQ_ISS_ID(System.Int64 value) { _REQ_ISS_ID = value; _REQ_ISS_IDFieldIsDirty = true; }
		protected virtual bool _REQ_ISS_IDFieldIsDirty { get; set; }

		protected System.Int16? _FRAUD_IND;
		protected virtual System.Int16? GetFRAUD_IND() { return _FRAUD_IND; }
		protected virtual void SetFRAUD_IND(System.Int16? value) { _FRAUD_IND = value; _FRAUD_INDFieldIsDirty = true; }
		protected virtual bool _FRAUD_INDFieldIsDirty { get; set; }

		protected System.DateTime? _OOS_OP_DT;
		protected virtual System.DateTime? GetOOS_OP_DT() { return _OOS_OP_DT; }
		protected virtual void SetOOS_OP_DT(System.DateTime? value) { _OOS_OP_DT = value; _OOS_OP_DTFieldIsDirty = true; }
		protected virtual bool _OOS_OP_DTFieldIsDirty { get; set; }

		protected System.Int64? _PARENT_OPGRP_ID;
		protected virtual System.Int64? GetPARENT_OPGRP_ID() { return _PARENT_OPGRP_ID; }
		protected virtual void SetPARENT_OPGRP_ID(System.Int64? value) { _PARENT_OPGRP_ID = value; _PARENT_OPGRP_IDFieldIsDirty = true; }
		protected virtual bool _PARENT_OPGRP_IDFieldIsDirty { get; set; }

		protected System.Decimal _WRITTEN_OFF_AMT;
		protected virtual System.Decimal GetWRITTEN_OFF_AMT() { return _WRITTEN_OFF_AMT; }
		protected virtual void SetWRITTEN_OFF_AMT(System.Decimal value) { _WRITTEN_OFF_AMT = value; _WRITTEN_OFF_AMTFieldIsDirty = true; }
		protected virtual bool _WRITTEN_OFF_AMTFieldIsDirty { get; set; }

		protected System.Decimal _CASH_RCVRY_AMT;
		protected virtual System.Decimal GetCASH_RCVRY_AMT() { return _CASH_RCVRY_AMT; }
		protected virtual void SetCASH_RCVRY_AMT(System.Decimal value) { _CASH_RCVRY_AMT = value; _CASH_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _CASH_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.Decimal _OP_BAL_AMT;
		protected virtual System.Decimal GetOP_BAL_AMT() { return _OP_BAL_AMT; }
		protected virtual void SetOP_BAL_AMT(System.Decimal value) { _OP_BAL_AMT = value; _OP_BAL_AMTFieldIsDirty = true; }
		protected virtual bool _OP_BAL_AMTFieldIsDirty { get; set; }

		protected System.Int64? _AP_DCKT_RES_ID;
		protected virtual System.Int64? GetAP_DCKT_RES_ID() { return _AP_DCKT_RES_ID; }
		protected virtual void SetAP_DCKT_RES_ID(System.Int64? value) { _AP_DCKT_RES_ID = value; _AP_DCKT_RES_IDFieldIsDirty = true; }
		protected virtual bool _AP_DCKT_RES_IDFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.Int16? _PROSECUTION_IND;
		protected virtual System.Int16? GetPROSECUTION_IND() { return _PROSECUTION_IND; }
		protected virtual void SetPROSECUTION_IND(System.Int16? value) { _PROSECUTION_IND = value; _PROSECUTION_INDFieldIsDirty = true; }
		protected virtual bool _PROSECUTION_INDFieldIsDirty { get; set; }

		protected System.Int16? _MAIL_IND;
		protected virtual System.Int16? GetMAIL_IND() { return _MAIL_IND; }
		protected virtual void SetMAIL_IND(System.Int16? value) { _MAIL_IND = value; _MAIL_INDFieldIsDirty = true; }
		protected virtual bool _MAIL_INDFieldIsDirty { get; set; }

		protected System.String _OPCLS_CD;
		protected virtual System.String GetOPCLS_CD() { return _OPCLS_CD; }
		protected virtual void SetOPCLS_CD(System.String value) { _OPCLS_CD = value; _OPCLS_CDFieldIsDirty = true; }
		protected virtual bool _OPCLS_CDFieldIsDirty { get; set; }

		protected System.DateTime? _OPGRP_DSP_DT;
		protected virtual System.DateTime? GetOPGRP_DSP_DT() { return _OPGRP_DSP_DT; }
		protected virtual void SetOPGRP_DSP_DT(System.DateTime? value) { _OPGRP_DSP_DT = value; _OPGRP_DSP_DTFieldIsDirty = true; }
		protected virtual bool _OPGRP_DSP_DTFieldIsDirty { get; set; }

		protected System.Decimal _CHARGE_OFF_AMT;
		protected virtual System.Decimal GetCHARGE_OFF_AMT() { return _CHARGE_OFF_AMT; }
		protected virtual void SetCHARGE_OFF_AMT(System.Decimal value) { _CHARGE_OFF_AMT = value; _CHARGE_OFF_AMTFieldIsDirty = true; }
		protected virtual bool _CHARGE_OFF_AMTFieldIsDirty { get; set; }

		protected System.Decimal _WAIVE_AMT;
		protected virtual System.Decimal GetWAIVE_AMT() { return _WAIVE_AMT; }
		protected virtual void SetWAIVE_AMT(System.Decimal value) { _WAIVE_AMT = value; _WAIVE_AMTFieldIsDirty = true; }
		protected virtual bool _WAIVE_AMTFieldIsDirty { get; set; }

		protected System.Int16? _APPEAL_HOLD_IND;
		protected virtual System.Int16? GetAPPEAL_HOLD_IND() { return _APPEAL_HOLD_IND; }
		protected virtual void SetAPPEAL_HOLD_IND(System.Int16? value) { _APPEAL_HOLD_IND = value; _APPEAL_HOLD_INDFieldIsDirty = true; }
		protected virtual bool _APPEAL_HOLD_INDFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.Int64 _OPGRP_ID;
		protected virtual System.Int64 GetOPGRP_ID() { return _OPGRP_ID; }
		protected virtual void SetOPGRP_ID(System.Int64 value) { _OPGRP_ID = value; _OPGRP_IDFieldIsDirty = true; }
		protected virtual bool _OPGRP_IDFieldIsDirty { get; set; }

		protected System.Decimal? _STIM_OP_AMT;
		protected virtual System.Decimal? GetSTIM_OP_AMT() { return _STIM_OP_AMT; }
		protected virtual void SetSTIM_OP_AMT(System.Decimal? value) { _STIM_OP_AMT = value; _STIM_OP_AMTFieldIsDirty = true; }
		protected virtual bool _STIM_OP_AMTFieldIsDirty { get; set; }

		protected System.String _OPCSE_CD;
		protected virtual System.String GetOPCSE_CD() { return _OPCSE_CD; }
		protected virtual void SetOPCSE_CD(System.String value) { _OPCSE_CD = value; _OPCSE_CDFieldIsDirty = true; }
		protected virtual bool _OPCSE_CDFieldIsDirty { get; set; }

		protected System.Int16? _BKCY_IND;
		protected virtual System.Int16? GetBKCY_IND() { return _BKCY_IND; }
		protected virtual void SetBKCY_IND(System.Int16? value) { _BKCY_IND = value; _BKCY_INDFieldIsDirty = true; }
		protected virtual bool _BKCY_INDFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_DT;
		protected virtual System.DateTime? GetMODIFIED_DT() { return _MODIFIED_DT; }
		protected virtual void SetMODIFIED_DT(System.DateTime? value) { _MODIFIED_DT = value; _MODIFIED_DTFieldIsDirty = true; }
		protected virtual bool _MODIFIED_DTFieldIsDirty { get; set; }

		protected System.Decimal _FINES_AMT;
		protected virtual System.Decimal GetFINES_AMT() { return _FINES_AMT; }
		protected virtual void SetFINES_AMT(System.Decimal value) { _FINES_AMT = value; _FINES_AMTFieldIsDirty = true; }
		protected virtual bool _FINES_AMTFieldIsDirty { get; set; }

		protected System.String _RSPAGT_CD;
		protected virtual System.String GetRSPAGT_CD() { return _RSPAGT_CD; }
		protected virtual void SetRSPAGT_CD(System.String value) { _RSPAGT_CD = value; _RSPAGT_CDFieldIsDirty = true; }
		protected virtual bool _RSPAGT_CDFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_DT;
		protected virtual System.DateTime GetCREATED_DT() { return _CREATED_DT; }
		protected virtual void SetCREATED_DT(System.DateTime value) { _CREATED_DT = value; _CREATED_DTFieldIsDirty = true; }
		protected virtual bool _CREATED_DTFieldIsDirty { get; set; }

		protected System.String _OPGRP_DSP_CD;
		protected virtual System.String GetOPGRP_DSP_CD() { return _OPGRP_DSP_CD; }
		protected virtual void SetOPGRP_DSP_CD(System.String value) { _OPGRP_DSP_CD = value; _OPGRP_DSP_CDFieldIsDirty = true; }
		protected virtual bool _OPGRP_DSP_CDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table V_OPGROUP

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "STIM_OFFSET_RCVRY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? STIM_OFFSET_RCVRY_AMT { get { return GetSTIM_OFFSET_RCVRY_AMT(); } set { SetSTIM_OFFSET_RCVRY_AMT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "ISS_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? ISS_ID { get { return GetISS_ID(); } set { SetISS_ID(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "PENALTY_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal PENALTY_AMT { get { return GetPENALTY_AMT(); } set { SetPENALTY_AMT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "CLM_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CLM_ID { get { return GetCLM_ID(); } set { SetCLM_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(400)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "PROGRAM_TYP", "VARCHAR2", typeof(System.String))]
		public virtual System.String PROGRAM_TYP { get { return GetPROGRAM_TYP(); } set { SetPROGRAM_TYP(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "STIM_PENALTY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? STIM_PENALTY_AMT { get { return GetSTIM_PENALTY_AMT(); } set { SetSTIM_PENALTY_AMT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "PROSECUTION_BEG_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? PROSECUTION_BEG_DT { get { return GetPROSECUTION_BEG_DT(); } set { SetPROSECUTION_BEG_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "ESTABLISH_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime ESTABLISH_DT { get { return GetESTABLISH_DT(); } set { SetESTABLISH_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "WRITE_OFF_IND", "NUMBER", typeof(System.Int16))]
		public virtual System.Int16 WRITE_OFF_IND { get { return GetWRITE_OFF_IND(); } set { SetWRITE_OFF_IND(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "COST_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal COST_AMT { get { return GetCOST_AMT(); } set { SetCOST_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "CANCEL_OP_BAL_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? CANCEL_OP_BAL_AMT { get { return GetCANCEL_OP_BAL_AMT(); } set { SetCANCEL_OP_BAL_AMT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "STATE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String STATE_CD { get { return GetSTATE_CD(); } set { SetSTATE_CD(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OP_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal OP_AMT { get { return GetOP_AMT(); } set { SetOP_AMT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "NOTIFY_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? NOTIFY_DT { get { return GetNOTIFY_DT(); } set { SetNOTIFY_DT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "INTEREST_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal INTEREST_AMT { get { return GetINTEREST_AMT(); } set { SetINTEREST_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OFFSET_RCVRY_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal OFFSET_RCVRY_AMT { get { return GetOFFSET_RCVRY_AMT(); } set { SetOFFSET_RCVRY_AMT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "PROSECUTION_END_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? PROSECUTION_END_DT { get { return GetPROSECUTION_END_DT(); } set { SetPROSECUTION_END_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "RECOVERY_LOGIC_CD", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? RECOVERY_LOGIC_CD { get { return GetRECOVERY_LOGIC_CD(); } set { SetRECOVERY_LOGIC_CD(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "WRITE_OFF_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? WRITE_OFF_DT { get { return GetWRITE_OFF_DT(); } set { SetWRITE_OFF_DT(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "V_OPGROUP", "OPSRC_CD", "CUBS_OWNER", "OP_SOURCE_CODES", "OPSRC_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OPSRC_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPSRC_CD { get { return GetOPSRC_CD(); } set { SetOPSRC_CD(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "FUND_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String FUND_CD { get { return GetFUND_CD(); } set { SetFUND_CD(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "REMOVED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? REMOVED_DT { get { return GetREMOVED_DT(); } set { SetREMOVED_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "REQ_ISS_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 REQ_ISS_ID { get { return GetREQ_ISS_ID(); } set { SetREQ_ISS_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "FRAUD_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? FRAUD_IND { get { return GetFRAUD_IND(); } set { SetFRAUD_IND(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OOS_OP_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? OOS_OP_DT { get { return GetOOS_OP_DT(); } set { SetOOS_OP_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "PARENT_OPGRP_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PARENT_OPGRP_ID { get { return GetPARENT_OPGRP_ID(); } set { SetPARENT_OPGRP_ID(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "WRITTEN_OFF_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal WRITTEN_OFF_AMT { get { return GetWRITTEN_OFF_AMT(); } set { SetWRITTEN_OFF_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "CASH_RCVRY_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal CASH_RCVRY_AMT { get { return GetCASH_RCVRY_AMT(); } set { SetCASH_RCVRY_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OP_BAL_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal OP_BAL_AMT { get { return GetOP_BAL_AMT(); } set { SetOP_BAL_AMT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "AP_DCKT_RES_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? AP_DCKT_RES_ID { get { return GetAP_DCKT_RES_ID(); } set { SetAP_DCKT_RES_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "PROSECUTION_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? PROSECUTION_IND { get { return GetPROSECUTION_IND(); } set { SetPROSECUTION_IND(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "MAIL_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? MAIL_IND { get { return GetMAIL_IND(); } set { SetMAIL_IND(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "V_OPGROUP", "OPCLS_CD", "CUBS_OWNER", "OP_CLASS_CODES", "OPCLS_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OPCLS_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPCLS_CD { get { return GetOPCLS_CD(); } set { SetOPCLS_CD(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OPGRP_DSP_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? OPGRP_DSP_DT { get { return GetOPGRP_DSP_DT(); } set { SetOPGRP_DSP_DT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "CHARGE_OFF_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal CHARGE_OFF_AMT { get { return GetCHARGE_OFF_AMT(); } set { SetCHARGE_OFF_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "WAIVE_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal WAIVE_AMT { get { return GetWAIVE_AMT(); } set { SetWAIVE_AMT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "APPEAL_HOLD_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? APPEAL_HOLD_IND { get { return GetAPPEAL_HOLD_IND(); } set { SetAPPEAL_HOLD_IND(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "V_OPGROUP", "PRTY_ID", "CATS_BOP_OWNER", "V_CLAIMANT", "PRTY_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CUBS_OWNER", "OP_TRANSACTIONS", "OPGRP_ID", "CATS_BOP_OWNER", "V_OPGROUP", "OPGRP_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OPGRP_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 OPGRP_ID { get { return GetOPGRP_ID(); } set { SetOPGRP_ID(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "STIM_OP_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? STIM_OP_AMT { get { return GetSTIM_OP_AMT(); } set { SetSTIM_OP_AMT(value); } }

		[ReferenceTo("CATS_BOP_OWNER", "V_OPGROUP", "OPCSE_CD", "CUBS_OWNER", "OP_CAUSE_CODES", "OPCSE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OPCSE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPCSE_CD { get { return GetOPCSE_CD(); } set { SetOPCSE_CD(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "BKCY_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? BKCY_IND { get { return GetBKCY_IND(); } set { SetBKCY_IND(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "MODIFIED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_DT { get { return GetMODIFIED_DT(); } set { SetMODIFIED_DT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "FINES_AMT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal FINES_AMT { get { return GetFINES_AMT(); } set { SetFINES_AMT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "RSPAGT_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String RSPAGT_CD { get { return GetRSPAGT_CD(); } set { SetRSPAGT_CD(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "CREATED_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_DT { get { return GetCREATED_DT(); } set { SetCREATED_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_BOP_OWNER", "V_OPGROUP", "OPGRP_DSP_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPGRP_DSP_CD { get { return GetOPGRP_DSP_CD(); } set { SetOPGRP_DSP_CD(value); } }


		public virtual V_CLAIMANT Ref_VClaimant { get; set; }
		public virtual OP_CAUSE_CODES Ref_OpCauseCodes { get; set; }
		public virtual OP_CLASS_CODES Ref_OpClassCodes { get; set; }
		public virtual OP_SOURCE_CODES Ref_OpSourceCodes { get; set; }
		public virtual ICollection<OP_TRANSACTIONS> RefMany_OpTransactions_OpgrpId { get; set; }

		#endregion

		#region Constructors for table V_OPGROUPGen
		public V_OPGROUPGen()
		{
		}

		public V_OPGROUPGen(System.Int64 CREATED_BY, System.Decimal? STIM_OFFSET_RCVRY_AMT, System.Int64? ISS_ID, System.Decimal PENALTY_AMT, System.Int64 CLM_ID, System.String PROGRAM_TYP, System.Decimal? STIM_PENALTY_AMT, System.DateTime? PROSECUTION_BEG_DT, System.DateTime ESTABLISH_DT, System.Int16 WRITE_OFF_IND, System.Decimal COST_AMT, System.Decimal? CANCEL_OP_BAL_AMT, System.String STATE_CD, System.Decimal OP_AMT, System.DateTime? NOTIFY_DT, System.Decimal INTEREST_AMT, System.Decimal OFFSET_RCVRY_AMT, System.DateTime? PROSECUTION_END_DT, System.Int64? RECOVERY_LOGIC_CD, System.DateTime? WRITE_OFF_DT, System.String OPSRC_CD, System.String FUND_CD, System.DateTime? REMOVED_DT, System.Int64 REQ_ISS_ID, System.Int16? FRAUD_IND, System.DateTime? OOS_OP_DT, System.Int64? PARENT_OPGRP_ID, System.Decimal WRITTEN_OFF_AMT, System.Decimal CASH_RCVRY_AMT, System.Decimal OP_BAL_AMT, System.Int64? AP_DCKT_RES_ID, System.Int64? MODIFIED_BY, System.Int16? PROSECUTION_IND, System.Int16? MAIL_IND, System.String OPCLS_CD, System.DateTime? OPGRP_DSP_DT, System.Decimal CHARGE_OFF_AMT, System.Decimal WAIVE_AMT, System.Int16? APPEAL_HOLD_IND, System.Int64 PRTY_ID, System.Int64 OPGRP_ID, System.Decimal? STIM_OP_AMT, System.String OPCSE_CD, System.Int16? BKCY_IND, System.DateTime? MODIFIED_DT, System.Decimal FINES_AMT, System.String RSPAGT_CD, System.DateTime CREATED_DT, System.String OPGRP_DSP_CD) : this()
		{
			this._CREATED_BY = CREATED_BY;
			this._STIM_OFFSET_RCVRY_AMT = STIM_OFFSET_RCVRY_AMT;
			this._ISS_ID = ISS_ID;
			this._PENALTY_AMT = PENALTY_AMT;
			this._CLM_ID = CLM_ID;
			this._PROGRAM_TYP = PROGRAM_TYP;
			this._STIM_PENALTY_AMT = STIM_PENALTY_AMT;
			this._PROSECUTION_BEG_DT = PROSECUTION_BEG_DT;
			this._ESTABLISH_DT = ESTABLISH_DT;
			this._WRITE_OFF_IND = WRITE_OFF_IND;
			this._COST_AMT = COST_AMT;
			this._CANCEL_OP_BAL_AMT = CANCEL_OP_BAL_AMT;
			this._STATE_CD = STATE_CD;
			this._OP_AMT = OP_AMT;
			this._NOTIFY_DT = NOTIFY_DT;
			this._INTEREST_AMT = INTEREST_AMT;
			this._OFFSET_RCVRY_AMT = OFFSET_RCVRY_AMT;
			this._PROSECUTION_END_DT = PROSECUTION_END_DT;
			this._RECOVERY_LOGIC_CD = RECOVERY_LOGIC_CD;
			this._WRITE_OFF_DT = WRITE_OFF_DT;
			this._OPSRC_CD = OPSRC_CD;
			this._FUND_CD = FUND_CD;
			this._REMOVED_DT = REMOVED_DT;
			this._REQ_ISS_ID = REQ_ISS_ID;
			this._FRAUD_IND = FRAUD_IND;
			this._OOS_OP_DT = OOS_OP_DT;
			this._PARENT_OPGRP_ID = PARENT_OPGRP_ID;
			this._WRITTEN_OFF_AMT = WRITTEN_OFF_AMT;
			this._CASH_RCVRY_AMT = CASH_RCVRY_AMT;
			this._OP_BAL_AMT = OP_BAL_AMT;
			this._AP_DCKT_RES_ID = AP_DCKT_RES_ID;
			this._MODIFIED_BY = MODIFIED_BY;
			this._PROSECUTION_IND = PROSECUTION_IND;
			this._MAIL_IND = MAIL_IND;
			this._OPCLS_CD = OPCLS_CD;
			this._OPGRP_DSP_DT = OPGRP_DSP_DT;
			this._CHARGE_OFF_AMT = CHARGE_OFF_AMT;
			this._WAIVE_AMT = WAIVE_AMT;
			this._APPEAL_HOLD_IND = APPEAL_HOLD_IND;
			this._PRTY_ID = PRTY_ID;
			this._OPGRP_ID = OPGRP_ID;
			this._STIM_OP_AMT = STIM_OP_AMT;
			this._OPCSE_CD = OPCSE_CD;
			this._BKCY_IND = BKCY_IND;
			this._MODIFIED_DT = MODIFIED_DT;
			this._FINES_AMT = FINES_AMT;
			this._RSPAGT_CD = RSPAGT_CD;
			this._CREATED_DT = CREATED_DT;
			this._OPGRP_DSP_CD = OPGRP_DSP_CD;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(V_OPGROUPGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_CREATED_BYFieldIsDirty = value;
			_STIM_OFFSET_RCVRY_AMTFieldIsDirty = value;
			_ISS_IDFieldIsDirty = value;
			_PENALTY_AMTFieldIsDirty = value;
			_CLM_IDFieldIsDirty = value;
			_PROGRAM_TYPFieldIsDirty = value;
			_STIM_PENALTY_AMTFieldIsDirty = value;
			_PROSECUTION_BEG_DTFieldIsDirty = value;
			_ESTABLISH_DTFieldIsDirty = value;
			_WRITE_OFF_INDFieldIsDirty = value;
			_COST_AMTFieldIsDirty = value;
			_CANCEL_OP_BAL_AMTFieldIsDirty = value;
			_STATE_CDFieldIsDirty = value;
			_OP_AMTFieldIsDirty = value;
			_NOTIFY_DTFieldIsDirty = value;
			_INTEREST_AMTFieldIsDirty = value;
			_OFFSET_RCVRY_AMTFieldIsDirty = value;
			_PROSECUTION_END_DTFieldIsDirty = value;
			_RECOVERY_LOGIC_CDFieldIsDirty = value;
			_WRITE_OFF_DTFieldIsDirty = value;
			_OPSRC_CDFieldIsDirty = value;
			_FUND_CDFieldIsDirty = value;
			_REMOVED_DTFieldIsDirty = value;
			_REQ_ISS_IDFieldIsDirty = value;
			_FRAUD_INDFieldIsDirty = value;
			_OOS_OP_DTFieldIsDirty = value;
			_PARENT_OPGRP_IDFieldIsDirty = value;
			_WRITTEN_OFF_AMTFieldIsDirty = value;
			_CASH_RCVRY_AMTFieldIsDirty = value;
			_OP_BAL_AMTFieldIsDirty = value;
			_AP_DCKT_RES_IDFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_PROSECUTION_INDFieldIsDirty = value;
			_MAIL_INDFieldIsDirty = value;
			_OPCLS_CDFieldIsDirty = value;
			_OPGRP_DSP_DTFieldIsDirty = value;
			_CHARGE_OFF_AMTFieldIsDirty = value;
			_WAIVE_AMTFieldIsDirty = value;
			_APPEAL_HOLD_INDFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_OPGRP_IDFieldIsDirty = value;
			_STIM_OP_AMTFieldIsDirty = value;
			_OPCSE_CDFieldIsDirty = value;
			_BKCY_INDFieldIsDirty = value;
			_MODIFIED_DTFieldIsDirty = value;
			_FINES_AMTFieldIsDirty = value;
			_RSPAGT_CDFieldIsDirty = value;
			_CREATED_DTFieldIsDirty = value;
			_OPGRP_DSP_CDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _CREATED_BYFieldIsDirty
				|| _STIM_OFFSET_RCVRY_AMTFieldIsDirty
				|| _ISS_IDFieldIsDirty
				|| _PENALTY_AMTFieldIsDirty
				|| _CLM_IDFieldIsDirty
				|| _PROGRAM_TYPFieldIsDirty
				|| _STIM_PENALTY_AMTFieldIsDirty
				|| _PROSECUTION_BEG_DTFieldIsDirty
				|| _ESTABLISH_DTFieldIsDirty
				|| _WRITE_OFF_INDFieldIsDirty
				|| _COST_AMTFieldIsDirty
				|| _CANCEL_OP_BAL_AMTFieldIsDirty
				|| _STATE_CDFieldIsDirty
				|| _OP_AMTFieldIsDirty
				|| _NOTIFY_DTFieldIsDirty
				|| _INTEREST_AMTFieldIsDirty
				|| _OFFSET_RCVRY_AMTFieldIsDirty
				|| _PROSECUTION_END_DTFieldIsDirty
				|| _RECOVERY_LOGIC_CDFieldIsDirty
				|| _WRITE_OFF_DTFieldIsDirty
				|| _OPSRC_CDFieldIsDirty
				|| _FUND_CDFieldIsDirty
				|| _REMOVED_DTFieldIsDirty
				|| _REQ_ISS_IDFieldIsDirty
				|| _FRAUD_INDFieldIsDirty
				|| _OOS_OP_DTFieldIsDirty
				|| _PARENT_OPGRP_IDFieldIsDirty
				|| _WRITTEN_OFF_AMTFieldIsDirty
				|| _CASH_RCVRY_AMTFieldIsDirty
				|| _OP_BAL_AMTFieldIsDirty
				|| _AP_DCKT_RES_IDFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _PROSECUTION_INDFieldIsDirty
				|| _MAIL_INDFieldIsDirty
				|| _OPCLS_CDFieldIsDirty
				|| _OPGRP_DSP_DTFieldIsDirty
				|| _CHARGE_OFF_AMTFieldIsDirty
				|| _WAIVE_AMTFieldIsDirty
				|| _APPEAL_HOLD_INDFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _OPGRP_IDFieldIsDirty
				|| _STIM_OP_AMTFieldIsDirty
				|| _OPCSE_CDFieldIsDirty
				|| _BKCY_INDFieldIsDirty
				|| _MODIFIED_DTFieldIsDirty
				|| _FINES_AMTFieldIsDirty
				|| _RSPAGT_CDFieldIsDirty
				|| _CREATED_DTFieldIsDirty
				|| _OPGRP_DSP_CDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_BOP_OWNER";
		}

		public override string TableName()
		{
			return "V_OPGROUP";
		}

		public override string PrimaryKeyFieldname()
		{
			return "OPGRP_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CUBS_OWNER", "OP_TRANSACTIONS", "OPGRP_ID", "CATS_BOP_OWNER", "V_OPGROUP", "OPGRP_ID");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (V_OPGROUP)this.Clone();
			result.CREATED_BY = this.CREATED_BY;
			result.STIM_OFFSET_RCVRY_AMT = this.STIM_OFFSET_RCVRY_AMT;
			result.ISS_ID = this.ISS_ID;
			result.PENALTY_AMT = this.PENALTY_AMT;
			result.CLM_ID = this.CLM_ID;
			result.PROGRAM_TYP = this.PROGRAM_TYP;
			result.STIM_PENALTY_AMT = this.STIM_PENALTY_AMT;
			result.PROSECUTION_BEG_DT = this.PROSECUTION_BEG_DT;
			result.ESTABLISH_DT = this.ESTABLISH_DT;
			result.WRITE_OFF_IND = this.WRITE_OFF_IND;
			result.COST_AMT = this.COST_AMT;
			result.CANCEL_OP_BAL_AMT = this.CANCEL_OP_BAL_AMT;
			result.STATE_CD = this.STATE_CD;
			result.OP_AMT = this.OP_AMT;
			result.NOTIFY_DT = this.NOTIFY_DT;
			result.INTEREST_AMT = this.INTEREST_AMT;
			result.OFFSET_RCVRY_AMT = this.OFFSET_RCVRY_AMT;
			result.PROSECUTION_END_DT = this.PROSECUTION_END_DT;
			result.RECOVERY_LOGIC_CD = this.RECOVERY_LOGIC_CD;
			result.WRITE_OFF_DT = this.WRITE_OFF_DT;
			result.OPSRC_CD = this.OPSRC_CD;
			result.FUND_CD = this.FUND_CD;
			result.REMOVED_DT = this.REMOVED_DT;
			result.REQ_ISS_ID = this.REQ_ISS_ID;
			result.FRAUD_IND = this.FRAUD_IND;
			result.OOS_OP_DT = this.OOS_OP_DT;
			result.PARENT_OPGRP_ID = this.PARENT_OPGRP_ID;
			result.WRITTEN_OFF_AMT = this.WRITTEN_OFF_AMT;
			result.CASH_RCVRY_AMT = this.CASH_RCVRY_AMT;
			result.OP_BAL_AMT = this.OP_BAL_AMT;
			result.AP_DCKT_RES_ID = this.AP_DCKT_RES_ID;
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.PROSECUTION_IND = this.PROSECUTION_IND;
			result.MAIL_IND = this.MAIL_IND;
			result.OPCLS_CD = this.OPCLS_CD;
			result.OPGRP_DSP_DT = this.OPGRP_DSP_DT;
			result.CHARGE_OFF_AMT = this.CHARGE_OFF_AMT;
			result.WAIVE_AMT = this.WAIVE_AMT;
			result.APPEAL_HOLD_IND = this.APPEAL_HOLD_IND;
			result.PRTY_ID = this.PRTY_ID;
			result.OPGRP_ID = this.OPGRP_ID;
			result.STIM_OP_AMT = this.STIM_OP_AMT;
			result.OPCSE_CD = this.OPCSE_CD;
			result.BKCY_IND = this.BKCY_IND;
			result.MODIFIED_DT = this.MODIFIED_DT;
			result.FINES_AMT = this.FINES_AMT;
			result.RSPAGT_CD = this.RSPAGT_CD;
			result.CREATED_DT = this.CREATED_DT;
			result.OPGRP_DSP_CD = this.OPGRP_DSP_CD;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_BOP_OWNER.V_OPGROUP")
				.Append(" { ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("STIM_OFFSET_RCVRY_AMT")
				.Append(" = ")
				.Append(this.STIM_OFFSET_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("ISS_ID")
				.Append(" = ")
				.Append(this.ISS_ID.ToString())
				.Append("; ")
				.Append("PENALTY_AMT")
				.Append(" = ")
				.Append(this.PENALTY_AMT.ToString())
				.Append("; ")
				.Append("CLM_ID")
				.Append(" = ")
				.Append(this.CLM_ID.ToString())
				.Append("; ")
				.Append("PROGRAM_TYP")
				.Append(" = ")
				.Append(this.PROGRAM_TYP.ToString())
				.Append("; ")
				.Append("STIM_PENALTY_AMT")
				.Append(" = ")
				.Append(this.STIM_PENALTY_AMT.ToString())
				.Append("; ")
				.Append("PROSECUTION_BEG_DT")
				.Append(" = ")
				.Append(this.PROSECUTION_BEG_DT.ToString())
				.Append("; ")
				.Append("ESTABLISH_DT")
				.Append(" = ")
				.Append(this.ESTABLISH_DT.ToString())
				.Append("; ")
				.Append("WRITE_OFF_IND")
				.Append(" = ")
				.Append(this.WRITE_OFF_IND.ToString())
				.Append("; ")
				.Append("COST_AMT")
				.Append(" = ")
				.Append(this.COST_AMT.ToString())
				.Append("; ")
				.Append("CANCEL_OP_BAL_AMT")
				.Append(" = ")
				.Append(this.CANCEL_OP_BAL_AMT.ToString())
				.Append("; ")
				.Append("STATE_CD")
				.Append(" = ")
				.Append(this.STATE_CD.ToString())
				.Append("; ")
				.Append("OP_AMT")
				.Append(" = ")
				.Append(this.OP_AMT.ToString())
				.Append("; ")
				.Append("NOTIFY_DT")
				.Append(" = ")
				.Append(this.NOTIFY_DT.ToString())
				.Append("; ")
				.Append("INTEREST_AMT")
				.Append(" = ")
				.Append(this.INTEREST_AMT.ToString())
				.Append("; ")
				.Append("OFFSET_RCVRY_AMT")
				.Append(" = ")
				.Append(this.OFFSET_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("PROSECUTION_END_DT")
				.Append(" = ")
				.Append(this.PROSECUTION_END_DT.ToString())
				.Append("; ")
				.Append("RECOVERY_LOGIC_CD")
				.Append(" = ")
				.Append(this.RECOVERY_LOGIC_CD.ToString())
				.Append("; ")
				.Append("WRITE_OFF_DT")
				.Append(" = ")
				.Append(this.WRITE_OFF_DT.ToString())
				.Append("; ")
				.Append("OPSRC_CD")
				.Append(" = ")
				.Append(this.OPSRC_CD.ToString())
				.Append("; ")
				.Append("FUND_CD")
				.Append(" = ")
				.Append(this.FUND_CD.ToString())
				.Append("; ")
				.Append("REMOVED_DT")
				.Append(" = ")
				.Append(this.REMOVED_DT.ToString())
				.Append("; ")
				.Append("REQ_ISS_ID")
				.Append(" = ")
				.Append(this.REQ_ISS_ID.ToString())
				.Append("; ")
				.Append("FRAUD_IND")
				.Append(" = ")
				.Append(this.FRAUD_IND.ToString())
				.Append("; ")
				.Append("OOS_OP_DT")
				.Append(" = ")
				.Append(this.OOS_OP_DT.ToString())
				.Append("; ")
				.Append("PARENT_OPGRP_ID")
				.Append(" = ")
				.Append(this.PARENT_OPGRP_ID.ToString())
				.Append("; ")
				.Append("WRITTEN_OFF_AMT")
				.Append(" = ")
				.Append(this.WRITTEN_OFF_AMT.ToString())
				.Append("; ")
				.Append("CASH_RCVRY_AMT")
				.Append(" = ")
				.Append(this.CASH_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("OP_BAL_AMT")
				.Append(" = ")
				.Append(this.OP_BAL_AMT.ToString())
				.Append("; ")
				.Append("AP_DCKT_RES_ID")
				.Append(" = ")
				.Append(this.AP_DCKT_RES_ID.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("PROSECUTION_IND")
				.Append(" = ")
				.Append(this.PROSECUTION_IND.ToString())
				.Append("; ")
				.Append("MAIL_IND")
				.Append(" = ")
				.Append(this.MAIL_IND.ToString())
				.Append("; ")
				.Append("OPCLS_CD")
				.Append(" = ")
				.Append(this.OPCLS_CD.ToString())
				.Append("; ")
				.Append("OPGRP_DSP_DT")
				.Append(" = ")
				.Append(this.OPGRP_DSP_DT.ToString())
				.Append("; ")
				.Append("CHARGE_OFF_AMT")
				.Append(" = ")
				.Append(this.CHARGE_OFF_AMT.ToString())
				.Append("; ")
				.Append("WAIVE_AMT")
				.Append(" = ")
				.Append(this.WAIVE_AMT.ToString())
				.Append("; ")
				.Append("APPEAL_HOLD_IND")
				.Append(" = ")
				.Append(this.APPEAL_HOLD_IND.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("OPGRP_ID")
				.Append(" = ")
				.Append(this.OPGRP_ID.ToString())
				.Append("; ")
				.Append("STIM_OP_AMT")
				.Append(" = ")
				.Append(this.STIM_OP_AMT.ToString())
				.Append("; ")
				.Append("OPCSE_CD")
				.Append(" = ")
				.Append(this.OPCSE_CD.ToString())
				.Append("; ")
				.Append("BKCY_IND")
				.Append(" = ")
				.Append(this.BKCY_IND.ToString())
				.Append("; ")
				.Append("MODIFIED_DT")
				.Append(" = ")
				.Append(this.MODIFIED_DT.ToString())
				.Append("; ")
				.Append("FINES_AMT")
				.Append(" = ")
				.Append(this.FINES_AMT.ToString())
				.Append("; ")
				.Append("RSPAGT_CD")
				.Append(" = ")
				.Append(this.RSPAGT_CD.ToString())
				.Append("; ")
				.Append("CREATED_DT")
				.Append(" = ")
				.Append(this.CREATED_DT.ToString())
				.Append("; ")
				.Append("OPGRP_DSP_CD")
				.Append(" = ")
				.Append(this.OPGRP_DSP_CD.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//ReferencedBy -> CATS_BOP_OWNER.HOLD.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_BOP_OWNER.HOLD.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_BOP_OWNER.LIEN_BOP.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_BOP_OWNER.NOTE_TYPE.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_BOP_OWNER.NOTE.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_BOP_OWNER.NOTE.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_LEGAL_OWNER.LIEN_STATE_HISTORY.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_LEGAL_OWNER.LIEN_MASTER.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_CORE_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_CORE_OWNER", "EMPLOYEE")]
	public partial class EMPLOYEEGen : EMPLOYEEBase
	{
		#region Property backing stores for table EMPLOYEE
		protected System.String _PRONOUN_POSS;
		protected virtual System.String GetPRONOUN_POSS() { return _PRONOUN_POSS; }
		protected virtual void SetPRONOUN_POSS(System.String value) { _PRONOUN_POSS = value; _PRONOUN_POSSFieldIsDirty = true; }
		protected virtual bool _PRONOUN_POSSFieldIsDirty { get; set; }

		protected System.String _PRONOUN;
		protected virtual System.String GetPRONOUN() { return _PRONOUN; }
		protected virtual void SetPRONOUN(System.String value) { _PRONOUN = value; _PRONOUNFieldIsDirty = true; }
		protected virtual bool _PRONOUNFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_TS;
		protected virtual System.DateTime? GetMODIFIED_TS() { return _MODIFIED_TS; }
		protected virtual void SetMODIFIED_TS(System.DateTime? value) { _MODIFIED_TS = value; _MODIFIED_TSFieldIsDirty = true; }
		protected virtual bool _MODIFIED_TSFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.String _USERID;
		protected virtual System.String GetUSERID() { return _USERID; }
		protected virtual void SetUSERID(System.String value) { _USERID = value; _USERIDFieldIsDirty = true; }
		protected virtual bool _USERIDFieldIsDirty { get; set; }

		protected System.String _EMAILADDR;
		protected virtual System.String GetEMAILADDR() { return _EMAILADDR; }
		protected virtual void SetEMAILADDR(System.String value) { _EMAILADDR = value; _EMAILADDRFieldIsDirty = true; }
		protected virtual bool _EMAILADDRFieldIsDirty { get; set; }

		protected System.String _FAX;
		protected virtual System.String GetFAX() { return _FAX; }
		protected virtual void SetFAX(System.String value) { _FAX = value; _FAXFieldIsDirty = true; }
		protected virtual bool _FAXFieldIsDirty { get; set; }

		protected System.String _PHONE;
		protected virtual System.String GetPHONE() { return _PHONE; }
		protected virtual void SetPHONE(System.String value) { _PHONE = value; _PHONEFieldIsDirty = true; }
		protected virtual bool _PHONEFieldIsDirty { get; set; }

		protected System.String _DEPARTMENT;
		protected virtual System.String GetDEPARTMENT() { return _DEPARTMENT; }
		protected virtual void SetDEPARTMENT(System.String value) { _DEPARTMENT = value; _DEPARTMENTFieldIsDirty = true; }
		protected virtual bool _DEPARTMENTFieldIsDirty { get; set; }

		protected System.String _ZIP;
		protected virtual System.String GetZIP() { return _ZIP; }
		protected virtual void SetZIP(System.String value) { _ZIP = value; _ZIPFieldIsDirty = true; }
		protected virtual bool _ZIPFieldIsDirty { get; set; }

		protected System.String _STATE;
		protected virtual System.String GetSTATE() { return _STATE; }
		protected virtual void SetSTATE(System.String value) { _STATE = value; _STATEFieldIsDirty = true; }
		protected virtual bool _STATEFieldIsDirty { get; set; }

		protected System.String _CITY;
		protected virtual System.String GetCITY() { return _CITY; }
		protected virtual void SetCITY(System.String value) { _CITY = value; _CITYFieldIsDirty = true; }
		protected virtual bool _CITYFieldIsDirty { get; set; }

		protected System.String _ADDRESS2;
		protected virtual System.String GetADDRESS2() { return _ADDRESS2; }
		protected virtual void SetADDRESS2(System.String value) { _ADDRESS2 = value; _ADDRESS2FieldIsDirty = true; }
		protected virtual bool _ADDRESS2FieldIsDirty { get; set; }

		protected System.String _ADDRESS1;
		protected virtual System.String GetADDRESS1() { return _ADDRESS1; }
		protected virtual void SetADDRESS1(System.String value) { _ADDRESS1 = value; _ADDRESS1FieldIsDirty = true; }
		protected virtual bool _ADDRESS1FieldIsDirty { get; set; }

		protected System.String _LASTNAME;
		protected virtual System.String GetLASTNAME() { return _LASTNAME; }
		protected virtual void SetLASTNAME(System.String value) { _LASTNAME = value; _LASTNAMEFieldIsDirty = true; }
		protected virtual bool _LASTNAMEFieldIsDirty { get; set; }

		protected System.String _FIRSTNAME;
		protected virtual System.String GetFIRSTNAME() { return _FIRSTNAME; }
		protected virtual void SetFIRSTNAME(System.String value) { _FIRSTNAME = value; _FIRSTNAMEFieldIsDirty = true; }
		protected virtual bool _FIRSTNAMEFieldIsDirty { get; set; }

		protected System.Int64 _EMPLOYEE_ID;
		protected virtual System.Int64 GetEMPLOYEE_ID() { return _EMPLOYEE_ID; }
		protected virtual void SetEMPLOYEE_ID(System.Int64 value) { _EMPLOYEE_ID = value; _EMPLOYEE_IDFieldIsDirty = true; }
		protected virtual bool _EMPLOYEE_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table EMPLOYEE

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "PRONOUN_POSS", "VARCHAR2", typeof(System.String))]
		public virtual System.String PRONOUN_POSS { get { return GetPRONOUN_POSS(); } set { SetPRONOUN_POSS(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "PRONOUN", "VARCHAR2", typeof(System.String))]
		public virtual System.String PRONOUN { get { return GetPRONOUN(); } set { SetPRONOUN(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "MODIFIED_TS", "TIMESTAMP(6)", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_TS { get { return GetMODIFIED_TS(); } set { SetMODIFIED_TS(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "USERID", "VARCHAR2", typeof(System.String))]
		public virtual System.String USERID { get { return GetUSERID(); } set { SetUSERID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(40)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "EMAILADDR", "VARCHAR2", typeof(System.String))]
		public virtual System.String EMAILADDR { get { return GetEMAILADDR(); } set { SetEMAILADDR(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "FAX", "VARCHAR2", typeof(System.String))]
		public virtual System.String FAX { get { return GetFAX(); } set { SetFAX(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(10)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "PHONE", "VARCHAR2", typeof(System.String))]
		public virtual System.String PHONE { get { return GetPHONE(); } set { SetPHONE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(25)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "DEPARTMENT", "VARCHAR2", typeof(System.String))]
		public virtual System.String DEPARTMENT { get { return GetDEPARTMENT(); } set { SetDEPARTMENT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(9)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "ZIP", "VARCHAR2", typeof(System.String))]
		public virtual System.String ZIP { get { return GetZIP(); } set { SetZIP(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "STATE", "VARCHAR2", typeof(System.String))]
		public virtual System.String STATE { get { return GetSTATE(); } set { SetSTATE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(19)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "CITY", "VARCHAR2", typeof(System.String))]
		public virtual System.String CITY { get { return GetCITY(); } set { SetCITY(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(35)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "ADDRESS2", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDRESS2 { get { return GetADDRESS2(); } set { SetADDRESS2(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(35)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "ADDRESS1", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADDRESS1 { get { return GetADDRESS1(); } set { SetADDRESS1(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(25)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "LASTNAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String LASTNAME { get { return GetLASTNAME(); } set { SetLASTNAME(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(20)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "FIRSTNAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String FIRSTNAME { get { return GetFIRSTNAME(); } set { SetFIRSTNAME(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "HOLD", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 EMPLOYEE_ID { get { return GetEMPLOYEE_ID(); } set { SetEMPLOYEE_ID(value); } }


		public virtual ICollection<HOLD> RefMany_Hold_CreatedBy { get; set; }
		public virtual ICollection<HOLD> RefMany_Hold_ModifiedBy { get; set; }
		public virtual ICollection<LIEN_BOP> RefMany_LienBop_CreatedBy { get; set; }
		public virtual ICollection<NOTE_TYPE> RefMany_NoteType_CreatedBy { get; set; }
		public virtual ICollection<NOTE> RefMany_Note_CreatedBy { get; set; }
		public virtual ICollection<NOTE> RefMany_Note_ModifiedBy { get; set; }
		public virtual ICollection<LIEN_STATE_HISTORY> RefMany_LienStateHistory_CreatedBy { get; set; }
		public virtual ICollection<LIEN_MASTER> RefMany_LienMaster { get; set; }

		#endregion

		#region Constructors for table EMPLOYEEGen
		public EMPLOYEEGen()
		{
		}

		public EMPLOYEEGen(System.String PRONOUN_POSS, System.String PRONOUN, System.DateTime? MODIFIED_TS, System.DateTime CREATED_TS, System.String USERID, System.String EMAILADDR, System.String FAX, System.String PHONE, System.String DEPARTMENT, System.String ZIP, System.String STATE, System.String CITY, System.String ADDRESS2, System.String ADDRESS1, System.String LASTNAME, System.String FIRSTNAME, System.Int64 EMPLOYEE_ID) : this()
		{
			this._PRONOUN_POSS = PRONOUN_POSS;
			this._PRONOUN = PRONOUN;
			this._MODIFIED_TS = MODIFIED_TS;
			this._CREATED_TS = CREATED_TS;
			this._USERID = USERID;
			this._EMAILADDR = EMAILADDR;
			this._FAX = FAX;
			this._PHONE = PHONE;
			this._DEPARTMENT = DEPARTMENT;
			this._ZIP = ZIP;
			this._STATE = STATE;
			this._CITY = CITY;
			this._ADDRESS2 = ADDRESS2;
			this._ADDRESS1 = ADDRESS1;
			this._LASTNAME = LASTNAME;
			this._FIRSTNAME = FIRSTNAME;
			this._EMPLOYEE_ID = EMPLOYEE_ID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(EMPLOYEEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_PRONOUN_POSSFieldIsDirty = value;
			_PRONOUNFieldIsDirty = value;
			_MODIFIED_TSFieldIsDirty = value;
			_CREATED_TSFieldIsDirty = value;
			_USERIDFieldIsDirty = value;
			_EMAILADDRFieldIsDirty = value;
			_FAXFieldIsDirty = value;
			_PHONEFieldIsDirty = value;
			_DEPARTMENTFieldIsDirty = value;
			_ZIPFieldIsDirty = value;
			_STATEFieldIsDirty = value;
			_CITYFieldIsDirty = value;
			_ADDRESS2FieldIsDirty = value;
			_ADDRESS1FieldIsDirty = value;
			_LASTNAMEFieldIsDirty = value;
			_FIRSTNAMEFieldIsDirty = value;
			_EMPLOYEE_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _PRONOUN_POSSFieldIsDirty
				|| _PRONOUNFieldIsDirty
				|| _MODIFIED_TSFieldIsDirty
				|| _CREATED_TSFieldIsDirty
				|| _USERIDFieldIsDirty
				|| _EMAILADDRFieldIsDirty
				|| _FAXFieldIsDirty
				|| _PHONEFieldIsDirty
				|| _DEPARTMENTFieldIsDirty
				|| _ZIPFieldIsDirty
				|| _STATEFieldIsDirty
				|| _CITYFieldIsDirty
				|| _ADDRESS2FieldIsDirty
				|| _ADDRESS1FieldIsDirty
				|| _LASTNAMEFieldIsDirty
				|| _FIRSTNAMEFieldIsDirty
				|| _EMPLOYEE_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_CORE_OWNER";
		}

		public override string TableName()
		{
			return "EMPLOYEE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "EMPLOYEE_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_BOP_OWNER", "HOLD", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield return ("CATS_BOP_OWNER", "HOLD", "MODIFIED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield return ("CATS_BOP_OWNER", "LIEN_BOP", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield return ("CATS_BOP_OWNER", "NOTE_TYPE", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield return ("CATS_BOP_OWNER", "NOTE", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield return ("CATS_BOP_OWNER", "NOTE", "MODIFIED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield return ("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield return ("CATS_LEGAL_OWNER", "LIEN_MASTER", "MODIFIED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (EMPLOYEE)this.Clone();
			result.PRONOUN_POSS = this.PRONOUN_POSS;
			result.PRONOUN = this.PRONOUN;
			result.MODIFIED_TS = this.MODIFIED_TS;
			result.CREATED_TS = this.CREATED_TS;
			result.USERID = this.USERID;
			result.EMAILADDR = this.EMAILADDR;
			result.FAX = this.FAX;
			result.PHONE = this.PHONE;
			result.DEPARTMENT = this.DEPARTMENT;
			result.ZIP = this.ZIP;
			result.STATE = this.STATE;
			result.CITY = this.CITY;
			result.ADDRESS2 = this.ADDRESS2;
			result.ADDRESS1 = this.ADDRESS1;
			result.LASTNAME = this.LASTNAME;
			result.FIRSTNAME = this.FIRSTNAME;
			result.EMPLOYEE_ID = this.EMPLOYEE_ID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_CORE_OWNER.EMPLOYEE")
				.Append(" { ")
				.Append("PRONOUN_POSS")
				.Append(" = ")
				.Append(this.PRONOUN_POSS.ToString())
				.Append("; ")
				.Append("PRONOUN")
				.Append(" = ")
				.Append(this.PRONOUN.ToString())
				.Append("; ")
				.Append("MODIFIED_TS")
				.Append(" = ")
				.Append(this.MODIFIED_TS.ToString())
				.Append("; ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("USERID")
				.Append(" = ")
				.Append(this.USERID.ToString())
				.Append("; ")
				.Append("EMAILADDR")
				.Append(" = ")
				.Append(this.EMAILADDR.ToString())
				.Append("; ")
				.Append("FAX")
				.Append(" = ")
				.Append(this.FAX.ToString())
				.Append("; ")
				.Append("PHONE")
				.Append(" = ")
				.Append(this.PHONE.ToString())
				.Append("; ")
				.Append("DEPARTMENT")
				.Append(" = ")
				.Append(this.DEPARTMENT.ToString())
				.Append("; ")
				.Append("ZIP")
				.Append(" = ")
				.Append(this.ZIP.ToString())
				.Append("; ")
				.Append("STATE")
				.Append(" = ")
				.Append(this.STATE.ToString())
				.Append("; ")
				.Append("CITY")
				.Append(" = ")
				.Append(this.CITY.ToString())
				.Append("; ")
				.Append("ADDRESS2")
				.Append(" = ")
				.Append(this.ADDRESS2.ToString())
				.Append("; ")
				.Append("ADDRESS1")
				.Append(" = ")
				.Append(this.ADDRESS1.ToString())
				.Append("; ")
				.Append("LASTNAME")
				.Append(" = ")
				.Append(this.LASTNAME.ToString())
				.Append("; ")
				.Append("FIRSTNAME")
				.Append(" = ")
				.Append(this.FIRSTNAME.ToString())
				.Append("; ")
				.Append("EMPLOYEE_ID")
				.Append(" = ")
				.Append(this.EMPLOYEE_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_CORE_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_CORE_OWNER", "VM_POSTAL_CODE")]
	public partial class VM_POSTAL_CODEGen : VM_POSTAL_CODEBase
	{
		#region Property backing stores for table VM_POSTAL_CODE
		protected System.String _COUNTY_FIPS;
		protected virtual System.String GetCOUNTY_FIPS() { return _COUNTY_FIPS; }
		protected virtual void SetCOUNTY_FIPS(System.String value) { _COUNTY_FIPS = value; _COUNTY_FIPSFieldIsDirty = true; }
		protected virtual bool _COUNTY_FIPSFieldIsDirty { get; set; }

		protected System.String _COUNTY_NAME;
		protected virtual System.String GetCOUNTY_NAME() { return _COUNTY_NAME; }
		protected virtual void SetCOUNTY_NAME(System.String value) { _COUNTY_NAME = value; _COUNTY_NAMEFieldIsDirty = true; }
		protected virtual bool _COUNTY_NAMEFieldIsDirty { get; set; }

		protected System.String _STATE;
		protected virtual System.String GetSTATE() { return _STATE; }
		protected virtual void SetSTATE(System.String value) { _STATE = value; _STATEFieldIsDirty = true; }
		protected virtual bool _STATEFieldIsDirty { get; set; }

		protected System.String _CITY;
		protected virtual System.String GetCITY() { return _CITY; }
		protected virtual void SetCITY(System.String value) { _CITY = value; _CITYFieldIsDirty = true; }
		protected virtual bool _CITYFieldIsDirty { get; set; }

		protected System.String _ZIP;
		protected virtual System.String GetZIP() { return _ZIP; }
		protected virtual void SetZIP(System.String value) { _ZIP = value; _ZIPFieldIsDirty = true; }
		protected virtual bool _ZIPFieldIsDirty { get; set; }

		#endregion

		#region Properties for table VM_POSTAL_CODE

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(5)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "VM_POSTAL_CODE", "COUNTY_FIPS", "VARCHAR2", typeof(System.String))]
		public virtual System.String COUNTY_FIPS { get { return GetCOUNTY_FIPS(); } set { SetCOUNTY_FIPS(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(40)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "VM_POSTAL_CODE", "COUNTY_NAME", "VARCHAR2", typeof(System.String))]
		public virtual System.String COUNTY_NAME { get { return GetCOUNTY_NAME(); } set { SetCOUNTY_NAME(value); } }

		[DBFieldDataType("CHAR")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "VM_POSTAL_CODE", "STATE", "CHAR", typeof(System.String))]
		public virtual System.String STATE { get { return GetSTATE(); } set { SetSTATE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(28)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "VM_POSTAL_CODE", "CITY", "VARCHAR2", typeof(System.String))]
		public virtual System.String CITY { get { return GetCITY(); } set { SetCITY(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(5)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_CORE_OWNER", "VM_POSTAL_CODE", "ZIP", "VARCHAR2", typeof(System.String))]
		public virtual System.String ZIP { get { return GetZIP(); } set { SetZIP(value); } }



		#endregion

		#region Constructors for table VM_POSTAL_CODEGen
		public VM_POSTAL_CODEGen()
		{
		}

		public VM_POSTAL_CODEGen(System.String COUNTY_FIPS, System.String COUNTY_NAME, System.String STATE, System.String CITY, System.String ZIP) : this()
		{
			this._COUNTY_FIPS = COUNTY_FIPS;
			this._COUNTY_NAME = COUNTY_NAME;
			this._STATE = STATE;
			this._CITY = CITY;
			this._ZIP = ZIP;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(VM_POSTAL_CODEGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_COUNTY_FIPSFieldIsDirty = value;
			_COUNTY_NAMEFieldIsDirty = value;
			_STATEFieldIsDirty = value;
			_CITYFieldIsDirty = value;
			_ZIPFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _COUNTY_FIPSFieldIsDirty
				|| _COUNTY_NAMEFieldIsDirty
				|| _STATEFieldIsDirty
				|| _CITYFieldIsDirty
				|| _ZIPFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_CORE_OWNER";
		}

		public override string TableName()
		{
			return "VM_POSTAL_CODE";
		}

		public override string PrimaryKeyFieldname()
		{
			return "ZIP";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return false;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (VM_POSTAL_CODE)this.Clone();
			result.COUNTY_FIPS = this.COUNTY_FIPS;
			result.COUNTY_NAME = this.COUNTY_NAME;
			result.STATE = this.STATE;
			result.CITY = this.CITY;
			result.ZIP = this.ZIP;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_CORE_OWNER.VM_POSTAL_CODE")
				.Append(" { ")
				.Append("COUNTY_FIPS")
				.Append(" = ")
				.Append(this.COUNTY_FIPS.ToString())
				.Append("; ")
				.Append("COUNTY_NAME")
				.Append(" = ")
				.Append(this.COUNTY_NAME.ToString())
				.Append("; ")
				.Append("STATE")
				.Append(" = ")
				.Append(this.STATE.ToString())
				.Append("; ")
				.Append("CITY")
				.Append(" = ")
				.Append(this.CITY.ToString())
				.Append("; ")
				.Append("ZIP")
				.Append(" = ")
				.Append(this.ZIP.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_LEGAL_OWNER.LIEN_MASTER.MODIFIED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//ReferencedBy -> CATS_BOP_OWNER.LIEN_BOP.LIEN_MASTER_ID->CATS_LEGAL_OWNER.LIEN_MASTER.LIEN_MASTER_ID
	//ReferencedBy -> CATS_LEGAL_OWNER.LIEN_STATE_HISTORY.LIEN_MASTER_ID->CATS_LEGAL_OWNER.LIEN_MASTER.LIEN_MASTER_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_LEGAL_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_LEGAL_OWNER", "LIEN_MASTER")]
	public partial class LIEN_MASTERGen : LIEN_MASTERBase
	{
		#region Property backing stores for table LIEN_MASTER
		protected System.Decimal? _RESTART_AMOUNT;
		protected virtual System.Decimal? GetRESTART_AMOUNT() { return _RESTART_AMOUNT; }
		protected virtual void SetRESTART_AMOUNT(System.Decimal? value) { _RESTART_AMOUNT = value; _RESTART_AMOUNTFieldIsDirty = true; }
		protected virtual bool _RESTART_AMOUNTFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_DT;
		protected virtual System.DateTime? GetMODIFIED_DT() { return _MODIFIED_DT; }
		protected virtual void SetMODIFIED_DT(System.DateTime? value) { _MODIFIED_DT = value; _MODIFIED_DTFieldIsDirty = true; }
		protected virtual bool _MODIFIED_DTFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.Decimal? _CONPEN_FORCED_AMOUNT;
		protected virtual System.Decimal? GetCONPEN_FORCED_AMOUNT() { return _CONPEN_FORCED_AMOUNT; }
		protected virtual void SetCONPEN_FORCED_AMOUNT(System.Decimal? value) { _CONPEN_FORCED_AMOUNT = value; _CONPEN_FORCED_AMOUNTFieldIsDirty = true; }
		protected virtual bool _CONPEN_FORCED_AMOUNTFieldIsDirty { get; set; }

		protected System.Decimal? _CONPEN_FILED_AMOUNT;
		protected virtual System.Decimal? GetCONPEN_FILED_AMOUNT() { return _CONPEN_FILED_AMOUNT; }
		protected virtual void SetCONPEN_FILED_AMOUNT(System.Decimal? value) { _CONPEN_FILED_AMOUNT = value; _CONPEN_FILED_AMOUNTFieldIsDirty = true; }
		protected virtual bool _CONPEN_FILED_AMOUNTFieldIsDirty { get; set; }

		protected System.Int16 _AMEND_IND;
		protected virtual System.Int16 GetAMEND_IND() { return _AMEND_IND; }
		protected virtual void SetAMEND_IND(System.Int16 value) { _AMEND_IND = value; _AMEND_INDFieldIsDirty = true; }
		protected virtual bool _AMEND_INDFieldIsDirty { get; set; }

		protected System.Int64? _PREV_FILED_LIEN_MASTER_ID;
		protected virtual System.Int64? GetPREV_FILED_LIEN_MASTER_ID() { return _PREV_FILED_LIEN_MASTER_ID; }
		protected virtual void SetPREV_FILED_LIEN_MASTER_ID(System.Int64? value) { _PREV_FILED_LIEN_MASTER_ID = value; _PREV_FILED_LIEN_MASTER_IDFieldIsDirty = true; }
		protected virtual bool _PREV_FILED_LIEN_MASTER_IDFieldIsDirty { get; set; }

		protected System.Int64? _PAYOFF_ID;
		protected virtual System.Int64? GetPAYOFF_ID() { return _PAYOFF_ID; }
		protected virtual void SetPAYOFF_ID(System.Int64? value) { _PAYOFF_ID = value; _PAYOFF_IDFieldIsDirty = true; }
		protected virtual bool _PAYOFF_IDFieldIsDirty { get; set; }

		protected System.Decimal _ORIGINAL_AMOUNT;
		protected virtual System.Decimal GetORIGINAL_AMOUNT() { return _ORIGINAL_AMOUNT; }
		protected virtual void SetORIGINAL_AMOUNT(System.Decimal value) { _ORIGINAL_AMOUNT = value; _ORIGINAL_AMOUNTFieldIsDirty = true; }
		protected virtual bool _ORIGINAL_AMOUNTFieldIsDirty { get; set; }

		protected System.Decimal? _FILED_AMOUNT;
		protected virtual System.Decimal? GetFILED_AMOUNT() { return _FILED_AMOUNT; }
		protected virtual void SetFILED_AMOUNT(System.Decimal? value) { _FILED_AMOUNT = value; _FILED_AMOUNTFieldIsDirty = true; }
		protected virtual bool _FILED_AMOUNTFieldIsDirty { get; set; }

		protected System.DateTime? _DT_PAID_OFF;
		protected virtual System.DateTime? GetDT_PAID_OFF() { return _DT_PAID_OFF; }
		protected virtual void SetDT_PAID_OFF(System.DateTime? value) { _DT_PAID_OFF = value; _DT_PAID_OFFFieldIsDirty = true; }
		protected virtual bool _DT_PAID_OFFFieldIsDirty { get; set; }

		protected System.DateTime? _DT_ISSUED;
		protected virtual System.DateTime? GetDT_ISSUED() { return _DT_ISSUED; }
		protected virtual void SetDT_ISSUED(System.DateTime? value) { _DT_ISSUED = value; _DT_ISSUEDFieldIsDirty = true; }
		protected virtual bool _DT_ISSUEDFieldIsDirty { get; set; }

		protected System.DateTime? _DT_REFILED;
		protected virtual System.DateTime? GetDT_REFILED() { return _DT_REFILED; }
		protected virtual void SetDT_REFILED(System.DateTime? value) { _DT_REFILED = value; _DT_REFILEDFieldIsDirty = true; }
		protected virtual bool _DT_REFILEDFieldIsDirty { get; set; }

		protected System.DateTime? _DT_FILED;
		protected virtual System.DateTime? GetDT_FILED() { return _DT_FILED; }
		protected virtual void SetDT_FILED(System.DateTime? value) { _DT_FILED = value; _DT_FILEDFieldIsDirty = true; }
		protected virtual bool _DT_FILEDFieldIsDirty { get; set; }

		protected System.DateTime? _DT_ESTABLISHED;
		protected virtual System.DateTime? GetDT_ESTABLISHED() { return _DT_ESTABLISHED; }
		protected virtual void SetDT_ESTABLISHED(System.DateTime? value) { _DT_ESTABLISHED = value; _DT_ESTABLISHEDFieldIsDirty = true; }
		protected virtual bool _DT_ESTABLISHEDFieldIsDirty { get; set; }

		protected System.String _FIPS;
		protected virtual System.String GetFIPS() { return _FIPS; }
		protected virtual void SetFIPS(System.String value) { _FIPS = value; _FIPSFieldIsDirty = true; }
		protected virtual bool _FIPSFieldIsDirty { get; set; }

		protected System.String _JUDGE;
		protected virtual System.String GetJUDGE() { return _JUDGE; }
		protected virtual void SetJUDGE(System.String value) { _JUDGE = value; _JUDGEFieldIsDirty = true; }
		protected virtual bool _JUDGEFieldIsDirty { get; set; }

		protected System.String _CASE_NUMBER;
		protected virtual System.String GetCASE_NUMBER() { return _CASE_NUMBER; }
		protected virtual void SetCASE_NUMBER(System.String value) { _CASE_NUMBER = value; _CASE_NUMBERFieldIsDirty = true; }
		protected virtual bool _CASE_NUMBERFieldIsDirty { get; set; }

		protected System.Decimal _ACCRUAL;
		protected virtual System.Decimal GetACCRUAL() { return _ACCRUAL; }
		protected virtual void SetACCRUAL(System.Decimal value) { _ACCRUAL = value; _ACCRUALFieldIsDirty = true; }
		protected virtual bool _ACCRUALFieldIsDirty { get; set; }

		protected System.Int16 _FILED_IND;
		protected virtual System.Int16 GetFILED_IND() { return _FILED_IND; }
		protected virtual void SetFILED_IND(System.Int16 value) { _FILED_IND = value; _FILED_INDFieldIsDirty = true; }
		protected virtual bool _FILED_INDFieldIsDirty { get; set; }

		protected System.DateTime _LIEN_STATE_CD_CHANGE_DT;
		protected virtual System.DateTime GetLIEN_STATE_CD_CHANGE_DT() { return _LIEN_STATE_CD_CHANGE_DT; }
		protected virtual void SetLIEN_STATE_CD_CHANGE_DT(System.DateTime value) { _LIEN_STATE_CD_CHANGE_DT = value; _LIEN_STATE_CD_CHANGE_DTFieldIsDirty = true; }
		protected virtual bool _LIEN_STATE_CD_CHANGE_DTFieldIsDirty { get; set; }

		protected System.String _LIEN_STATE_CD;
		protected virtual System.String GetLIEN_STATE_CD() { return _LIEN_STATE_CD; }
		protected virtual void SetLIEN_STATE_CD(System.String value) { _LIEN_STATE_CD = value; _LIEN_STATE_CDFieldIsDirty = true; }
		protected virtual bool _LIEN_STATE_CDFieldIsDirty { get; set; }

		protected System.Int64 _LIEN_MASTER_ID;
		protected virtual System.Int64 GetLIEN_MASTER_ID() { return _LIEN_MASTER_ID; }
		protected virtual void SetLIEN_MASTER_ID(System.Int64 value) { _LIEN_MASTER_ID = value; _LIEN_MASTER_IDFieldIsDirty = true; }
		protected virtual bool _LIEN_MASTER_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table LIEN_MASTER

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "RESTART_AMOUNT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? RESTART_AMOUNT { get { return GetRESTART_AMOUNT(); } set { SetRESTART_AMOUNT(value); } }

		[ReferenceTo("CATS_LEGAL_OWNER", "LIEN_MASTER", "MODIFIED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "MODIFIED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_DT { get { return GetMODIFIED_DT(); } set { SetMODIFIED_DT(value); } }

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "CONPEN_FORCED_AMOUNT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? CONPEN_FORCED_AMOUNT { get { return GetCONPEN_FORCED_AMOUNT(); } set { SetCONPEN_FORCED_AMOUNT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "CONPEN_FILED_AMOUNT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? CONPEN_FILED_AMOUNT { get { return GetCONPEN_FILED_AMOUNT(); } set { SetCONPEN_FILED_AMOUNT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "AMEND_IND", "NUMBER", typeof(System.Int16))]
		public virtual System.Int16 AMEND_IND { get { return GetAMEND_IND(); } set { SetAMEND_IND(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "PREV_FILED_LIEN_MASTER_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PREV_FILED_LIEN_MASTER_ID { get { return GetPREV_FILED_LIEN_MASTER_ID(); } set { SetPREV_FILED_LIEN_MASTER_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "PAYOFF_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PAYOFF_ID { get { return GetPAYOFF_ID(); } set { SetPAYOFF_ID(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "ORIGINAL_AMOUNT", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal ORIGINAL_AMOUNT { get { return GetORIGINAL_AMOUNT(); } set { SetORIGINAL_AMOUNT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "FILED_AMOUNT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? FILED_AMOUNT { get { return GetFILED_AMOUNT(); } set { SetFILED_AMOUNT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "DT_PAID_OFF", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? DT_PAID_OFF { get { return GetDT_PAID_OFF(); } set { SetDT_PAID_OFF(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "DT_ISSUED", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? DT_ISSUED { get { return GetDT_ISSUED(); } set { SetDT_ISSUED(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "DT_REFILED", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? DT_REFILED { get { return GetDT_REFILED(); } set { SetDT_REFILED(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "DT_FILED", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? DT_FILED { get { return GetDT_FILED(); } set { SetDT_FILED(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "DT_ESTABLISHED", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? DT_ESTABLISHED { get { return GetDT_ESTABLISHED(); } set { SetDT_ESTABLISHED(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "FIPS", "VARCHAR2", typeof(System.String))]
		public virtual System.String FIPS { get { return GetFIPS(); } set { SetFIPS(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "JUDGE", "VARCHAR2", typeof(System.String))]
		public virtual System.String JUDGE { get { return GetJUDGE(); } set { SetJUDGE(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(13)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "CASE_NUMBER", "VARCHAR2", typeof(System.String))]
		public virtual System.String CASE_NUMBER { get { return GetCASE_NUMBER(); } set { SetCASE_NUMBER(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "ACCRUAL", "FLOAT", typeof(System.Decimal))]
		public virtual System.Decimal ACCRUAL { get { return GetACCRUAL(); } set { SetACCRUAL(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "FILED_IND", "NUMBER", typeof(System.Int16))]
		public virtual System.Int16 FILED_IND { get { return GetFILED_IND(); } set { SetFILED_IND(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_STATE_CD_CHANGE_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime LIEN_STATE_CD_CHANGE_DT { get { return GetLIEN_STATE_CD_CHANGE_DT(); } set { SetLIEN_STATE_CD_CHANGE_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_STATE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String LIEN_STATE_CD { get { return GetLIEN_STATE_CD(); } set { SetLIEN_STATE_CD(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CATS_BOP_OWNER", "LIEN_BOP", "LIEN_MASTER_ID", "CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_MASTER_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_MASTER_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LIEN_MASTER_ID { get { return GetLIEN_MASTER_ID(); } set { SetLIEN_MASTER_ID(value); } }


		public virtual EMPLOYEE Ref_Employee { get; set; }
		public virtual ICollection<LIEN_BOP> RefMany_LienBop_LienMasterId { get; set; }
		public virtual ICollection<LIEN_STATE_HISTORY> RefMany_LienStateHistory_LienMasterId { get; set; }

		#endregion

		#region Constructors for table LIEN_MASTERGen
		public LIEN_MASTERGen()
		{
		}

		public LIEN_MASTERGen(System.Decimal? RESTART_AMOUNT, System.Int64? MODIFIED_BY, System.DateTime? MODIFIED_DT, System.DateTime CREATED_TS, System.Decimal? CONPEN_FORCED_AMOUNT, System.Decimal? CONPEN_FILED_AMOUNT, System.Int16 AMEND_IND, System.Int64? PREV_FILED_LIEN_MASTER_ID, System.Int64? PAYOFF_ID, System.Decimal ORIGINAL_AMOUNT, System.Decimal? FILED_AMOUNT, System.DateTime? DT_PAID_OFF, System.DateTime? DT_ISSUED, System.DateTime? DT_REFILED, System.DateTime? DT_FILED, System.DateTime? DT_ESTABLISHED, System.String FIPS, System.String JUDGE, System.String CASE_NUMBER, System.Decimal ACCRUAL, System.Int16 FILED_IND, System.DateTime LIEN_STATE_CD_CHANGE_DT, System.String LIEN_STATE_CD, System.Int64 LIEN_MASTER_ID) : this()
		{
			this._RESTART_AMOUNT = RESTART_AMOUNT;
			this._MODIFIED_BY = MODIFIED_BY;
			this._MODIFIED_DT = MODIFIED_DT;
			this._CREATED_TS = CREATED_TS;
			this._CONPEN_FORCED_AMOUNT = CONPEN_FORCED_AMOUNT;
			this._CONPEN_FILED_AMOUNT = CONPEN_FILED_AMOUNT;
			this._AMEND_IND = AMEND_IND;
			this._PREV_FILED_LIEN_MASTER_ID = PREV_FILED_LIEN_MASTER_ID;
			this._PAYOFF_ID = PAYOFF_ID;
			this._ORIGINAL_AMOUNT = ORIGINAL_AMOUNT;
			this._FILED_AMOUNT = FILED_AMOUNT;
			this._DT_PAID_OFF = DT_PAID_OFF;
			this._DT_ISSUED = DT_ISSUED;
			this._DT_REFILED = DT_REFILED;
			this._DT_FILED = DT_FILED;
			this._DT_ESTABLISHED = DT_ESTABLISHED;
			this._FIPS = FIPS;
			this._JUDGE = JUDGE;
			this._CASE_NUMBER = CASE_NUMBER;
			this._ACCRUAL = ACCRUAL;
			this._FILED_IND = FILED_IND;
			this._LIEN_STATE_CD_CHANGE_DT = LIEN_STATE_CD_CHANGE_DT;
			this._LIEN_STATE_CD = LIEN_STATE_CD;
			this._LIEN_MASTER_ID = LIEN_MASTER_ID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(LIEN_MASTERGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_RESTART_AMOUNTFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_MODIFIED_DTFieldIsDirty = value;
			_CREATED_TSFieldIsDirty = value;
			_CONPEN_FORCED_AMOUNTFieldIsDirty = value;
			_CONPEN_FILED_AMOUNTFieldIsDirty = value;
			_AMEND_INDFieldIsDirty = value;
			_PREV_FILED_LIEN_MASTER_IDFieldIsDirty = value;
			_PAYOFF_IDFieldIsDirty = value;
			_ORIGINAL_AMOUNTFieldIsDirty = value;
			_FILED_AMOUNTFieldIsDirty = value;
			_DT_PAID_OFFFieldIsDirty = value;
			_DT_ISSUEDFieldIsDirty = value;
			_DT_REFILEDFieldIsDirty = value;
			_DT_FILEDFieldIsDirty = value;
			_DT_ESTABLISHEDFieldIsDirty = value;
			_FIPSFieldIsDirty = value;
			_JUDGEFieldIsDirty = value;
			_CASE_NUMBERFieldIsDirty = value;
			_ACCRUALFieldIsDirty = value;
			_FILED_INDFieldIsDirty = value;
			_LIEN_STATE_CD_CHANGE_DTFieldIsDirty = value;
			_LIEN_STATE_CDFieldIsDirty = value;
			_LIEN_MASTER_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _RESTART_AMOUNTFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _MODIFIED_DTFieldIsDirty
				|| _CREATED_TSFieldIsDirty
				|| _CONPEN_FORCED_AMOUNTFieldIsDirty
				|| _CONPEN_FILED_AMOUNTFieldIsDirty
				|| _AMEND_INDFieldIsDirty
				|| _PREV_FILED_LIEN_MASTER_IDFieldIsDirty
				|| _PAYOFF_IDFieldIsDirty
				|| _ORIGINAL_AMOUNTFieldIsDirty
				|| _FILED_AMOUNTFieldIsDirty
				|| _DT_PAID_OFFFieldIsDirty
				|| _DT_ISSUEDFieldIsDirty
				|| _DT_REFILEDFieldIsDirty
				|| _DT_FILEDFieldIsDirty
				|| _DT_ESTABLISHEDFieldIsDirty
				|| _FIPSFieldIsDirty
				|| _JUDGEFieldIsDirty
				|| _CASE_NUMBERFieldIsDirty
				|| _ACCRUALFieldIsDirty
				|| _FILED_INDFieldIsDirty
				|| _LIEN_STATE_CD_CHANGE_DTFieldIsDirty
				|| _LIEN_STATE_CDFieldIsDirty
				|| _LIEN_MASTER_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_LEGAL_OWNER";
		}

		public override string TableName()
		{
			return "LIEN_MASTER";
		}

		public override string PrimaryKeyFieldname()
		{
			return "LIEN_MASTER_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CATS_BOP_OWNER", "LIEN_BOP", "LIEN_MASTER_ID", "CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_MASTER_ID");
			yield return ("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "LIEN_MASTER_ID", "CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_MASTER_ID");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (LIEN_MASTER)this.Clone();
			result.RESTART_AMOUNT = this.RESTART_AMOUNT;
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.MODIFIED_DT = this.MODIFIED_DT;
			result.CREATED_TS = this.CREATED_TS;
			result.CONPEN_FORCED_AMOUNT = this.CONPEN_FORCED_AMOUNT;
			result.CONPEN_FILED_AMOUNT = this.CONPEN_FILED_AMOUNT;
			result.AMEND_IND = this.AMEND_IND;
			result.PREV_FILED_LIEN_MASTER_ID = this.PREV_FILED_LIEN_MASTER_ID;
			result.PAYOFF_ID = this.PAYOFF_ID;
			result.ORIGINAL_AMOUNT = this.ORIGINAL_AMOUNT;
			result.FILED_AMOUNT = this.FILED_AMOUNT;
			result.DT_PAID_OFF = this.DT_PAID_OFF;
			result.DT_ISSUED = this.DT_ISSUED;
			result.DT_REFILED = this.DT_REFILED;
			result.DT_FILED = this.DT_FILED;
			result.DT_ESTABLISHED = this.DT_ESTABLISHED;
			result.FIPS = this.FIPS;
			result.JUDGE = this.JUDGE;
			result.CASE_NUMBER = this.CASE_NUMBER;
			result.ACCRUAL = this.ACCRUAL;
			result.FILED_IND = this.FILED_IND;
			result.LIEN_STATE_CD_CHANGE_DT = this.LIEN_STATE_CD_CHANGE_DT;
			result.LIEN_STATE_CD = this.LIEN_STATE_CD;
			result.LIEN_MASTER_ID = this.LIEN_MASTER_ID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_LEGAL_OWNER.LIEN_MASTER")
				.Append(" { ")
				.Append("RESTART_AMOUNT")
				.Append(" = ")
				.Append(this.RESTART_AMOUNT.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("MODIFIED_DT")
				.Append(" = ")
				.Append(this.MODIFIED_DT.ToString())
				.Append("; ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("CONPEN_FORCED_AMOUNT")
				.Append(" = ")
				.Append(this.CONPEN_FORCED_AMOUNT.ToString())
				.Append("; ")
				.Append("CONPEN_FILED_AMOUNT")
				.Append(" = ")
				.Append(this.CONPEN_FILED_AMOUNT.ToString())
				.Append("; ")
				.Append("AMEND_IND")
				.Append(" = ")
				.Append(this.AMEND_IND.ToString())
				.Append("; ")
				.Append("PREV_FILED_LIEN_MASTER_ID")
				.Append(" = ")
				.Append(this.PREV_FILED_LIEN_MASTER_ID.ToString())
				.Append("; ")
				.Append("PAYOFF_ID")
				.Append(" = ")
				.Append(this.PAYOFF_ID.ToString())
				.Append("; ")
				.Append("ORIGINAL_AMOUNT")
				.Append(" = ")
				.Append(this.ORIGINAL_AMOUNT.ToString())
				.Append("; ")
				.Append("FILED_AMOUNT")
				.Append(" = ")
				.Append(this.FILED_AMOUNT.ToString())
				.Append("; ")
				.Append("DT_PAID_OFF")
				.Append(" = ")
				.Append(this.DT_PAID_OFF.ToString())
				.Append("; ")
				.Append("DT_ISSUED")
				.Append(" = ")
				.Append(this.DT_ISSUED.ToString())
				.Append("; ")
				.Append("DT_REFILED")
				.Append(" = ")
				.Append(this.DT_REFILED.ToString())
				.Append("; ")
				.Append("DT_FILED")
				.Append(" = ")
				.Append(this.DT_FILED.ToString())
				.Append("; ")
				.Append("DT_ESTABLISHED")
				.Append(" = ")
				.Append(this.DT_ESTABLISHED.ToString())
				.Append("; ")
				.Append("FIPS")
				.Append(" = ")
				.Append(this.FIPS.ToString())
				.Append("; ")
				.Append("JUDGE")
				.Append(" = ")
				.Append(this.JUDGE.ToString())
				.Append("; ")
				.Append("CASE_NUMBER")
				.Append(" = ")
				.Append(this.CASE_NUMBER.ToString())
				.Append("; ")
				.Append("ACCRUAL")
				.Append(" = ")
				.Append(this.ACCRUAL.ToString())
				.Append("; ")
				.Append("FILED_IND")
				.Append(" = ")
				.Append(this.FILED_IND.ToString())
				.Append("; ")
				.Append("LIEN_STATE_CD_CHANGE_DT")
				.Append(" = ")
				.Append(this.LIEN_STATE_CD_CHANGE_DT.ToString())
				.Append("; ")
				.Append("LIEN_STATE_CD")
				.Append(" = ")
				.Append(this.LIEN_STATE_CD.ToString())
				.Append("; ")
				.Append("LIEN_MASTER_ID")
				.Append(" = ")
				.Append(this.LIEN_MASTER_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CATS_LEGAL_OWNER.LIEN_STATE_HISTORY.CREATED_BY->CATS_CORE_OWNER.EMPLOYEE.EMPLOYEE_ID
	//Reference to -> CATS_LEGAL_OWNER.LIEN_STATE_HISTORY.LIEN_MASTER_ID->CATS_LEGAL_OWNER.LIEN_MASTER.LIEN_MASTER_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CATS_LEGAL_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY")]
	public partial class LIEN_STATE_HISTORYGen : LIEN_STATE_HISTORYBase
	{
		#region Property backing stores for table LIEN_STATE_HISTORY
		protected System.DateTime _CREATED_TS;
		protected virtual System.DateTime GetCREATED_TS() { return _CREATED_TS; }
		protected virtual void SetCREATED_TS(System.DateTime value) { _CREATED_TS = value; _CREATED_TSFieldIsDirty = true; }
		protected virtual bool _CREATED_TSFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.String _REASON;
		protected virtual System.String GetREASON() { return _REASON; }
		protected virtual void SetREASON(System.String value) { _REASON = value; _REASONFieldIsDirty = true; }
		protected virtual bool _REASONFieldIsDirty { get; set; }

		protected System.String _LIEN_STATE_CD;
		protected virtual System.String GetLIEN_STATE_CD() { return _LIEN_STATE_CD; }
		protected virtual void SetLIEN_STATE_CD(System.String value) { _LIEN_STATE_CD = value; _LIEN_STATE_CDFieldIsDirty = true; }
		protected virtual bool _LIEN_STATE_CDFieldIsDirty { get; set; }

		protected System.DateTime _ACTION_DT;
		protected virtual System.DateTime GetACTION_DT() { return _ACTION_DT; }
		protected virtual void SetACTION_DT(System.DateTime value) { _ACTION_DT = value; _ACTION_DTFieldIsDirty = true; }
		protected virtual bool _ACTION_DTFieldIsDirty { get; set; }

		protected System.Int64 _LIEN_MASTER_ID;
		protected virtual System.Int64 GetLIEN_MASTER_ID() { return _LIEN_MASTER_ID; }
		protected virtual void SetLIEN_MASTER_ID(System.Int64 value) { _LIEN_MASTER_ID = value; _LIEN_MASTER_IDFieldIsDirty = true; }
		protected virtual bool _LIEN_MASTER_IDFieldIsDirty { get; set; }

		protected System.Int64 _LIEN_STATE_HISTORY_ID;
		protected virtual System.Int64 GetLIEN_STATE_HISTORY_ID() { return _LIEN_STATE_HISTORY_ID; }
		protected virtual void SetLIEN_STATE_HISTORY_ID(System.Int64 value) { _LIEN_STATE_HISTORY_ID = value; _LIEN_STATE_HISTORY_IDFieldIsDirty = true; }
		protected virtual bool _LIEN_STATE_HISTORY_IDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table LIEN_STATE_HISTORY

		[DBFieldDataType("TIMESTAMP(6)")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "CREATED_TS", "TIMESTAMP(6)", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_TS { get { return GetCREATED_TS(); } set { SetCREATED_TS(value); } }

		[ReferenceTo("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "CREATED_BY", "CATS_CORE_OWNER", "EMPLOYEE", "EMPLOYEE_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1000)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "REASON", "VARCHAR2", typeof(System.String))]
		public virtual System.String REASON { get { return GetREASON(); } set { SetREASON(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "LIEN_STATE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String LIEN_STATE_CD { get { return GetLIEN_STATE_CD(); } set { SetLIEN_STATE_CD(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "ACTION_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime ACTION_DT { get { return GetACTION_DT(); } set { SetACTION_DT(value); } }

		[ReferenceTo("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "LIEN_MASTER_ID", "CATS_LEGAL_OWNER", "LIEN_MASTER", "LIEN_MASTER_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "LIEN_MASTER_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LIEN_MASTER_ID { get { return GetLIEN_MASTER_ID(); } set { SetLIEN_MASTER_ID(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CATS_LEGAL_OWNER", "LIEN_STATE_HISTORY", "LIEN_STATE_HISTORY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 LIEN_STATE_HISTORY_ID { get { return GetLIEN_STATE_HISTORY_ID(); } set { SetLIEN_STATE_HISTORY_ID(value); } }


		public virtual EMPLOYEE Ref_Employee { get; set; }
		public virtual LIEN_MASTER Ref_LienMaster { get; set; }

		#endregion

		#region Constructors for table LIEN_STATE_HISTORYGen
		public LIEN_STATE_HISTORYGen()
		{
		}

		public LIEN_STATE_HISTORYGen(System.DateTime CREATED_TS, System.Int64 CREATED_BY, System.String REASON, System.String LIEN_STATE_CD, System.DateTime ACTION_DT, System.Int64 LIEN_MASTER_ID, System.Int64 LIEN_STATE_HISTORY_ID) : this()
		{
			this._CREATED_TS = CREATED_TS;
			this._CREATED_BY = CREATED_BY;
			this._REASON = REASON;
			this._LIEN_STATE_CD = LIEN_STATE_CD;
			this._ACTION_DT = ACTION_DT;
			this._LIEN_MASTER_ID = LIEN_MASTER_ID;
			this._LIEN_STATE_HISTORY_ID = LIEN_STATE_HISTORY_ID;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(LIEN_STATE_HISTORYGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_CREATED_TSFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_REASONFieldIsDirty = value;
			_LIEN_STATE_CDFieldIsDirty = value;
			_ACTION_DTFieldIsDirty = value;
			_LIEN_MASTER_IDFieldIsDirty = value;
			_LIEN_STATE_HISTORY_IDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _CREATED_TSFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _REASONFieldIsDirty
				|| _LIEN_STATE_CDFieldIsDirty
				|| _ACTION_DTFieldIsDirty
				|| _LIEN_MASTER_IDFieldIsDirty
				|| _LIEN_STATE_HISTORY_IDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CATS_LEGAL_OWNER";
		}

		public override string TableName()
		{
			return "LIEN_STATE_HISTORY";
		}

		public override string PrimaryKeyFieldname()
		{
			return "LIEN_STATE_HISTORY_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (LIEN_STATE_HISTORY)this.Clone();
			result.CREATED_TS = this.CREATED_TS;
			result.CREATED_BY = this.CREATED_BY;
			result.REASON = this.REASON;
			result.LIEN_STATE_CD = this.LIEN_STATE_CD;
			result.ACTION_DT = this.ACTION_DT;
			result.LIEN_MASTER_ID = this.LIEN_MASTER_ID;
			result.LIEN_STATE_HISTORY_ID = this.LIEN_STATE_HISTORY_ID;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CATS_LEGAL_OWNER.LIEN_STATE_HISTORY")
				.Append(" { ")
				.Append("CREATED_TS")
				.Append(" = ")
				.Append(this.CREATED_TS.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("REASON")
				.Append(" = ")
				.Append(this.REASON.ToString())
				.Append("; ")
				.Append("LIEN_STATE_CD")
				.Append(" = ")
				.Append(this.LIEN_STATE_CD.ToString())
				.Append("; ")
				.Append("ACTION_DT")
				.Append(" = ")
				.Append(this.ACTION_DT.ToString())
				.Append("; ")
				.Append("LIEN_MASTER_ID")
				.Append(" = ")
				.Append(this.LIEN_MASTER_ID.ToString())
				.Append("; ")
				.Append("LIEN_STATE_HISTORY_ID")
				.Append(" = ")
				.Append(this.LIEN_STATE_HISTORY_ID.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CUBS_OWNER.OP_CAUSE_CODES.CREATED_BY->..
	//Reference to -> CUBS_OWNER.OP_CAUSE_CODES.MODIFIED_BY->..
	//ReferencedBy -> CUBS_OWNER.OP_TRANSACTIONS.OPCSE_CD->CUBS_OWNER.OP_CAUSE_CODES.OPCSE_CD
	//ReferencedBy -> CATS_BOP_OWNER.V_OPGROUP.OPCSE_CD->CUBS_OWNER.OP_CAUSE_CODES.OPCSE_CD
	[Cats.Bop.Claimant.Data.Models.DBSchema("CUBS_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CUBS_OWNER", "OP_CAUSE_CODES")]
	public partial class OP_CAUSE_CODESGen : OP_CAUSE_CODESBase
	{
		#region Property backing stores for table OP_CAUSE_CODES
		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.DateTime? _END_DT;
		protected virtual System.DateTime? GetEND_DT() { return _END_DT; }
		protected virtual void SetEND_DT(System.DateTime? value) { _END_DT = value; _END_DTFieldIsDirty = true; }
		protected virtual bool _END_DTFieldIsDirty { get; set; }

		protected System.DateTime _BEG_DT;
		protected virtual System.DateTime GetBEG_DT() { return _BEG_DT; }
		protected virtual void SetBEG_DT(System.DateTime value) { _BEG_DT = value; _BEG_DTFieldIsDirty = true; }
		protected virtual bool _BEG_DTFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_DT;
		protected virtual System.DateTime? GetMODIFIED_DT() { return _MODIFIED_DT; }
		protected virtual void SetMODIFIED_DT(System.DateTime? value) { _MODIFIED_DT = value; _MODIFIED_DTFieldIsDirty = true; }
		protected virtual bool _MODIFIED_DTFieldIsDirty { get; set; }

		protected System.String _OPCSE_CD;
		protected virtual System.String GetOPCSE_CD() { return _OPCSE_CD; }
		protected virtual void SetOPCSE_CD(System.String value) { _OPCSE_CD = value; _OPCSE_CDFieldIsDirty = true; }
		protected virtual bool _OPCSE_CDFieldIsDirty { get; set; }

		protected System.String _TXT;
		protected virtual System.String GetTXT() { return _TXT; }
		protected virtual void SetTXT(System.String value) { _TXT = value; _TXTFieldIsDirty = true; }
		protected virtual bool _TXTFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_DT;
		protected virtual System.DateTime GetCREATED_DT() { return _CREATED_DT; }
		protected virtual void SetCREATED_DT(System.DateTime value) { _CREATED_DT = value; _CREATED_DTFieldIsDirty = true; }
		protected virtual bool _CREATED_DTFieldIsDirty { get; set; }

		protected System.String _DESCR;
		protected virtual System.String GetDESCR() { return _DESCR; }
		protected virtual void SetDESCR(System.String value) { _DESCR = value; _DESCRFieldIsDirty = true; }
		protected virtual bool _DESCRFieldIsDirty { get; set; }

		#endregion

		#region Properties for table OP_CAUSE_CODES

		[ReferenceTo("CUBS_OWNER", "OP_CAUSE_CODES", "MODIFIED_BY", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_CAUSE_CODES", "CREATED_BY", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "END_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? END_DT { get { return GetEND_DT(); } set { SetEND_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "BEG_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime BEG_DT { get { return GetBEG_DT(); } set { SetBEG_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "MODIFIED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_DT { get { return GetMODIFIED_DT(); } set { SetMODIFIED_DT(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CUBS_OWNER", "OP_TRANSACTIONS", "OPCSE_CD", "CUBS_OWNER", "OP_CAUSE_CODES", "OPCSE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "OPCSE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPCSE_CD { get { return GetOPCSE_CD(); } set { SetOPCSE_CD(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(200)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "TXT", "VARCHAR2", typeof(System.String))]
		public virtual System.String TXT { get { return GetTXT(); } set { SetTXT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "CREATED_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_DT { get { return GetCREATED_DT(); } set { SetCREATED_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CAUSE_CODES", "DESCR", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCR { get { return GetDESCR(); } set { SetDESCR(value); } }


		// Ignoring dead-end RefTo from CUBS_OWNER.OP_CAUSE_CODES.CREATED_BY->...
		// Ignoring dead-end RefTo from CUBS_OWNER.OP_CAUSE_CODES.MODIFIED_BY->...
		public virtual ICollection<OP_TRANSACTIONS> RefMany_OpTransactions_OpcseCd { get; set; }
		public virtual ICollection<V_OPGROUP> RefMany_VOpgroup_OpcseCd { get; set; }

		#endregion

		#region Constructors for table OP_CAUSE_CODESGen
		public OP_CAUSE_CODESGen()
		{
		}

		public OP_CAUSE_CODESGen(System.Int64? MODIFIED_BY, System.Int64 CREATED_BY, System.DateTime? END_DT, System.DateTime BEG_DT, System.DateTime? MODIFIED_DT, System.String OPCSE_CD, System.String TXT, System.DateTime CREATED_DT, System.String DESCR) : this()
		{
			this._MODIFIED_BY = MODIFIED_BY;
			this._CREATED_BY = CREATED_BY;
			this._END_DT = END_DT;
			this._BEG_DT = BEG_DT;
			this._MODIFIED_DT = MODIFIED_DT;
			this._OPCSE_CD = OPCSE_CD;
			this._TXT = TXT;
			this._CREATED_DT = CREATED_DT;
			this._DESCR = DESCR;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_CAUSE_CODESGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_MODIFIED_BYFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_END_DTFieldIsDirty = value;
			_BEG_DTFieldIsDirty = value;
			_MODIFIED_DTFieldIsDirty = value;
			_OPCSE_CDFieldIsDirty = value;
			_TXTFieldIsDirty = value;
			_CREATED_DTFieldIsDirty = value;
			_DESCRFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _MODIFIED_BYFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _END_DTFieldIsDirty
				|| _BEG_DTFieldIsDirty
				|| _MODIFIED_DTFieldIsDirty
				|| _OPCSE_CDFieldIsDirty
				|| _TXTFieldIsDirty
				|| _CREATED_DTFieldIsDirty
				|| _DESCRFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CUBS_OWNER";
		}

		public override string TableName()
		{
			return "OP_CAUSE_CODES";
		}

		public override string PrimaryKeyFieldname()
		{
			return "OPCSE_CD";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CUBS_OWNER", "OP_TRANSACTIONS", "OPCSE_CD", "CUBS_OWNER", "OP_CAUSE_CODES", "OPCSE_CD");
			yield return ("CATS_BOP_OWNER", "V_OPGROUP", "OPCSE_CD", "CUBS_OWNER", "OP_CAUSE_CODES", "OPCSE_CD");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (OP_CAUSE_CODES)this.Clone();
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.CREATED_BY = this.CREATED_BY;
			result.END_DT = this.END_DT;
			result.BEG_DT = this.BEG_DT;
			result.MODIFIED_DT = this.MODIFIED_DT;
			result.OPCSE_CD = this.OPCSE_CD;
			result.TXT = this.TXT;
			result.CREATED_DT = this.CREATED_DT;
			result.DESCR = this.DESCR;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CUBS_OWNER.OP_CAUSE_CODES")
				.Append(" { ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("END_DT")
				.Append(" = ")
				.Append(this.END_DT.ToString())
				.Append("; ")
				.Append("BEG_DT")
				.Append(" = ")
				.Append(this.BEG_DT.ToString())
				.Append("; ")
				.Append("MODIFIED_DT")
				.Append(" = ")
				.Append(this.MODIFIED_DT.ToString())
				.Append("; ")
				.Append("OPCSE_CD")
				.Append(" = ")
				.Append(this.OPCSE_CD.ToString())
				.Append("; ")
				.Append("TXT")
				.Append(" = ")
				.Append(this.TXT.ToString())
				.Append("; ")
				.Append("CREATED_DT")
				.Append(" = ")
				.Append(this.CREATED_DT.ToString())
				.Append("; ")
				.Append("DESCR")
				.Append(" = ")
				.Append(this.DESCR.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CUBS_OWNER.OP_CLASS_CODES.CREATED_BY->..
	//Reference to -> CUBS_OWNER.OP_CLASS_CODES.MODIFIED_BY->..
	//ReferencedBy -> CUBS_OWNER.OP_TRANSACTIONS.OPCLS_CD->CUBS_OWNER.OP_CLASS_CODES.OPCLS_CD
	//ReferencedBy -> CATS_BOP_OWNER.V_OPGROUP.OPCLS_CD->CUBS_OWNER.OP_CLASS_CODES.OPCLS_CD
	[Cats.Bop.Claimant.Data.Models.DBSchema("CUBS_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CUBS_OWNER", "OP_CLASS_CODES")]
	public partial class OP_CLASS_CODESGen : OP_CLASS_CODESBase
	{
		#region Property backing stores for table OP_CLASS_CODES
		protected System.Int64 _PRIORITY;
		protected virtual System.Int64 GetPRIORITY() { return _PRIORITY; }
		protected virtual void SetPRIORITY(System.Int64 value) { _PRIORITY = value; _PRIORITYFieldIsDirty = true; }
		protected virtual bool _PRIORITYFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.DateTime? _END_DT;
		protected virtual System.DateTime? GetEND_DT() { return _END_DT; }
		protected virtual void SetEND_DT(System.DateTime? value) { _END_DT = value; _END_DTFieldIsDirty = true; }
		protected virtual bool _END_DTFieldIsDirty { get; set; }

		protected System.DateTime _BEG_DT;
		protected virtual System.DateTime GetBEG_DT() { return _BEG_DT; }
		protected virtual void SetBEG_DT(System.DateTime value) { _BEG_DT = value; _BEG_DTFieldIsDirty = true; }
		protected virtual bool _BEG_DTFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_DT;
		protected virtual System.DateTime GetCREATED_DT() { return _CREATED_DT; }
		protected virtual void SetCREATED_DT(System.DateTime value) { _CREATED_DT = value; _CREATED_DTFieldIsDirty = true; }
		protected virtual bool _CREATED_DTFieldIsDirty { get; set; }

		protected System.String _OPCLS_CD;
		protected virtual System.String GetOPCLS_CD() { return _OPCLS_CD; }
		protected virtual void SetOPCLS_CD(System.String value) { _OPCLS_CD = value; _OPCLS_CDFieldIsDirty = true; }
		protected virtual bool _OPCLS_CDFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_DT;
		protected virtual System.DateTime? GetMODIFIED_DT() { return _MODIFIED_DT; }
		protected virtual void SetMODIFIED_DT(System.DateTime? value) { _MODIFIED_DT = value; _MODIFIED_DTFieldIsDirty = true; }
		protected virtual bool _MODIFIED_DTFieldIsDirty { get; set; }

		protected System.String _DESCR;
		protected virtual System.String GetDESCR() { return _DESCR; }
		protected virtual void SetDESCR(System.String value) { _DESCR = value; _DESCRFieldIsDirty = true; }
		protected virtual bool _DESCRFieldIsDirty { get; set; }

		#endregion

		#region Properties for table OP_CLASS_CODES

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "PRIORITY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRIORITY { get { return GetPRIORITY(); } set { SetPRIORITY(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_CLASS_CODES", "MODIFIED_BY", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_CLASS_CODES", "CREATED_BY", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "END_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? END_DT { get { return GetEND_DT(); } set { SetEND_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "BEG_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime BEG_DT { get { return GetBEG_DT(); } set { SetBEG_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "CREATED_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_DT { get { return GetCREATED_DT(); } set { SetCREATED_DT(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CUBS_OWNER", "OP_TRANSACTIONS", "OPCLS_CD", "CUBS_OWNER", "OP_CLASS_CODES", "OPCLS_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "OPCLS_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPCLS_CD { get { return GetOPCLS_CD(); } set { SetOPCLS_CD(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "MODIFIED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_DT { get { return GetMODIFIED_DT(); } set { SetMODIFIED_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_CLASS_CODES", "DESCR", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCR { get { return GetDESCR(); } set { SetDESCR(value); } }


		// Ignoring dead-end RefTo from CUBS_OWNER.OP_CLASS_CODES.CREATED_BY->...
		// Ignoring dead-end RefTo from CUBS_OWNER.OP_CLASS_CODES.MODIFIED_BY->...
		public virtual ICollection<OP_TRANSACTIONS> RefMany_OpTransactions_OpclsCd { get; set; }
		public virtual ICollection<V_OPGROUP> RefMany_VOpgroup_OpclsCd { get; set; }

		#endregion

		#region Constructors for table OP_CLASS_CODESGen
		public OP_CLASS_CODESGen()
		{
		}

		public OP_CLASS_CODESGen(System.Int64 PRIORITY, System.Int64? MODIFIED_BY, System.Int64 CREATED_BY, System.DateTime? END_DT, System.DateTime BEG_DT, System.DateTime CREATED_DT, System.String OPCLS_CD, System.DateTime? MODIFIED_DT, System.String DESCR) : this()
		{
			this._PRIORITY = PRIORITY;
			this._MODIFIED_BY = MODIFIED_BY;
			this._CREATED_BY = CREATED_BY;
			this._END_DT = END_DT;
			this._BEG_DT = BEG_DT;
			this._CREATED_DT = CREATED_DT;
			this._OPCLS_CD = OPCLS_CD;
			this._MODIFIED_DT = MODIFIED_DT;
			this._DESCR = DESCR;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_CLASS_CODESGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_PRIORITYFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_END_DTFieldIsDirty = value;
			_BEG_DTFieldIsDirty = value;
			_CREATED_DTFieldIsDirty = value;
			_OPCLS_CDFieldIsDirty = value;
			_MODIFIED_DTFieldIsDirty = value;
			_DESCRFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _PRIORITYFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _END_DTFieldIsDirty
				|| _BEG_DTFieldIsDirty
				|| _CREATED_DTFieldIsDirty
				|| _OPCLS_CDFieldIsDirty
				|| _MODIFIED_DTFieldIsDirty
				|| _DESCRFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CUBS_OWNER";
		}

		public override string TableName()
		{
			return "OP_CLASS_CODES";
		}

		public override string PrimaryKeyFieldname()
		{
			return "OPCLS_CD";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CUBS_OWNER", "OP_TRANSACTIONS", "OPCLS_CD", "CUBS_OWNER", "OP_CLASS_CODES", "OPCLS_CD");
			yield return ("CATS_BOP_OWNER", "V_OPGROUP", "OPCLS_CD", "CUBS_OWNER", "OP_CLASS_CODES", "OPCLS_CD");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (OP_CLASS_CODES)this.Clone();
			result.PRIORITY = this.PRIORITY;
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.CREATED_BY = this.CREATED_BY;
			result.END_DT = this.END_DT;
			result.BEG_DT = this.BEG_DT;
			result.CREATED_DT = this.CREATED_DT;
			result.OPCLS_CD = this.OPCLS_CD;
			result.MODIFIED_DT = this.MODIFIED_DT;
			result.DESCR = this.DESCR;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CUBS_OWNER.OP_CLASS_CODES")
				.Append(" { ")
				.Append("PRIORITY")
				.Append(" = ")
				.Append(this.PRIORITY.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("END_DT")
				.Append(" = ")
				.Append(this.END_DT.ToString())
				.Append("; ")
				.Append("BEG_DT")
				.Append(" = ")
				.Append(this.BEG_DT.ToString())
				.Append("; ")
				.Append("CREATED_DT")
				.Append(" = ")
				.Append(this.CREATED_DT.ToString())
				.Append("; ")
				.Append("OPCLS_CD")
				.Append(" = ")
				.Append(this.OPCLS_CD.ToString())
				.Append("; ")
				.Append("MODIFIED_DT")
				.Append(" = ")
				.Append(this.MODIFIED_DT.ToString())
				.Append("; ")
				.Append("DESCR")
				.Append(" = ")
				.Append(this.DESCR.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CUBS_OWNER.OP_SOURCE_CODES.MODIFIED_BY->..
	//Reference to -> CUBS_OWNER.OP_SOURCE_CODES.CREATED_BY->..
	//ReferencedBy -> CUBS_OWNER.OP_TRANSACTIONS.OPSRC_CD->CUBS_OWNER.OP_SOURCE_CODES.OPSRC_CD
	//ReferencedBy -> CATS_BOP_OWNER.V_OPGROUP.OPSRC_CD->CUBS_OWNER.OP_SOURCE_CODES.OPSRC_CD
	[Cats.Bop.Claimant.Data.Models.DBSchema("CUBS_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CUBS_OWNER", "OP_SOURCE_CODES")]
	public partial class OP_SOURCE_CODESGen : OP_SOURCE_CODESBase
	{
		#region Property backing stores for table OP_SOURCE_CODES
		protected System.String _DOMAIN;
		protected virtual System.String GetDOMAIN() { return _DOMAIN; }
		protected virtual void SetDOMAIN(System.String value) { _DOMAIN = value; _DOMAINFieldIsDirty = true; }
		protected virtual bool _DOMAINFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.DateTime? _END_DT;
		protected virtual System.DateTime? GetEND_DT() { return _END_DT; }
		protected virtual void SetEND_DT(System.DateTime? value) { _END_DT = value; _END_DTFieldIsDirty = true; }
		protected virtual bool _END_DTFieldIsDirty { get; set; }

		protected System.DateTime _BEG_DT;
		protected virtual System.DateTime GetBEG_DT() { return _BEG_DT; }
		protected virtual void SetBEG_DT(System.DateTime value) { _BEG_DT = value; _BEG_DTFieldIsDirty = true; }
		protected virtual bool _BEG_DTFieldIsDirty { get; set; }

		protected System.DateTime? _MODIFIED_DT;
		protected virtual System.DateTime? GetMODIFIED_DT() { return _MODIFIED_DT; }
		protected virtual void SetMODIFIED_DT(System.DateTime? value) { _MODIFIED_DT = value; _MODIFIED_DTFieldIsDirty = true; }
		protected virtual bool _MODIFIED_DTFieldIsDirty { get; set; }

		protected System.String _OPSRC_CD;
		protected virtual System.String GetOPSRC_CD() { return _OPSRC_CD; }
		protected virtual void SetOPSRC_CD(System.String value) { _OPSRC_CD = value; _OPSRC_CDFieldIsDirty = true; }
		protected virtual bool _OPSRC_CDFieldIsDirty { get; set; }

		protected System.Int16? _BC_EMPR_RQRD_IND;
		protected virtual System.Int16? GetBC_EMPR_RQRD_IND() { return _BC_EMPR_RQRD_IND; }
		protected virtual void SetBC_EMPR_RQRD_IND(System.Int16? value) { _BC_EMPR_RQRD_IND = value; _BC_EMPR_RQRD_INDFieldIsDirty = true; }
		protected virtual bool _BC_EMPR_RQRD_INDFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_DT;
		protected virtual System.DateTime GetCREATED_DT() { return _CREATED_DT; }
		protected virtual void SetCREATED_DT(System.DateTime value) { _CREATED_DT = value; _CREATED_DTFieldIsDirty = true; }
		protected virtual bool _CREATED_DTFieldIsDirty { get; set; }

		protected System.String _DESCR;
		protected virtual System.String GetDESCR() { return _DESCR; }
		protected virtual void SetDESCR(System.String value) { _DESCR = value; _DESCRFieldIsDirty = true; }
		protected virtual bool _DESCRFieldIsDirty { get; set; }

		#endregion

		#region Properties for table OP_SOURCE_CODES

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(30)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "DOMAIN", "VARCHAR2", typeof(System.String))]
		public virtual System.String DOMAIN { get { return GetDOMAIN(); } set { SetDOMAIN(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_SOURCE_CODES", "MODIFIED_BY", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "END_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? END_DT { get { return GetEND_DT(); } set { SetEND_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "BEG_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime BEG_DT { get { return GetBEG_DT(); } set { SetBEG_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "MODIFIED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_DT { get { return GetMODIFIED_DT(); } set { SetMODIFIED_DT(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CUBS_OWNER", "OP_TRANSACTIONS", "OPSRC_CD", "CUBS_OWNER", "OP_SOURCE_CODES", "OPSRC_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "OPSRC_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPSRC_CD { get { return GetOPSRC_CD(); } set { SetOPSRC_CD(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "BC_EMPR_RQRD_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? BC_EMPR_RQRD_IND { get { return GetBC_EMPR_RQRD_IND(); } set { SetBC_EMPR_RQRD_IND(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_SOURCE_CODES", "CREATED_BY", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "CREATED_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_DT { get { return GetCREATED_DT(); } set { SetCREATED_DT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(60)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_SOURCE_CODES", "DESCR", "VARCHAR2", typeof(System.String))]
		public virtual System.String DESCR { get { return GetDESCR(); } set { SetDESCR(value); } }


		// Ignoring dead-end RefTo from CUBS_OWNER.OP_SOURCE_CODES.MODIFIED_BY->...
		// Ignoring dead-end RefTo from CUBS_OWNER.OP_SOURCE_CODES.CREATED_BY->...
		public virtual ICollection<OP_TRANSACTIONS> RefMany_OpTransactions_OpsrcCd { get; set; }
		public virtual ICollection<V_OPGROUP> RefMany_VOpgroup_OpsrcCd { get; set; }

		#endregion

		#region Constructors for table OP_SOURCE_CODESGen
		public OP_SOURCE_CODESGen()
		{
		}

		public OP_SOURCE_CODESGen(System.String DOMAIN, System.Int64? MODIFIED_BY, System.DateTime? END_DT, System.DateTime BEG_DT, System.DateTime? MODIFIED_DT, System.String OPSRC_CD, System.Int16? BC_EMPR_RQRD_IND, System.Int64 CREATED_BY, System.DateTime CREATED_DT, System.String DESCR) : this()
		{
			this._DOMAIN = DOMAIN;
			this._MODIFIED_BY = MODIFIED_BY;
			this._END_DT = END_DT;
			this._BEG_DT = BEG_DT;
			this._MODIFIED_DT = MODIFIED_DT;
			this._OPSRC_CD = OPSRC_CD;
			this._BC_EMPR_RQRD_IND = BC_EMPR_RQRD_IND;
			this._CREATED_BY = CREATED_BY;
			this._CREATED_DT = CREATED_DT;
			this._DESCR = DESCR;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_SOURCE_CODESGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_DOMAINFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_END_DTFieldIsDirty = value;
			_BEG_DTFieldIsDirty = value;
			_MODIFIED_DTFieldIsDirty = value;
			_OPSRC_CDFieldIsDirty = value;
			_BC_EMPR_RQRD_INDFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_CREATED_DTFieldIsDirty = value;
			_DESCRFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _DOMAINFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _END_DTFieldIsDirty
				|| _BEG_DTFieldIsDirty
				|| _MODIFIED_DTFieldIsDirty
				|| _OPSRC_CDFieldIsDirty
				|| _BC_EMPR_RQRD_INDFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _CREATED_DTFieldIsDirty
				|| _DESCRFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CUBS_OWNER";
		}

		public override string TableName()
		{
			return "OP_SOURCE_CODES";
		}

		public override string PrimaryKeyFieldname()
		{
			return "OPSRC_CD";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CUBS_OWNER", "OP_TRANSACTIONS", "OPSRC_CD", "CUBS_OWNER", "OP_SOURCE_CODES", "OPSRC_CD");
			yield return ("CATS_BOP_OWNER", "V_OPGROUP", "OPSRC_CD", "CUBS_OWNER", "OP_SOURCE_CODES", "OPSRC_CD");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (OP_SOURCE_CODES)this.Clone();
			result.DOMAIN = this.DOMAIN;
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.END_DT = this.END_DT;
			result.BEG_DT = this.BEG_DT;
			result.MODIFIED_DT = this.MODIFIED_DT;
			result.OPSRC_CD = this.OPSRC_CD;
			result.BC_EMPR_RQRD_IND = this.BC_EMPR_RQRD_IND;
			result.CREATED_BY = this.CREATED_BY;
			result.CREATED_DT = this.CREATED_DT;
			result.DESCR = this.DESCR;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CUBS_OWNER.OP_SOURCE_CODES")
				.Append(" { ")
				.Append("DOMAIN")
				.Append(" = ")
				.Append(this.DOMAIN.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("END_DT")
				.Append(" = ")
				.Append(this.END_DT.ToString())
				.Append("; ")
				.Append("BEG_DT")
				.Append(" = ")
				.Append(this.BEG_DT.ToString())
				.Append("; ")
				.Append("MODIFIED_DT")
				.Append(" = ")
				.Append(this.MODIFIED_DT.ToString())
				.Append("; ")
				.Append("OPSRC_CD")
				.Append(" = ")
				.Append(this.OPSRC_CD.ToString())
				.Append("; ")
				.Append("BC_EMPR_RQRD_IND")
				.Append(" = ")
				.Append(this.BC_EMPR_RQRD_IND.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("CREATED_DT")
				.Append(" = ")
				.Append(this.CREATED_DT.ToString())
				.Append("; ")
				.Append("DESCR")
				.Append(" = ")
				.Append(this.DESCR.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}

	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.OPCSE_CD->CUBS_OWNER.OP_CAUSE_CODES.OPCSE_CD
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.OPCLS_CD->CUBS_OWNER.OP_CLASS_CODES.OPCLS_CD
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.OPSRC_CD->CUBS_OWNER.OP_SOURCE_CODES.OPSRC_CD
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.PARENT_OPTRANS_ID->CUBS_OWNER.OP_TRANSACTIONS.OPTRANS_ID
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.FRAUD_PARENT_OPTRANS_ID->CUBS_OWNER.OP_TRANSACTIONS.OPTRANS_ID
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.OPTYP_CD->CUBS_OWNER.OP_TYPE_CODES.OPTYP_CD
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.CLM_ID->..
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.ISS_ID->..
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.PRTY_ID->..
	//Reference to -> CUBS_OWNER.OP_TRANSACTIONS.OPGRP_ID->CATS_BOP_OWNER.V_OPGROUP.OPGRP_ID
	//ReferencedBy -> CUBS_OWNER.OP_TRANSACTIONS.PARENT_OPTRANS_ID->CUBS_OWNER.OP_TRANSACTIONS.OPTRANS_ID
	//ReferencedBy -> CUBS_OWNER.OP_TRANSACTIONS.FRAUD_PARENT_OPTRANS_ID->CUBS_OWNER.OP_TRANSACTIONS.OPTRANS_ID
	[Cats.Bop.Claimant.Data.Models.DBSchema("CUBS_OWNER")]
	[Cats.Bop.Claimant.Data.Models.DBTable("CUBS_OWNER", "OP_TRANSACTIONS")]
	public partial class OP_TRANSACTIONSGen : OP_TRANSACTIONSBase
	{
		#region Property backing stores for table OP_TRANSACTIONS
		protected System.DateTime? _MODIFIED_DT;
		protected virtual System.DateTime? GetMODIFIED_DT() { return _MODIFIED_DT; }
		protected virtual void SetMODIFIED_DT(System.DateTime? value) { _MODIFIED_DT = value; _MODIFIED_DTFieldIsDirty = true; }
		protected virtual bool _MODIFIED_DTFieldIsDirty { get; set; }

		protected System.DateTime _CREATED_DT;
		protected virtual System.DateTime GetCREATED_DT() { return _CREATED_DT; }
		protected virtual void SetCREATED_DT(System.DateTime value) { _CREATED_DT = value; _CREATED_DTFieldIsDirty = true; }
		protected virtual bool _CREATED_DTFieldIsDirty { get; set; }

		protected System.Int16 _REV_IND;
		protected virtual System.Int16 GetREV_IND() { return _REV_IND; }
		protected virtual void SetREV_IND(System.Int16 value) { _REV_IND = value; _REV_INDFieldIsDirty = true; }
		protected virtual bool _REV_INDFieldIsDirty { get; set; }

		protected System.Decimal? _AMT;
		protected virtual System.Decimal? GetAMT() { return _AMT; }
		protected virtual void SetAMT(System.Decimal? value) { _AMT = value; _AMTFieldIsDirty = true; }
		protected virtual bool _AMTFieldIsDirty { get; set; }

		protected System.Int64? _ISS_ID;
		protected virtual System.Int64? GetISS_ID() { return _ISS_ID; }
		protected virtual void SetISS_ID(System.Int64? value) { _ISS_ID = value; _ISS_IDFieldIsDirty = true; }
		protected virtual bool _ISS_IDFieldIsDirty { get; set; }

		protected System.String _RSPAGT_CD;
		protected virtual System.String GetRSPAGT_CD() { return _RSPAGT_CD; }
		protected virtual void SetRSPAGT_CD(System.String value) { _RSPAGT_CD = value; _RSPAGT_CDFieldIsDirty = true; }
		protected virtual bool _RSPAGT_CDFieldIsDirty { get; set; }

		protected System.String _OPCLS_CD;
		protected virtual System.String GetOPCLS_CD() { return _OPCLS_CD; }
		protected virtual void SetOPCLS_CD(System.String value) { _OPCLS_CD = value; _OPCLS_CDFieldIsDirty = true; }
		protected virtual bool _OPCLS_CDFieldIsDirty { get; set; }

		protected System.Int64 _CLM_ID;
		protected virtual System.Int64 GetCLM_ID() { return _CLM_ID; }
		protected virtual void SetCLM_ID(System.Int64 value) { _CLM_ID = value; _CLM_IDFieldIsDirty = true; }
		protected virtual bool _CLM_IDFieldIsDirty { get; set; }

		protected System.Int64? _PARENT_OPTRANS_ID;
		protected virtual System.Int64? GetPARENT_OPTRANS_ID() { return _PARENT_OPTRANS_ID; }
		protected virtual void SetPARENT_OPTRANS_ID(System.Int64? value) { _PARENT_OPTRANS_ID = value; _PARENT_OPTRANS_IDFieldIsDirty = true; }
		protected virtual bool _PARENT_OPTRANS_IDFieldIsDirty { get; set; }

		protected System.Int64? _PARENT_OPGRP_ID;
		protected virtual System.Int64? GetPARENT_OPGRP_ID() { return _PARENT_OPGRP_ID; }
		protected virtual void SetPARENT_OPGRP_ID(System.Int64? value) { _PARENT_OPGRP_ID = value; _PARENT_OPGRP_IDFieldIsDirty = true; }
		protected virtual bool _PARENT_OPGRP_IDFieldIsDirty { get; set; }

		protected System.Int16? _WO_IND;
		protected virtual System.Int16? GetWO_IND() { return _WO_IND; }
		protected virtual void SetWO_IND(System.Int16? value) { _WO_IND = value; _WO_INDFieldIsDirty = true; }
		protected virtual bool _WO_INDFieldIsDirty { get; set; }

		protected System.Int64? _MDD_ID;
		protected virtual System.Int64? GetMDD_ID() { return _MDD_ID; }
		protected virtual void SetMDD_ID(System.Int64? value) { _MDD_ID = value; _MDD_IDFieldIsDirty = true; }
		protected virtual bool _MDD_IDFieldIsDirty { get; set; }

		protected System.Int64? _OPGRP_ID;
		protected virtual System.Int64? GetOPGRP_ID() { return _OPGRP_ID; }
		protected virtual void SetOPGRP_ID(System.Int64? value) { _OPGRP_ID = value; _OPGRP_IDFieldIsDirty = true; }
		protected virtual bool _OPGRP_IDFieldIsDirty { get; set; }

		protected System.Decimal? _INIT_RCVRY_AMT;
		protected virtual System.Decimal? GetINIT_RCVRY_AMT() { return _INIT_RCVRY_AMT; }
		protected virtual void SetINIT_RCVRY_AMT(System.Decimal? value) { _INIT_RCVRY_AMT = value; _INIT_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _INIT_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.Decimal? _OFFSET_RCVRY_AMT;
		protected virtual System.Decimal? GetOFFSET_RCVRY_AMT() { return _OFFSET_RCVRY_AMT; }
		protected virtual void SetOFFSET_RCVRY_AMT(System.Decimal? value) { _OFFSET_RCVRY_AMT = value; _OFFSET_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _OFFSET_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.Int16? _RCVRY_REV_IND;
		protected virtual System.Int16? GetRCVRY_REV_IND() { return _RCVRY_REV_IND; }
		protected virtual void SetRCVRY_REV_IND(System.Int16? value) { _RCVRY_REV_IND = value; _RCVRY_REV_INDFieldIsDirty = true; }
		protected virtual bool _RCVRY_REV_INDFieldIsDirty { get; set; }

		protected System.Int64? _PMT_TRANS_ID;
		protected virtual System.Int64? GetPMT_TRANS_ID() { return _PMT_TRANS_ID; }
		protected virtual void SetPMT_TRANS_ID(System.Int64? value) { _PMT_TRANS_ID = value; _PMT_TRANS_IDFieldIsDirty = true; }
		protected virtual bool _PMT_TRANS_IDFieldIsDirty { get; set; }

		protected System.Decimal? _CONSUMED_RCVRY_AMT;
		protected virtual System.Decimal? GetCONSUMED_RCVRY_AMT() { return _CONSUMED_RCVRY_AMT; }
		protected virtual void SetCONSUMED_RCVRY_AMT(System.Decimal? value) { _CONSUMED_RCVRY_AMT = value; _CONSUMED_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _CONSUMED_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.String _RCVRY_CD;
		protected virtual System.String GetRCVRY_CD() { return _RCVRY_CD; }
		protected virtual void SetRCVRY_CD(System.String value) { _RCVRY_CD = value; _RCVRY_CDFieldIsDirty = true; }
		protected virtual bool _RCVRY_CDFieldIsDirty { get; set; }

		protected System.Decimal? _ORIG_OP_AMT;
		protected virtual System.Decimal? GetORIG_OP_AMT() { return _ORIG_OP_AMT; }
		protected virtual void SetORIG_OP_AMT(System.Decimal? value) { _ORIG_OP_AMT = value; _ORIG_OP_AMTFieldIsDirty = true; }
		protected virtual bool _ORIG_OP_AMTFieldIsDirty { get; set; }

		protected System.String _ADJRQC_CD;
		protected virtual System.String GetADJRQC_CD() { return _ADJRQC_CD; }
		protected virtual void SetADJRQC_CD(System.String value) { _ADJRQC_CD = value; _ADJRQC_CDFieldIsDirty = true; }
		protected virtual bool _ADJRQC_CDFieldIsDirty { get; set; }

		protected System.Decimal? _SIBLING_AMT;
		protected virtual System.Decimal? GetSIBLING_AMT() { return _SIBLING_AMT; }
		protected virtual void SetSIBLING_AMT(System.Decimal? value) { _SIBLING_AMT = value; _SIBLING_AMTFieldIsDirty = true; }
		protected virtual bool _SIBLING_AMTFieldIsDirty { get; set; }

		protected System.DateTime? _DECISION_DT;
		protected virtual System.DateTime? GetDECISION_DT() { return _DECISION_DT; }
		protected virtual void SetDECISION_DT(System.DateTime? value) { _DECISION_DT = value; _DECISION_DTFieldIsDirty = true; }
		protected virtual bool _DECISION_DTFieldIsDirty { get; set; }

		protected System.Int64? _PROCESS_STATE;
		protected virtual System.Int64? GetPROCESS_STATE() { return _PROCESS_STATE; }
		protected virtual void SetPROCESS_STATE(System.Int64? value) { _PROCESS_STATE = value; _PROCESS_STATEFieldIsDirty = true; }
		protected virtual bool _PROCESS_STATEFieldIsDirty { get; set; }

		protected System.Int64 _REQ_ISS_ID;
		protected virtual System.Int64 GetREQ_ISS_ID() { return _REQ_ISS_ID; }
		protected virtual void SetREQ_ISS_ID(System.Int64 value) { _REQ_ISS_ID = value; _REQ_ISS_IDFieldIsDirty = true; }
		protected virtual bool _REQ_ISS_IDFieldIsDirty { get; set; }

		protected System.String _PENALTY_CD;
		protected virtual System.String GetPENALTY_CD() { return _PENALTY_CD; }
		protected virtual void SetPENALTY_CD(System.String value) { _PENALTY_CD = value; _PENALTY_CDFieldIsDirty = true; }
		protected virtual bool _PENALTY_CDFieldIsDirty { get; set; }

		protected System.Int64? _PRIORITY;
		protected virtual System.Int64? GetPRIORITY() { return _PRIORITY; }
		protected virtual void SetPRIORITY(System.Int64? value) { _PRIORITY = value; _PRIORITYFieldIsDirty = true; }
		protected virtual bool _PRIORITYFieldIsDirty { get; set; }

		protected System.Decimal? _PENALTY_AMT;
		protected virtual System.Decimal? GetPENALTY_AMT() { return _PENALTY_AMT; }
		protected virtual void SetPENALTY_AMT(System.Decimal? value) { _PENALTY_AMT = value; _PENALTY_AMTFieldIsDirty = true; }
		protected virtual bool _PENALTY_AMTFieldIsDirty { get; set; }

		protected System.Decimal? _WAIVE_AMT;
		protected virtual System.Decimal? GetWAIVE_AMT() { return _WAIVE_AMT; }
		protected virtual void SetWAIVE_AMT(System.Decimal? value) { _WAIVE_AMT = value; _WAIVE_AMTFieldIsDirty = true; }
		protected virtual bool _WAIVE_AMTFieldIsDirty { get; set; }

		protected System.Decimal? _SETUP_BAL;
		protected virtual System.Decimal? GetSETUP_BAL() { return _SETUP_BAL; }
		protected virtual void SetSETUP_BAL(System.Decimal? value) { _SETUP_BAL = value; _SETUP_BALFieldIsDirty = true; }
		protected virtual bool _SETUP_BALFieldIsDirty { get; set; }

		protected System.DateTime _ESTABLISH_DT;
		protected virtual System.DateTime GetESTABLISH_DT() { return _ESTABLISH_DT; }
		protected virtual void SetESTABLISH_DT(System.DateTime value) { _ESTABLISH_DT = value; _ESTABLISH_DTFieldIsDirty = true; }
		protected virtual bool _ESTABLISH_DTFieldIsDirty { get; set; }

		protected System.Int64? _MODIFIED_BY;
		protected virtual System.Int64? GetMODIFIED_BY() { return _MODIFIED_BY; }
		protected virtual void SetMODIFIED_BY(System.Int64? value) { _MODIFIED_BY = value; _MODIFIED_BYFieldIsDirty = true; }
		protected virtual bool _MODIFIED_BYFieldIsDirty { get; set; }

		protected System.Int64 _CREATED_BY;
		protected virtual System.Int64 GetCREATED_BY() { return _CREATED_BY; }
		protected virtual void SetCREATED_BY(System.Int64 value) { _CREATED_BY = value; _CREATED_BYFieldIsDirty = true; }
		protected virtual bool _CREATED_BYFieldIsDirty { get; set; }

		protected System.String _STATE_CD;
		protected virtual System.String GetSTATE_CD() { return _STATE_CD; }
		protected virtual void SetSTATE_CD(System.String value) { _STATE_CD = value; _STATE_CDFieldIsDirty = true; }
		protected virtual bool _STATE_CDFieldIsDirty { get; set; }

		protected System.Int64? _RCVRY_ID;
		protected virtual System.Int64? GetRCVRY_ID() { return _RCVRY_ID; }
		protected virtual void SetRCVRY_ID(System.Int64? value) { _RCVRY_ID = value; _RCVRY_IDFieldIsDirty = true; }
		protected virtual bool _RCVRY_IDFieldIsDirty { get; set; }

		protected System.DateTime? _CC_BWE_DT;
		protected virtual System.DateTime? GetCC_BWE_DT() { return _CC_BWE_DT; }
		protected virtual void SetCC_BWE_DT(System.DateTime? value) { _CC_BWE_DT = value; _CC_BWE_DTFieldIsDirty = true; }
		protected virtual bool _CC_BWE_DTFieldIsDirty { get; set; }

		protected System.Int64? _ADJREQ_ID;
		protected virtual System.Int64? GetADJREQ_ID() { return _ADJREQ_ID; }
		protected virtual void SetADJREQ_ID(System.Int64? value) { _ADJREQ_ID = value; _ADJREQ_IDFieldIsDirty = true; }
		protected virtual bool _ADJREQ_IDFieldIsDirty { get; set; }

		protected System.String _OPCSE_CD;
		protected virtual System.String GetOPCSE_CD() { return _OPCSE_CD; }
		protected virtual void SetOPCSE_CD(System.String value) { _OPCSE_CD = value; _OPCSE_CDFieldIsDirty = true; }
		protected virtual bool _OPCSE_CDFieldIsDirty { get; set; }

		protected System.String _OPSRC_CD;
		protected virtual System.String GetOPSRC_CD() { return _OPSRC_CD; }
		protected virtual void SetOPSRC_CD(System.String value) { _OPSRC_CD = value; _OPSRC_CDFieldIsDirty = true; }
		protected virtual bool _OPSRC_CDFieldIsDirty { get; set; }

		protected System.Int64 _PRTY_ID;
		protected virtual System.Int64 GetPRTY_ID() { return _PRTY_ID; }
		protected virtual void SetPRTY_ID(System.Int64 value) { _PRTY_ID = value; _PRTY_IDFieldIsDirty = true; }
		protected virtual bool _PRTY_IDFieldIsDirty { get; set; }

		protected System.String _OPTRANS_CD;
		protected virtual System.String GetOPTRANS_CD() { return _OPTRANS_CD; }
		protected virtual void SetOPTRANS_CD(System.String value) { _OPTRANS_CD = value; _OPTRANS_CDFieldIsDirty = true; }
		protected virtual bool _OPTRANS_CDFieldIsDirty { get; set; }

		protected System.Int64 _OPTRANS_ID;
		protected virtual System.Int64 GetOPTRANS_ID() { return _OPTRANS_ID; }
		protected virtual void SetOPTRANS_ID(System.Int64 value) { _OPTRANS_ID = value; _OPTRANS_IDFieldIsDirty = true; }
		protected virtual bool _OPTRANS_IDFieldIsDirty { get; set; }

		protected System.Decimal? _CANCEL_OP_BAL_AMT;
		protected virtual System.Decimal? GetCANCEL_OP_BAL_AMT() { return _CANCEL_OP_BAL_AMT; }
		protected virtual void SetCANCEL_OP_BAL_AMT(System.Decimal? value) { _CANCEL_OP_BAL_AMT = value; _CANCEL_OP_BAL_AMTFieldIsDirty = true; }
		protected virtual bool _CANCEL_OP_BAL_AMTFieldIsDirty { get; set; }

		protected System.String _COMMENTS;
		protected virtual System.String GetCOMMENTS() { return _COMMENTS; }
		protected virtual void SetCOMMENTS(System.String value) { _COMMENTS = value; _COMMENTSFieldIsDirty = true; }
		protected virtual bool _COMMENTSFieldIsDirty { get; set; }

		protected System.String _PMT_PROG_CD;
		protected virtual System.String GetPMT_PROG_CD() { return _PMT_PROG_CD; }
		protected virtual void SetPMT_PROG_CD(System.String value) { _PMT_PROG_CD = value; _PMT_PROG_CDFieldIsDirty = true; }
		protected virtual bool _PMT_PROG_CDFieldIsDirty { get; set; }

		protected System.Decimal? _OFFSET_REDUCTION_AMT;
		protected virtual System.Decimal? GetOFFSET_REDUCTION_AMT() { return _OFFSET_REDUCTION_AMT; }
		protected virtual void SetOFFSET_REDUCTION_AMT(System.Decimal? value) { _OFFSET_REDUCTION_AMT = value; _OFFSET_REDUCTION_AMTFieldIsDirty = true; }
		protected virtual bool _OFFSET_REDUCTION_AMTFieldIsDirty { get; set; }

		protected System.Decimal? _CASH_RCVRY_AMT;
		protected virtual System.Decimal? GetCASH_RCVRY_AMT() { return _CASH_RCVRY_AMT; }
		protected virtual void SetCASH_RCVRY_AMT(System.Decimal? value) { _CASH_RCVRY_AMT = value; _CASH_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _CASH_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.String _OP_PROG_CD;
		protected virtual System.String GetOP_PROG_CD() { return _OP_PROG_CD; }
		protected virtual void SetOP_PROG_CD(System.String value) { _OP_PROG_CD = value; _OP_PROG_CDFieldIsDirty = true; }
		protected virtual bool _OP_PROG_CDFieldIsDirty { get; set; }

		protected System.Int64? _RCVRY_PRIORITY;
		protected virtual System.Int64? GetRCVRY_PRIORITY() { return _RCVRY_PRIORITY; }
		protected virtual void SetRCVRY_PRIORITY(System.Int64? value) { _RCVRY_PRIORITY = value; _RCVRY_PRIORITYFieldIsDirty = true; }
		protected virtual bool _RCVRY_PRIORITYFieldIsDirty { get; set; }

		protected System.Decimal? _AVAIL_RCVRY_AMT;
		protected virtual System.Decimal? GetAVAIL_RCVRY_AMT() { return _AVAIL_RCVRY_AMT; }
		protected virtual void SetAVAIL_RCVRY_AMT(System.Decimal? value) { _AVAIL_RCVRY_AMT = value; _AVAIL_RCVRY_AMTFieldIsDirty = true; }
		protected virtual bool _AVAIL_RCVRY_AMTFieldIsDirty { get; set; }

		protected System.Int16? _MANUAL_TRANS_IND;
		protected virtual System.Int16? GetMANUAL_TRANS_IND() { return _MANUAL_TRANS_IND; }
		protected virtual void SetMANUAL_TRANS_IND(System.Int16? value) { _MANUAL_TRANS_IND = value; _MANUAL_TRANS_INDFieldIsDirty = true; }
		protected virtual bool _MANUAL_TRANS_INDFieldIsDirty { get; set; }

		protected System.Int16? _MANUAL_SPLIT_IND;
		protected virtual System.Int16? GetMANUAL_SPLIT_IND() { return _MANUAL_SPLIT_IND; }
		protected virtual void SetMANUAL_SPLIT_IND(System.Int16? value) { _MANUAL_SPLIT_IND = value; _MANUAL_SPLIT_INDFieldIsDirty = true; }
		protected virtual bool _MANUAL_SPLIT_INDFieldIsDirty { get; set; }

		protected System.Int64? _SIBLING_PRIORITY;
		protected virtual System.Int64? GetSIBLING_PRIORITY() { return _SIBLING_PRIORITY; }
		protected virtual void SetSIBLING_PRIORITY(System.Int64? value) { _SIBLING_PRIORITY = value; _SIBLING_PRIORITYFieldIsDirty = true; }
		protected virtual bool _SIBLING_PRIORITYFieldIsDirty { get; set; }

		protected System.Int64? _FRAUD_PARENT_OPTRANS_ID;
		protected virtual System.Int64? GetFRAUD_PARENT_OPTRANS_ID() { return _FRAUD_PARENT_OPTRANS_ID; }
		protected virtual void SetFRAUD_PARENT_OPTRANS_ID(System.Int64? value) { _FRAUD_PARENT_OPTRANS_ID = value; _FRAUD_PARENT_OPTRANS_IDFieldIsDirty = true; }
		protected virtual bool _FRAUD_PARENT_OPTRANS_IDFieldIsDirty { get; set; }

		protected System.Int16? _SPLIT_IND;
		protected virtual System.Int16? GetSPLIT_IND() { return _SPLIT_IND; }
		protected virtual void SetSPLIT_IND(System.Int16? value) { _SPLIT_IND = value; _SPLIT_INDFieldIsDirty = true; }
		protected virtual bool _SPLIT_INDFieldIsDirty { get; set; }

		protected System.Decimal? _FRAUD_AMT;
		protected virtual System.Decimal? GetFRAUD_AMT() { return _FRAUD_AMT; }
		protected virtual void SetFRAUD_AMT(System.Decimal? value) { _FRAUD_AMT = value; _FRAUD_AMTFieldIsDirty = true; }
		protected virtual bool _FRAUD_AMTFieldIsDirty { get; set; }

		protected System.Decimal? _CHARGE_OFF_AMT;
		protected virtual System.Decimal? GetCHARGE_OFF_AMT() { return _CHARGE_OFF_AMT; }
		protected virtual void SetCHARGE_OFF_AMT(System.Decimal? value) { _CHARGE_OFF_AMT = value; _CHARGE_OFF_AMTFieldIsDirty = true; }
		protected virtual bool _CHARGE_OFF_AMTFieldIsDirty { get; set; }

		protected System.Int64? _PARENT_SETUP_OPTRANS_ID;
		protected virtual System.Int64? GetPARENT_SETUP_OPTRANS_ID() { return _PARENT_SETUP_OPTRANS_ID; }
		protected virtual void SetPARENT_SETUP_OPTRANS_ID(System.Int64? value) { _PARENT_SETUP_OPTRANS_ID = value; _PARENT_SETUP_OPTRANS_IDFieldIsDirty = true; }
		protected virtual bool _PARENT_SETUP_OPTRANS_IDFieldIsDirty { get; set; }

		protected System.String _OPTYP_CD;
		protected virtual System.String GetOPTYP_CD() { return _OPTYP_CD; }
		protected virtual void SetOPTYP_CD(System.String value) { _OPTYP_CD = value; _OPTYP_CDFieldIsDirty = true; }
		protected virtual bool _OPTYP_CDFieldIsDirty { get; set; }

		#endregion

		#region Properties for table OP_TRANSACTIONS

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "MODIFIED_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? MODIFIED_DT { get { return GetMODIFIED_DT(); } set { SetMODIFIED_DT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CREATED_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime CREATED_DT { get { return GetCREATED_DT(); } set { SetCREATED_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "REV_IND", "NUMBER", typeof(System.Int16))]
		public virtual System.Int16 REV_IND { get { return GetREV_IND(); } set { SetREV_IND(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? AMT { get { return GetAMT(); } set { SetAMT(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "ISS_ID", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "ISS_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? ISS_ID { get { return GetISS_ID(); } set { SetISS_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "RSPAGT_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String RSPAGT_CD { get { return GetRSPAGT_CD(); } set { SetRSPAGT_CD(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "OPCLS_CD", "CUBS_OWNER", "OP_CLASS_CODES", "OPCLS_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OPCLS_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPCLS_CD { get { return GetOPCLS_CD(); } set { SetOPCLS_CD(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "CLM_ID", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CLM_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CLM_ID { get { return GetCLM_ID(); } set { SetCLM_ID(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "PARENT_OPTRANS_ID", "CUBS_OWNER", "OP_TRANSACTIONS", "OPTRANS_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PARENT_OPTRANS_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PARENT_OPTRANS_ID { get { return GetPARENT_OPTRANS_ID(); } set { SetPARENT_OPTRANS_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PARENT_OPGRP_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PARENT_OPGRP_ID { get { return GetPARENT_OPGRP_ID(); } set { SetPARENT_OPGRP_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "WO_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? WO_IND { get { return GetWO_IND(); } set { SetWO_IND(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "MDD_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MDD_ID { get { return GetMDD_ID(); } set { SetMDD_ID(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "OPGRP_ID", "CATS_BOP_OWNER", "V_OPGROUP", "OPGRP_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OPGRP_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? OPGRP_ID { get { return GetOPGRP_ID(); } set { SetOPGRP_ID(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "INIT_RCVRY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? INIT_RCVRY_AMT { get { return GetINIT_RCVRY_AMT(); } set { SetINIT_RCVRY_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OFFSET_RCVRY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? OFFSET_RCVRY_AMT { get { return GetOFFSET_RCVRY_AMT(); } set { SetOFFSET_RCVRY_AMT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "RCVRY_REV_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? RCVRY_REV_IND { get { return GetRCVRY_REV_IND(); } set { SetRCVRY_REV_IND(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PMT_TRANS_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PMT_TRANS_ID { get { return GetPMT_TRANS_ID(); } set { SetPMT_TRANS_ID(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CONSUMED_RCVRY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? CONSUMED_RCVRY_AMT { get { return GetCONSUMED_RCVRY_AMT(); } set { SetCONSUMED_RCVRY_AMT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "RCVRY_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String RCVRY_CD { get { return GetRCVRY_CD(); } set { SetRCVRY_CD(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "ORIG_OP_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? ORIG_OP_AMT { get { return GetORIG_OP_AMT(); } set { SetORIG_OP_AMT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "ADJRQC_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String ADJRQC_CD { get { return GetADJRQC_CD(); } set { SetADJRQC_CD(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "SIBLING_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? SIBLING_AMT { get { return GetSIBLING_AMT(); } set { SetSIBLING_AMT(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "DECISION_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? DECISION_DT { get { return GetDECISION_DT(); } set { SetDECISION_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PROCESS_STATE", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PROCESS_STATE { get { return GetPROCESS_STATE(); } set { SetPROCESS_STATE(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "REQ_ISS_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 REQ_ISS_ID { get { return GetREQ_ISS_ID(); } set { SetREQ_ISS_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PENALTY_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String PENALTY_CD { get { return GetPENALTY_CD(); } set { SetPENALTY_CD(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PRIORITY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PRIORITY { get { return GetPRIORITY(); } set { SetPRIORITY(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PENALTY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? PENALTY_AMT { get { return GetPENALTY_AMT(); } set { SetPENALTY_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "WAIVE_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? WAIVE_AMT { get { return GetWAIVE_AMT(); } set { SetWAIVE_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "SETUP_BAL", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? SETUP_BAL { get { return GetSETUP_BAL(); } set { SetSETUP_BAL(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "ESTABLISH_DT", "DATE", typeof(System.DateTime))]
		public virtual System.DateTime ESTABLISH_DT { get { return GetESTABLISH_DT(); } set { SetESTABLISH_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "MODIFIED_BY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? MODIFIED_BY { get { return GetMODIFIED_BY(); } set { SetMODIFIED_BY(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CREATED_BY", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 CREATED_BY { get { return GetCREATED_BY(); } set { SetCREATED_BY(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "STATE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String STATE_CD { get { return GetSTATE_CD(); } set { SetSTATE_CD(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "RCVRY_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? RCVRY_ID { get { return GetRCVRY_ID(); } set { SetRCVRY_ID(value); } }

		[DBFieldDataType("DATE")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CC_BWE_DT", "DATE", typeof(System.DateTime?))]
		public virtual System.DateTime? CC_BWE_DT { get { return GetCC_BWE_DT(); } set { SetCC_BWE_DT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "ADJREQ_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? ADJREQ_ID { get { return GetADJREQ_ID(); } set { SetADJREQ_ID(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "OPCSE_CD", "CUBS_OWNER", "OP_CAUSE_CODES", "OPCSE_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OPCSE_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPCSE_CD { get { return GetOPCSE_CD(); } set { SetOPCSE_CD(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "OPSRC_CD", "CUBS_OWNER", "OP_SOURCE_CODES", "OPSRC_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OPSRC_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPSRC_CD { get { return GetOPSRC_CD(); } set { SetOPSRC_CD(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "PRTY_ID", "", "", "")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PRTY_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 PRTY_ID { get { return GetPRTY_ID(); } set { SetPRTY_ID(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(2)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OPTRANS_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPTRANS_CD { get { return GetOPTRANS_CD(); } set { SetOPTRANS_CD(value); } }

		[Cats.Bop.Claimant.Data.Models.PrimaryKeyColumn()]
		[ReferenceFrom("CUBS_OWNER", "OP_TRANSACTIONS", "PARENT_OPTRANS_ID", "CUBS_OWNER", "OP_TRANSACTIONS", "OPTRANS_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OPTRANS_ID", "NUMBER", typeof(System.Int64))]
		public virtual System.Int64 OPTRANS_ID { get { return GetOPTRANS_ID(); } set { SetOPTRANS_ID(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CANCEL_OP_BAL_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? CANCEL_OP_BAL_AMT { get { return GetCANCEL_OP_BAL_AMT(); } set { SetCANCEL_OP_BAL_AMT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(50)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "COMMENTS", "VARCHAR2", typeof(System.String))]
		public virtual System.String COMMENTS { get { return GetCOMMENTS(); } set { SetCOMMENTS(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(5)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PMT_PROG_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String PMT_PROG_CD { get { return GetPMT_PROG_CD(); } set { SetPMT_PROG_CD(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OFFSET_REDUCTION_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? OFFSET_REDUCTION_AMT { get { return GetOFFSET_REDUCTION_AMT(); } set { SetOFFSET_REDUCTION_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CASH_RCVRY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? CASH_RCVRY_AMT { get { return GetCASH_RCVRY_AMT(); } set { SetCASH_RCVRY_AMT(value); } }

		[DBFieldDataType("VARCHAR2")]
		[MaxLength(5)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OP_PROG_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OP_PROG_CD { get { return GetOP_PROG_CD(); } set { SetOP_PROG_CD(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "RCVRY_PRIORITY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? RCVRY_PRIORITY { get { return GetRCVRY_PRIORITY(); } set { SetRCVRY_PRIORITY(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "AVAIL_RCVRY_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? AVAIL_RCVRY_AMT { get { return GetAVAIL_RCVRY_AMT(); } set { SetAVAIL_RCVRY_AMT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "MANUAL_TRANS_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? MANUAL_TRANS_IND { get { return GetMANUAL_TRANS_IND(); } set { SetMANUAL_TRANS_IND(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "MANUAL_SPLIT_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? MANUAL_SPLIT_IND { get { return GetMANUAL_SPLIT_IND(); } set { SetMANUAL_SPLIT_IND(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "SIBLING_PRIORITY", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? SIBLING_PRIORITY { get { return GetSIBLING_PRIORITY(); } set { SetSIBLING_PRIORITY(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "FRAUD_PARENT_OPTRANS_ID", "CUBS_OWNER", "OP_TRANSACTIONS", "OPTRANS_ID")]
		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "FRAUD_PARENT_OPTRANS_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? FRAUD_PARENT_OPTRANS_ID { get { return GetFRAUD_PARENT_OPTRANS_ID(); } set { SetFRAUD_PARENT_OPTRANS_ID(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "SPLIT_IND", "NUMBER", typeof(System.Int16?))]
		public virtual System.Int16? SPLIT_IND { get { return GetSPLIT_IND(); } set { SetSPLIT_IND(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "FRAUD_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? FRAUD_AMT { get { return GetFRAUD_AMT(); } set { SetFRAUD_AMT(value); } }

		[DBFieldDataType("FLOAT")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "CHARGE_OFF_AMT", "FLOAT", typeof(System.Decimal?))]
		public virtual System.Decimal? CHARGE_OFF_AMT { get { return GetCHARGE_OFF_AMT(); } set { SetCHARGE_OFF_AMT(value); } }

		[DBFieldDataType("NUMBER")]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "PARENT_SETUP_OPTRANS_ID", "NUMBER", typeof(System.Int64?))]
		public virtual System.Int64? PARENT_SETUP_OPTRANS_ID { get { return GetPARENT_SETUP_OPTRANS_ID(); } set { SetPARENT_SETUP_OPTRANS_ID(value); } }

		[ReferenceTo("CUBS_OWNER", "OP_TRANSACTIONS", "OPTYP_CD", "CUBS_OWNER", "OP_TYPE_CODES", "OPTYP_CD")]
		[DBFieldDataType("VARCHAR2")]
		[MaxLength(1)]
		[Cats.Bop.Claimant.Data.Models.Column("CUBS_OWNER", "OP_TRANSACTIONS", "OPTYP_CD", "VARCHAR2", typeof(System.String))]
		public virtual System.String OPTYP_CD { get { return GetOPTYP_CD(); } set { SetOPTYP_CD(value); } }


		public virtual OP_CAUSE_CODES Ref_OpCauseCodes { get; set; }
		public virtual OP_CLASS_CODES Ref_OpClassCodes { get; set; }
		public virtual OP_SOURCE_CODES Ref_OpSourceCodes { get; set; }
		public virtual OP_TRANSACTIONS Ref_OpTransactions_ParentOptransId { get; set; }
		public virtual OP_TRANSACTIONS Ref_OpTransactions_FraudParentOptransId { get; set; }
		// Ignoring dead-end RefTo from CUBS_OWNER.OP_TRANSACTIONS.OPTYP_CD->CUBS_OWNER.OP_TYPE_CODES.OPTYP_CD.
		// Ignoring dead-end RefTo from CUBS_OWNER.OP_TRANSACTIONS.CLM_ID->...
		// Ignoring dead-end RefTo from CUBS_OWNER.OP_TRANSACTIONS.ISS_ID->...
		// Ignoring dead-end RefTo from CUBS_OWNER.OP_TRANSACTIONS.PRTY_ID->...
		public virtual V_OPGROUP Ref_VOpgroup { get; set; }
		public virtual ICollection<OP_TRANSACTIONS> RefMany_OpTransactions_ParentOptransId { get; set; }
		public virtual ICollection<OP_TRANSACTIONS> RefMany_OpTransactions_FraudParentOptransId { get; set; }

		#endregion

		#region Constructors for table OP_TRANSACTIONSGen
		public OP_TRANSACTIONSGen()
		{
		}

		public OP_TRANSACTIONSGen(System.DateTime? MODIFIED_DT, System.DateTime CREATED_DT, System.Int16 REV_IND, System.Decimal? AMT, System.Int64? ISS_ID, System.String RSPAGT_CD, System.String OPCLS_CD, System.Int64 CLM_ID, System.Int64? PARENT_OPTRANS_ID, System.Int64? PARENT_OPGRP_ID, System.Int16? WO_IND, System.Int64? MDD_ID, System.Int64? OPGRP_ID, System.Decimal? INIT_RCVRY_AMT, System.Decimal? OFFSET_RCVRY_AMT, System.Int16? RCVRY_REV_IND, System.Int64? PMT_TRANS_ID, System.Decimal? CONSUMED_RCVRY_AMT, System.String RCVRY_CD, System.Decimal? ORIG_OP_AMT, System.String ADJRQC_CD, System.Decimal? SIBLING_AMT, System.DateTime? DECISION_DT, System.Int64? PROCESS_STATE, System.Int64 REQ_ISS_ID, System.String PENALTY_CD, System.Int64? PRIORITY, System.Decimal? PENALTY_AMT, System.Decimal? WAIVE_AMT, System.Decimal? SETUP_BAL, System.DateTime ESTABLISH_DT, System.Int64? MODIFIED_BY, System.Int64 CREATED_BY, System.String STATE_CD, System.Int64? RCVRY_ID, System.DateTime? CC_BWE_DT, System.Int64? ADJREQ_ID, System.String OPCSE_CD, System.String OPSRC_CD, System.Int64 PRTY_ID, System.String OPTRANS_CD, System.Int64 OPTRANS_ID, System.Decimal? CANCEL_OP_BAL_AMT, System.String COMMENTS, System.String PMT_PROG_CD, System.Decimal? OFFSET_REDUCTION_AMT, System.Decimal? CASH_RCVRY_AMT, System.String OP_PROG_CD, System.Int64? RCVRY_PRIORITY, System.Decimal? AVAIL_RCVRY_AMT, System.Int16? MANUAL_TRANS_IND, System.Int16? MANUAL_SPLIT_IND, System.Int64? SIBLING_PRIORITY, System.Int64? FRAUD_PARENT_OPTRANS_ID, System.Int16? SPLIT_IND, System.Decimal? FRAUD_AMT, System.Decimal? CHARGE_OFF_AMT, System.Int64? PARENT_SETUP_OPTRANS_ID, System.String OPTYP_CD) : this()
		{
			this._MODIFIED_DT = MODIFIED_DT;
			this._CREATED_DT = CREATED_DT;
			this._REV_IND = REV_IND;
			this._AMT = AMT;
			this._ISS_ID = ISS_ID;
			this._RSPAGT_CD = RSPAGT_CD;
			this._OPCLS_CD = OPCLS_CD;
			this._CLM_ID = CLM_ID;
			this._PARENT_OPTRANS_ID = PARENT_OPTRANS_ID;
			this._PARENT_OPGRP_ID = PARENT_OPGRP_ID;
			this._WO_IND = WO_IND;
			this._MDD_ID = MDD_ID;
			this._OPGRP_ID = OPGRP_ID;
			this._INIT_RCVRY_AMT = INIT_RCVRY_AMT;
			this._OFFSET_RCVRY_AMT = OFFSET_RCVRY_AMT;
			this._RCVRY_REV_IND = RCVRY_REV_IND;
			this._PMT_TRANS_ID = PMT_TRANS_ID;
			this._CONSUMED_RCVRY_AMT = CONSUMED_RCVRY_AMT;
			this._RCVRY_CD = RCVRY_CD;
			this._ORIG_OP_AMT = ORIG_OP_AMT;
			this._ADJRQC_CD = ADJRQC_CD;
			this._SIBLING_AMT = SIBLING_AMT;
			this._DECISION_DT = DECISION_DT;
			this._PROCESS_STATE = PROCESS_STATE;
			this._REQ_ISS_ID = REQ_ISS_ID;
			this._PENALTY_CD = PENALTY_CD;
			this._PRIORITY = PRIORITY;
			this._PENALTY_AMT = PENALTY_AMT;
			this._WAIVE_AMT = WAIVE_AMT;
			this._SETUP_BAL = SETUP_BAL;
			this._ESTABLISH_DT = ESTABLISH_DT;
			this._MODIFIED_BY = MODIFIED_BY;
			this._CREATED_BY = CREATED_BY;
			this._STATE_CD = STATE_CD;
			this._RCVRY_ID = RCVRY_ID;
			this._CC_BWE_DT = CC_BWE_DT;
			this._ADJREQ_ID = ADJREQ_ID;
			this._OPCSE_CD = OPCSE_CD;
			this._OPSRC_CD = OPSRC_CD;
			this._PRTY_ID = PRTY_ID;
			this._OPTRANS_CD = OPTRANS_CD;
			this._OPTRANS_ID = OPTRANS_ID;
			this._CANCEL_OP_BAL_AMT = CANCEL_OP_BAL_AMT;
			this._COMMENTS = COMMENTS;
			this._PMT_PROG_CD = PMT_PROG_CD;
			this._OFFSET_REDUCTION_AMT = OFFSET_REDUCTION_AMT;
			this._CASH_RCVRY_AMT = CASH_RCVRY_AMT;
			this._OP_PROG_CD = OP_PROG_CD;
			this._RCVRY_PRIORITY = RCVRY_PRIORITY;
			this._AVAIL_RCVRY_AMT = AVAIL_RCVRY_AMT;
			this._MANUAL_TRANS_IND = MANUAL_TRANS_IND;
			this._MANUAL_SPLIT_IND = MANUAL_SPLIT_IND;
			this._SIBLING_PRIORITY = SIBLING_PRIORITY;
			this._FRAUD_PARENT_OPTRANS_ID = FRAUD_PARENT_OPTRANS_ID;
			this._SPLIT_IND = SPLIT_IND;
			this._FRAUD_AMT = FRAUD_AMT;
			this._CHARGE_OFF_AMT = CHARGE_OFF_AMT;
			this._PARENT_SETUP_OPTRANS_ID = PARENT_SETUP_OPTRANS_ID;
			this._OPTYP_CD = OPTYP_CD;
		}
		#endregion

		#region Overrides

		public override List<(System.Reflection.PropertyInfo Prop, System.Attribute Attr)> GetAllAttributes()
		{
			var myAttributes = typeof(OP_TRANSACTIONSGen)
				.GetProperties()
				.SelectMany(p => p
					.GetCustomAttributes(true)
					.Cast<System.Attribute>()
					.Select<System.Attribute, (System.Reflection.PropertyInfo Prop, System.Attribute Attr)>(a => (p, a)));

			var inheritedAttributes = base.GetAllAttributes();
			return myAttributes.Concat(inheritedAttributes).ToList();
		}

		public override void SetDirtyFields(bool value)
		{
			_MODIFIED_DTFieldIsDirty = value;
			_CREATED_DTFieldIsDirty = value;
			_REV_INDFieldIsDirty = value;
			_AMTFieldIsDirty = value;
			_ISS_IDFieldIsDirty = value;
			_RSPAGT_CDFieldIsDirty = value;
			_OPCLS_CDFieldIsDirty = value;
			_CLM_IDFieldIsDirty = value;
			_PARENT_OPTRANS_IDFieldIsDirty = value;
			_PARENT_OPGRP_IDFieldIsDirty = value;
			_WO_INDFieldIsDirty = value;
			_MDD_IDFieldIsDirty = value;
			_OPGRP_IDFieldIsDirty = value;
			_INIT_RCVRY_AMTFieldIsDirty = value;
			_OFFSET_RCVRY_AMTFieldIsDirty = value;
			_RCVRY_REV_INDFieldIsDirty = value;
			_PMT_TRANS_IDFieldIsDirty = value;
			_CONSUMED_RCVRY_AMTFieldIsDirty = value;
			_RCVRY_CDFieldIsDirty = value;
			_ORIG_OP_AMTFieldIsDirty = value;
			_ADJRQC_CDFieldIsDirty = value;
			_SIBLING_AMTFieldIsDirty = value;
			_DECISION_DTFieldIsDirty = value;
			_PROCESS_STATEFieldIsDirty = value;
			_REQ_ISS_IDFieldIsDirty = value;
			_PENALTY_CDFieldIsDirty = value;
			_PRIORITYFieldIsDirty = value;
			_PENALTY_AMTFieldIsDirty = value;
			_WAIVE_AMTFieldIsDirty = value;
			_SETUP_BALFieldIsDirty = value;
			_ESTABLISH_DTFieldIsDirty = value;
			_MODIFIED_BYFieldIsDirty = value;
			_CREATED_BYFieldIsDirty = value;
			_STATE_CDFieldIsDirty = value;
			_RCVRY_IDFieldIsDirty = value;
			_CC_BWE_DTFieldIsDirty = value;
			_ADJREQ_IDFieldIsDirty = value;
			_OPCSE_CDFieldIsDirty = value;
			_OPSRC_CDFieldIsDirty = value;
			_PRTY_IDFieldIsDirty = value;
			_OPTRANS_CDFieldIsDirty = value;
			_OPTRANS_IDFieldIsDirty = value;
			_CANCEL_OP_BAL_AMTFieldIsDirty = value;
			_COMMENTSFieldIsDirty = value;
			_PMT_PROG_CDFieldIsDirty = value;
			_OFFSET_REDUCTION_AMTFieldIsDirty = value;
			_CASH_RCVRY_AMTFieldIsDirty = value;
			_OP_PROG_CDFieldIsDirty = value;
			_RCVRY_PRIORITYFieldIsDirty = value;
			_AVAIL_RCVRY_AMTFieldIsDirty = value;
			_MANUAL_TRANS_INDFieldIsDirty = value;
			_MANUAL_SPLIT_INDFieldIsDirty = value;
			_SIBLING_PRIORITYFieldIsDirty = value;
			_FRAUD_PARENT_OPTRANS_IDFieldIsDirty = value;
			_SPLIT_INDFieldIsDirty = value;
			_FRAUD_AMTFieldIsDirty = value;
			_CHARGE_OFF_AMTFieldIsDirty = value;
			_PARENT_SETUP_OPTRANS_IDFieldIsDirty = value;
			_OPTYP_CDFieldIsDirty = value;
		}

		public override bool HasDirtyFields()
		{
			bool result = false
				|| _MODIFIED_DTFieldIsDirty
				|| _CREATED_DTFieldIsDirty
				|| _REV_INDFieldIsDirty
				|| _AMTFieldIsDirty
				|| _ISS_IDFieldIsDirty
				|| _RSPAGT_CDFieldIsDirty
				|| _OPCLS_CDFieldIsDirty
				|| _CLM_IDFieldIsDirty
				|| _PARENT_OPTRANS_IDFieldIsDirty
				|| _PARENT_OPGRP_IDFieldIsDirty
				|| _WO_INDFieldIsDirty
				|| _MDD_IDFieldIsDirty
				|| _OPGRP_IDFieldIsDirty
				|| _INIT_RCVRY_AMTFieldIsDirty
				|| _OFFSET_RCVRY_AMTFieldIsDirty
				|| _RCVRY_REV_INDFieldIsDirty
				|| _PMT_TRANS_IDFieldIsDirty
				|| _CONSUMED_RCVRY_AMTFieldIsDirty
				|| _RCVRY_CDFieldIsDirty
				|| _ORIG_OP_AMTFieldIsDirty
				|| _ADJRQC_CDFieldIsDirty
				|| _SIBLING_AMTFieldIsDirty
				|| _DECISION_DTFieldIsDirty
				|| _PROCESS_STATEFieldIsDirty
				|| _REQ_ISS_IDFieldIsDirty
				|| _PENALTY_CDFieldIsDirty
				|| _PRIORITYFieldIsDirty
				|| _PENALTY_AMTFieldIsDirty
				|| _WAIVE_AMTFieldIsDirty
				|| _SETUP_BALFieldIsDirty
				|| _ESTABLISH_DTFieldIsDirty
				|| _MODIFIED_BYFieldIsDirty
				|| _CREATED_BYFieldIsDirty
				|| _STATE_CDFieldIsDirty
				|| _RCVRY_IDFieldIsDirty
				|| _CC_BWE_DTFieldIsDirty
				|| _ADJREQ_IDFieldIsDirty
				|| _OPCSE_CDFieldIsDirty
				|| _OPSRC_CDFieldIsDirty
				|| _PRTY_IDFieldIsDirty
				|| _OPTRANS_CDFieldIsDirty
				|| _OPTRANS_IDFieldIsDirty
				|| _CANCEL_OP_BAL_AMTFieldIsDirty
				|| _COMMENTSFieldIsDirty
				|| _PMT_PROG_CDFieldIsDirty
				|| _OFFSET_REDUCTION_AMTFieldIsDirty
				|| _CASH_RCVRY_AMTFieldIsDirty
				|| _OP_PROG_CDFieldIsDirty
				|| _RCVRY_PRIORITYFieldIsDirty
				|| _AVAIL_RCVRY_AMTFieldIsDirty
				|| _MANUAL_TRANS_INDFieldIsDirty
				|| _MANUAL_SPLIT_INDFieldIsDirty
				|| _SIBLING_PRIORITYFieldIsDirty
				|| _FRAUD_PARENT_OPTRANS_IDFieldIsDirty
				|| _SPLIT_INDFieldIsDirty
				|| _FRAUD_AMTFieldIsDirty
				|| _CHARGE_OFF_AMTFieldIsDirty
				|| _PARENT_SETUP_OPTRANS_IDFieldIsDirty
				|| _OPTYP_CDFieldIsDirty;

			return result;
		}

	public override string SchemaName()
		{
			return "CUBS_OWNER";
		}

		public override string TableName()
		{
			return "OP_TRANSACTIONS";
		}

		public override string PrimaryKeyFieldname()
		{
			return "OPTRANS_ID";
		}

		public override bool HasPrimaryKey()
		{
			return true;
		}

		public override bool HasForeignKeys()
		{
			return true;
		}

		public override IEnumerable<(string RefSchemaName, string RefTableName, string RefColumnName, 
			string ForeignSchemaName, string ForeignTableName, string ForeignColumnName)> ForeignKeys()
		{
			yield return ("CUBS_OWNER", "OP_TRANSACTIONS", "PARENT_OPTRANS_ID", "CUBS_OWNER", "OP_TRANSACTIONS", "OPTRANS_ID");
			yield return ("CUBS_OWNER", "OP_TRANSACTIONS", "FRAUD_PARENT_OPTRANS_ID", "CUBS_OWNER", "OP_TRANSACTIONS", "OPTRANS_ID");
			yield break;
		}

		public override bool HasCompositePrimaryKey()
		{
			return false;
		}

		public override EntityBase Clone() { return (EntityBase) this.MemberwiseClone(); }
		public override EntityBase DeepClone()
		{
			var result = (OP_TRANSACTIONS)this.Clone();
			result.MODIFIED_DT = this.MODIFIED_DT;
			result.CREATED_DT = this.CREATED_DT;
			result.REV_IND = this.REV_IND;
			result.AMT = this.AMT;
			result.ISS_ID = this.ISS_ID;
			result.RSPAGT_CD = this.RSPAGT_CD;
			result.OPCLS_CD = this.OPCLS_CD;
			result.CLM_ID = this.CLM_ID;
			result.PARENT_OPTRANS_ID = this.PARENT_OPTRANS_ID;
			result.PARENT_OPGRP_ID = this.PARENT_OPGRP_ID;
			result.WO_IND = this.WO_IND;
			result.MDD_ID = this.MDD_ID;
			result.OPGRP_ID = this.OPGRP_ID;
			result.INIT_RCVRY_AMT = this.INIT_RCVRY_AMT;
			result.OFFSET_RCVRY_AMT = this.OFFSET_RCVRY_AMT;
			result.RCVRY_REV_IND = this.RCVRY_REV_IND;
			result.PMT_TRANS_ID = this.PMT_TRANS_ID;
			result.CONSUMED_RCVRY_AMT = this.CONSUMED_RCVRY_AMT;
			result.RCVRY_CD = this.RCVRY_CD;
			result.ORIG_OP_AMT = this.ORIG_OP_AMT;
			result.ADJRQC_CD = this.ADJRQC_CD;
			result.SIBLING_AMT = this.SIBLING_AMT;
			result.DECISION_DT = this.DECISION_DT;
			result.PROCESS_STATE = this.PROCESS_STATE;
			result.REQ_ISS_ID = this.REQ_ISS_ID;
			result.PENALTY_CD = this.PENALTY_CD;
			result.PRIORITY = this.PRIORITY;
			result.PENALTY_AMT = this.PENALTY_AMT;
			result.WAIVE_AMT = this.WAIVE_AMT;
			result.SETUP_BAL = this.SETUP_BAL;
			result.ESTABLISH_DT = this.ESTABLISH_DT;
			result.MODIFIED_BY = this.MODIFIED_BY;
			result.CREATED_BY = this.CREATED_BY;
			result.STATE_CD = this.STATE_CD;
			result.RCVRY_ID = this.RCVRY_ID;
			result.CC_BWE_DT = this.CC_BWE_DT;
			result.ADJREQ_ID = this.ADJREQ_ID;
			result.OPCSE_CD = this.OPCSE_CD;
			result.OPSRC_CD = this.OPSRC_CD;
			result.PRTY_ID = this.PRTY_ID;
			result.OPTRANS_CD = this.OPTRANS_CD;
			result.OPTRANS_ID = this.OPTRANS_ID;
			result.CANCEL_OP_BAL_AMT = this.CANCEL_OP_BAL_AMT;
			result.COMMENTS = this.COMMENTS;
			result.PMT_PROG_CD = this.PMT_PROG_CD;
			result.OFFSET_REDUCTION_AMT = this.OFFSET_REDUCTION_AMT;
			result.CASH_RCVRY_AMT = this.CASH_RCVRY_AMT;
			result.OP_PROG_CD = this.OP_PROG_CD;
			result.RCVRY_PRIORITY = this.RCVRY_PRIORITY;
			result.AVAIL_RCVRY_AMT = this.AVAIL_RCVRY_AMT;
			result.MANUAL_TRANS_IND = this.MANUAL_TRANS_IND;
			result.MANUAL_SPLIT_IND = this.MANUAL_SPLIT_IND;
			result.SIBLING_PRIORITY = this.SIBLING_PRIORITY;
			result.FRAUD_PARENT_OPTRANS_ID = this.FRAUD_PARENT_OPTRANS_ID;
			result.SPLIT_IND = this.SPLIT_IND;
			result.FRAUD_AMT = this.FRAUD_AMT;
			result.CHARGE_OFF_AMT = this.CHARGE_OFF_AMT;
			result.PARENT_SETUP_OPTRANS_ID = this.PARENT_SETUP_OPTRANS_ID;
			result.OPTYP_CD = this.OPTYP_CD;
			return this;
		}

		public override bool Validate(Action<string> errorHandler = null)
		{
			return base.Validate(errorHandler);
		}

		public string ToStringVerbose()
		{
			return new StringBuilder()
				.Append("CUBS_OWNER.OP_TRANSACTIONS")
				.Append(" { ")
				.Append("MODIFIED_DT")
				.Append(" = ")
				.Append(this.MODIFIED_DT.ToString())
				.Append("; ")
				.Append("CREATED_DT")
				.Append(" = ")
				.Append(this.CREATED_DT.ToString())
				.Append("; ")
				.Append("REV_IND")
				.Append(" = ")
				.Append(this.REV_IND.ToString())
				.Append("; ")
				.Append("AMT")
				.Append(" = ")
				.Append(this.AMT.ToString())
				.Append("; ")
				.Append("ISS_ID")
				.Append(" = ")
				.Append(this.ISS_ID.ToString())
				.Append("; ")
				.Append("RSPAGT_CD")
				.Append(" = ")
				.Append(this.RSPAGT_CD.ToString())
				.Append("; ")
				.Append("OPCLS_CD")
				.Append(" = ")
				.Append(this.OPCLS_CD.ToString())
				.Append("; ")
				.Append("CLM_ID")
				.Append(" = ")
				.Append(this.CLM_ID.ToString())
				.Append("; ")
				.Append("PARENT_OPTRANS_ID")
				.Append(" = ")
				.Append(this.PARENT_OPTRANS_ID.ToString())
				.Append("; ")
				.Append("PARENT_OPGRP_ID")
				.Append(" = ")
				.Append(this.PARENT_OPGRP_ID.ToString())
				.Append("; ")
				.Append("WO_IND")
				.Append(" = ")
				.Append(this.WO_IND.ToString())
				.Append("; ")
				.Append("MDD_ID")
				.Append(" = ")
				.Append(this.MDD_ID.ToString())
				.Append("; ")
				.Append("OPGRP_ID")
				.Append(" = ")
				.Append(this.OPGRP_ID.ToString())
				.Append("; ")
				.Append("INIT_RCVRY_AMT")
				.Append(" = ")
				.Append(this.INIT_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("OFFSET_RCVRY_AMT")
				.Append(" = ")
				.Append(this.OFFSET_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("RCVRY_REV_IND")
				.Append(" = ")
				.Append(this.RCVRY_REV_IND.ToString())
				.Append("; ")
				.Append("PMT_TRANS_ID")
				.Append(" = ")
				.Append(this.PMT_TRANS_ID.ToString())
				.Append("; ")
				.Append("CONSUMED_RCVRY_AMT")
				.Append(" = ")
				.Append(this.CONSUMED_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("RCVRY_CD")
				.Append(" = ")
				.Append(this.RCVRY_CD.ToString())
				.Append("; ")
				.Append("ORIG_OP_AMT")
				.Append(" = ")
				.Append(this.ORIG_OP_AMT.ToString())
				.Append("; ")
				.Append("ADJRQC_CD")
				.Append(" = ")
				.Append(this.ADJRQC_CD.ToString())
				.Append("; ")
				.Append("SIBLING_AMT")
				.Append(" = ")
				.Append(this.SIBLING_AMT.ToString())
				.Append("; ")
				.Append("DECISION_DT")
				.Append(" = ")
				.Append(this.DECISION_DT.ToString())
				.Append("; ")
				.Append("PROCESS_STATE")
				.Append(" = ")
				.Append(this.PROCESS_STATE.ToString())
				.Append("; ")
				.Append("REQ_ISS_ID")
				.Append(" = ")
				.Append(this.REQ_ISS_ID.ToString())
				.Append("; ")
				.Append("PENALTY_CD")
				.Append(" = ")
				.Append(this.PENALTY_CD.ToString())
				.Append("; ")
				.Append("PRIORITY")
				.Append(" = ")
				.Append(this.PRIORITY.ToString())
				.Append("; ")
				.Append("PENALTY_AMT")
				.Append(" = ")
				.Append(this.PENALTY_AMT.ToString())
				.Append("; ")
				.Append("WAIVE_AMT")
				.Append(" = ")
				.Append(this.WAIVE_AMT.ToString())
				.Append("; ")
				.Append("SETUP_BAL")
				.Append(" = ")
				.Append(this.SETUP_BAL.ToString())
				.Append("; ")
				.Append("ESTABLISH_DT")
				.Append(" = ")
				.Append(this.ESTABLISH_DT.ToString())
				.Append("; ")
				.Append("MODIFIED_BY")
				.Append(" = ")
				.Append(this.MODIFIED_BY.ToString())
				.Append("; ")
				.Append("CREATED_BY")
				.Append(" = ")
				.Append(this.CREATED_BY.ToString())
				.Append("; ")
				.Append("STATE_CD")
				.Append(" = ")
				.Append(this.STATE_CD.ToString())
				.Append("; ")
				.Append("RCVRY_ID")
				.Append(" = ")
				.Append(this.RCVRY_ID.ToString())
				.Append("; ")
				.Append("CC_BWE_DT")
				.Append(" = ")
				.Append(this.CC_BWE_DT.ToString())
				.Append("; ")
				.Append("ADJREQ_ID")
				.Append(" = ")
				.Append(this.ADJREQ_ID.ToString())
				.Append("; ")
				.Append("OPCSE_CD")
				.Append(" = ")
				.Append(this.OPCSE_CD.ToString())
				.Append("; ")
				.Append("OPSRC_CD")
				.Append(" = ")
				.Append(this.OPSRC_CD.ToString())
				.Append("; ")
				.Append("PRTY_ID")
				.Append(" = ")
				.Append(this.PRTY_ID.ToString())
				.Append("; ")
				.Append("OPTRANS_CD")
				.Append(" = ")
				.Append(this.OPTRANS_CD.ToString())
				.Append("; ")
				.Append("OPTRANS_ID")
				.Append(" = ")
				.Append(this.OPTRANS_ID.ToString())
				.Append("; ")
				.Append("CANCEL_OP_BAL_AMT")
				.Append(" = ")
				.Append(this.CANCEL_OP_BAL_AMT.ToString())
				.Append("; ")
				.Append("COMMENTS")
				.Append(" = ")
				.Append(this.COMMENTS.ToString())
				.Append("; ")
				.Append("PMT_PROG_CD")
				.Append(" = ")
				.Append(this.PMT_PROG_CD.ToString())
				.Append("; ")
				.Append("OFFSET_REDUCTION_AMT")
				.Append(" = ")
				.Append(this.OFFSET_REDUCTION_AMT.ToString())
				.Append("; ")
				.Append("CASH_RCVRY_AMT")
				.Append(" = ")
				.Append(this.CASH_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("OP_PROG_CD")
				.Append(" = ")
				.Append(this.OP_PROG_CD.ToString())
				.Append("; ")
				.Append("RCVRY_PRIORITY")
				.Append(" = ")
				.Append(this.RCVRY_PRIORITY.ToString())
				.Append("; ")
				.Append("AVAIL_RCVRY_AMT")
				.Append(" = ")
				.Append(this.AVAIL_RCVRY_AMT.ToString())
				.Append("; ")
				.Append("MANUAL_TRANS_IND")
				.Append(" = ")
				.Append(this.MANUAL_TRANS_IND.ToString())
				.Append("; ")
				.Append("MANUAL_SPLIT_IND")
				.Append(" = ")
				.Append(this.MANUAL_SPLIT_IND.ToString())
				.Append("; ")
				.Append("SIBLING_PRIORITY")
				.Append(" = ")
				.Append(this.SIBLING_PRIORITY.ToString())
				.Append("; ")
				.Append("FRAUD_PARENT_OPTRANS_ID")
				.Append(" = ")
				.Append(this.FRAUD_PARENT_OPTRANS_ID.ToString())
				.Append("; ")
				.Append("SPLIT_IND")
				.Append(" = ")
				.Append(this.SPLIT_IND.ToString())
				.Append("; ")
				.Append("FRAUD_AMT")
				.Append(" = ")
				.Append(this.FRAUD_AMT.ToString())
				.Append("; ")
				.Append("CHARGE_OFF_AMT")
				.Append(" = ")
				.Append(this.CHARGE_OFF_AMT.ToString())
				.Append("; ")
				.Append("PARENT_SETUP_OPTRANS_ID")
				.Append(" = ")
				.Append(this.PARENT_SETUP_OPTRANS_ID.ToString())
				.Append("; ")
				.Append("OPTYP_CD")
				.Append(" = ")
				.Append(this.OPTYP_CD.ToString())
				.Append("; ")
				.Append("}")
				.ToString();
		}
		#endregion
	}
}

