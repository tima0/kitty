using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Models
{
	public class AddressModel
	{
		public long PartyId { get; set; }
		public long AddressId { get; set; }
		public string Address1 { get; set; }
		public string Address2 { get; set; }
		public string City { get; set; }
		public string State { get; set; }
		public string Zip { get; set; }
		public string BadAddressFlag { get; set; }
		public string AddressCleansedCd { get; set; }
    }

	public static class AddressModelExtensions
	{
		public static AddressModel LoadFromVAddress(this AddressModel addressModel, V_CLAIMANT_ADDRESS vaddress)
		{
			addressModel.PartyId = vaddress.PRTY_ID;
			addressModel.AddressId = vaddress.CADR_ID;
			addressModel.Address1 = vaddress.ADDRESS1;
			addressModel.Address2 = vaddress.ADDRESS2;
			addressModel.City = vaddress.CITY;
			addressModel.State = vaddress.STATE;
			addressModel.Zip = vaddress.ZIP;
			addressModel.BadAddressFlag = vaddress.BAD_ADDRESS_FLAG;
			addressModel.AddressCleansedCd = vaddress.ADDRESS_CLEANSED_CD;

			return addressModel;
		}
	}
}
