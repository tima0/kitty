using Cats.Bop.Claimant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Models
{
		public class NotesDataModel
		{
			public long BopNoteId { get; set; }
			public string BopNoteSourceCd { get; set; }
			public long? BopProsecutionId { get; set; }
			public long? BopGarnishmentId { get; set; }
			public long PrtyId { get; set; }
			public string ContactName { get; set; }
			public string ContactTitle { get; set; }
			public string ContactPhone { get; set; }
			public string ContactExt { get; set; }
			public string Descr { get; set; }
			public string Note { get; set; }
			public string MachineName { get; set; }
			public long CreatedBy { get; set; }
			public DateTime CreateTs { get; set; }
			public long? ModifiedBy { get; set; }
			public DateTime? ModifiedTs { get; set; }
			public string ImageId { get; set; }
			public long? LettersLetterId { get; set; }
		}

	public static class NotesModelExtensions
	{
		public static NotesDataModel LoadDMFromNote(this NotesDataModel notesDataModel, NOTE note)
		{
			notesDataModel.BopNoteId = note.NOTE_ID;
			notesDataModel.BopNoteSourceCd = note.NOTE_SOURCE_CD;
			notesDataModel.BopProsecutionId = note.PROSECUTION_ID;
			notesDataModel.BopGarnishmentId = note.GARNISHMENT_ID;
			notesDataModel.PrtyId = note.PRTY_ID;
			notesDataModel.ContactName = note.CONTACT_NAME;
			notesDataModel.ContactTitle = note.CONTACT_TITLE;
			notesDataModel.ContactPhone = note.CONTACT_PHONE;
			notesDataModel.ContactExt = note.CONTACT_EXT;
			notesDataModel.Descr = note.DESCRIPTION;
			notesDataModel.Note = note.NOTE_CONTENT;
			notesDataModel.MachineName = note.MACHINE_NAME;
			notesDataModel.CreatedBy = note.CREATED_BY;
			notesDataModel.CreateTs = note.CREATED_TS;
			notesDataModel.ModifiedBy = note.MODIFIED_BY;
			notesDataModel.ModifiedTs = note.MODIFIED_TS;
			notesDataModel.ImageId = note.IMAGEID;
			notesDataModel.LettersLetterId = note.LETTERS_LETTER_ID;

			return notesDataModel;
		}
	}
}
