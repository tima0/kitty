using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Data.Models
{
	public class ClaimantModel
	{
		public long PartyId { get; set; }
		public string PID { get; set; }
		public string SSN { get; set; }
		public long? CliId { get; set; }
		public string FirstName { get; set; }
		public string MiddleName { get; set; }
		public string LastName { get; set; }
		public string Email { get; set; }
		public string BadEmailFlag { get; set; }  // 1 byte / 1 char
		public DateTime BirthDate { get; set; }
		public string DriversLicenseNumber { get; set; }
		public string MothersMaidenName { get; set; }
		public bool WriteOffIndicator { get; set; } // number, 0 or 1
	}

	public static class ClaimantModelExtensions
	{
		public static IEnumerable<ClaimantModel> ToClaimants(this IEnumerable<V_CLAIMANT> parties)
		{
			return parties.Select(p => p.ToClaimant());
		}

		public static ClaimantModel ToClaimant(this V_CLAIMANT party)
		{
			return new ClaimantModel().LoadFromVClaimant(party);
		}
		public static ClaimantModel LoadFromVClaimant(this ClaimantModel claimant, V_CLAIMANT vparties)
		{
			claimant.PartyId = vparties.PRTY_ID;
			claimant.PID = vparties.PID;
			claimant.SSN = vparties.SSN;
			claimant.CliId = vparties.CLI_ID;
			claimant.LastName = vparties.LAST_NAME;
			claimant.FirstName = vparties.FIRST_NAME;
			claimant.MiddleName = vparties.MIDDLE_NAME;
			claimant.Email = vparties.EMAIL;
			claimant.BadEmailFlag = vparties.BAD_EMAIL_FLAG;
			claimant.BirthDate = vparties.BIRTH_DT;
			claimant.DriversLicenseNumber = vparties.DRIVERS_LICENSE_NUMBER;
			claimant.MothersMaidenName = vparties.MOTHERS_MAIDEN_NAME;
			claimant.WriteOffIndicator = vparties.WRITE_OFF_IND != 0;
			return claimant;
		}
	}
}
