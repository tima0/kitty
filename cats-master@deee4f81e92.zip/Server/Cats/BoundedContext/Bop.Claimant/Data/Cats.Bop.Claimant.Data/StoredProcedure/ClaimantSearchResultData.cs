namespace Cats.Bop.Claimant.Data.StoredProcedure
{
	public class ClaimantSearchResultData
	{
		public decimal PARTY_ID { get; set; }
		public string HLCI { get; set; }
		public decimal OPGRP_ID { get; set; }
		public string SSN { get; set; }
		public string FIRST_NAME { get; set; }
		public string MIDDLE_NAME { get; set; }
		public string LAST_NAME { get; set; }
		public decimal? OPS { get; set; }
		public decimal? OPBAL { get; set; }
		public string ADDR1 { get; set; }
		public string ADDR2 { get; set; }
		public string CITY { get; set; }
		public string STATE { get; set; }
		public string ZIP { get; set; }
	}
}
