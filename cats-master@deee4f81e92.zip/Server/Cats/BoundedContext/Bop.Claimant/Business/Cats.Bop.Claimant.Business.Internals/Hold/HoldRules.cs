using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Business.Hold;

namespace Cats.Bop.Claimant.Business.Internals.Hold
{
	public class HoldRules : IHoldRules
	{
		public IEnumerable<CurrentHold> AddInactiveHolds(IEnumerable<CurrentHold> activeHolds, IEnumerable<string> possibleHolds)
		{
			// Find Holds that are currently not set
			IEnumerable<string> missingHoldTypes = possibleHolds
				.Where(ht => !activeHolds.Select(h => h.HoldType).Contains(ht));

			// Take Hold that are set already
			List<CurrentHold> holdList = new List<CurrentHold>(activeHolds);

			// Add Missing Holds
			foreach (string ht in missingHoldTypes)
			{
				holdList.Add(new CurrentHold()
				{
					Active = false,
					HoldType = ht
				});
			}

			return holdList;
		}
	}
}
