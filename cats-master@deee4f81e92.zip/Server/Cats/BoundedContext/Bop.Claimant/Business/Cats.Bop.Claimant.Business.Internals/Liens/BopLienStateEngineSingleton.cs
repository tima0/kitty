using Cats.Core.Liens;
using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Business.Internals.Liens
{
	public class BopLienStateEngineSingleton : LienStateEngineBase
	{
		private static BopLienStateEngineSingleton _instance = null;
		private static readonly object _mutex = new object();

		public BopLienStateEngineSingleton(StateCode initialState, IStateFlowHistory<ActionCode, StateCode, LienData> stateFlowHistory, DateTime processingDate)
			: base(initialState, stateFlowHistory, processingDate)
		{
		}

		public static BopLienStateEngineSingleton Create(StateCode initialState, IStateFlowHistory<ActionCode, StateCode, LienData> stateFlowHistory, DateTime processingDate)
		{
			if (_instance == null)
			{
				lock(_mutex)
				{
					if (_instance == null)
					{
						_instance = new BopLienStateEngineSingleton(initialState, stateFlowHistory, processingDate);
					}
				}
			}
			// always reset the engine
			_instance.ResetState(initialState);
			_instance.StateFlowHistory.FlowHistory.Clear();
			return _instance;
		}
	}
}
