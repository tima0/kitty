using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;

namespace Cats.Bop.Claimant.Business.Internals.Liens.StateFlowRules
{
	public class BopFlowRuleFactory : FlowRuleFactory
	{
		public BopFlowRuleFactory(DateTime processingDate) : base(processingDate)
		{
		}

		protected override IFlowRule<ActionCode, StateCode, LienData> CreateFlowRuleObject(Type flowRuleClass)
		{
			if (flowRuleClass == typeof(FlagStopFlow))
			{
				return new FlagStopFlowFraud(ProcessingDate);
			}
			else if (flowRuleClass == typeof(NoFlagStopFlowFraud))
			{
				return new NoFlagStopFlowFraud(ProcessingDate);
			}
			else
			{
				var result = flowRuleClass.GetConstructor(new Type[] { typeof(DateTime) }).Invoke(new object[] { ProcessingDate });
				return result as IFlowRule<ActionCode, StateCode, LienData>;
			}
		}
	}
}
