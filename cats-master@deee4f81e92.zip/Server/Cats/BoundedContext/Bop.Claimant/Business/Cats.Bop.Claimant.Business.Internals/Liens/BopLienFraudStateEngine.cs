using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using DwsUI.Core.Collections;
using Cats.Bop.Claimant.Business.Internals.Liens.StateFlowRules;

namespace Cats.Bop.Claimant.Business.Internals.Liens
{
	public class BopLienFraudStateEngine : BopLienStateEngineSingleton
	{	
		public BopLienFraudStateEngine(StateCode initialState, IStateFlowHistory<ActionCode, StateCode, LienData> stateFlowHistory,
			DateTime processingDate) : base(initialState, stateFlowHistory, processingDate)
		{
		}

		protected override void InitializeFlows(FlowRuleFactory flowRuleFactory)
		{
			// flow rule factory override
			this._flowRuleFactory = new BopFlowRuleFactory(ProcessingDate);
			base.InitializeFlows(_flowRuleFactory);
			
			// configure or replace state configurations

			ConfigureOrReplace(StateCode.Filed, flowRuleFactory)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.Expired, StateCode.Expired)
				.Flow(ActionCode.Expiring, StateCode.Expiring, new ExpiringCheckFlow(ProcessingDate)) // flow rule override
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw, new CanceledDebtFlow(ProcessingDate)) 
				.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)				
				.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
				.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid)
				.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
				.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy);

			ConfigureOrReplace(StateCode.Expiring, flowRuleFactory)
				.Flow(ActionCode.Filed, StateCode.Filed)
				//.Flow(ActionCode.WillExpire, StateCode.WillExpire)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
				.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy)
				.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw, new CanceledDebtFlow(ProcessingDate)) 
				.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
				.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid)
				.Flow(ActionCode.Expired, StateCode.Expired);

			//ConfigureOrReplace(StateCode.WillExpire, flowRuleFactory)
			//	.Flow(ActionCode.Expired, StateCode.Expired)
			//	.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
			//	.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
			//	.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy)
			//	.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)
			//	.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw, new CanceledDebtFlow(ProcessingDate)) 
			//	.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
			//	.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid);

			ConfigureOrReplace(StateCode.Expired, flowRuleFactory)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.ManualWithdraw, StateCode.ManualWithdraw)
				.Flow(ActionCode.ManualSatisfy, StateCode.ManualSatisfy)
				.Flow(ActionCode.WdrawIfPaid, StateCode.WdrawIfPaid)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.SatCertPaid, StateCode.SatCertPaid)
				.Flow(ActionCode.SatNonCertPaid, StateCode.SatNonCertPaid)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw, new CanceledDebtFlow(ProcessingDate)); 

			ConfigureOrReplace(StateCode.ARIncrease, flowRuleFactory)
				.Flow(ActionCode.ManualAmend, StateCode.ManualAmend)
				.Flow(ActionCode.Filed, StateCode.Filed)
				.Flow(ActionCode.ReqWithdraw, StateCode.ReqWithdraw, new CanceledDebtFlow(ProcessingDate)); 
		}
	}
}
