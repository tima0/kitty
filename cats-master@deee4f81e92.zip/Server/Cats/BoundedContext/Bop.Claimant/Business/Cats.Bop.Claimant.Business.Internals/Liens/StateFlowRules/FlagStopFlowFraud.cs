using Cats.Core.Liens;
using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Business.Internals.Liens.StateFlowRules
{
	public sealed class FlagStopFlowFraud : FlowRuleBase
	{
		public FlagStopFlowFraud(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			var data = transitionInfo.Data;
			return !(transitionInfo.Data.HasAdminHold || transitionInfo.Data.HasAppealHold || transitionInfo.Data.HasBankruptcy);
		}

		protected override string GetFlowReason(LienData data)
		{
			var reason = string.Empty;
			if (data.HasAdminHold)
			{
				reason += "Admin Hold";
			}

			if (data.HasAppealHold)
			{
				reason += "Appeal Hold";
			}

			if (data.HasBankruptcy)
			{
				reason += "Bankruptcy Hold";
			}

			if (data.HasInstallmentAgreement)
			{
				reason += "Installment Agreement";
			}
			return reason;
		}
	}
}
