using Cats.Bop.Claimant.Business.Liens;
using Cats.Core.Liens;
using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Business.Internals.Liens
{
	public class BopLienStateEngineService : IBopLienStateEngineServiceInterface
	{
		private readonly IStateFlowHistory<ActionCode, StateCode, LienData> _stateFlowHistory;

		public BopLienStateEngineService(IStateFlowHistory<ActionCode, StateCode, LienData> stateFlowHistory)
		{
			_stateFlowHistory = stateFlowHistory;
		}

		private LienStateEngineBase GetLienEngine(StateCode initialState, BopLienType bopLienType, DateTime dateRun)
		{
			if (bopLienType == BopLienType.Fault)
			{
				return BopLienFaultStateEngine.Create(initialState, _stateFlowHistory, dateRun);
			}
			else if (bopLienType == BopLienType.Fraud)
			{
				return BopLienFraudStateEngine.Create(initialState, _stateFlowHistory, dateRun);
			}
			else
				return null;
		}

		public void ExecuteFlow(LienData lienData, BopLienType bopLienType, DateTime dateRun)
		{
			LienStateEngineBase stateEngine = GetLienEngine(lienData.PreviousStateCode, bopLienType, dateRun);					
			stateEngine?.ExecuteFlow(lienData);			
		}

		public void ExecuteFlow(LienData lienData, BopLienType bopLienType, ActionCode actionCode, DateTime dateRun)
		{
			LienStateEngineBase stateEngine = GetLienEngine(lienData.PreviousStateCode, bopLienType, dateRun);
			stateEngine?.ExecuteFlow(actionCode, lienData);
		}
	}
}
