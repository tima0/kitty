using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;
using DwsUI.Core.Collections;

namespace Cats.Bop.Claimant.Business.Internals.Liens.StateFlowRules
{
	public sealed class NoFlagStopFlowFraud : FlowRuleBase
	{
		public NoFlagStopFlowFraud(DateTime processingDate) : base(processingDate)
		{
		}

		protected override bool GetCanFlow(FlowTransitionInfo<ActionCode, StateCode, LienData> transitionInfo)
		{
			return !(transitionInfo.Data.HasAdminHold || transitionInfo.Data.HasAppealHold || transitionInfo.Data.HasBankruptcy);
		}
	}
}
