using Cats.Bop.Claimant.Business.Internals.Liens;
using Cats.Core.Liens;
using DwsUI.Core.Collections;
using System;
using Xunit;
using Shouldly;
using System.Linq;
using Cats.Bop.Claimant.Business.Internals.Liens.StateFlowRules;

namespace Cats.Bop.Claimant.Business.Internals.Tests.Liens
{
    public class BopLienFaultStateEngineTest : LienStateEngineBaseTest
	{
		[Fact]
		public void CanceledDebtFlowTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Filed);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.Filed, StateCode.ReqWithdraw);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Expiring);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.Expiring, StateCode.ReqWithdraw);
		}

		[Fact]
		public void WillExpireTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-3000), 4000, StateCode.Filed);
			lien.FiledDate = DateTime.Now.AddYears(-8).AddDays(55);
			PerformTests(lien, ActionCode.Filed, StateCode.Expiring);
		}

		[Fact]
		public void AfterFiledPaidCertFundsTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Filed);
			lien.LastNonCertPmtDate = null;
			lien.LastCertPmtDate = DateTime.Now;
			PerformTests(lien, ActionCode.Filed, StateCode.SatCertPaid);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Expiring);
			lien.LastNonCertPmtDate = null;
			lien.LastCertPmtDate = DateTime.Now;
			PerformTests(lien, ActionCode.Expiring, StateCode.SatCertPaid);
		}

		[Fact]
		public void AfterFiledPaidNonCertFundsTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Filed);
			lien.LastNonCertPmtDate = DateTime.Now;
			lien.LastCertPmtDate = null;
			PerformTests(lien, ActionCode.Filed, StateCode.SatNonCertPaid);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Expiring);
			lien.LastNonCertPmtDate = DateTime.Now;
			lien.LastCertPmtDate = null;
			PerformTests(lien, ActionCode.Expiring, StateCode.SatNonCertPaid);			
		}

		[Fact]
		public void WaitNonCertFundsTest()
		{
			var processedDate = new DateTime(2012, 12, 5);
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 2);
			lien.LastLienActionDate = new DateTime(2012, 12, 3);
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy, processedDate);
		}

		[Fact]
		public void WaitCertFundsTest()
		{
			//LastLIenACtionDate is the day after the pmt is made.
			var processingDate = new DateTime(2012, 12, 5); // Wed
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 2); //  Monday
			lien.LastLienActionDate = new DateTime(2012, 12, 3); //  Monday
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy, processingDate);

			processingDate = new DateTime(2012, 12, 6); // Thursday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 3);
			lien.LastLienActionDate = new DateTime(2012, 12, 4); // Tuesday
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy, processingDate);

			processingDate = new DateTime(2012, 12, 7); // a friday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 4); // wed
			lien.LastLienActionDate = new DateTime(2012, 12, 5); // wed
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy, processingDate);

			processingDate = new DateTime(2012, 12, 10); // monday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 5);
			lien.LastLienActionDate = new DateTime(2012, 12, 6); // thursday
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy, processingDate);

			processingDate = new DateTime(2012, 12, 11); // tuesday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 6);
			lien.LastLienActionDate = new DateTime(2012, 12, 7); // friday
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy, processingDate);

		}

		[Fact]
		public void MoreWaitCertFundsTest()
		{
			var processingDate = new DateTime(2012, 12, 4); // wed
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 2);
			lien.LastLienActionDate = new DateTime(2012, 12, 3); // monday
			lien.HasAdminHold = true;
			var engine = CreateBopLienFaultStateEngine(StateCode.SatCertPaid, processingDate);
			engine.ExecuteFlow(lien);
			engine.State.ShouldBe(StateCode.SatCertPaid); // no state change expected

			processingDate = new DateTime(2012, 12, 5); // thursday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 3);
			lien.LastLienActionDate = new DateTime(2012, 12, 4); // tuesday
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move
			engine = CreateBopLienFaultStateEngine(StateCode.SatCertPaid, processingDate);
			engine.ExecuteFlow(lien);
			engine.State.ShouldBe(StateCode.SatCertPaid); // no state change expected

			processingDate = new DateTime(2012, 12, 6); // friday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 4);
			lien.LastLienActionDate = new DateTime(2012, 12, 5); // wed
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move
			engine = CreateBopLienFaultStateEngine(StateCode.SatCertPaid, processingDate);
			engine.ExecuteFlow(lien);
			engine.State.ShouldBe(StateCode.SatCertPaid); // no state change expected

			processingDate = new DateTime(2012, 12, 9); // monday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 5);
			lien.LastLienActionDate = new DateTime(2012, 12, 6); // thursday
			lien.HasAdminHold = true; // Regardless of Holds if paid it should move
			engine = CreateBopLienFaultStateEngine(StateCode.SatCertPaid, processingDate);
			engine.ExecuteFlow(lien);
			engine.State.ShouldBe(StateCode.SatCertPaid); // no state change expected

			processingDate = new DateTime(2012, 12, 10); // tuesday
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 6);
			lien.LastLienActionDate = new DateTime(2012, 12, 7); // friday			
			engine = CreateBopLienFaultStateEngine(StateCode.SatCertPaid, processingDate);
			engine.ExecuteFlow(lien);
			engine.State.ShouldBe(StateCode.SatCertPaid); // no state change expected

			processingDate = new DateTime(2012, 12, 25); // tuesday (christmas)
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 20);
			lien.LastLienActionDate = new DateTime(2012, 12, 21); // friday before			
			engine = CreateBopLienFaultStateEngine(StateCode.SatCertPaid, processingDate);
			engine.ExecuteFlow(lien);
			engine.State.ShouldBe(StateCode.SatCertPaid); // no state change expected

			processingDate = new DateTime(2012, 12, 26); // wed, day after christmas
			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 20);
			lien.LastLienActionDate = new DateTime(2012, 12, 21); // friday before			
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy);
		}

		[Fact]
		public void WaitCertFundsHolidayTest()
		{
			var processingDate = new DateTime(2012, 12, 26); // wed, day after xmas
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SatCertPaid);
			lien.LastCertPmtDate = new DateTime(2012, 12, 20);
			lien.LastLienActionDate = new DateTime(2012, 12, 21); // friday before
			PerformTests(lien, ActionCode.SatCertPaid, StateCode.ReqToSatisfy);
		}

		[Fact]
		public void MoreCanceledDebtFlowTest()
		{
			var lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Need28);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.Need28, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.AR28Hold);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.AR28Hold, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode._28PrintHold);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode._28PrintHold, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode._28Printed);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode._28Printed, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Wait10day);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.Wait10day, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode._10DayHold);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode._10DayHold, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.Need10day);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.Need10day, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode._10DayPrinted);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode._10DayPrinted, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.WaitToFile);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.WaitToFile, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.WaitToFileHold);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.WaitToFileHold, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.SentToFile);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.SentToFile, StateCode.DoNotFile);

			lien = CreateLienData(DateTime.Now.AddDays(-100), 0, StateCode.FileReject);
			lien.CanceledDebt = true;
			PerformTests(lien, ActionCode.FileReject, StateCode.DoNotFile);
		}

		protected void PerformTests(LienData lienData, ActionCode sourceAction, StateCode expectedState, DateTime? processedDate = null)
		{
			var _stateEngine = CreateBopLienFaultStateEngine(lienData.PreviousStateCode, processedDate ?? DateTime.Now);

			_stateEngine.ExecuteFlow(lienData);
			_stateEngine.State.ShouldBe(expectedState);

			lienData.LastLienAction.ShouldBe(expectedState);
			lienData.LastLienActionDate.Value.Date.ShouldBe(_stateEngine.ProcessingDate.Date);

			_stateEngine.StateFlowHistory.FlowHistory.Count.ShouldBeGreaterThan(0);
			if (_stateEngine.StateFlowHistory.FlowHistory.Count > 0)
			{
				var lastFlow = _stateEngine.StateFlowHistory.FlowHistory.Last();
				StateFlowHistoryItem<ActionCode, StateCode, LienData> historyItem = lastFlow.Value;

				historyItem.TransititionInfo.DestinationState.ShouldBe(expectedState);
			}
		}

		protected BopLienFaultStateEngine CreateBopLienFaultStateEngine(StateCode initialState, DateTime? processedDate = null)
		{			
			var processingDate = processedDate ?? DateTime.Now;
			var stateFlowHistory = new StateFlowHistory<ActionCode, StateCode, LienData>();
			var _stateEngine = new BopLienFaultStateEngine(initialState, stateFlowHistory, processingDate);			
			return _stateEngine;

		}
	}
}
