using Cats.Core.Liens;
using DwsUI.Core.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;

namespace Cats.Bop.Claimant.Business.Internals.Tests.Liens.StateFlowRules
{
    public class StateFlowRuleTests
    {
        public LienData CreateLienData(DateTime establishedDate, decimal arBalance, StateCode currentState)
		{
			var result = new LienData { LienID = 1, ArEstablishedDate = establishedDate, ArBalance = arBalance, LastLienAction = currentState};
			return result;
		}

		public FlowTransitionInfo<ActionCode, StateCode, LienData> CreateFlowTransitionInfo(StateCode sourceState, StateCode destinationState, ActionCode actionCode, LienData data)
		{
			return new FlowTransitionInfo<ActionCode, StateCode, LienData>(sourceState, destinationState, actionCode, data);
		}

		// Source state, destination state and action code parameters
		// only matters when your flow rule class uses it to make a flow decision
		// data is most of the time that is used to make a flow decision
		public FlowTransitionInfo<ActionCode, StateCode, LienData> CreateFlowTransitionInfo(LienData lienData)
		{
			return new FlowTransitionInfo<ActionCode, StateCode, LienData>(StateCode.AR, StateCode.AR28Hold, ActionCode.ARIncrease, lienData);
		}

		public Mock<LienStateEngineBase> MockLienStateEngine()
		{
			var lienEngine = new Mock<LienStateEngineBase>(StateCode.AR, null, DateTime.Now);			
			return lienEngine;
		}
	}
}
