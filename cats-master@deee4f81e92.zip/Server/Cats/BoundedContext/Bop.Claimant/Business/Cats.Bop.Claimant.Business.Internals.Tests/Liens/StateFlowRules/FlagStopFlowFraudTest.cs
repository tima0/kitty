using System;
using Xunit;
using Moq;
using Shouldly;
using Cats.Core.Liens.StateFlowRules;
using Cats.Core.Liens;
using Cats.Bop.Claimant.Business.Internals.Liens.StateFlowRules;

namespace Cats.Bop.Claimant.Business.Internals.Tests.Liens.StateFlowRules
{
	public class FlagStopFlowFraudTest : StateFlowRuleTests
	{
		[Fact]
		public void CanFlowTest_ReturnTrue()
		{
			// HasAdminHold || HasAppealHold || HasBankruptcy
			var lien = new Mock<LienData>().Object;
			lien.HasAdminHold = true;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = false;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.ARPaid, lien);
			var flowRule = new FlagStopFlowFraud(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);

			lien.HasAdminHold = false;
			lien.HasAppealHold = true;
			lien.HasBankruptcy = false;
			result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);

			lien.HasAdminHold = false;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = true;
			result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);

			lien.HasAdminHold = true;
			lien.HasAppealHold = true;
			lien.HasBankruptcy = true;
			result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);

			lien.HasAdminHold = false;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = false;
			result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			// not (HasAdminHold || HasAppealHold || HasBankruptcy)
			var lien = new Mock<LienData>().Object;
			lien.HasAdminHold = false;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = false;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.ARPaid, lien);
			var flowRule = new FlagStopFlowFraud(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}
	}
}

