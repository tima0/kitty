using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Cats.Core.Liens;
using Shouldly;
using DwsUI.Core.Collections;
using Cats.Bop.Claimant.Business.Internals.Liens;

namespace Cats.Bop.Claimant.Business.Internals.Tests.Liens
{
    public class LienStateEngineBaseTest
    {
		protected LienData CreateLienData(DateTime establishedDate, decimal arBalance, StateCode currentState)
		{
			var lienData = new LienData
			{
				ArEstablishedDate = establishedDate,
				ArBalance = arBalance,
				LastLienAction = currentState,
				LastLienActionDate = DateTime.Now,
				PreviousStateCode = currentState
			};
			return lienData;
		}
	}
}
