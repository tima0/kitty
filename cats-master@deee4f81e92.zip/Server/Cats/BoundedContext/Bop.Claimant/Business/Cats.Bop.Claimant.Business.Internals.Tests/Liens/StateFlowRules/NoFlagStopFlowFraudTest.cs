using System;
using Xunit;
using Moq;
using Cats.Core.Liens;
using Cats.Core.Liens.StateFlowRules;
using Shouldly;
using DwsUI.Core.Collections;
using Cats.Bop.Claimant.Business.Internals.Liens.StateFlowRules;

namespace Cats.Bop.Claimant.Business.Internals.Tests.Liens.StateFlowRules
{
    public class NoFlagStopFlowFraudTest : StateFlowRuleTests
    {
		[Fact]
        public void CanFlowTest_ReturnTrue()
		{
			// not (HasAdminHold || HasAppealHold || HasBankruptcy)
			var lien = new Mock<LienData>().Object;
			lien.HasAdminHold = false;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = false;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new NoFlagStopFlowFraud(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(true);
		}

		[Fact]
		public void CanFlowTest_ReturnFalse()
		{
			var lien = new Mock<LienData>().Object;
			lien.HasAdminHold = true;
			lien.HasAppealHold = false;
			lien.HasBankruptcy = false;

			var transitionInfo = this.CreateFlowTransitionInfo(StateCode.AR, StateCode.AR28Hold, ActionCode.AR28Hold, lien);
			var flowRule = new NoFlagStopFlowFraud(DateTime.Now);
			var result = flowRule.CanFlow(transitionInfo);
			result.ShouldBe(false);
		}
	}
}
