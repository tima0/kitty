using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using Cats.Bop.Claimant.Business.Internals.Hold;
using Cats.Bop.Claimant.Business.Hold;

namespace Cats.Bop.Claimant.Business.Internals.Tests.Hold
{
	public class HoldRulesTests
	{
		[Fact]
		public void AddInactiveHoldsTest()
		{
			// Arrange
			HoldRules holdRules = new HoldRules();
			string[] possibleHolds = { "A", "B", "C" };
			List<CurrentHold> activeHolds = new List<CurrentHold>
			{
				new CurrentHold()
				{
					Active = true,
					HoldType = "A"
				}
			};

			// public IEnumerable<CurrentHold> AddInactiveHolds(IEnumerable<CurrentHold> activeHolds, IEnumerable<string> possibleHolds)
			// Act
			IEnumerable<CurrentHold> completeList = holdRules.AddInactiveHolds(activeHolds, possibleHolds);

			// Assert
			completeList.Count().ShouldBe(3);
			completeList.SingleOrDefault(h => h.HoldType == "A").Active.ShouldBeTrue();
			completeList.SingleOrDefault(h => h.HoldType == "B").Active.ShouldBeFalse();
			completeList.SingleOrDefault(h => h.HoldType == "C").Active.ShouldBeFalse();
		}
	}
}
