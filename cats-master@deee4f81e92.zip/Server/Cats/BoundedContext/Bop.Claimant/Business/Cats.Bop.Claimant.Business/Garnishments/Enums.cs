using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Business.Garnishments
{
	public enum StateCode
	{
		AcceptedByCourt,
		AttorneyApproval,
		AttorneyDisapproval,
		BackToAttorney,
		BackToWaiting,
		Bankruptcy,
		ClosingAnotherCreditor,
		CollectorResolvedEFLEXProblem,
		CollectorResolvesIssue,
		CourtApproval,
		CourtDisapproval,
		CourtDisapprovalNotResolved,
		CourtHearingDone,
		CreditBalance,
		DiscretionaryStop,
		DissapprovalCouldNotBeResolved,
		FirstPaymentMissed,
		ManualWritReturned,
		NoFirstInterrogatory,
		NoMoneyGarnishment,
		OPPaidInFull,
		PacketPrinted,
		PacketServed,
		PaymentMissed,
		PaymentsBeingReceived,
		Prosecution,
		ReadyToBePrinted,
		ReadyToRelease,
		ReadyForEFLEX,
		ReadyToPrint,
		ReducedGarnishment,
		RejectedByCourt,
		ReleaseSentToCourt,
		ReleaseToCourt,
		Released,
		ReleasedToPrint,
		RequestGarnCheck,
		SentToCourt,
		ServiceProblem,
		ServiceProblemNotResolved,
		Terminated,
		ToAttorneyForReview,
		ToProcessServer,
		UnableToVerifyProceedAnyway,
		UncooperativeEmployer,
		UtahDistrictCourtHearing,
		VerificationFailedNotEmployed,
		VerificationInProgress,
		VerificationNotStarted,
		VerificationProblemAnotherCreditor,
		VerifiedEmployment,
		Waiting,
		WaitingOnOtherCreditor,
		WaitingOnOtherCreditorAttReview,
		WritReturnedFromCourt,
		WritNotReturned
	}
}
