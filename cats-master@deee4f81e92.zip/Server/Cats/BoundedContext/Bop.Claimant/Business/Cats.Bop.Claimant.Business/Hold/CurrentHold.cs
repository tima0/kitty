using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Business.Hold
{
	public class CurrentHold
	{
		public bool Active { get; set; }
		public string HoldType { get; set; }
		public string ReasonHoldSet { get; set; }
		public DateTime? DateHoldSet { get; set; }
		public DateTime? DateHoldWillBeRemoved { get; set; }
		public string HoldSetBy { get; set; }
		public string HoldLastChangedBy { get; set; }
	}
}
