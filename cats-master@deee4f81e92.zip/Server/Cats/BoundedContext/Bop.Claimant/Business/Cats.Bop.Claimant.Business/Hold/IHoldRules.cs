using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Business.Hold
{
	public interface IHoldRules
	{
		IEnumerable<CurrentHold> AddInactiveHolds(IEnumerable<CurrentHold> activeHolds, IEnumerable<string> possibleHolds);
	}
}
