using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Core.Liens;

namespace Cats.Bop.Claimant.Business.Liens
{
	public enum BopLienType { Fraud, Fault };

    public interface IBopLienStateEngineServiceInterface
    {
		void ExecuteFlow(LienData lienData, BopLienType bopLienType, DateTime dateRun);
		void ExecuteFlow(LienData lienData, BopLienType bopLienType, ActionCode actionCode, DateTime dateRun);
    }
}
