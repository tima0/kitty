using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Internals.Mappings;
using Cats.Bop.Claimant.Models;
using Cats.Core;
using Cats.Core.Liens;
using DwsUI.Core.Job;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Internals.Batch.Liens
{
	public class LienBOPFraud28Print : IListJob
	{
		public string Name => nameof(LienBOPFraud28Print);
		private readonly ILetterRequest _letterRequest;
		private readonly IBopLienRepository _repository;
		private readonly IBopLienAppService _bopLienAppService;
		private readonly IDateRun _dateRun;

		public LienBOPFraud28Print(ILetterRequest letterRequest, IDateRun dateRun, IBopLienRepository repository, IBopLienAppService bopLienAppService)
		{
			_letterRequest = letterRequest;
			_dateRun = dateRun;
			_bopLienAppService = bopLienAppService;
			_repository = repository;
		}

		public void AbortProcessing()
		{

		}

		public void DoneProcessing()
		{

		}

		public IEnumerable<object> GetRecords()
		{
			return _repository.GetBopLienLetterInfo(BopType.Fraud, StateCode.Need28)
					.Select(x => x.ToAppModel());
		}

		public bool IsFatal(object data, Exception ex)
		{
			return true;
		}

		public int MaxSkippedErrors()
		{
			return 0;
		}

		public void ProcessRecord(object data)
		{
			var bop = (BopLienLetterModel)data;
			var bookmark = new LetterAddressBookmark
			{
				Address1 = bop.Address1,
				Address2 = bop.Address2,
				City = bop.City,
				DbaName = "",
				Country = bop.ForeignCountry ?? "",
				FullName = bop.FirstName + " " + bop.LastName,
				InternationalIndicator = bop.ForeignCountry != "" ? 1 : 0,
				State = bop.ForeignStateOrProvince ?? bop.State,
				Zip = bop.ForeignPostalCode ?? bop.Zip
			};

			//TODO letter engine not available yet
			_letterRequest.Print("Form28B", bookmark);
			var bopLien = _repository.GetBopLiens(bop.LienId).ToAppModel();
			_bopLienAppService.ExecuteLienAction(bopLien, ActionCode._28Printed, _dateRun.RunDate);
		}

		public void StartProcessing()
		{

		}
	}
}
