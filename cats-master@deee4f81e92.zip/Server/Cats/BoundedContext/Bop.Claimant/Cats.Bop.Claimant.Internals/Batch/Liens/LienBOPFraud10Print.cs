using Cats.Core;
using DwsUI.Core.Job;
using System;
using System.Collections.Generic;
using Cats.Bop.Claimant.Models;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Internals.Mappings;
using System.Linq;
using DwsUI.Core.Logging;

namespace Cats.Bop.Claimant.Internals.Batch.Liens
{
	public class LienBOPFraud10Print : IListJob
	{
		public string Name => nameof(LienBOPFraud10Print);
		private readonly IDateRun _dateRun;
		private readonly IBopLienAppService _bopLienAppService;
		private readonly ILetterRequest _letterRequest;
		private readonly IBopLienRepository _repository;
		private readonly ILogger _logger;


		public LienBOPFraud10Print(ILetterRequest letterRequest, IDateRun dateRun, IBopLienRepository repository, IBopLienAppService bopLienAppService, ILogger logger)
		{
			_dateRun = dateRun;
			_bopLienAppService = bopLienAppService;
			_letterRequest = letterRequest;
			_repository = repository;
			_logger = logger;
		}

		public void AbortProcessing()
		{

		}

		public void DoneProcessing()
		{

		}

		public IEnumerable<object> GetRecords()
		{
			return _repository.GetBopLienLetterInfo(BopType.Fraud, Core.Liens.StateCode.Need10day)
					.Select(x => x.ToAppModel());
		}

		public bool IsFatal(object data, Exception ex)
		{
			return true;
		}

		public void ProcessRecord(object data)
		{
			var bop = (BopLienLetterModel)data;
			if (bop.AmountDue == 0)
			{
				_logger.LogError($"On lien {bop.LienId}  Zero Amount Due is not Valid ");
			}
			else
			{
				var bookmark = new LetterAddressBookmark
				{
					Address1 = bop.Address1,
					Address2 = bop.Address2,
					City = bop.City,
					DbaName = "",
					Country = bop.ForeignCountry ?? "",
					FullName = bop.FirstName + " " + bop.LastName,
					InternationalIndicator = bop.ForeignCountry != "" ? 1 : 0,
					State = bop.ForeignStateOrProvince ?? bop.State,
					Zip = bop.ForeignPostalCode ?? bop.Zip
				};
						
				_letterRequest.Print(Name, bookmark);
				var bopLien = _repository.GetBopLiens(bop.LienId).ToAppModel();
			
				_bopLienAppService.ExecuteLienAction(bopLien, Core.Liens.ActionCode._10DayPrinted, _dateRun.RunDate);
			};
		}

		public void StartProcessing()
		{
			
		}

		public int MaxSkippedErrors()
		{
			return 0;
		}
	}
}
