using Cats.Bop.Claimant.Models;
using DwsUI.Core.Job;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Internals.Batch.Liens
{
	public class LienBOPFault : IListJob
	{
		public string Name => nameof(LienBOPFault);
		private readonly IDateRun _dateRun;
		private readonly IBopLienAppService _bopLienAppService;

		public LienBOPFault(IDateRun dateRun, IBopLienAppService bopLienAppService)
		{
			_dateRun = dateRun;
			_bopLienAppService = bopLienAppService;
		}

		public void AbortProcessing()
		{
			
		}

		public void DoneProcessing()
		{
			
		}

		public IEnumerable<object> GetRecords()
		{
			return _bopLienAppService.GetBopLiensFaults();
		}

		public bool IsFatal(object data, Exception ex)
		{
			return true;
		}

		public void ProcessRecord(object data)
		{
			_bopLienAppService.ProcessLien((BopLienModel)data, _dateRun.RunDate);
		}

		public void StartProcessing()
		{
			
		}

		public int MaxSkippedErrors()
		{
			return 0;
		}
	}
}
