using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Models;
using DwsUI.Core.Job;

namespace Cats.Bop.Claimant.Internals.Batch.Liens
{
	public class LienBopFraud : IListJob
	{
		public string Name => nameof(LienBopFraud);
		private readonly IDateRun _dateRun;
		private readonly IBopLienAppService _bopLienAppService;
		public LienBopFraud(IDateRun dateRun, IBopLienAppService bopLienAppService)
		{
			_dateRun = dateRun;
			_bopLienAppService = bopLienAppService;
		}

		public void AbortProcessing()
		{
			
		}

		public void DoneProcessing()
		{
			
		}

		public IEnumerable<object> GetRecords()
		{
			return _bopLienAppService.GetBopLiensFraud();
		}

		public bool IsFatal(object data, Exception ex)
		{
			return true;
		}

		public void ProcessRecord(object data)
		{
			_bopLienAppService.ProcessLien((BopLienModel)data, _dateRun.RunDate);
		}

		void IListJob.StartProcessing()
		{
			
		}

		public int MaxSkippedErrors()
		{
			return 0;
		}
	}
}
