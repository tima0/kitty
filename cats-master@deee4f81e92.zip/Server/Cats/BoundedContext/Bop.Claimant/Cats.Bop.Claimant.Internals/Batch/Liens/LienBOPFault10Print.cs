using Cats.Core;
using DwsUI.Core.Job;
using System;
using System.Collections.Generic;
using Cats.Bop.Claimant.Models;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Internals.Mappings;
using Cats.Core.Liens;
using System.Linq;
using DwsUI.Core.Logging;

namespace Cats.Bop.Claimant.Internals.Batch.Liens
{
	public class LienBOPFault10Print : IListJob
	{
		public string Name => nameof(LienBOPFault10Print);
		private readonly IDateRun _dateRun;
		private readonly IBopLienAppService _bopLienAppService;
		private readonly ILetterRequest _letterRequest;
		private readonly IBopLienRepository _repository;
		private readonly ILogger _logger;

		public LienBOPFault10Print(ILetterRequest letterRequest, IDateRun dateRun, IBopLienRepository repository,
			IBopLienAppService bopLienAppService, ILogger logger)
		{
			_dateRun = dateRun;
			_bopLienAppService = bopLienAppService;
			_letterRequest = letterRequest;
			_repository = repository;
			_logger = logger;
		}

		public void AbortProcessing()
		{
			
		}

		public void DoneProcessing()
		{
			
		}

		public IEnumerable<object> GetRecords()
		{
			return _repository.GetBopLienLetterInfo(BopType.Fault, StateCode.Need10day)
					.Select(x => x.ToAppModel());
		}

		public bool IsFatal(object data, Exception ex)
		{
			return true;
		}

		public int MaxSkippedErrors()
		{
			return 0;
		}

		public void ProcessRecord(object data)
		{			
			var bop = (BopLienLetterModel)data;
			if (bop.AmountDue == 0)
			{
				_logger.LogError($"On Lien: {bop.LienId} Zero amount due is not valid.");
			}
			else
			{
				var bookmark = new LetterAddressBookmark
				{
					Address1 = bop.Address1,
					Address2 = bop.Address2,
					City = bop.City,
					DbaName = "",
					Country = bop.ForeignCountry ?? "",
					FullName = bop.FirstName + " " + bop.LastName,
					InternationalIndicator = bop.ForeignCountry != "" ? 1 : 0,
					State = bop.ForeignStateOrProvince ?? bop.State,
					Zip = bop.ForeignPostalCode ?? bop.Zip
				};

				//TODO letter engine not available yet
				_letterRequest.Print("Form737R", bookmark);
				var bopLien = _repository.GetBopLiens(bop.LienId).ToAppModel();
				_bopLienAppService.ExecuteLienAction(bopLien, ActionCode._10DayPrinted, _dateRun.RunDate);
			}
		}

		public void StartProcessing()
		{
			
		}
	}
}
