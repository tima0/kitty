using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Internals.Mappings;
using Cats.Bop.Claimant.Models;
using Cats.Core;
using Cats.Core.Liens;
using DwsUI.Core.Job;
using DwsUI.Core.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Internals.Batch.Liens
{
	public class LienBOPFault28Print : IListJob
	{
		public string Name => nameof(LienBOPFault28Print);
		private readonly ILetterRequest _letterRequest;
		private readonly IBopLienRepository _repository;
		private readonly IBopLienAppService _bopLienAppService;
		private readonly IDateRun _dateRun;
		private readonly ILogger _logger;

		public LienBOPFault28Print(ILetterRequest letterRequest, IDateRun dateRun, IBopLienRepository repository,
			IBopLienAppService bopLienAppService, ILogger logger)
		{
			_letterRequest = letterRequest;
			_dateRun = dateRun;
			_bopLienAppService = bopLienAppService;
			_repository = repository;
			_logger = logger;
		}

		public void AbortProcessing()
		{
			
		}

		public void DoneProcessing()
		{
			
		}

		public IEnumerable<object> GetRecords()
		{
			return _repository.GetBopLienLetterInfo(BopType.Fault, StateCode.Need28)
					.Select(x => x.ToAppModel());
		}

		public bool IsFatal(object data, Exception ex)
		{
			return true;
		}

		public int MaxSkippedErrors()
		{
			return 0;
		}

		public void ProcessRecord(object data)
		{
			var bop = (BopLienLetterModel)data;
			if (bop.AmountDue == 0)
			{
				_logger.LogError($"On Lien: {bop.LienId} Zero amount due is not valid.");
			}
			else
			{
				var bookmark = new LetterAddressBookmark
				{
					Address1 = bop.Address1,
					Address2 = bop.Address2,
					City = bop.City,
					DbaName = "",
					Country = bop.ForeignCountry ?? "",
					FullName = bop.FirstName + " " + bop.LastName,
					InternationalIndicator = bop.ForeignCountry != "" ? 1 : 0,
					State = bop.ForeignStateOrProvince ?? bop.State,
					Zip = bop.ForeignPostalCode ?? bop.Zip
				};

				//TODO letter engine not available yet
				_letterRequest.Print("Form28B", bookmark);
				var bopLien = _repository.GetBopLiens(bop.LienId).ToAppModel();
				_bopLienAppService.ExecuteLienAction(bopLien, ActionCode._28Printed, _dateRun.RunDate);
			}
		}

		public void StartProcessing()
		{
			
		}
	}
}
