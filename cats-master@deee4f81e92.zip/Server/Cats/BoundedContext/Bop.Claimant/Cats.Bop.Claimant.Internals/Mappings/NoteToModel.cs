using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Models;
using Cats.Bop.Claimant.Data.Models;

namespace Cats.Bop.Claimant.Internals.Mappings
{
	public static class NoteToModel
	{
		public static NotesModel ToAppModel(this NOTE note)
		{
			if (note == null)
			{
				return null;
			}
			else
			{
				return new NotesModel()
				{
					BopNoteId = note.NOTE_ID,
					BopNoteSourceCd = note.NOTE_SOURCE_CD,
					BopProsecutionId = note.PROSECUTION_ID,
					BopGarnishmentId = note.GARNISHMENT_ID,
					PrtyId = note.PRTY_ID,
					ContactName = note.CONTACT_NAME,
					ContactTitle = note.CONTACT_TITLE,
					ContactPhone = note.CONTACT_PHONE,
					ContactExt = note.CONTACT_EXT,
					Descr = note.DESCRIPTION,
					Note = note.NOTE_CONTENT,
					MachineName = note.MACHINE_NAME,
					CreatedBy = note.CREATED_BY,
					CreateTs = note.CREATED_TS,
					ModifiedBy = note.MODIFIED_BY,
					ModifiedTs = note.MODIFIED_TS,
					ImageId = note.IMAGEID,
				};
			}
		}
	}
}
