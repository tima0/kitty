using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Internals.Mappings
{
    public static class BopLienLetterToModel
    {
        public static Cats.Bop.Claimant.Models.BopLienLetterModel ToAppModel(this Data.Models.BopLienLetterModel bopLienLetter)
		{
			if (bopLienLetter == null)
			{
				return null;
			}
			else
			{
				return new Models.BopLienLetterModel
				{
					Address1 = bopLienLetter.Address1,
					Address2 = bopLienLetter.Address2,
					AmountDue = bopLienLetter.AmountDue,
					BopId = bopLienLetter.BopId,
					BopType = bopLienLetter.BopType,
					City = bopLienLetter.City,
					FirstName = bopLienLetter.FirstName,
					ForeignCountry = bopLienLetter.ForeignCountry,
					ForeignPostalCode = bopLienLetter.ForeignPostalCode,
					ForeignStateOrProvince = bopLienLetter.ForeignStateOrProvince,
					LastName = bopLienLetter.LastName,
					LienId = bopLienLetter.LienId,
					PartyId = bopLienLetter.PartyId,
					PID = bopLienLetter.PID,
					SSN = bopLienLetter.SSN,
					State = bopLienLetter.State,
					Zip = bopLienLetter.Zip
				};
			}
		}

    }
}
