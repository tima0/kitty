using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant.Models;
using Cats.Bop.Claimant.Data.Models;

namespace Cats.Bop.Claimant.Internals.Mappings
{
	public static class PhoneToModel
	{
		public static PhoneModel ToAppModel(this V_CLAIMANT_PHONE dbModel)
		{
			if (dbModel == null)
			{
				return null;
			}
			else
			{
				return new PhoneModel()
				{
					PartyId = dbModel.PRTY_ID,
					Phone = dbModel.PHONE,
					PhoneType = dbModel.TYPE_CD,
					BadPhoneFlag = dbModel.BAD_PHONE_FLAG,
					CliId = dbModel.CLI_ID,
					CpId = dbModel.CP_ID
				};
			}
		}
	}
}
