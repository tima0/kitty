using Cats.Core.Liens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Internals.Mappings
{
    public static class BopLienToLienData
    {
        public static Cats.Bop.Claimant.Models.BopLienModel ToAppModel(this Data.Models.BopLienModel lienBop)
		{
			if (lienBop == null)
			{
				return null;
			}
			else
			{
				return new Models.BopLienModel
				{
					ArBalance = lienBop.ArBalance,
					BalanceChangeNeedRestart = lienBop.BalanceChangeNeedRestart,
					CanceledDebt = lienBop.CanceledDebt,
					ChargeOffAmount = lienBop.ChargeOffAmount,
					CurrentRestartBalance = lienBop.CurrentRestartBalance,
					DateFiled = lienBop.DateFiled,
					EstablishedDate = lienBop.EstablishedDate,
					FiledLienAmount = lienBop.FiledLienAmount,
					FirstWait10Day = lienBop.FirstWait10Day,
					FirstWaitToFile = lienBop.FirstWaitToFile,
					HasAdminHold = lienBop.HasAdminHold,
					HasAppealHold = lienBop.HasAppealHold,
					HasBankruptcy = lienBop.HasBankruptcy,
					HasInstallmentAgreement = lienBop.HasInstallmentAgreement,
					LastActionCode = lienBop.LastActionCode,
					LastActionDate = lienBop.LastActionDate,
					LastCertifiedPaymentDate = lienBop.LastCertifiedPaymentDate,
					LastCorrespondenceDate = lienBop.LastCorrespondenceDate,
					LastNonCertifiedPaymentDate = lienBop.LastNonCertifiedPaymentDate,
					LienId = lienBop.LienId,
					LienType = lienBop.LienType,					
					PenaltyBalanceAmount = lienBop.PenaltyBalanceAmount,
					PenaltyDueAmount = lienBop.PenaltyDueAmount,
					PenaltyFiledAmount = lienBop.PenaltyFiledAmount,
					PenaltyForcedAmount = lienBop.PenaltyForcedAmount,
					PreviousState = lienBop.PreviousState,
					RestartBalanceWhen28Sent = lienBop.RestartBalanceWhen28Sent
				};
			}
		}

		public static Cats.Bop.Claimant.Data.Models.BopLienModel ToDomainModel(this Cats.Bop.Claimant.Models.BopLienModel lienBop)
		{
			if (lienBop == null)
			{
				return null;
			}
			else
			{
				var result = new Data.Models.BopLienModel
				{
					ArBalance = lienBop.ArBalance,
					BalanceChangeNeedRestart = lienBop.BalanceChangeNeedRestart,
					CanceledDebt = lienBop.CanceledDebt,
					ChargeOffAmount = lienBop.ChargeOffAmount,
					CurrentRestartBalance = lienBop.CurrentRestartBalance,
					DateFiled = lienBop.DateFiled,
					EstablishedDate = lienBop.EstablishedDate,
					FiledLienAmount = lienBop.FiledLienAmount,
					FirstWait10Day = lienBop.FirstWait10Day,
					FirstWaitToFile = lienBop.FirstWaitToFile,
					HasAdminHold = lienBop.HasAdminHold,
					HasAppealHold = lienBop.HasAppealHold,
					HasBankruptcy = lienBop.HasBankruptcy,
					HasInstallmentAgreement = lienBop.HasInstallmentAgreement,
					LastActionCode = lienBop.LastActionCode,
					LastActionDate = lienBop.LastActionDate,
					LastCertifiedPaymentDate = lienBop.LastCertifiedPaymentDate,
					LastCorrespondenceDate = lienBop.LastCorrespondenceDate,
					LastNonCertifiedPaymentDate = lienBop.LastNonCertifiedPaymentDate,
					LienId = lienBop.LienId,
					LienType = lienBop.LienType,
					PenaltyBalanceAmount = lienBop.PenaltyBalanceAmount,
					PenaltyDueAmount = lienBop.PenaltyDueAmount,
					PenaltyFiledAmount = lienBop.PenaltyFiledAmount,
					PenaltyForcedAmount = lienBop.PenaltyForcedAmount,
					PreviousState = lienBop.PreviousState,
					RestartBalanceWhen28Sent = lienBop.RestartBalanceWhen28Sent
				};
				return result;
			}
		}

		public static LienData ToLienData(this Data.Models.BopLienModel bopLienModel)
		{
			if (bopLienModel == null)
			{
				return null;
			}
			else
			{
				var lastActionCode = bopLienModel.LastActionCode;
				switch (bopLienModel.LastActionCode)
				{
					case "10DAYHOLD":
					case "10DAYPRINTED":
					case "28PRINTED":
					case "28PRINTHOLD":
						lastActionCode = "_" + bopLienModel.LastActionCode;
						break;
				}

				var previousStateCode = bopLienModel.PreviousState;
				switch (bopLienModel.PreviousState)
				{
					case "10DAYHOLD":
					case "10DAYPRINTED":
					case "28PRINTED":
					case "28PRINTHOLD":
						previousStateCode = "_" + bopLienModel.PreviousState;
						break;
				}

				return new LienData()
				{
					ArBalance = bopLienModel.ArBalance,
					ArEstablishedDate = bopLienModel.EstablishedDate,
					BalanceChangedNeedToRestart = bopLienModel.BalanceChangeNeedRestart,
					CanceledDebt = bopLienModel.CanceledDebt,
					ChargeOffAmt = bopLienModel.ChargeOffAmount,
					ConPenBalAmount = bopLienModel.PenaltyBalanceAmount,
					ConPenDueAmount = bopLienModel.PenaltyDueAmount,
					ConPenDueFiledAmt = bopLienModel.PenaltyFiledAmount,
					ConPenDueForcedAmt = bopLienModel.PenaltyForcedAmount,
					CurrentRestartBal = bopLienModel.CurrentRestartBalance,
					FiledDate = bopLienModel.DateFiled,
					FiledLienAmount = bopLienModel.FiledLienAmount,
					FirstWait10DayDate = bopLienModel.FirstWait10Day,
					FirstWaitToFileDate = bopLienModel.FirstWaitToFile,
					HasAdminHold = bopLienModel.HasAdminHold,
					HasAppealHold = bopLienModel.HasAppealHold,
					HasBankruptcy = bopLienModel.HasBankruptcy,
					HasInstallmentAgreement = bopLienModel.HasInstallmentAgreement,
					LastLienAction = lastActionCode.ToStateCode(),
					PreviousStateCode = previousStateCode.ToStateCode(),
					LastLienActionDate = bopLienModel.LastActionDate,
					LienID = bopLienModel.LienId,
					RestartBalanceWhen28Sent = bopLienModel.RestartBalanceWhen28Sent,
					LastCertPmtDate = bopLienModel.LastCertifiedPaymentDate,
					LastCorrespondenceDate = bopLienModel.LastCorrespondenceDate,
					LastNonCertPmtDate = bopLienModel.LastNonCertifiedPaymentDate,
				};
			}
		}
    }
}
