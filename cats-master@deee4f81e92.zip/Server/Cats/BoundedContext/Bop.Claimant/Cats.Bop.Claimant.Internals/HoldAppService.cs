using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cats.Bop.Claimant;
using DwsUI.Core.Collections;
using DwsUI.Core.ListParams;

namespace Cats.Bop.Claimant.Internals
{
	class HoldAppService : IHoldAppService
	{
		readonly IHoldRepository _holdRepository;
		public HoldAppService(IHoldRepository holdRepository)
		{
			_holdRepository = holdRepository;
		}
		public ListEnvelope<HoldModel> GetAllHoldsForPartyId(long partyId, OrderListParam order)
		{
			throw new NotImplementedException();
		}

		public HoldModel GetHoldByPartyId(long partyId, string holdType)
		{
			throw new NotImplementedException();
		}
	}
}
