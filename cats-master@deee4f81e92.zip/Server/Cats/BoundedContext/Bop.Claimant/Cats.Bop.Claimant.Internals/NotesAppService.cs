using AutoMapper;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Data.Models;
using Cats.Bop.Claimant;
using Cats.Bop.Claimant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;
using Cats.Bop.Claimant.Internals.Mappings;

namespace Cats.Bop.Claimant.Internals
{
	public interface INotesAppMappers
	{
		IMapper NotesMapper { get; }
	}

	public class NotesAppMappers : MappersBase, INotesAppMappers
	{
		public IMapper NotesMapper { get; private set; }

		protected override void CreateMappers()
		{
			var notesMapConfig = new MapperConfiguration(
				c => c.CreateMap<Cats.Bop.Claimant.Data.Models.NOTE, Cats.Bop.Claimant.Models.NotesModel>());
			this.NotesMapper = notesMapConfig.CreateMapper();
		}
	}


	public class NotesAppService: INotesAppService
	{
		readonly INotesRepository _notesRepository;

		public NotesAppService(INotesRepository notesRepository)
		{
			_notesRepository = notesRepository;
		}

		public NotesModel GetNoteByNoteID(long BopNoteID)
		{
			var notesMapConfig = new MapperConfiguration(
					c => c.CreateMap<Cats.Bop.Claimant.Data.Models.NotesDataModel, Cats.Bop.Claimant.Models.NotesModel>());
			IMapper mapper = notesMapConfig.CreateMapper();

			Cats.Bop.Claimant.Data.Models.NotesDataModel x = _notesRepository.GetNoteByNoteID(BopNoteID);
			return (x == null) ? null : mapper.Map<Cats.Bop.Claimant.Models.NotesModel>(x);
		}

		public ListEnvelope<NotesModel> GetNotesByPartyID(long PartyID, PageListParam page, OrderListParam order)
		{
						
			return _notesRepository.GetNotesByPartyID(PartyID, page, order)
				.ToEnvelope<NotesModel>(x => (x == null) ? null : NoteToModel.ToAppModel(x));
		}
	}
}
