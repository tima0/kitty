using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Cats.Bop.Claimant.Models;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Internals;
using DwsUI.Core.Collections;
using DwsUI.Core.ListParams;
using Cats.Bop.Claimant.Internals.Mappings;

namespace Cats.Bop.Claimant.Internals
{

	public interface IPhoneAppMappers
	{
		IMapper PhoneMapper { get; }
	}
		
	public class PhoneAppMappers : MappersBase, IPhoneAppMappers
	{
		public IMapper PhoneMapper { get; private set; }

		protected override void CreateMappers()
		{
			var phoneMapConfig = new MapperConfiguration(
				c => c.CreateMap<Cats.Bop.Claimant.Data.Models.V_CLAIMANT_PHONE, Cats.Bop.Claimant.Models.PhoneModel>());
			this.PhoneMapper = phoneMapConfig.CreateMapper();
		}
	}


	public class PhoneAppService : MappersBase, IPhoneAppService
	{
		
		private IPhoneRepository _phoneRepository { get; }
		private IMapper _phoneMapper { get; set; }
		

		protected override void CreateMappers()
		{
			var phoneMapConfig = new MapperConfiguration(
				c => c.CreateMap<Cats.Bop.Claimant.Data.Models.V_CLAIMANT_PHONE, Cats.Bop.Claimant.Models.PhoneModel>());
			this._phoneMapper = phoneMapConfig.CreateMapper();
		}

		public PhoneAppService(IPhoneRepository phoneRepository, IPhoneAppMappers phoneAppMappers)
		{
			_phoneRepository = phoneRepository;
			
			_phoneMapper = phoneAppMappers.PhoneMapper;
		}

		public PhoneModel GetPhone(long partyId, string phonetype)
		{	
			return _phoneRepository.GetPhone(partyId, phonetype).ToAppModel();
		}

		public ListEnvelope<PhoneModel> GetPhones(long partyId, PageListParam page, OrderListParam order)
		{
				return _phoneRepository.GetPhones(partyId,page,order)
					.ToEnvelope<PhoneModel>(p => p.ToAppModel());
			
		}

	}
}

