using Cats.Bop.Claimant.Business.Liens;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Internals.Mappings;
using Cats.Bop.Claimant.Models;
using Cats.Core.Liens;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cats.Bop.Claimant.Internals
{
	public class BopLienAppService : IBopLienAppService
	{
		private readonly IBopLienRepository _repository;
		private readonly IBopLienStateEngineServiceInterface _stateEngineService;

		public BopLienAppService(IBopLienRepository repository, IBopLienStateEngineServiceInterface stateEngineService)
		{
			_repository = repository;
			_stateEngineService = stateEngineService;
		}

		public IEnumerable<BopLienModel> GetBopLiensFaults()
		{
			_repository.PickupNewBopFaultAR();
			_repository.PickupARFromPaidBopFault();

			var result = _repository.GetBopLiens(BopType.Fault);
			return result.Select(x => x.ToAppModel());			
		}

		public IEnumerable<BopLienModel> GetBopLiensFraud()
		{
			_repository.PickupNewBopFraudAR();
			_repository.PickupARFromPaidBopFraud();
			var result = _repository.GetBopLiens(BopType.Fraud);
			return result.Select(x => x.ToAppModel());
		}

		public void ProcessLien(Cats.Bop.Claimant.Models.BopLienModel bopLien, DateTime dateRun)
		{
			// convert to LienModel
			// call IBopLienStateEngine.ExecuteFlow()

			// Claimant.Models.BopLienModel -> Data.Models.BopLienModel -> LienData
			// maybe this can go straight to LienData?
			var data = bopLien.ToDomainModel(); 

			LienData lienData = data.ToLienData();
			StateCode beforeExecState = lienData.LastLienAction;
			var bopLienType = bopLien.LienType == "R" ? BopLienType.Fault : BopLienType.Fraud;
			_stateEngineService.ExecuteFlow(lienData, bopLienType, dateRun);

			if (beforeExecState != lienData.LastLienAction)
			{
				var lastAction = lienData.LastLienAction.ToStateCodeString();				
				_repository.UpdateLastAction(lienData.LienID, lastAction, lienData.LastActionReason, 6);
			}			
		}

		public void ExecuteLienAction(BopLienModel bopLien, ActionCode actionCode, DateTime dateRun)
		{
			LienData lienData = bopLien.ToDomainModel().ToLienData();
			StateCode beforeExecState = lienData.LastLienAction;

			var bopLienType = bopLien.LienType == "R" ? BopLienType.Fault : BopLienType.Fraud;
			_stateEngineService.ExecuteFlow(lienData, bopLienType, dateRun);
			if (beforeExecState != lienData.LastLienAction)
			{
				var lastAction = lienData.LastLienAction.ToStateCodeString();
				_repository.UpdateLastAction(lienData.LienID, lastAction, lienData.LastActionReason, 6);
			}
		}
	}
}
