
using Cats.Bop.Claimant.Data.Internals;
using Cats.Bop.Claimant.Data.Models;
using Cats.Bop.Claimant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Internals
{
	/// <summary> A sample extensions class for the VClaimant app model. </summary>
	public static class V_CLAIMANTExtensions
	{
		/// <summary> Converts an entity to an app model.  Pair this with .LoadFromEntity(). </summary>
		//public static Models.ClaimantModel ToAppModel(this V_CLAIMANT entity)
		//{
		//	return new Models.ClaimantModel().LoadFromEntity(entity);
		//}

		/// <summary> Copies property values from an entity to an existing app model. </summary>
		public static ClaimantModel LoadFromEntity(this ClaimantModel appModel, V_CLAIMANT entity)
		{
			appModel.BadEmailFlag = entity.BAD_EMAIL_FLAG;
			appModel.Email = entity.EMAIL;
			appModel.PartyId = entity.PRTY_ID;
			appModel.FirstName = entity.FIRST_NAME;
			appModel.SSN = entity.SSN;
			appModel.CliId = entity.CLI_ID;
			appModel.DriversLicenseNumber = entity.DRIVERS_LICENSE_NUMBER;
			appModel.MiddleName = entity.MIDDLE_NAME;
			appModel.LastName = entity.LAST_NAME;
			appModel.WriteOffIndicator = entity.WRITE_OFF_IND != 0;
			appModel.MothersMaidenName = entity.MOTHERS_MAIDEN_NAME;
			appModel.BirthDate = entity.BIRTH_DT;
			appModel.PID = entity.PID;
			return appModel;
		}

		/// <summary> Converts an app model to an entity.  Pair this with .LoadFromAppModel(). </summary>
		public static ClaimantModel ToEntity(this ClaimantAppModel appModel)
		{
			return new ClaimantModel().LoadFromAppModel(appModel);
		}

		/// <summary> Copies property values from an app model to an entity. </summary>
		public static ClaimantModel LoadFromAppModel(this ClaimantModel entity, ClaimantAppModel appModel)
		{
			entity.BadEmailFlag = appModel.BadEmailFlag;
			entity.Email = appModel.Email;
			entity.PartyId = appModel.PartyId;
			entity.FirstName = appModel.FirstName;
			entity.SSN = appModel.SSN;
			entity.CliId = appModel.CliId;
			entity.DriversLicenseNumber = appModel.DriversLicenseNumber;
			entity.MiddleName = appModel.MiddleName;
			entity.LastName = appModel.LastName;
			entity.WriteOffIndicator = appModel.WriteOffInd != 0;
			entity.MothersMaidenName = appModel.MothersMaidenName;
			entity.BirthDate = appModel.BirthDt;
			entity.PID = appModel.PID;
			return entity;
		}
	}
}
