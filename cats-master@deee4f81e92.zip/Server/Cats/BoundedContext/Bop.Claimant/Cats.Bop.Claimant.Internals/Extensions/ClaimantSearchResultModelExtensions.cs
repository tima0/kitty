using Cats.Bop.Claimant.Data.StoredProcedure;
using Cats.Bop.Claimant.Models;
using System.Collections.Generic;
using System.Linq;

namespace Cats.Bop.Claimant.Internals.Extensions
{
	public static class ClaimantSearchResultModelExtensions
	{
		public static ClaimantSearchResultModel ToDomainModel(this ClaimantSearchResultData value)
		{
			ClaimantSearchResultModel domainModel = null;

			if (value != null)
			{
				domainModel = new ClaimantSearchResultModel()
				{
					Address1 = value.ADDR1,
					Address2 = value.ADDR2,
					City = value.CITY,
					FirstName = value.FIRST_NAME,
					LastName = value.LAST_NAME,
					OpBal = value.OPBAL,
					OpCount= value.OPS,
					PartyId = value.PARTY_ID,
					SSN = value.SSN,
					State = value.STATE,
					Zip = value.ZIP
				};
			}

			return domainModel;
		}

		public static IEnumerable<ClaimantSearchResultModel> ToDomainModels(this IEnumerable<ClaimantSearchResultData> value)
		{
			return value.AsEnumerable().Select(n => n.ToDomainModel());
		}
	}
}
