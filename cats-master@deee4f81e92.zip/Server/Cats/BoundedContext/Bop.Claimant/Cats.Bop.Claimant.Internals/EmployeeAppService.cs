using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Logging;

namespace Cats.Bop.Claimant.Internals
{
	public class EmployeeAppService : IEmployeeAppService
	{
		private Cats.Bop.Claimant.Data.Interfaces.IClaimantRepository _repo { get; }
		private ILogger _logger { get; }

		public EmployeeAppService(
			Cats.Bop.Claimant.Data.Interfaces.IClaimantRepository repo,
			ILogger logger)
		{
			_repo = repo;
			_logger = logger;
		}

		public Models.EmployeeModel GetEmployee(long id)
		{
			var employeeFromDatabase = _repo.GetEmployee(id);
			if (employeeFromDatabase == null)
				_logger.LogInformation($"Employee record not found with ID {id}.");
			else
				_logger.LogInformation($"Found employee with ID {id}.");

			// TODO:  Investigate replacing this conversion with AutoMapper.

			return employeeFromDatabase.ToAppModel();
		}
	}

	public static partial class AppModelExtensions
	{
		public static Cats.Bop.Claimant.Models.EmployeeModel ToAppModel(this Cats.Bop.Claimant.Data.Models.EMPLOYEE dbEmployee)
		{
			return new Cats.Bop.Claimant.Models.EmployeeModel()
			{
				Pronoun = dbEmployee.PRONOUN,
				Pronoun_Possessive = dbEmployee.PRONOUN_POSS,
				EmployeeId = dbEmployee.EMPLOYEE_ID,
				FirstName = dbEmployee.FIRSTNAME,
				LastName = dbEmployee.LASTNAME,
				Address1 = dbEmployee.ADDRESS1,
				Address2 = dbEmployee.ADDRESS2,
				City = dbEmployee.CITY,
				State = dbEmployee.STATE,
				Zip = dbEmployee.ZIP,
				Phone = dbEmployee.PHONE,
				Fax = dbEmployee.FAX,
				Email = dbEmployee.EMAILADDR,
				LoginID = dbEmployee.USERID
			};
		}
	}
}
