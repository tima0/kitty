using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Models;

namespace Cats.Bop.Claimant.Internals
{
	public interface IClaimantAppMappers
	{
		IMapper ClaimantMapper { get; }
	}

	public abstract class MappersBase
	{
		public MappersBase()
		{
			CreateMappers();
		}

		protected abstract void CreateMappers();
	}

	public class ClaimantAppMappers : MappersBase, IClaimantAppMappers
	{
		public IMapper ClaimantMapper { get; private set; }

		protected override void CreateMappers()
		{
			var claimantMapConfig = new MapperConfiguration(
				c => c.CreateMap<Cats.Bop.Claimant.Data.Models.ClaimantModel, ClaimantAppModel>());
			this.ClaimantMapper = claimantMapConfig.CreateMapper();
		}
	}

	public class ClaimantAppService : IClaimantAppService
	{
		private IClaimantRepository _claimantRepository { get; }
		private IMapper _claimantMapper { get; set; }

		public ClaimantAppService(IClaimantRepository claimantRepository, IClaimantAppMappers claimantAppMappers)
		{
			_claimantRepository = claimantRepository;
			// We get the claimant mapper from Unity, but we could just instantiate it directly.
			_claimantMapper = claimantAppMappers.ClaimantMapper;
		}

		// TODO: Remove automapper and switch back to a converter when the model finally stabilizes.
		public ClaimantAppModel GetClaimantByPartyId(long partyId)
		{
			Cats.Bop.Claimant.Data.Models.ClaimantModel x = _claimantRepository.GetClaimantByPartyId(partyId);

			// Works great.
			return (x == null)
				? null
				: _claimantMapper.Map<ClaimantAppModel>(x);

			// Works, of course.
			//return (x == null)
			//	? null
			//	: new ClaimantModel()
			//	{
			//		PartyId = x.PartyId,
			//		PID = x.PID,
			//		SSN = x.SSN,
			//		CliId = x.CliId,
			//		LastName = x.LastName,
			//		FirstName = x.FirstName,
			//		MiddleName = x.MiddleName,
			//		Email = x.MiddleName,
			//		BadEmailFlag = x.BadEmailFlag,
			//		BirthDate = x.BirthDate,
			//		DriversLicenseNumber = x.DriversLicenseNumber,
			//		MothersMaidenName = x.MothersMaidenName,
			//		WriteOffIndicator = x.WriteOffIndicator
			//	};
		}

		// TODO: This will be replaced by ClaimantSearch.
		public IEnumerable<ClaimantAppModel> GetClaimants(int count)
		{
			var lst = _claimantRepository.GetClaimants(count);
			if (lst == null)
				throw new Exception("ClaimantRepository.GetClaimants() returned null.");
			return lst.Select(
				x => _claimantMapper.Map<ClaimantAppModel>(x));

				//x => new ClaimantModel()
				//{
				//	PartyId = x.PartyId,
				//	PID = x.PID,
				//	SSN = x.SSN,
				//	CliId = x.CliId,
				//	LastName = x.LastName,
				//	FirstName = x.FirstName,
				//	MiddleName = x.MiddleName,
				//	Email = x.MiddleName,
				//	BadEmailFlag = x.BadEmailFlag,
				//	BirthDate = x.BirthDate,
				//	DriversLicenseNumber = x.DriversLicenseNumber,
				//	MothersMaidenName = x.MothersMaidenName,
				//	WriteOffIndicator = x.WriteOffIndicator
				//});
		}
	}
}
