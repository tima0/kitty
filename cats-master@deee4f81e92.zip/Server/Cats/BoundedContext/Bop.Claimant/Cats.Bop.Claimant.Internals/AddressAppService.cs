using AutoMapper;
using Cats.Bop.Claimant.Data.Interfaces;
using Cats.Bop.Claimant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cats.Bop.Claimant.Internals
{
	public class AddressAppService : IAddressAppService
	{
		readonly IAddressRepository _addressRepository;

		public AddressAppService(IAddressRepository addressRepository)
		{
			_addressRepository = addressRepository;
		}

		public AddressModel GetAddressByPartyId(long partyId)
		{
			var addressMapConfig = new MapperConfiguration(
					c => c.CreateMap<Cats.Bop.Claimant.Data.Models.AddressModel, Cats.Bop.Claimant.Models.AddressModel>());
			IMapper mapper = addressMapConfig.CreateMapper();

			Cats.Bop.Claimant.Data.Models.AddressModel x = _addressRepository.GetAddressByPartyId(partyId);
			return (x == null) ? null : mapper.Map<Cats.Bop.Claimant.Models.AddressModel>(x);
		}

		public void UpdateAddress(Cats.Bop.Claimant.Models.AddressModel addressModel)
		{
			var addressMapConfig = new MapperConfiguration(
				c => c.CreateMap<Cats.Bop.Claimant.Models.AddressModel, Cats.Bop.Claimant.Data.Models.AddressModel>());
			IMapper mapper = addressMapConfig.CreateMapper();

			var updateObject = mapper.Map<Cats.Bop.Claimant.Data.Models.AddressModel>(addressModel);
			_addressRepository.UpdateAddress(updateObject);
		}
	}
}
