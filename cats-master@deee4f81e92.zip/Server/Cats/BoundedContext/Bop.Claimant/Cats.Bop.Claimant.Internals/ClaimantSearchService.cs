using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DwsUI.Core.Logging;
using System.Collections;
using Cats.Bop.Claimant.Models;
using Cats.Bop.Claimant.Internals.Extensions;
using DwsUI.Core.ListParams;
using DwsUI.Core.Collections;

namespace Cats.Bop.Claimant.Internals
{
	public class ClaimantSearchService : IClaimantSearchService
	{
		private Cats.Bop.Claimant.Data.Interfaces.IClaimantRepository _repo { get; }
		private ILogger _logger { get; }


		public ClaimantSearchService(Cats.Bop.Claimant.Data.Interfaces.IClaimantRepository repo, ILogger logger)
		{
			_repo = repo;
			_logger = logger;

		}
		private int SkipCount(int page, int pageSize)
		{
			int _skipCount = 0;
			if (page > 1)
				_skipCount = page * pageSize;
			return _skipCount;

		}

		public SearchResult GetSearchResults(string search, int page, int recordCount, string orderBy)
		{
			try
			{
				int totalRecords = _repo.GetSearchResultCount(search);

				//TODO: Do we want to do this?
				//if (totalRecords <= 10000)
				//{
					var domainModels = _repo
						.GetSearchResults(search, page, recordCount, orderBy)
						.ToDomainModels()
						.ToList();

					var searchResult = new SearchResult
					{
						Contents = domainModels,
						PageNumber = page,
						PageSize = recordCount,
						TotalRecords = totalRecords
					};

					return searchResult;
				//}
				//else
				//{
				//	throw new Exception("This search returns more than 100 rows.  Please refine your search.");
				//}
			}
			catch (Exception )
			{
				//TODO: Log error here?
				throw;
			}
		}


		public ListEnvelope<ClaimantSearchResult> SearchClaimant(string searchTerm, PageListParam page, OrderListParam order)
		{
			var searchResults = _repo.FindClaimants(searchTerm, page, order);

			_logger.LogTrace($"Bop Search Term: {searchTerm} found { searchResults.TotalCount } results. Offset: {searchResults.RowOffset} pageSize: {searchResults.PageSize}");
			_logger.LogTrace($"Bop Search Term: {searchTerm} found { searchResults.TotalCount } results");


			return searchResults.ToEnvelope(
				w => new ClaimantSearchResult
				{
					// TODO:  Investigate replacing this conversion with AutoMapper.
					PartyId = w.PartyId,
					PId = w.PId,
					FirstName = w.FirstName,
					LastName = w.LastName,
					SSN = w.SSN,
					Address1 = w.Address1,
					City = w.City,
					State = w.State,
					Zip = w.Zip,
					OpCount = w.OpCount,
					OpBal = w.OpBal,
					SearchVal = w.SearchVal
				});


		}

	}

	public static partial class AppModelExtensions
	{
		public static Models.ClaimantSearchResult ToAppModel(this Cats.Bop.Claimant.Data.Models.ClaimantSearchResults csr)
		{
			return new Models.ClaimantSearchResult()
			{
				PartyId = csr.PartyId,
				PId = csr.PId,
				FirstName = csr.FirstName,
				LastName = csr.LastName,
				Address1 = csr.Address1,
				City = csr.City,
				SSN = csr.SSN,
				State = csr.State,
				Zip = csr.Zip,


			};
		}
	}

}
